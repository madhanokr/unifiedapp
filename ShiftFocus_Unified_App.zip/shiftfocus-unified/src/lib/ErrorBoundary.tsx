import React from 'react';

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div
          className="min-h-screen flex items-center justify-center p-8"
          style={{ backgroundColor: 'var(--bg-level-1)' }}
        >
          <div
            className="max-w-md w-full p-8 text-center"
            style={{
              backgroundColor: 'var(--white)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-card)',
              border: '1px solid var(--neutral-200)',
            }}
          >
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: 'var(--danger-light)' }}
            >
              <span style={{ color: 'var(--danger)', fontSize: '20px' }}>!</span>
            </div>
            <h2 className="text-h2 mb-2" style={{ color: 'var(--neutral-800)' }}>
              Something went wrong
            </h2>
            <p className="text-body mb-6" style={{ color: 'var(--neutral-600)' }}>
              {this.state.error?.message || 'An unexpected error occurred.'}
            </p>
            <button
              onClick={this.handleReset}
              className="px-4 py-2"
              style={{
                backgroundColor: 'var(--brand-primary)',
                color: 'var(--white)',
                borderRadius: 'var(--radius-button)',
                transition: 'all var(--duration-standard) var(--ease-apple)',
              }}
            >
              Try Again
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { ErrorBoundary } from './lib/ErrorBoundary';
import { AppShell } from './components/shell/AppShell';

// Page imports — lazy loaded
import { lazy, Suspense } from 'react';

const OKRsPage = lazy(() => import('./pages/okrs'));
const KPIsPage = lazy(() => import('./pages/okrs/kpis'));
const EnforcementPage = lazy(() => import('./pages/enforcement'));
const AdminPage = lazy(() => import('./pages/admin'));
const TasksPage = lazy(() => import('./pages/tasks'));
const WeeklyPage = lazy(() => import('./pages/weekly'));
const InitiativeHubPage = lazy(() => import('./pages/initiative-hub'));
const InitiativeDetailPage = lazy(() => import('./pages/initiative-detail'));
const ManagerPage = lazy(() => import('./pages/manager'));
const PeoplePage = lazy(() => import('./pages/people'));
const ExecutionPage = lazy(() => import('./pages/execution'));
const IntelligencePage = lazy(() => import('./pages/intelligence'));
const StrategyPage = lazy(() => import('./pages/strategy'));
const RiskPage = lazy(() => import('./pages/risk'));
const NotificationsPage = lazy(() => import('./pages/notifications'));

// Loading fallback
function PageLoader() {
  return (
    <div className="flex items-center justify-center" style={{ minHeight: '400px' }}>
      <div className="flex flex-col items-center gap-3">
        <div
          className="w-8 h-8 rounded-full animate-spin"
          style={{
            border: '3px solid var(--neutral-200)',
            borderTopColor: 'var(--brand-primary)',
          }}
        />
        <span style={{ fontSize: '14px', color: 'var(--neutral-400)' }}>Loading...</span>
      </div>
    </div>
  );
}

// Placeholder for pages not yet built
function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-center" style={{ minHeight: '400px' }}>
      <div className="text-center">
        <h2 style={{ fontSize: '24px', fontWeight: 600, color: 'var(--neutral-800)', marginBottom: '8px' }}>
          {title}
        </h2>
        <p style={{ fontSize: '14px', color: 'var(--neutral-400)' }}>
          This module is coming soon.
        </p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Toaster position="top-right" richColors closeButton />
        <Routes>
          <Route element={<AppShell />}>
            {/* Redirect root to execution dashboard */}
            <Route path="/" element={<Navigate to="/execution" replace />} />

            {/* EXECUTION INTELLIGENCE */}
            <Route path="/execution" element={<Suspense fallback={<PageLoader />}><ExecutionPage /></Suspense>} />
            <Route path="/org-health" element={<ComingSoon title="Org Health Radar" />} />
            <Route path="/team-comparison" element={<ComingSoon title="Team Comparison OS" />} />
            <Route path="/weekly" element={<Suspense fallback={<PageLoader />}><WeeklyPage /></Suspense>} />
            <Route path="/risk" element={<Suspense fallback={<PageLoader />}><RiskPage /></Suspense>} />
            <Route path="/intelligence" element={<Suspense fallback={<PageLoader />}><IntelligencePage /></Suspense>} />

            {/* OKR SYSTEM */}
            <Route path="/okrs" element={<Suspense fallback={<PageLoader />}><OKRsPage /></Suspense>} />
            <Route path="/key-results" element={<ComingSoon title="Key Results Center" />} />
            <Route path="/strategy" element={<Suspense fallback={<PageLoader />}><StrategyPage /></Suspense>} />
            <Route path="/kpis" element={<Suspense fallback={<PageLoader />}><KPIsPage /></Suspense>} />
            <Route path="/check-ins" element={<ComingSoon title="Check-ins" />} />

            {/* INITIATIVES & PROJECTS */}
            <Route path="/initiative-hub" element={<Suspense fallback={<PageLoader />}><InitiativeHubPage /></Suspense>} />
            <Route path="/initiative-detail" element={<Suspense fallback={<PageLoader />}><InitiativeDetailPage /></Suspense>} />

            {/* TASK OS */}
            <Route path="/tasks" element={<Suspense fallback={<PageLoader />}><TasksPage /></Suspense>} />
            <Route path="/my-tasks" element={<ComingSoon title="My Tasks" />} />
            <Route path="/team-tasks" element={<ComingSoon title="Team Tasks" />} />

            {/* PEOPLE INTELLIGENCE */}
            <Route path="/manager" element={<Suspense fallback={<PageLoader />}><ManagerPage /></Suspense>} />
            <Route path="/people" element={<Suspense fallback={<PageLoader />}><PeoplePage /></Suspense>} />
            <Route path="/teams" element={<ComingSoon title="Teams Directory" />} />
            <Route path="/capacity" element={<ComingSoon title="Team Capacity" />} />
            <Route path="/one-on-one" element={<ComingSoon title="1:1 Prep Intelligence" />} />

            {/* ENFORCEMENT */}
            <Route path="/enforcement/*" element={<Suspense fallback={<PageLoader />}><EnforcementPage /></Suspense>} />

            {/* ADMIN & SETTINGS */}
            <Route path="/admin/*" element={<Suspense fallback={<PageLoader />}><AdminPage /></Suspense>} />
            <Route path="/notifications" element={<Suspense fallback={<PageLoader />}><NotificationsPage /></Suspense>} />

            {/* 404 */}
            <Route path="*" element={<ComingSoon title="Page Not Found" />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

import React from 'react';
import { motion } from 'motion/react';
import { AlertCircle, RefreshCw, Inbox } from 'lucide-react';
import {
  Skeleton as DSSkeleton,
  EmptyState as DSEmptyState,
  Button,
} from './design-system';

/* ── Skeleton Primitives ─────────────────────────────────── */

export const SkeletonPulse = ({ className = '', style }: { className?: string; style?: React.CSSProperties }) => (
  <DSSkeleton variant="text" className={className} style={style} />
);

/* ── List View Skeleton ──────────────────────────────────── */

export const ListSkeleton = ({ rows = 8 }: { rows?: number }) => (
  <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden">
    {/* Header */}
    <div className="h-[40px] bg-[var(--neutral-50)] border-b border-[var(--neutral-200)] px-4 flex items-center gap-4">
      <SkeletonPulse className="w-5 h-5 rounded" />
      <SkeletonPulse className="w-16 h-3" />
      <SkeletonPulse className="w-24 h-3 flex-1 max-w-[200px]" />
      <SkeletonPulse className="w-20 h-3" />
      <SkeletonPulse className="w-16 h-3" />
      <SkeletonPulse className="w-16 h-3" />
      <SkeletonPulse className="w-12 h-3" />
    </div>
    {/* Rows */}
    {Array.from({ length: rows }).map((_, i) => (
      <motion.div
        key={i}
        className="h-[48px] border-b border-[var(--neutral-200)] px-4 flex items-center gap-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: i * 0.04 }}
      >
        <SkeletonPulse className="w-5 h-5 rounded" />
        <SkeletonPulse className="w-16 h-[24px] rounded-[var(--badge-radius)]" />
        <div className="flex-1 space-y-1.5">
          <SkeletonPulse className="h-3.5 w-[60%]" />
          <SkeletonPulse className="h-2.5 w-[30%]" />
        </div>
        <SkeletonPulse className="w-8 h-8 rounded-full" />
        <SkeletonPulse className="w-20 h-[24px] rounded-[var(--badge-radius)]" />
        <SkeletonPulse className="w-14 h-3" />
        <SkeletonPulse className="w-10 h-3" />
        <SkeletonPulse className="w-8 h-8 rounded-full" />
      </motion.div>
    ))}
  </div>
);

/* ── Kanban Skeleton ─────────────────────────────────────── */

export const KanbanSkeleton = ({ columns = 5 }: { columns?: number }) => (
  <div className="flex gap-5 overflow-x-auto pb-6">
    {Array.from({ length: columns }).map((_, col) => (
      <div key={col} className="flex-shrink-0 w-[304px]">
        {/* Column Header */}
        <div className="mb-3 px-1 flex items-center gap-2.5">
          <SkeletonPulse className="w-2.5 h-2.5 rounded-full" />
          <SkeletonPulse className="w-20 h-3.5" />
          <SkeletonPulse className="w-6 h-5 rounded-full" />
        </div>
        {/* Cards */}
        <div className="space-y-2.5">
          {Array.from({ length: Math.max(1, 3 - col) }).map((_, card) => (
            <motion.div
              key={card}
              className="p-4 bg-[var(--bg-level-0)] rounded-[var(--card-radius)] border border-[var(--neutral-200)] shadow-[var(--shadow-card)]"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: col * 0.08 + card * 0.04 }}
            >
              <div className="flex items-center justify-between mb-3">
                <SkeletonPulse className="w-16 h-[24px] rounded-[var(--badge-radius)]" />
                <SkeletonPulse className="w-7 h-7 rounded-full" />
              </div>
              <SkeletonPulse className="h-4 w-[80%] mb-1.5" />
              <SkeletonPulse className="h-3 w-[60%] mb-4" />
              <div className="flex items-center justify-between pt-3 border-t border-[var(--neutral-100)]">
                <div className="flex items-center gap-2">
                  <SkeletonPulse className="w-7 h-7 rounded-full" />
                  <SkeletonPulse className="w-14 h-3" />
                </div>
                <SkeletonPulse className="w-10 h-3" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    ))}
  </div>
);

/* ── Timeline Skeleton ───────────────────────────────────── */

export const TimelineSkeleton = () => (
  <div>
    {/* Toolbar skeleton */}
    <div className="mb-5 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <SkeletonPulse className="w-[200px] h-[36px] rounded-lg" />
        <SkeletonPulse className="w-[120px] h-[32px] rounded-lg" />
        <SkeletonPulse className="w-[130px] h-[32px] rounded-lg" />
      </div>
      <div className="flex items-center gap-2">
        <SkeletonPulse className="w-8 h-8 rounded-lg" />
        <SkeletonPulse className="w-16 h-8 rounded-lg" />
        <SkeletonPulse className="w-8 h-8 rounded-lg" />
      </div>
    </div>
    {/* Timeline container skeleton */}
    <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden">
      <div className="bg-[var(--neutral-50)] border-b border-[var(--neutral-200)] h-[44px] flex items-center px-5">
        <SkeletonPulse className="w-[100px] h-3" />
      </div>
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.div
          key={i}
          className="flex items-center h-[56px] border-b border-[var(--neutral-100)] px-5"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: i * 0.04 }}
        >
          <div className="w-[280px] shrink-0 flex items-center gap-3">
            <SkeletonPulse className="w-2 h-2 rounded-full" />
            <div className="flex-1 space-y-1.5">
              <SkeletonPulse className="h-3.5 w-[70%]" />
              <SkeletonPulse className="h-[20px] w-16 rounded-[4px]" />
            </div>
          </div>
          <div className="flex-1 px-4">
            <SkeletonPulse className="h-7 rounded-md" style={{ width: `${20 + Math.random() * 40}%`, marginLeft: `${Math.random() * 30}%` } as React.CSSProperties} />
          </div>
        </motion.div>
      ))}
    </div>
  </div>
);

/* ── Calendar Skeleton ───────────────────────────────────── */

export const CalendarSkeleton = () => (
  <div>
    {/* Header skeleton */}
    <div className="mb-5 flex items-center justify-between">
      <SkeletonPulse className="w-[180px] h-6" />
      <div className="flex items-center gap-2">
        <SkeletonPulse className="w-9 h-9 rounded-lg" />
        <SkeletonPulse className="w-16 h-9 rounded-lg" />
        <SkeletonPulse className="w-9 h-9 rounded-lg" />
      </div>
    </div>
    {/* Calendar grid skeleton */}
    <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden">
      <div className="grid grid-cols-7 bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]">
        {Array.from({ length: 7 }).map((_, i) => (
          <div key={i} className="py-3 flex justify-center border-r border-[var(--neutral-100)] last:border-r-0">
            <SkeletonPulse className="w-8 h-3" />
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {Array.from({ length: 35 }).map((_, i) => (
          <div key={i} className="min-h-[120px] p-2.5 border-r border-b border-[var(--neutral-100)]">
            <SkeletonPulse className="w-7 h-7 rounded-full mb-2" />
            {i % 3 === 0 && <SkeletonPulse className="h-6 w-full rounded-md mb-1" />}
            {i % 5 === 0 && <SkeletonPulse className="h-6 w-[80%] rounded-md" />}
          </div>
        ))}
      </div>
    </div>
  </div>
);

/* ── MyTasks Skeleton ────────────────────────────────────── */

export const MyTasksSkeleton = () => (
  <div className="flex gap-6">
    {/* Left Sidebar */}
    <div className="w-[240px] flex-shrink-0 space-y-5">
      <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-3 space-y-2">
        {Array.from({ length: 7 }).map((_, i) => (
          <SkeletonPulse key={i} className="h-[44px] w-full rounded-lg" />
        ))}
      </div>
      <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-4 space-y-4">
        <SkeletonPulse className="h-4 w-32" />
        <SkeletonPulse className="h-1.5 w-full rounded-full" />
        <SkeletonPulse className="h-3 w-full" />
        <SkeletonPulse className="h-3 w-full" />
        <SkeletonPulse className="h-[60px] w-full rounded-md" />
      </div>
    </div>
    {/* Right Content */}
    <div className="flex-1 space-y-2.5">
      <SkeletonPulse className="h-5 w-32 mb-1" />
      <SkeletonPulse className="h-3 w-48 mb-4" />
      {Array.from({ length: 5 }).map((_, i) => (
        <motion.div
          key={i}
          className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.04 }}
        >
          <div className="flex items-start gap-4">
            <SkeletonPulse className="w-5 h-5 rounded mt-1" />
            <div className="flex-1 space-y-2">
              <SkeletonPulse className="h-4 w-[70%]" />
              <div className="flex gap-4">
                <SkeletonPulse className="h-3 w-20" />
                <SkeletonPulse className="h-3 w-20" />
                <SkeletonPulse className="h-3 w-16" />
              </div>
            </div>
            <SkeletonPulse className="w-16 h-[24px] rounded-[var(--badge-radius)]" />
          </div>
        </motion.div>
      ))}
    </div>
  </div>
);

/* ── Chart Skeleton ──────────────────────────────────────── */

export const ChartSkeleton = () => (
  <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-6">
    <SkeletonPulse className="h-4 w-32 mb-2" />
    <SkeletonPulse className="h-3 w-48 mb-6" />
    <div className="flex items-end gap-2 h-[200px]">
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.div
          key={i}
          className="flex-1"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: i * 0.05 }}
        >
          <SkeletonPulse
            className="w-full rounded-t-sm"
            style={{ height: `${30 + Math.random() * 70}%` } as React.CSSProperties}
          />
        </motion.div>
      ))}
    </div>
  </div>
);

/* ── Error State ─────────────────────────────────────────── */

export const ErrorState = ({
  message = 'Something went wrong',
  onRetry,
}: {
  message?: string;
  onRetry?: () => void;
}) => (
  <motion.div
    className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-12 text-center"
    initial={{ opacity: 0, scale: 0.98 }}
    animate={{ opacity: 1, scale: 1 }}
  >
    <div className="w-12 h-12 mx-auto mb-4 bg-[var(--danger-light)] rounded-full flex items-center justify-center">
      <AlertCircle size={24} className="text-[var(--danger)]" />
    </div>
    <h3 className="text-[16px] font-medium leading-[1.3] text-[var(--text-primary)] mb-2">Error Loading Data</h3>
    <p className="text-[14px] font-normal leading-[1.5] text-[var(--text-secondary)] mb-6 max-w-[360px] mx-auto">
      {message}
    </p>
    {onRetry && (
      <Button variant="primary" icon={<RefreshCw size={16} />} onClick={onRetry}>
        Retry
      </Button>
    )}
  </motion.div>
);

/* ── Empty State ─────────────────────────────────────────── */

export const EmptyState = ({
  title = 'No items found',
  description = 'Try adjusting your filters or create a new item.',
  icon: Icon = Inbox,
  action,
}: {
  title?: string;
  description?: string;
  icon?: React.ElementType;
  action?: { label: string; onClick: () => void };
}) => (
  <motion.div
    className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-12 text-center"
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
  >
    <div className="w-12 h-12 mx-auto mb-4 bg-[var(--neutral-100)] rounded-full flex items-center justify-center">
      <Icon size={24} className="text-[var(--text-tertiary)]" />
    </div>
    <h3 className="text-[16px] font-medium leading-[1.3] text-[var(--text-primary)] mb-2">{title}</h3>
    <p className="text-[14px] font-normal leading-[1.5] text-[var(--text-secondary)] max-w-[360px] mx-auto mb-6">
      {description}
    </p>
    {action && (
      <Button variant="primary" onClick={action.onClick}>
        {action.label}
      </Button>
    )}
  </motion.div>
);

/* ── Simulated Loading Hook (legacy compat) ──────────────── */

export function useSimulatedLoading(delay = 800) {
  const [isLoading, setIsLoading] = React.useState(true);
  const [hasError, setHasError] = React.useState(false);

  React.useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  const retry = React.useCallback(() => {
    setHasError(false);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), delay);
  }, [delay]);

  return { isLoading, hasError, setHasError, retry };
}

/* ── Data Loader Hook with try/catch ─────────────────────── */

export function useDataLoader<T>(
  loader: () => T,
  delay = 800
): { data: T | null; isLoading: boolean; hasError: boolean; errorMessage: string; retry: () => void } {
  const [data, setData] = React.useState<T | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [hasError, setHasError] = React.useState(false);
  const [errorMessage, setErrorMessage] = React.useState('');

  const loadData = React.useCallback(() => {
    setIsLoading(true);
    setHasError(false);
    setErrorMessage('');

    const timer = setTimeout(() => {
      try {
        const result = loader();
        setData(result);
        setIsLoading(false);
      } catch (err: unknown) {
        setHasError(true);
        setErrorMessage((err as Error)?.message || 'Failed to load data from local storage.');
        setIsLoading(false);
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [loader, delay]);

  React.useEffect(() => {
    const cleanup = loadData();
    return cleanup;
  }, [loadData]);

  const retry = React.useCallback(() => {
    loadData();
  }, [loadData]);

  return { data, isLoading, hasError, errorMessage, retry };
}
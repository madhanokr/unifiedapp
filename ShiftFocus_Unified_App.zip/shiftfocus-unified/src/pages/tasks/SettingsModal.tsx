import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  User,
  Bell,
  Palette,
  Zap,
  Shield,
  Globe,
  Check,
  Monitor,
  Moon,
  RotateCcw,
} from 'lucide-react';
import { db, UserSettings } from './data-store';
import { Button, Switch, Input, Select, sfToast } from './design-system';
import ConfirmDialog from './ConfirmDialog';

interface SettingsModalProps {
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const [settings, setSettings] = useState<UserSettings>(() => db.getSettings());
  const [activeTab, setActiveTab] = useState('appearance');
  const [hasChanges, setHasChanges] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const updateSetting = <K extends keyof UserSettings>(key: K, value: UserSettings[K]) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    db.updateSettings(settings);
    setHasChanges(false);
    // Apply theme to DOM
    const root = document.documentElement;
    root.classList.remove('dark', 'amoled');
    if (settings.theme === 'dark') root.classList.add('dark');
    else if (settings.theme === 'amoled') root.classList.add('dark', 'amoled');
    sfToast.success('Settings saved successfully');
  };

  const resetSettings = () => {
    db.reset();
    setSettings(db.getSettings());
    setHasChanges(false);
    // Reset theme
    const root = document.documentElement;
    root.classList.remove('dark', 'amoled');
    sfToast.success('Settings reset to defaults');
  };

  const tabs = [
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'ai', label: 'AI Settings', icon: Zap },
    { id: 'account', label: 'Account', icon: User },
    { id: 'privacy', label: 'Privacy', icon: Shield },
    { id: 'language', label: 'Language', icon: Globe },
  ];

  const Toggle = ({
    checked,
    onChange,
  }: {
    checked: boolean;
    onChange: (val: boolean) => void;
  }) => (
    <Switch
      checked={checked}
      onCheckedChange={onChange}
    />
  );

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.12 }}
          onClick={onClose}
        />

        {/* Modal */}
        <motion.div
          className="relative w-full max-w-[900px] h-[620px] bg-white rounded-[16px] shadow-[var(--shadow-modal)] overflow-hidden flex"
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
        >
          {/* Left Sidebar */}
          <div className="w-[240px] bg-[var(--neutral-50)] border-r border-[var(--neutral-200)] p-5 flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)]">Settings</h2>
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors duration-[120ms] text-[var(--neutral-600)] hover:text-[var(--neutral-800)]"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-1 flex-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`
                      w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-[14px] font-medium transition-all duration-[120ms]
                      ${activeTab === tab.id
                        ? 'bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-primary-active)] text-white shadow-[var(--shadow-brand)]'
                        : 'text-[var(--neutral-800)] hover:bg-[var(--neutral-100)]'
                      }
                    `}
                  >
                    <Icon size={16} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Reset Button */}
            <button
              onClick={() => setShowResetConfirm(true)}
              className="flex items-center gap-2 px-3 py-2 text-[12px] font-medium text-[var(--danger)] hover:bg-[var(--danger-bg)] rounded-lg transition-colors mt-auto"
            >
              <RotateCcw size={14} />
              Reset to defaults
            </button>
          </div>

          {/* Right Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-8">
              {/* Appearance Tab */}
              {activeTab === 'appearance' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    Appearance
                  </h3>

                  <div className="space-y-8">
                    {/* Theme */}
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-3">
                        Theme
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {[
                          { id: 'light', label: 'Light', icon: Monitor, bg: 'bg-white border-[var(--neutral-200)]', inner: 'bg-[var(--neutral-50)]' },
                          { id: 'dark', label: 'Dark', icon: Moon, bg: 'bg-[var(--surface-elevated)]', inner: 'bg-[var(--neutral-800)]' },
                          { id: 'amoled', label: 'AMOLED', icon: Monitor, bg: 'bg-black', inner: 'bg-[var(--amoled-bg)]' },
                        ].map((t) => {
                          const Icon = t.icon;
                          return (
                            <button
                              key={t.id}
                              onClick={() => updateSetting('theme', t.id as UserSettings['theme'])}
                              className={`
                                p-4 rounded-[12px] border-2 transition-all duration-[120ms]
                                ${settings.theme === t.id
                                  ? 'border-[var(--brand-primary)] shadow-[var(--shadow-focus)]'
                                  : 'border-[var(--neutral-200)] hover:border-[var(--neutral-400)]'
                                }
                              `}
                            >
                              <div className={`w-full h-16 rounded-lg mb-3 ${t.bg} border border-[var(--neutral-200)] relative overflow-hidden`}>
                                <div className={`absolute bottom-0 left-0 right-0 h-6 ${t.inner}`} />
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-[14px] font-medium text-[var(--neutral-800)]">
                                  {t.label}
                                </span>
                                {settings.theme === t.id && (
                                  <div className="w-5 h-5 bg-[var(--brand-primary)] rounded-full flex items-center justify-center">
                                    <Check size={12} className="text-white" />
                                  </div>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Compact Mode */}
                    <div className="flex items-center justify-between py-4 border-b border-[var(--neutral-200)]">
                      <div>
                        <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-0.5">
                          Compact Mode
                        </div>
                        <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                          Reduce row spacing in list view
                        </div>
                      </div>
                      <Toggle
                        checked={settings.compactMode}
                        onChange={(val) => updateSetting('compactMode', val)}
                      />
                    </div>

                    {/* Show Avatars */}
                    <div className="flex items-center justify-between py-4 border-b border-[var(--neutral-200)]">
                      <div>
                        <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-0.5">
                          Show Assignee Avatars
                        </div>
                        <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                          Display user avatars in task lists
                        </div>
                      </div>
                      <Toggle
                        checked={settings.showAvatars}
                        onChange={(val) => updateSetting('showAvatars', val)}
                      />
                    </div>

                    {/* Default View */}
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-2">
                        Default View
                      </label>
                      <select
                        value={settings.defaultView}
                        onChange={(e) => updateSetting('defaultView', e.target.value)}
                        className="w-full h-[40px] px-3 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:shadow-[var(--shadow-focus)] focus:border-[var(--brand-primary)] text-[14px] text-[var(--neutral-800)] bg-white transition-all duration-[120ms]"
                      >
                        <option value="list">List View</option>
                        <option value="kanban">Kanban Board</option>
                        <option value="timeline">Timeline / Gantt</option>
                        <option value="calendar">Calendar</option>
                        <option value="mytasks">My Tasks</option>
                        <option value="ai">AI Mode</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Notifications Tab */}
              {activeTab === 'notifications' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    Notification Preferences
                  </h3>

                  <div className="space-y-0">
                    {[
                      {
                        key: 'emailNotifications' as const,
                        label: 'Email Notifications',
                        desc: 'Receive task updates and escalation alerts via email',
                      },
                      {
                        key: 'pushNotifications' as const,
                        label: 'Push Notifications',
                        desc: 'Receive browser push notifications for urgent items',
                      },
                      {
                        key: 'slackNotifications' as const,
                        label: 'Slack Integration',
                        desc: 'Forward escalation and SLA alerts to Slack channels',
                      },
                    ].map((item) => (
                      <div
                        key={item.key}
                        className="flex items-center justify-between py-4 border-b border-[var(--neutral-200)]"
                      >
                        <div>
                          <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-0.5">
                            {item.label}
                          </div>
                          <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                            {item.desc}
                          </div>
                        </div>
                        <Toggle
                          checked={settings[item.key]}
                          onChange={(val) => updateSetting(item.key, val)}
                        />
                      </div>
                    ))}
                  </div>

                  {/* Notification Categories */}
                  <div className="mt-8">
                    <h4 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-4">
                      Notification Types
                    </h4>
                    <div className="space-y-3">
                      {[
                        { label: 'Escalation Alerts', desc: 'When tasks approach SLA deadlines', enabled: true },
                        { label: 'Idle Task Warnings', desc: 'Subtasks without progress signals > 48h', enabled: true },
                        { label: 'Dependency Changes', desc: 'When blocked/blocking tasks change status', enabled: true },
                        { label: 'Assignment Notifications', desc: 'When tasks are assigned to you', enabled: true },
                        { label: 'AI Recommendations', desc: 'AI-generated optimization suggestions', enabled: true },
                      ].map((cat, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between py-3 px-4 bg-[var(--neutral-50)] rounded-lg"
                        >
                          <div>
                            <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">
                              {cat.label}
                            </div>
                            <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                              {cat.desc}
                            </div>
                          </div>
                          <Toggle checked={cat.enabled} onChange={(val) => console.log('Toggle notification:', cat.label, val)} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* AI Settings Tab */}
              {activeTab === 'ai' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    AI Configuration
                  </h3>

                  <div className="space-y-8">
                    {/* AI Level */}
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-3">
                        AI Recommendation Level
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {[
                          {
                            id: 'minimal',
                            label: 'Minimal',
                            desc: 'Only critical alerts and escalation warnings',
                            icon: '🔕',
                          },
                          {
                            id: 'balanced',
                            label: 'Balanced',
                            desc: 'Smart insights with moderate recommendations',
                            icon: '⚖️',
                          },
                          {
                            id: 'aggressive',
                            label: 'Aggressive',
                            desc: 'Maximum automation and proactive fixes',
                            icon: '⚡',
                          },
                        ].map((level) => (
                          <button
                            key={level.id}
                            onClick={() =>
                              updateSetting('aiLevel', level.id as UserSettings['aiLevel'])
                            }
                            className={`
                              p-4 rounded-xl border-2 transition-all duration-[120ms]
                              ${settings.aiLevel === level.id
                                ? 'border-[var(--brand-primary)] bg-[var(--brand-primary-light)] shadow-[var(--shadow-focus)]'
                                : 'border-[var(--neutral-200)] hover:border-[var(--neutral-300)]'
                              }
                            `}
                          >
                            <div className="text-[20px] mb-2">{level.icon}</div>
                            <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                              {level.label}
                            </div>
                            <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                              {level.desc}
                            </div>
                            {settings.aiLevel === level.id && (
                              <div className="mt-3 flex items-center gap-1.5 text-[12px] font-medium text-[var(--brand-primary)]">
                                <Check size={12} />
                                Active
                              </div>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* AI Features */}
                    <div>
                      <h4 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-4">
                        AI Features
                      </h4>
                      <div className="space-y-3">
                        {[
                          { label: 'Auto-detect idle subtasks', desc: 'Flag subtasks without updates > 48h', enabled: true },
                          { label: 'Predictive delay analysis', desc: 'Use historical data to predict delays', enabled: true },
                          { label: 'Smart task splitting', desc: 'Suggest breaking large tasks into subtasks', enabled: true },
                          { label: 'Workload balancing', desc: 'Recommend task reassignment for team balance', enabled: false },
                        ].map((feature, i) => (
                          <div
                            key={i}
                            className="flex items-center justify-between py-3 px-4 bg-[var(--neutral-50)] rounded-lg"
                          >
                            <div>
                              <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">
                                {feature.label}
                              </div>
                              <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                                {feature.desc}
                              </div>
                            </div>
                            <Toggle checked={feature.enabled} onChange={(val) => console.log('Toggle AI feature:', feature.label, val)} />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Account Tab */}
              {activeTab === 'account' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    Account Settings
                  </h3>

                  <div className="space-y-6">
                    {/* Avatar */}
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[var(--brand-primary)] to-[var(--brand-primary-active)] flex items-center justify-center text-white text-[20px] font-semibold">
                        {settings.userName.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                      </div>
                      <div>
                        <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">
                          {settings.userName}
                        </div>
                        <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                          {settings.userEmail}
                        </div>
                      </div>
                    </div>

                    {/* Name */}
                    <Input
                      label="Full Name"
                      value={settings.userName}
                      onChange={(e) => updateSetting('userName', e.target.value)}
                    />

                    {/* Email */}
                    <Input
                      label="Email Address"
                      type="email"
                      value={settings.userEmail}
                      onChange={(e) => updateSetting('userEmail', e.target.value)}
                    />

                    {/* Role */}
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-2">
                        Role
                      </label>
                      <div className="h-[40px] px-3 border border-[var(--neutral-200)] rounded-lg bg-[var(--neutral-50)] flex items-center text-[14px] text-[var(--neutral-600)]">
                        Engineering Manager
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Privacy Tab */}
              {activeTab === 'privacy' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    Privacy & Security
                  </h3>
                  <div className="space-y-0">
                    {[
                      { label: 'Activity tracking', desc: 'Allow AI to learn from your task patterns', enabled: true },
                      { label: 'Anonymous analytics', desc: 'Share anonymous usage data to improve ShiftFocus', enabled: false },
                      { label: 'Two-factor authentication', desc: 'Add extra security to your account', enabled: true },
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between py-4 border-b border-[var(--neutral-200)]"
                      >
                        <div>
                          <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-0.5">
                            {item.label}
                          </div>
                          <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                            {item.desc}
                          </div>
                        </div>
                        <Toggle checked={item.enabled} onChange={(val) => console.log('Toggle privacy:', item.label, val)} />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Language Tab */}
              {activeTab === 'language' && (
                <div>
                  <h3 className="text-[18px] font-medium leading-[1.3] text-[var(--neutral-800)] mb-6">
                    Language & Region
                  </h3>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-2">
                        Language
                      </label>
                      <select
                        value={settings.language}
                        onChange={(e) => updateSetting('language', e.target.value)}
                        className="w-full h-[40px] px-3 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:shadow-[var(--shadow-focus)] focus:border-[var(--brand-primary)] text-[14px] text-[var(--neutral-800)] bg-white transition-all duration-[120ms]"
                      >
                        <option value="en">English (US)</option>
                        <option value="en-gb">English (UK)</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                        <option value="ja">Japanese</option>
                        <option value="ko">Korean</option>
                        <option value="zh">Chinese (Simplified)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-2">
                        Date Format
                      </label>
                      <select className="w-full h-[40px] px-3 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:shadow-[var(--shadow-focus)] focus:border-[var(--brand-primary)] text-[14px] text-[var(--neutral-800)] bg-white transition-all duration-[120ms]">
                        <option>MM/DD/YYYY</option>
                        <option>DD/MM/YYYY</option>
                        <option>YYYY-MM-DD</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-2">
                        Time Zone
                      </label>
                      <select className="w-full h-[40px] px-3 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:shadow-[var(--shadow-focus)] focus:border-[var(--brand-primary)] text-[14px] text-[var(--neutral-800)] bg-white transition-all duration-[120ms]">
                        <option>Pacific Time (PT) - UTC-8</option>
                        <option>Eastern Time (ET) - UTC-5</option>
                        <option>Central European (CET) - UTC+1</option>
                        <option>Japan Standard (JST) - UTC+9</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Save Bar */}
            <AnimatePresence>
              {hasChanges && (
                <motion.div
                  initial={{ y: 60, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 60, opacity: 0 }}
                  transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                  className="px-8 py-4 border-t border-[var(--neutral-200)] bg-[var(--neutral-50)] flex items-center justify-end gap-3"
                >
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setSettings(db.getSettings());
                      setHasChanges(false);
                    }}
                  >
                    Discard
                  </Button>
                  <Button
                    variant="primary"
                    onClick={saveSettings}
                  >
                    Save Changes
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      {/* Reset Confirmation Dialog */}
      <ConfirmDialog
        open={showResetConfirm}
        onOpenChange={setShowResetConfirm}
        title="Reset All Settings"
        description="This will clear all settings and restore defaults. All your customizations will be lost. Continue?"
        confirmLabel="Reset Everything"
        variant="destructive"
        onConfirm={resetSettings}
      />
    </AnimatePresence>
  );
};

export default SettingsModal;
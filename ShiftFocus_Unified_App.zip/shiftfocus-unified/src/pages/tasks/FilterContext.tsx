import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { Task } from './data-store';

export type SortField = 'dueDate' | 'priority' | 'krImpact' | 'aiRisk' | 'title' | 'status';
export type SortDirection = 'asc' | 'desc';
export type GroupField = 'project' | 'priority' | 'status' | 'assignee' | 'aiRisk' | 'none';

export interface FilterState {
  sortField: SortField;
  sortDirection: SortDirection;
  groupField: GroupField;
  hiddenColumns: Set<string>;
  statusFilters: Set<string>;
  priorityFilters: Set<string>;
  assigneeFilters: Set<string>;
  activeProjectId: string | null; // null = All Tasks
}

interface FilterContextValue {
  filters: FilterState;
  setSortField: (field: SortField) => void;
  setSortDirection: (dir: SortDirection) => void;
  setGroupField: (field: GroupField) => void;
  toggleColumn: (col: string) => void;
  toggleStatusFilter: (status: string) => void;
  togglePriorityFilter: (priority: string) => void;
  toggleAssigneeFilter: (assignee: string) => void;
  setActiveProjectId: (projectId: string | null) => void;
  clearAllFilters: () => void;
  applySort: (tasks: Task[]) => Task[];
  applyFilters: (tasks: Task[]) => Task[];
  applyGrouping: (tasks: Task[]) => Map<string, Task[]>;
}

const DEFAULT_FILTERS: FilterState = {
  sortField: 'dueDate',
  sortDirection: 'asc',
  groupField: 'none',
  hiddenColumns: new Set<string>(),
  statusFilters: new Set<string>(),
  priorityFilters: new Set<string>(),
  assigneeFilters: new Set<string>(),
  activeProjectId: null,
};

const FilterContext = createContext<FilterContextValue | null>(null);

const PRIORITY_ORDER: Record<string, number> = {
  Critical: 0,
  High: 1,
  Medium: 2,
  Low: 3,
};

const RISK_ORDER: Record<string, number> = {
  high: 0,
  medium: 1,
  low: 2,
};

export function FilterProvider({ children }: { children: React.ReactNode }) {
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);

  const setSortField = useCallback((field: SortField) => {
    setFilters((prev) => ({
      ...prev,
      sortField: field,
      sortDirection: prev.sortField === field && prev.sortDirection === 'asc' ? 'desc' : 'asc',
    }));
  }, []);

  const setSortDirection = useCallback((dir: SortDirection) => {
    setFilters((prev) => ({ ...prev, sortDirection: dir }));
  }, []);

  const setGroupField = useCallback((field: GroupField) => {
    setFilters((prev) => ({ ...prev, groupField: field }));
  }, []);

  const toggleColumn = useCallback((col: string) => {
    setFilters((prev) => {
      const next = new Set(prev.hiddenColumns);
      if (next.has(col)) next.delete(col);
      else next.add(col);
      return { ...prev, hiddenColumns: next };
    });
  }, []);

  const toggleStatusFilter = useCallback((status: string) => {
    setFilters((prev) => {
      const next = new Set(prev.statusFilters);
      if (next.has(status)) next.delete(status);
      else next.add(status);
      return { ...prev, statusFilters: next };
    });
  }, []);

  const togglePriorityFilter = useCallback((priority: string) => {
    setFilters((prev) => {
      const next = new Set(prev.priorityFilters);
      if (next.has(priority)) next.delete(priority);
      else next.add(priority);
      return { ...prev, priorityFilters: next };
    });
  }, []);

  const toggleAssigneeFilter = useCallback((assignee: string) => {
    setFilters((prev) => {
      const next = new Set(prev.assigneeFilters);
      if (next.has(assignee)) next.delete(assignee);
      else next.add(assignee);
      return { ...prev, assigneeFilters: next };
    });
  }, []);

  const setActiveProjectId = useCallback((projectId: string | null) => {
    setFilters((prev) => ({ ...prev, activeProjectId: projectId }));
  }, []);

  const clearAllFilters = useCallback(() => {
    setFilters((prev) => ({
      ...DEFAULT_FILTERS,
      activeProjectId: prev.activeProjectId, // Preserve project selection when clearing filters
    }));
  }, []);

  const applyFilters = useCallback(
    (tasks: Task[]): Task[] => {
      let result = tasks;
      // Apply project filter
      if (filters.activeProjectId !== null) {
        result = result.filter((t) => t.projectId === filters.activeProjectId);
      }
      if (filters.statusFilters.size > 0) {
        result = result.filter((t) => filters.statusFilters.has(t.status));
      }
      if (filters.priorityFilters.size > 0) {
        result = result.filter((t) => filters.priorityFilters.has(t.priority));
      }
      if (filters.assigneeFilters.size > 0) {
        result = result.filter((t) => filters.assigneeFilters.has(t.assignee.name));
      }
      return result;
    },
    [filters.statusFilters, filters.priorityFilters, filters.assigneeFilters, filters.activeProjectId]
  );

  const applySort = useCallback(
    (tasks: Task[]): Task[] => {
      const dir = filters.sortDirection === 'asc' ? 1 : -1;
      return [...tasks].sort((a, b) => {
        switch (filters.sortField) {
          case 'dueDate':
            return dir * ((a.dueDate || '').localeCompare(b.dueDate || ''));
          case 'priority':
            return dir * ((PRIORITY_ORDER[a.priority] ?? 99) - (PRIORITY_ORDER[b.priority] ?? 99));
          case 'krImpact':
            return dir * (a.krImpact - b.krImpact);
          case 'aiRisk':
            return dir * ((RISK_ORDER[a.aiRisk] ?? 99) - (RISK_ORDER[b.aiRisk] ?? 99));
          case 'title':
            return dir * a.title.localeCompare(b.title);
          case 'status':
            return dir * a.status.localeCompare(b.status);
          default:
            return 0;
        }
      });
    },
    [filters.sortField, filters.sortDirection]
  );

  const applyGrouping = useCallback(
    (tasks: Task[]): Map<string, Task[]> => {
      const groups = new Map<string, Task[]>();
      if (filters.groupField === 'none') {
        groups.set('all', tasks);
        return groups;
      }
      tasks.forEach((task) => {
        let key = '';
        switch (filters.groupField) {
          case 'priority':
            key = task.priority;
            break;
          case 'status':
            key = task.status;
            break;
          case 'assignee':
            key = task.assignee.name;
            break;
          case 'aiRisk':
            key = task.aiRisk === 'high' ? 'High Risk' : task.aiRisk === 'medium' ? 'Medium Risk' : 'Low Risk';
            break;
          case 'project':
            key = task.projectId || 'inbox';
            break;
        }
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(task);
      });
      return groups;
    },
    [filters.groupField]
  );

  const value = useMemo(
    () => ({
      filters,
      setSortField,
      setSortDirection,
      setGroupField,
      toggleColumn,
      toggleStatusFilter,
      togglePriorityFilter,
      toggleAssigneeFilter,
      setActiveProjectId,
      clearAllFilters,
      applySort,
      applyFilters,
      applyGrouping,
    }),
    [
      filters,
      setSortField,
      setSortDirection,
      setGroupField,
      toggleColumn,
      toggleStatusFilter,
      togglePriorityFilter,
      toggleAssigneeFilter,
      setActiveProjectId,
      clearAllFilters,
      applySort,
      applyFilters,
      applyGrouping,
    ]
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilters() {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error('useFilters must be used within FilterProvider');
  return ctx;
}

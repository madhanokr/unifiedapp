import React, { useState, useMemo, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import {
  ZoomIn,
  ZoomOut,
  GitBranch,
  Sparkles,
  AlertTriangle,
  Clock,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  CalendarDays,
} from 'lucide-react';
import TaskDetailModal from './TaskDetailModal';
import { db, Task, PRIORITY_STYLES, RISK_STYLES, STATUS_DOT_COLORS } from './data-store';
import { useFilters } from './FilterContext';
import { TimelineSkeleton, ErrorState, EmptyState, useDataLoader } from './LoadingStates';

type ZoomLevel = 'day' | 'week' | 'month';

const TimelineView = () => {
  const [zoom, setZoom] = useState<ZoomLevel>('week');
  const [showDependencies, setShowDependencies] = useState(true);
  const [showCriticalPath, setShowCriticalPath] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [hoveredTask, setHoveredTask] = useState<string | null>(null);
  const [weekOffset, setWeekOffset] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const loader = useCallback(() => db.getTasks().filter(t => t.status !== 'Completed'), []);
  const { data: rawTasks, isLoading, hasError, errorMessage, retry } = useDataLoader(loader, 800);

  const { applyFilters, applySort } = useFilters();
  const tasks = useMemo(() => {
    if (!rawTasks) return [];
    return applySort(applyFilters(rawTasks));
  }, [rawTasks, applyFilters, applySort]);

  // Generate date range based on zoom
  const baseDate = useMemo(() => {
    const d = new Date('2026-02-10');
    d.setDate(d.getDate() + weekOffset * 7);
    return d;
  }, [weekOffset]);

  const dateColumns = useMemo(() => {
    const cols: { date: Date; label: string; isToday: boolean; isWeekend: boolean }[] = [];
    const numDays = zoom === 'day' ? 14 : zoom === 'week' ? 28 : 60;
    const startDate = new Date(baseDate);
    startDate.setDate(startDate.getDate() - 3);

    for (let i = 0; i < numDays; i++) {
      const d = new Date(startDate);
      d.setDate(d.getDate() + i);
      const today = new Date('2026-02-10');
      cols.push({
        date: d,
        label: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        isToday: d.toDateString() === today.toDateString(),
        isWeekend: d.getDay() === 0 || d.getDay() === 6,
      });
    }
    return cols;
  }, [baseDate, zoom]);

  const getTaskPosition = (task: Task) => {
    if (!task.dueDate) return null;
    const startDate = dateColumns[0]?.date;
    if (!startDate) return null;

    const dueDate = new Date(task.dueDate);
    // Estimate start: 7 days before due
    const taskStart = new Date(dueDate);
    taskStart.setDate(taskStart.getDate() - 7);

    const totalDays = dateColumns.length;
    const startDay = Math.max(
      0,
      Math.floor((taskStart.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
    );
    const endDay = Math.min(
      totalDays,
      Math.floor((dueDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
    );

    if (endDay < 0 || startDay >= totalDays) return null;

    const left = (Math.max(0, startDay) / totalDays) * 100;
    const width = ((Math.min(totalDays, endDay) - Math.max(0, startDay)) / totalDays) * 100;

    return { left, width: Math.max(width, 3) };
  };

  const isOverdue = (task: Task) => {
    if (!task.dueDate) return false;
    const due = new Date(task.dueDate);
    const today = new Date('2026-02-10');
    return due < today && task.status !== 'Completed';
  };

  const barGradients: Record<string, string> = {
    Critical: 'from-[var(--danger)] to-[var(--danger-dark)]',
    High: 'from-[var(--at-risk)] to-[var(--warning)]',
    Medium: 'from-[var(--info-dark)] to-[var(--info)]',
    Low: 'from-[var(--neutral-400)] to-[var(--neutral-600)]',
  };

  const criticalPathTasks = useMemo(() => {
    return tasks.filter(t => t.aiRisk === 'high' || t.priority === 'Critical');
  }, [tasks]);

  const displayTasks = showCriticalPath ? criticalPathTasks : tasks;

  if (isLoading) return <TimelineSkeleton />;
  if (hasError) return <ErrorState message={errorMessage} onRetry={retry} />;
  if (!rawTasks || rawTasks.length === 0)
    return <EmptyState title="No active tasks" description="All tasks are completed or no tasks have been created yet." icon={CalendarDays} />;
  if (displayTasks.length === 0)
    return <EmptyState title="No tasks match your filters" description="Try adjusting your filter criteria or disabling Critical Path mode." icon={CalendarDays} />;

  return (
    <>
      <div>
        {/* Toolbar */}
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Zoom Selector */}
            <div className="flex items-center gap-1 bg-[var(--bg-level-0)] rounded-lg border border-[var(--neutral-200)] p-1">
              {(['day', 'week', 'month'] as const).map((z) => (
                <button
                  key={z}
                  onClick={() => setZoom(z)}
                  className={`
                    h-[32px] px-4 rounded-md text-[12px] font-medium leading-[1.4] transition-all duration-[var(--duration-fast)]
                    ${zoom === z
                      ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white shadow-[var(--shadow-card)]'
                      : 'text-[var(--text-secondary)] hover:bg-[var(--neutral-50)] hover:text-[var(--text-primary)]'
                    }
                  `}
                >
                  {z.charAt(0).toUpperCase() + z.slice(1)}
                </button>
              ))}
            </div>

            {/* Dependencies Toggle */}
            <button
              onClick={() => setShowDependencies(!showDependencies)}
              className={`
                h-[32px] px-3 rounded-lg text-[12px] font-medium border transition-all duration-[var(--duration-fast)] flex items-center gap-2
                ${showDependencies
                  ? 'bg-[var(--brand-primary-light)] border-[var(--info-light)] text-[var(--brand-primary)]'
                  : 'border-[var(--neutral-200)] text-[var(--text-secondary)] hover:bg-[var(--neutral-50)]'
                }
              `}
            >
              <GitBranch size={14} />
              Dependencies
            </button>

            {/* Critical Path Toggle */}
            <button
              onClick={() => setShowCriticalPath(!showCriticalPath)}
              className={`
                h-[32px] px-3 rounded-lg text-[12px] font-medium border transition-all duration-[var(--duration-fast)] flex items-center gap-2
                ${showCriticalPath
                  ? 'bg-[var(--danger-light)] border-[var(--danger-light)] text-[var(--danger)]'
                  : 'border-[var(--neutral-200)] text-[var(--text-secondary)] hover:bg-[var(--neutral-50)]'
                }
              `}
            >
              <Sparkles size={14} />
              Critical Path
              {showCriticalPath && (
                <span className="h-[20px] px-2 bg-[var(--danger)] text-white rounded-full text-[10px] font-medium flex items-center">
                  {criticalPathTasks.length}
                </span>
              )}
            </button>
          </div>

          {/* Navigation & Zoom */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setWeekOffset((w) => w - 1)}
              className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors text-[var(--text-secondary)]"
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => setWeekOffset(0)}
              className="h-8 px-3 text-[12px] font-medium text-[var(--text-secondary)] hover:bg-[var(--neutral-100)] rounded-lg transition-colors"
            >
              Today
            </button>
            <button
              onClick={() => setWeekOffset((w) => w + 1)}
              className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors text-[var(--text-secondary)]"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        {/* Timeline Container */}
        <div
          ref={containerRef}
          className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden"
        >
          {/* Timeline Header */}
          <div className="bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]">
            <div className="flex">
              <div className="w-[280px] shrink-0 px-5 py-3 typography-caption-medium tracking-[0.01em] text-[var(--text-secondary)] uppercase border-r border-[var(--neutral-200)]">
                Task Name
              </div>
              <div className="flex-1 flex">
                {dateColumns.map((col, i) => (
                  <div
                    key={i}
                    className={`
                      flex-1 text-center py-3 text-[12px] font-normal leading-[1.3] border-l border-[var(--neutral-100)]
                      ${col.isToday ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)] font-medium' : col.isWeekend ? 'text-[var(--text-tertiary)] bg-[var(--neutral-50)]' : 'text-[var(--text-secondary)]'}
                    `}
                  >
                    {col.label}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Timeline Body */}
          <div>
            {displayTasks.map((task, index) => {
              const pos = getTaskPosition(task);
              const overdue = isOverdue(task);
              const isHovered = hoveredTask === task.id;

              return (
                <motion.div
                  key={task.id}
                  className={`
                    flex items-center border-b border-[var(--neutral-100)] hover:bg-[var(--neutral-50)] transition-colors cursor-pointer
                    ${isHovered ? 'bg-[var(--brand-primary-light)]' : ''}
                  `}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.03, duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                  onClick={() => setSelectedTask(task)}
                  onMouseEnter={() => setHoveredTask(task.id)}
                  onMouseLeave={() => setHoveredTask(null)}
                >
                  {/* Task Name Column */}
                  <div className="w-[280px] shrink-0 px-5 py-3.5 border-r border-[var(--neutral-100)]">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full shrink-0 ${STATUS_DOT_COLORS[task.status]}`} />
                      <div className="min-w-0 flex-1">
                        <div className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] truncate">
                          {task.title}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span
                            className={`
                              h-[20px] px-2 rounded-[4px] border
                              text-[10px] font-medium leading-[1.2] tracking-[0.01em] uppercase
                              flex items-center
                              ${PRIORITY_STYLES[task.priority]}
                            `}
                          >
                            {task.priority}
                          </span>
                          {overdue && (
                            <span className="flex items-center gap-1 text-[10px] font-medium text-[var(--danger)]">
                              <AlertTriangle size={10} />
                              Overdue
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Timeline Bar Area */}
                  <div className="flex-1 relative h-[56px] flex items-center">
                    {/* Today Line */}
                    {dateColumns.findIndex((c) => c.isToday) >= 0 && (
                      <div
                        className="absolute top-0 bottom-0 w-px bg-[var(--brand-primary)] z-10 opacity-40"
                        style={{
                          left: `${((dateColumns.findIndex((c) => c.isToday) + 0.5) / dateColumns.length) * 100}%`,
                        }}
                      />
                    )}

                    {/* Grid Lines */}
                    {dateColumns.map((col, i) => (
                      <div
                        key={i}
                        className={`absolute top-0 bottom-0 border-l ${col.isWeekend ? 'bg-[var(--neutral-50)]' : ''} border-[var(--neutral-100)]`}
                        style={{ left: `${(i / dateColumns.length) * 100}%`, width: `${100 / dateColumns.length}%` }}
                      />
                    ))}

                    {/* Task Bar */}
                    {pos && (
                      <motion.div
                        className={`
                          absolute h-7 bg-gradient-to-r ${barGradients[task.priority] || barGradients['Medium']}
                          rounded-md shadow-[var(--shadow-tooltip)] cursor-pointer z-20
                          ${overdue ? 'opacity-80' : ''}
                        `}
                        style={{
                          left: `${pos.left}%`,
                          width: `${pos.width}%`,
                        }}
                        initial={{ scaleX: 0, originX: 0 }}
                        animate={{ scaleX: 1 }}
                        transition={{
                          delay: index * 0.05,
                          duration: 0.4,
                          ease: [0.4, 0, 0.2, 1],
                        }}
                        whileHover={{
                          scaleY: 1.3,
                          zIndex: 30,
                          boxShadow: 'var(--shadow-card-hover)',
                        }}
                      >
                        <div className="h-full flex items-center justify-between px-2 text-white">
                          <span className="text-[10px] font-medium truncate">
                            {task.assignee.avatar}
                          </span>
                          <span className="text-[10px] font-medium">
                            {task.krImpact}%
                          </span>
                        </div>
                      </motion.div>
                    )}

                    {/* Dependency Lines */}
                    {showDependencies && index < displayTasks.length - 1 && pos && (
                      <svg
                        className="absolute inset-0 w-full h-full pointer-events-none z-10"
                        preserveAspectRatio="none"
                      >
                        <motion.line
                          x1={`${pos.left + pos.width}%`}
                          y1="50%"
                          x2={`${(getTaskPosition(displayTasks[index + 1]!)?.left ?? 0)}%`}
                          y2="50%"
                          stroke="var(--brand-primary)"
                          strokeWidth="1.5"
                          strokeDasharray="4 4"
                          strokeOpacity="0.3"
                          initial={{ pathLength: 0 }}
                          animate={{ pathLength: 1 }}
                          transition={{ duration: 0.5, delay: index * 0.05 }}
                        />
                      </svg>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="mt-4 flex items-center gap-6 px-1">
          <div className="text-[12px] font-medium leading-[1.3] text-[var(--text-tertiary)] uppercase tracking-[0.03em]">
            Legend:
          </div>
          {Object.entries(barGradients).map(([priority, gradient]) => (
            <div key={priority} className="flex items-center gap-2">
              <div className={`w-4 h-2.5 rounded-sm bg-gradient-to-r ${gradient}`} />
              <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
                {priority}
              </span>
            </div>
          ))}
          <div className="flex items-center gap-2">
            <div className="w-4 h-px bg-[var(--brand-primary)]" style={{ borderBottom: '2px dashed var(--brand-primary)' }} />
            <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
              Dependency
            </span>
          </div>
        </div>
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal task={selectedTask} onClose={() => setSelectedTask(null)} />
      )}
    </>
  );
};

export default TimelineView;
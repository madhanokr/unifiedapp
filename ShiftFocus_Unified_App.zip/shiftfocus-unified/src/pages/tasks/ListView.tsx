import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, ChevronRight, MoreHorizontal, AlertTriangle, TrendingUp, MessageSquare, Paperclip } from 'lucide-react';
import TaskDetailModal from './TaskDetailModal';
import { db, Task, PRIORITY_STYLES as priorityStyles, STATUS_STYLES as statusStylesMap, RISK_STYLES } from './data-store';
import { useFilters } from './FilterContext';
import { ListSkeleton, ErrorState, useDataLoader } from './LoadingStates';
import {
  PriorityBadge,
  StatusBadge,
  Card,
  ProgressBar,
  EmptyState as DSEmptyState,
  CountBadge,
} from './design-system';

// ShiftFocus Design System: Risk icon colors
const riskColors = {
  high: 'text-[var(--danger)]',
  medium: 'text-[var(--warning-dark)]',
  low: 'text-[var(--on-track)]',
};

// Helper to resolve project group keys to display names
const getProjectGroupLabel = (projectId: string): { label: string; icon: string } => {
  const project = db.getProjectById(projectId);
  if (project) return { label: project.name, icon: project.icon };
  return { label: 'Unknown', icon: '❓' };
};

const ListView = () => {
  const loader = React.useCallback(() => db.getTasks(), []);
  const { data: rawTasks, isLoading, hasError, errorMessage, retry } = useDataLoader(loader, 800);
  const allTasks = rawTasks || [];
  const { applySort, applyFilters, applyGrouping, filters } = useFilters();
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [checkedTasks, setCheckedTasks] = useState<Set<string>>(new Set());

  const tasks = useMemo(() => {
    const filtered = applyFilters(allTasks);
    return applySort(filtered);
  }, [allTasks, applyFilters, applySort]);

  const groupedTasks = useMemo(() => applyGrouping(tasks), [tasks, applyGrouping]);

  const handleCheckboxToggle = (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCheckedTasks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  const toggleExpanded = (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedTask(expandedTask === taskId ? null : taskId);
  };

  if (isLoading) return <ListSkeleton rows={8} />;
  if (hasError) return <ErrorState message={errorMessage || 'Failed to load tasks from local storage.'} onRetry={retry} />;
  if (tasks.length === 0) return <DSEmptyState title="No tasks match your filters" description="Try adjusting your filter criteria or create a new task." />;

  return (
    <>
      {/* ShiftFocus Design System: Card Container - 12px radius, precise border and shadow */}
      {Array.from(groupedTasks.entries()).map(([groupKey, groupTasks]) => (
        <div key={groupKey} className="mb-6">
          {filters.groupField !== 'none' && (
            <div className="mb-3 flex items-center gap-2">
              {filters.groupField === 'project' ? (
                <>
                  <span className="text-[16px]">{getProjectGroupLabel(groupKey).icon}</span>
                  <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">{getProjectGroupLabel(groupKey).label}</h3>
                </>
              ) : (
                <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">{groupKey}</h3>
              )}
              <CountBadge count={groupTasks.length} />
            </div>
          )}
          <Card>
            
            {/* Table Header - Fixed 40px height, 12px Medium UPPERCASE */}
            <div className="h-[40px] bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]">
              <div className="grid grid-cols-[40px_100px_1fr_160px_120px_100px_100px_80px_40px] gap-3 h-full items-center px-4">
                <div className="flex items-center justify-center">
                  <input
                    type="checkbox"
                    className="w-5 h-5 rounded border-2 border-[var(--neutral-200)] text-[var(--brand-primary)] focus:ring-0 focus:ring-offset-0 transition-colors"
                    onChange={(e) => {
                      if (e.target.checked) {
                        setCheckedTasks(new Set(groupTasks.map(t => t.id)));
                      } else {
                        setCheckedTasks(new Set());
                      }
                    }}
                    checked={checkedTasks.size === groupTasks.length && groupTasks.length > 0}
                  />
                </div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">Priority</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">Task Name</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">Assignee</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">Status</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">Due Date</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">KR Impact</div>
                <div className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase text-center">Risk</div>
                <div></div>
              </div>
            </div>

            {/* Table Body */}
            <div>
              {groupTasks.map((task, index) => (
                <motion.div key={task.id}>
                  {/* Table Row - Fixed 48px height */}
                  <motion.div
                    className={`
                      h-[48px] border-b border-[var(--neutral-200)] cursor-pointer
                      transition-colors duration-[80ms]
                      ${expandedTask === task.id ? 'bg-[var(--info-bg)]' : 'bg-white hover:bg-[var(--neutral-50)]'}
                      ${checkedTasks.has(task.id) ? 'bg-[var(--info-bg)]' : ''}
                    `}
                    onClick={() => setSelectedTask(task)}
                    whileHover={{ backgroundColor: expandedTask === task.id ? 'var(--info-bg)' : 'var(--neutral-50)' }}
                  >
                    <div className="grid grid-cols-[40px_100px_1fr_160px_120px_100px_100px_80px_40px] gap-3 h-full items-center px-4">
                      
                      {/* Checkbox - 20px × 20px */}
                      <div className="flex items-center justify-center">
                        <input
                          type="checkbox"
                          checked={checkedTasks.has(task.id)}
                          onChange={(e) => handleCheckboxToggle(task.id, e)}
                          onClick={(e) => e.stopPropagation()}
                          className="w-5 h-5 rounded border-2 border-[var(--neutral-200)] text-[var(--brand-primary)] focus:ring-0 focus:ring-offset-0 transition-colors cursor-pointer"
                        />
                      </div>

                      {/* Priority Badge - 24px height, 6px radius */}
                      <div className="flex items-center">
                        <PriorityBadge value={task.priority} />
                      </div>

                      {/* Task Name with expand button */}
                      <div className="flex items-center gap-2 min-w-0">
                        <button
                          onClick={(e) => toggleExpanded(task.id, e)}
                          className="shrink-0 w-6 h-6 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-colors"
                        >
                          {expandedTask === task.id ? (
                            <ChevronDown size={16} className="text-[var(--neutral-600)]" />
                          ) : (
                            <ChevronRight size={16} className="text-[var(--neutral-600)]" />
                          )}
                        </button>
                        <div className="min-w-0 flex-1">
                          <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] truncate">
                            {task.title}
                          </div>
                          <div className="flex items-center gap-3 mt-0.5">
                            {task.comments && (
                              <div className="flex items-center gap-1 text-[var(--neutral-400)]">
                                <MessageSquare size={12} />
                                <span className="text-[12px] font-normal leading-[1.3]">{task.comments}</span>
                              </div>
                            )}
                            {task.attachments && (
                              <div className="flex items-center gap-1 text-[var(--neutral-400)]">
                                <Paperclip size={12} />
                                <span className="text-[12px] font-normal leading-[1.3]">{task.attachments}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Assignee - Avatar 32px */}
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[12px] font-medium shrink-0">
                          {task.assignee.avatar}
                        </div>
                        <span className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] truncate">
                          {task.assignee.name}
                        </span>
                      </div>

                      {/* Status Badge - 24px height, 6px radius */}
                      <div className="flex items-center">
                        <StatusBadge value={task.status} />
                      </div>

                      {/* Due Date */}
                      <div className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)]">
                        {task.dueDate ? new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—'}
                      </div>

                      {/* KR Impact with icon */}
                      <div className="flex items-center gap-1">
                        <TrendingUp size={14} className="text-[var(--brand-primary)]" />
                        <span className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">
                          {task.krImpact}%
                        </span>
                      </div>

                      {/* AI Risk Icon */}
                      <div className="flex items-center justify-center">
                        <div className={`
                          w-8 h-8 rounded-full flex items-center justify-center
                          ${task.aiRisk === 'high' ? 'bg-[var(--danger-light)]' : task.aiRisk === 'medium' ? 'bg-[var(--warning-light)]' : 'bg-[var(--success-light)]'}
                        `}>
                          <AlertTriangle size={14} className={riskColors[task.aiRisk]} />
                        </div>
                      </div>

                      {/* Actions Menu */}
                      <div className="flex items-center justify-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Action menu logic here
                          }}
                          className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors"
                        >
                          <MoreHorizontal size={16} className="text-[var(--neutral-400)]" />
                        </button>
                      </div>
                    </div>
                  </motion.div>

                  {/* Expanded Row Details */}
                  <AnimatePresence>
                    {expandedTask === task.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                        className="overflow-hidden bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]"
                      >
                        <div className="p-6">
                          <div className="grid grid-cols-2 gap-8">
                            
                            {/* Left Column: Task Details */}
                            <div className="space-y-4">
                              <div>
                                <h4 className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] uppercase tracking-[0.01em] mb-2">
                                  Description
                                </h4>
                                <p className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)]">
                                  {task.description}
                                </p>
                              </div>

                              <div>
                                <h4 className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] uppercase tracking-[0.01em] mb-2">
                                  Progress Timeline
                                </h4>
                                <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                                  <motion.div
                                    initial={{ width: 0 }}
                                    animate={{ width: `${task.krImpact}%` }}
                                    transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
                                    className="h-full bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-full"
                                  />
                                </div>
                                <div className="flex justify-between mt-1">
                                  <span className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">Started</span>
                                  <span className="text-[12px] font-medium leading-[1.3] text-[var(--brand-primary)]">{task.krImpact}% Complete</span>
                                </div>
                              </div>

                              <div>
                                <h4 className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] uppercase tracking-[0.01em] mb-2">
                                  Quick Actions
                                </h4>
                                <div className="flex gap-2">
                                  <button className="h-8 px-4 bg-white border border-[var(--neutral-200)] rounded-lg text-[12px] font-medium text-[var(--neutral-800)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] transition-all">
                                    Add Subtask
                                  </button>
                                  <button className="h-8 px-4 bg-white border border-[var(--neutral-200)] rounded-lg text-[12px] font-medium text-[var(--neutral-800)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] transition-all">
                                    Link Task
                                  </button>
                                  <button className="h-8 px-4 bg-white border border-[var(--neutral-200)] rounded-lg text-[12px] font-medium text-[var(--neutral-800)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] transition-all">
                                    View History
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Right Column: AI Insights */}
                            <div className="space-y-3">
                              <h4 className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] uppercase tracking-[0.01em] mb-2">
                                AI Insights
                              </h4>
                              
                              {/* High Risk Insight */}
                              {task.aiRisk === 'high' && (
                                <motion.div
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="p-4 bg-white rounded-lg border border-[var(--neutral-200)] hover:border-[var(--danger)] hover:shadow-[var(--shadow-card-hover)] transition-all"
                                >
                                  <div className="flex gap-3">
                                    <div className="w-8 h-8 bg-[var(--danger-light)] rounded-full flex items-center justify-center shrink-0">
                                      <AlertTriangle size={16} className="text-[var(--danger)]" />
                                    </div>
                                    <div className="flex-1">
                                      <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                                        Critical: Task blocking sprint goals
                                      </div>
                                      <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)] mb-3">
                                        This task is delaying your sprint by 2.1 days. Consider prioritizing or reassigning resources.
                                      </div>
                                      <button className="h-7 px-3 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white text-[12px] font-medium rounded-lg hover:shadow-[var(--shadow-brand-hover)] transition-all">
                                        View Recommendations
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}

                              {/* Medium Risk Insight */}
                              {task.aiRisk === 'medium' && (
                                <motion.div
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="p-4 bg-white rounded-lg border border-[var(--neutral-200)] hover:border-[var(--warning-dark)] hover:shadow-[var(--shadow-card-hover)] transition-all"
                                >
                                  <div className="flex gap-3">
                                    <div className="w-8 h-8 bg-[var(--warning-light)] rounded-full flex items-center justify-center shrink-0">
                                      <TrendingUp size={16} className="text-[var(--warning-dark)]" />
                                    </div>
                                    <div className="flex-1">
                                      <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                                        Optimization opportunity detected
                                      </div>
                                      <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)] mb-3">
                                        AI suggests breaking this into 2 subtasks for better tracking and parallelization.
                                      </div>
                                      <button className="h-7 px-3 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white text-[12px] font-medium rounded-lg hover:shadow-[var(--shadow-brand-hover)] transition-all">
                                        Auto-Create Subtasks
                                      </button>
                                    </div>
                                  </div>
                                </motion.div>
                              )}

                              {/* Low Risk Insight */}
                              {task.aiRisk === 'low' && (
                                <motion.div
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="p-4 bg-white rounded-lg border border-[var(--neutral-200)] hover:border-[var(--on-track)] hover:shadow-[var(--shadow-card-hover)] transition-all"
                                >
                                  <div className="flex gap-3">
                                    <div className="w-8 h-8 bg-[var(--success-light)] rounded-full flex items-center justify-center shrink-0">
                                      <TrendingUp size={16} className="text-[var(--on-track)]" />
                                    </div>
                                    <div className="flex-1">
                                      <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                                        On track - No issues detected
                                      </div>
                                      <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                                        Task is progressing as expected. Keep up the momentum!
                                      </div>
                                    </div>
                                  </div>
                                </motion.div>
                              )}

                              {/* Additional Insight */}
                              <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.1 }}
                                className="p-4 bg-white rounded-lg border border-[var(--neutral-200)] hover:shadow-[var(--shadow-card-hover)] transition-all"
                              >
                                <div className="flex gap-3">
                                  <div className="w-8 h-8 bg-[var(--info-bg)] rounded-full flex items-center justify-center shrink-0">
                                    <TrendingUp size={16} className="text-[var(--brand-primary)]" />
                                  </div>
                                  <div className="flex-1">
                                    <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                                      Impact Analysis
                                    </div>
                                    <div className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                                      This task contributes {task.krImpact}% towards your quarterly KR target of "Increase platform reliability".
                                    </div>
                                  </div>
                                </div>
                              </motion.div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              ))}
            </div>
          </Card>
        </div>
      ))}

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
        />
      )}
    </>
  );
};

export default ListView;
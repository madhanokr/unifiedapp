import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronDown,
  ChevronRight,
  Plus,
  MoreHorizontal,
  Inbox,
  FolderKanban,
  Pencil,
  Palette,
  Trash2,
  PanelLeftClose,
  PanelLeftOpen,
  Layers,
  X,
  Check,
} from 'lucide-react';
import { db, Project, PROJECT_COLOR_MAP } from './data-store';
import { useFilters } from './FilterContext';
import ConfirmDialog from './ConfirmDialog';
import { sfToast } from './design-system';

const PROJECT_COLORS = [
  { id: 'brand', label: 'Brand' },
  { id: 'danger', label: 'Red' },
  { id: 'warning', label: 'Orange' },
  { id: 'success', label: 'Green' },
  { id: 'info', label: 'Blue' },
  { id: 'neutral', label: 'Gray' },
];

const EMOJI_OPTIONS = ['📥', '🏃', '🗺️', '🎯', '🚀', '💡', '🔧', '📊', '🎨', '📋', '⚡', '🏆'];

interface ProjectSidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

const ProjectSidebar: React.FC<ProjectSidebarProps> = ({ collapsed, onToggleCollapse }) => {
  const { filters, setActiveProjectId } = useFilters();
  const [projects, setProjects] = useState<Project[]>(() => db.getProjects());
  const [isExpanded, setIsExpanded] = useState(true);
  const [showNewProject, setShowNewProject] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectIcon, setNewProjectIcon] = useState('📋');
  const [newProjectColor, setNewProjectColor] = useState('brand');
  const [editingProject, setEditingProject] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [contextMenu, setContextMenu] = useState<string | null>(null);
  const [showColorPicker, setShowColorPicker] = useState<string | null>(null);
  const [showIconPicker, setShowIconPicker] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ open: boolean; project: Project | null; taskCount: number }>({
    open: false,
    project: null,
    taskCount: 0,
  });

  const refreshProjects = () => setProjects(db.getProjects());

  const allTasks = useMemo(() => db.getTasks(), [projects]); // eslint-disable-line react-hooks/exhaustive-deps
  const getTaskCount = (projectId: string) => allTasks.filter(t => t.projectId === projectId).length;
  const totalTaskCount = allTasks.length;

  const handleCreateProject = () => {
    if (!newProjectName.trim()) return;
    const created = db.createProject({
      name: newProjectName.trim(),
      icon: newProjectIcon,
      color: newProjectColor,
    });
    refreshProjects();
    setShowNewProject(false);
    setNewProjectName('');
    setNewProjectIcon('📋');
    setNewProjectColor('brand');
    sfToast.success('Project created', `"${created.name}" is ready to use.`);
  };

  const handleRenameProject = (id: string) => {
    if (!editName.trim() || id === 'inbox') return;
    db.updateProject(id, { name: editName.trim() });
    refreshProjects();
    setEditingProject(null);
    sfToast.success('Project renamed');
  };

  const handleDeleteProject = (project: Project) => {
    const taskCount = getTaskCount(project.id);
    setDeleteConfirm({ open: true, project, taskCount });
    setContextMenu(null);
  };

  const confirmDelete = () => {
    if (!deleteConfirm.project) return;
    const result = db.deleteProject(deleteConfirm.project.id);
    if (result) {
      refreshProjects();
      if (filters.activeProjectId === deleteConfirm.project.id) {
        setActiveProjectId(null);
      }
      sfToast.success(
        'Project deleted',
        `"${result.deletedProject.name}" removed. ${result.movedTaskCount} task${result.movedTaskCount !== 1 ? 's' : ''} moved to Inbox.`
      );
    }
    setDeleteConfirm({ open: false, project: null, taskCount: 0 });
  };

  const handleChangeColor = (projectId: string, color: string) => {
    db.updateProject(projectId, { color });
    refreshProjects();
    setShowColorPicker(null);
    setContextMenu(null);
  };

  const handleChangeIcon = (projectId: string, icon: string) => {
    db.updateProject(projectId, { icon });
    refreshProjects();
    setShowIconPicker(null);
    setContextMenu(null);
  };

  if (collapsed) {
    return (
      <div className="w-12 bg-[var(--bg-level-0)] border-r border-[var(--neutral-200)] flex flex-col items-center py-4 shrink-0">
        <button
          onClick={onToggleCollapse}
          className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors text-[var(--neutral-600)]"
        >
          <PanelLeftOpen size={16} />
        </button>
        <div className="w-6 h-px bg-[var(--neutral-200)] my-3" />
        {/* Collapsed project icons */}
        <button
          onClick={() => { onToggleCollapse(); setActiveProjectId(null); }}
          className={`w-8 h-8 flex items-center justify-center rounded-lg mb-1 transition-colors ${
            filters.activeProjectId === null ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)]' : 'text-[var(--neutral-600)] hover:bg-[var(--neutral-100)]'
          }`}
        >
          <Layers size={16} />
        </button>
        {projects.map(p => (
          <button
            key={p.id}
            onClick={() => { onToggleCollapse(); setActiveProjectId(p.id); }}
            className={`w-8 h-8 flex items-center justify-center rounded-lg mb-1 transition-colors text-[14px] ${
              filters.activeProjectId === p.id ? 'bg-[var(--brand-primary-light)]' : 'hover:bg-[var(--neutral-100)]'
            }`}
            title={p.name}
          >
            {p.icon}
          </button>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="w-[240px] bg-[var(--bg-level-0)] border-r border-[var(--neutral-200)] flex flex-col shrink-0 overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-[var(--neutral-200)]">
          <span className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] uppercase tracking-[0.01em]">
            Projects
          </span>
          <button
            onClick={onToggleCollapse}
            className="w-7 h-7 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors text-[var(--neutral-400)]"
          >
            <PanelLeftClose size={14} />
          </button>
        </div>

        {/* Scrollable Project List */}
        <div className="flex-1 overflow-y-auto px-2 py-2">
          {/* All Tasks */}
          <button
            onClick={() => setActiveProjectId(null)}
            className={`
              w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[14px] font-medium transition-all duration-[120ms] mb-1
              ${filters.activeProjectId === null
                ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)]'
                : 'text-[var(--neutral-800)] hover:bg-[var(--neutral-100)]'
              }
            `}
          >
            <Layers size={16} />
            <span className="flex-1 text-left truncate">All Tasks</span>
            <span className="text-[12px] font-normal text-[var(--neutral-400)] tabular-nums">
              {totalTaskCount}
            </span>
          </button>

          {/* Collapsible Section Header */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full flex items-center gap-2 px-3 py-1.5 text-[12px] font-medium text-[var(--neutral-400)] uppercase tracking-[0.01em] hover:text-[var(--neutral-600)] transition-colors"
          >
            {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            Projects
          </button>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                className="overflow-hidden"
              >
                {projects.map((project) => {
                  const count = getTaskCount(project.id);
                  const isActive = filters.activeProjectId === project.id;
                  const colorVar = PROJECT_COLOR_MAP[project.color] || 'var(--neutral-600)';

                  return (
                    <div key={project.id} className="relative group">
                      {editingProject === project.id ? (
                        /* Inline Rename */
                        <div className="flex items-center gap-2 px-3 py-1.5">
                          <span className="text-[14px]">{project.icon}</span>
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            onBlur={() => handleRenameProject(project.id)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleRenameProject(project.id);
                              if (e.key === 'Escape') setEditingProject(null);
                            }}
                            className="flex-1 text-[14px] font-medium bg-transparent border-b border-[var(--brand-primary)] focus:outline-none text-[var(--neutral-800)] min-w-0"
                            autoFocus
                          />
                        </div>
                      ) : (
                        <button
                          onClick={() => setActiveProjectId(project.id)}
                          className={`
                            w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[14px] font-medium transition-all duration-[120ms]
                            ${isActive
                              ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)]'
                              : 'text-[var(--neutral-800)] hover:bg-[var(--neutral-100)]'
                            }
                          `}
                        >
                          <span className="text-[14px]">{project.icon}</span>
                          <span className="flex-1 text-left truncate">{project.name}</span>
                          <span className="text-[12px] font-normal text-[var(--neutral-400)] tabular-nums mr-1">
                            {count}
                          </span>
                          {/* Context Menu Trigger */}
                          {project.id !== 'inbox' && (
                            <span
                              onClick={(e) => {
                                e.stopPropagation();
                                setContextMenu(contextMenu === project.id ? null : project.id);
                              }}
                              className="opacity-0 group-hover:opacity-100 w-6 h-6 flex items-center justify-center hover:bg-[var(--neutral-200)] rounded transition-all shrink-0"
                            >
                              <MoreHorizontal size={14} className="text-[var(--neutral-400)]" />
                            </span>
                          )}
                        </button>
                      )}

                      {/* Context Menu Dropdown */}
                      <AnimatePresence>
                        {contextMenu === project.id && project.id !== 'inbox' && (
                          <motion.div
                            initial={{ opacity: 0, y: -4, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -4, scale: 0.95 }}
                            transition={{ duration: 0.1 }}
                            className="absolute right-2 top-full z-50 w-[180px] bg-white rounded-lg border border-[var(--neutral-200)] shadow-[var(--shadow-dropdown)] py-1"
                          >
                            <button
                              onClick={() => {
                                setEditName(project.name);
                                setEditingProject(project.id);
                                setContextMenu(null);
                              }}
                              className="w-full flex items-center gap-2 px-3 py-2 text-[14px] font-normal text-[var(--neutral-800)] hover:bg-[var(--neutral-50)] transition-colors"
                            >
                              <Pencil size={14} className="text-[var(--neutral-400)]" />
                              Rename
                            </button>
                            <button
                              onClick={() => {
                                setShowIconPicker(project.id);
                                setContextMenu(null);
                              }}
                              className="w-full flex items-center gap-2 px-3 py-2 text-[14px] font-normal text-[var(--neutral-800)] hover:bg-[var(--neutral-50)] transition-colors"
                            >
                              <span className="w-[14px] text-center text-[14px]">{project.icon}</span>
                              Change Icon
                            </button>
                            <button
                              onClick={() => {
                                setShowColorPicker(project.id);
                                setContextMenu(null);
                              }}
                              className="w-full flex items-center gap-2 px-3 py-2 text-[14px] font-normal text-[var(--neutral-800)] hover:bg-[var(--neutral-50)] transition-colors"
                            >
                              <Palette size={14} className="text-[var(--neutral-400)]" />
                              Change Color
                            </button>
                            <div className="h-px bg-[var(--neutral-200)] my-1" />
                            <button
                              onClick={() => handleDeleteProject(project)}
                              className="w-full flex items-center gap-2 px-3 py-2 text-[14px] font-normal text-[var(--danger)] hover:bg-[var(--danger-bg)] transition-colors"
                            >
                              <Trash2 size={14} />
                              Delete
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Color Picker Popover */}
                      <AnimatePresence>
                        {showColorPicker === project.id && (
                          <motion.div
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -4 }}
                            transition={{ duration: 0.1 }}
                            className="absolute right-2 top-full z-50 w-[180px] bg-white rounded-lg border border-[var(--neutral-200)] shadow-[var(--shadow-dropdown)] p-3"
                          >
                            <div className="text-[12px] font-medium text-[var(--neutral-600)] mb-2">Color</div>
                            <div className="grid grid-cols-3 gap-2">
                              {PROJECT_COLORS.map(c => (
                                <button
                                  key={c.id}
                                  onClick={() => handleChangeColor(project.id, c.id)}
                                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg border transition-colors text-[12px] ${
                                    project.color === c.id
                                      ? 'border-[var(--brand-primary)] bg-[var(--brand-primary-light)]'
                                      : 'border-[var(--neutral-200)] hover:border-[var(--neutral-400)]'
                                  }`}
                                >
                                  <div
                                    className="w-3 h-3 rounded-full shrink-0"
                                    style={{ backgroundColor: PROJECT_COLOR_MAP[c.id] }}
                                  />
                                  <span className="text-[var(--neutral-800)]">{c.label}</span>
                                </button>
                              ))}
                            </div>
                            <button
                              onClick={() => setShowColorPicker(null)}
                              className="mt-2 w-full text-center text-[12px] text-[var(--neutral-400)] hover:text-[var(--neutral-600)]"
                            >
                              Close
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Icon Picker Popover */}
                      <AnimatePresence>
                        {showIconPicker === project.id && (
                          <motion.div
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -4 }}
                            transition={{ duration: 0.1 }}
                            className="absolute right-2 top-full z-50 w-[200px] bg-white rounded-lg border border-[var(--neutral-200)] shadow-[var(--shadow-dropdown)] p-3"
                          >
                            <div className="text-[12px] font-medium text-[var(--neutral-600)] mb-2">Icon</div>
                            <div className="grid grid-cols-6 gap-1">
                              {EMOJI_OPTIONS.map(emoji => (
                                <button
                                  key={emoji}
                                  onClick={() => handleChangeIcon(project.id, emoji)}
                                  className={`w-8 h-8 flex items-center justify-center rounded-lg text-[16px] transition-colors ${
                                    project.icon === emoji
                                      ? 'bg-[var(--brand-primary-light)]'
                                      : 'hover:bg-[var(--neutral-100)]'
                                  }`}
                                >
                                  {emoji}
                                </button>
                              ))}
                            </div>
                            <button
                              onClick={() => setShowIconPicker(null)}
                              className="mt-2 w-full text-center text-[12px] text-[var(--neutral-400)] hover:text-[var(--neutral-600)]"
                            >
                              Close
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </motion.div>
            )}
          </AnimatePresence>

          {/* New Project Form */}
          <AnimatePresence>
            {showNewProject && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.12 }}
                className="overflow-hidden"
              >
                <div className="px-3 py-3 mx-1 bg-[var(--neutral-50)] rounded-lg border border-[var(--neutral-200)] mt-1">
                  <div className="flex items-center gap-2 mb-2">
                    {/* Icon selector */}
                    <button
                      onClick={() => {
                        const idx = EMOJI_OPTIONS.indexOf(newProjectIcon);
                        setNewProjectIcon(EMOJI_OPTIONS[(idx + 1) % EMOJI_OPTIONS.length] || '📋');
                      }}
                      className="w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-[var(--neutral-200)] text-[14px] hover:border-[var(--brand-primary)] transition-colors"
                      title="Click to change icon"
                    >
                      {newProjectIcon}
                    </button>
                    <input
                      type="text"
                      value={newProjectName}
                      onChange={(e) => setNewProjectName(e.target.value)}
                      placeholder="Project name..."
                      className="flex-1 text-[14px] font-medium bg-white border border-[var(--neutral-200)] rounded-lg px-3 py-1.5 focus:outline-none focus:border-[var(--brand-primary)] text-[var(--neutral-800)] placeholder:text-[var(--neutral-400)]"
                      autoFocus
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleCreateProject();
                        if (e.key === 'Escape') setShowNewProject(false);
                      }}
                    />
                  </div>
                  {/* Color selector */}
                  <div className="flex items-center gap-1 mb-2">
                    {PROJECT_COLORS.map(c => (
                      <button
                        key={c.id}
                        onClick={() => setNewProjectColor(c.id)}
                        className={`w-5 h-5 rounded-full border-2 transition-colors ${
                          newProjectColor === c.id ? 'border-[var(--brand-primary)] scale-110' : 'border-transparent'
                        }`}
                        title={c.label}
                      >
                        <div
                          className="w-full h-full rounded-full"
                          style={{ backgroundColor: PROJECT_COLOR_MAP[c.id] }}
                        />
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCreateProject}
                      disabled={!newProjectName.trim()}
                      className={`flex-1 h-7 text-[12px] font-medium rounded-lg transition-all ${
                        newProjectName.trim()
                          ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white hover:shadow-[var(--shadow-brand)]'
                          : 'bg-[var(--neutral-200)] text-[var(--neutral-400)] cursor-not-allowed'
                      }`}
                    >
                      Create
                    </button>
                    <button
                      onClick={() => { setShowNewProject(false); setNewProjectName(''); }}
                      className="h-7 px-3 text-[12px] font-medium text-[var(--neutral-600)] hover:bg-[var(--neutral-200)] rounded-lg transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Bottom: New Project Button */}
        <div className="px-3 py-3 border-t border-[var(--neutral-200)]">
          <button
            onClick={() => setShowNewProject(true)}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-[14px] font-medium text-[var(--brand-primary)] hover:bg-[var(--brand-primary-light)] transition-colors"
          >
            <Plus size={16} />
            New Project
          </button>
        </div>
      </div>

      {/* Click-away overlay for context menus */}
      {(contextMenu || showColorPicker || showIconPicker) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setContextMenu(null);
            setShowColorPicker(null);
            setShowIconPicker(null);
          }}
        />
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteConfirm.open}
        onOpenChange={(open) => setDeleteConfirm(prev => ({ ...prev, open }))}
        title="Delete Project"
        description={`Deleting "${deleteConfirm.project?.name}" will move ${deleteConfirm.taskCount} task${deleteConfirm.taskCount !== 1 ? 's' : ''} to Inbox. This action cannot be undone. Continue?`}
        confirmLabel="Delete Project"
        variant="destructive"
        onConfirm={confirmDelete}
      />
    </>
  );
};

export default ProjectSidebar;

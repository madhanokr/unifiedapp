import React from 'react';
import { X, ArrowUpDown, Layers, SlidersHorizontal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useFilters, SortField, GroupField } from './FilterContext';
import {
  Button,
  Badge,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from './design-system';

const SORT_OPTIONS: { field: SortField; label: string }[] = [
  { field: 'dueDate', label: 'Due Date' },
  { field: 'priority', label: 'Priority' },
  { field: 'krImpact', label: 'KR Impact' },
  { field: 'aiRisk', label: 'AI Risk' },
  { field: 'title', label: 'Title (A-Z)' },
  { field: 'status', label: 'Status' },
];

const GROUP_OPTIONS: { field: GroupField; label: string }[] = [
  { field: 'none', label: 'No Grouping' },
  { field: 'project', label: 'Project' },
  { field: 'priority', label: 'Priority' },
  { field: 'status', label: 'Status' },
  { field: 'assignee', label: 'Assignee' },
  { field: 'aiRisk', label: 'AI Risk Level' },
];

const COLUMN_OPTIONS = [
  { id: 'priority', label: 'Priority' },
  { id: 'assignee', label: 'Assignee' },
  { id: 'status', label: 'Status' },
  { id: 'dueDate', label: 'Due Date' },
  { id: 'krImpact', label: 'KR Impact' },
  { id: 'aiRisk', label: 'AI Risk' },
  { id: 'comments', label: 'Comments' },
  { id: 'attachments', label: 'Attachments' },
];

const STATUS_OPTIONS = ['In Progress', 'Not Started', 'Blocked', 'Waiting', 'Completed'];
const PRIORITY_OPTIONS = ['Critical', 'High', 'Medium', 'Low'];

const FilterBar = () => {
  const {
    filters,
    setSortField,
    setGroupField,
    toggleColumn,
    toggleStatusFilter,
    togglePriorityFilter,
    clearAllFilters,
  } = useFilters();

  const activeFilterChips: { label: string; onRemove: () => void }[] = [];
  filters.statusFilters.forEach((s) => {
    activeFilterChips.push({ label: `Status: ${s}`, onRemove: () => toggleStatusFilter(s) });
  });
  filters.priorityFilters.forEach((p) => {
    activeFilterChips.push({ label: `Priority: ${p}`, onRemove: () => togglePriorityFilter(p) });
  });

  const currentSortLabel = SORT_OPTIONS.find((o) => o.field === filters.sortField)?.label || 'Due Date';
  const currentGroupLabel = GROUP_OPTIONS.find((o) => o.field === filters.groupField)?.label || 'None';

  return (
    <div className="bg-[var(--bg-level-0)] border-b border-[var(--neutral-200)] h-16">
      <div className="h-full px-8 flex items-center justify-between">
        {/* Left: Filter Chips */}
        <div className="flex items-center gap-2">
          <AnimatePresence>
            {activeFilterChips.map((chip) => (
              <motion.div
                key={chip.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.12, ease: [0.4, 0.0, 0.2, 1] }}
              >
                <Badge variant="brand" size="md" className="gap-2 cursor-default">
                  {chip.label}
                  <button
                    onClick={chip.onRemove}
                    className="w-4 h-4 flex items-center justify-center text-[var(--brand-primary)] hover:text-[var(--danger)] transition-colors"
                  >
                    <X size={12} />
                  </button>
                </Badge>
              </motion.div>
            ))}
          </AnimatePresence>

          {activeFilterChips.length === 0 && (
            <span className="text-[14px] text-[var(--text-tertiary)]">No active filters</span>
          )}

          {activeFilterChips.length > 0 && (
            <Button variant="destructive" size="sm" onClick={clearAllFilters}>
              Clear All
            </Button>
          )}
        </div>

        {/* Right: Sort, Group, Customize */}
        <div className="flex items-center gap-3">
          {/* Sort Dropdown — Radix */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" icon={<ArrowUpDown size={14} />}>
                Sort: {currentSortLabel}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[220px]">
              <DropdownMenuLabel>Sort by</DropdownMenuLabel>
              <DropdownMenuRadioGroup
                value={filters.sortField}
                onValueChange={(v) => setSortField(v as SortField)}
              >
                {SORT_OPTIONS.map((opt) => (
                  <DropdownMenuRadioItem key={opt.field} value={opt.field}>
                    {opt.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Group Dropdown — Radix */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" icon={<Layers size={14} />}>
                Group: {currentGroupLabel}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[220px]">
              <DropdownMenuLabel>Group by</DropdownMenuLabel>
              <DropdownMenuRadioGroup
                value={filters.groupField}
                onValueChange={(v) => setGroupField(v as GroupField)}
              >
                {GROUP_OPTIONS.map((opt) => (
                  <DropdownMenuRadioItem key={opt.field} value={opt.field}>
                    {opt.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Customize Dropdown — Radix */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" icon={<SlidersHorizontal size={14} />}>
                Customize
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[280px]">
              <DropdownMenuLabel>Visible Columns</DropdownMenuLabel>
              {COLUMN_OPTIONS.map((col) => (
                <DropdownMenuCheckboxItem
                  key={col.id}
                  checked={!filters.hiddenColumns.has(col.id)}
                  onCheckedChange={() => toggleColumn(col.id)}
                >
                  {col.label}
                </DropdownMenuCheckboxItem>
              ))}

              <DropdownMenuSeparator />

              <DropdownMenuLabel>Filter by Status</DropdownMenuLabel>
              {STATUS_OPTIONS.map((status) => (
                <DropdownMenuCheckboxItem
                  key={status}
                  checked={filters.statusFilters.has(status)}
                  onCheckedChange={() => toggleStatusFilter(status)}
                >
                  {status}
                </DropdownMenuCheckboxItem>
              ))}

              <DropdownMenuSeparator />

              <DropdownMenuLabel>Filter by Priority</DropdownMenuLabel>
              {PRIORITY_OPTIONS.map((priority) => (
                <DropdownMenuCheckboxItem
                  key={priority}
                  checked={filters.priorityFilters.has(priority)}
                  onCheckedChange={() => togglePriorityFilter(priority)}
                >
                  {priority}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};

export default FilterBar;
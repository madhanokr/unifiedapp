import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { Activity, TrendingUp, Target, BarChart3 } from 'lucide-react';
import { db } from './data-store';
import { ChartSkeleton, ErrorState, useSimulatedLoading } from './LoadingStates';

/* ── Chart Color Tokens ─────────────────────────────────────
 * Recharts renders SVG, which supports CSS custom properties
 * via `var(--token)` in `stroke`, `fill`, and `style` props.
 * We use the design-system chart tokens so dark/light themes
 * propagate automatically.
 * ──────────────────────────────────────────────────────────── */

const COLORS = {
  primary: 'var(--chart-primary)',
  primaryLight: 'var(--brand-primary-light)',
  success: 'var(--chart-success)',
  successLight: 'var(--success-light)',
  warning: 'var(--chart-warning)',
  warningLight: 'var(--warning-light)',
  danger: 'var(--chart-danger)',
  dangerLight: 'var(--danger-light)',
  info: 'var(--info)',
  infoLight: 'var(--info-light)',
  neutral: 'var(--chart-secondary)',
  grid: 'var(--chart-grid)',
  axis: 'var(--chart-axis)',
};

const PRIORITY_COLORS: Record<string, string> = {
  Critical: COLORS.danger,
  High: COLORS.warning,
  Medium: COLORS.info,
  Low: COLORS.neutral,
};

const STATUS_COLORS: Record<string, string> = {
  'In Progress': COLORS.info,
  'Not Started': COLORS.neutral,
  'Blocked': COLORS.danger,
  'Waiting': COLORS.warning,
  'Completed': COLORS.success,
};

/* ── Custom Tooltip ──────────────────────────────────────── */

interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string; color: string }>;
  label?: string;
}

const CustomTooltip = ({ active, payload, label }: ChartTooltipProps) => {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-[var(--bg-level-0)] rounded-lg shadow-[var(--shadow-elevated)] border border-[var(--neutral-200)] px-4 py-3">
      <p className="text-[12px] font-medium text-[var(--text-primary)] mb-1.5">{label}</p>
      {payload.map((entry, i: number) => (
        <div key={i} className="flex items-center gap-2 text-[12px]">
          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-[var(--text-secondary)]">{entry.name}:</span>
          <span className="font-medium text-[var(--text-primary)]">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

/* ── Main Charts Component ───────────────────────────────── */

const SprintHealthCharts = () => {
  const { isLoading } = useSimulatedLoading(800);

  const tasks = useMemo(() => {
    try {
      return db.getTasks();
    } catch {
      return [];
    }
  }, []);

  const loadError = tasks.length === 0;

  /* ── Derived Data ──────────────────────────────────────── */

  // Velocity trend (simulated daily burn-up over sprint)
  const velocityData = useMemo(() => {
    const days = ['Feb 3', 'Feb 4', 'Feb 5', 'Feb 6', 'Feb 7', 'Feb 8', 'Feb 9', 'Feb 10'];
    const planned = [0, 2, 3, 5, 7, 8, 10, 12];
    const actual = [0, 1, 2, 4, 5, 6, 7, 8];
    return days.map((day, i) => ({
      day,
      Planned: planned[i],
      Actual: actual[i],
      Ideal: Math.round((12 / 7) * i),
    }));
  }, []);

  // Priority distribution
  const priorityData = useMemo(() => {
    const counts: Record<string, number> = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    tasks.forEach((t) => {
      counts[t.priority] = (counts[t.priority] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({
      name,
      value,
      fill: PRIORITY_COLORS[name] || COLORS.neutral,
    }));
  }, [tasks]);

  // Status breakdown
  const statusData = useMemo(() => {
    const counts: Record<string, number> = {};
    tasks.forEach((t) => {
      counts[t.status] = (counts[t.status] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({
      name,
      value,
      fill: STATUS_COLORS[name] || COLORS.neutral,
    }));
  }, [tasks]);

  // KR Impact by assignee
  const assigneeData = useMemo(() => {
    const map = new Map<string, { total: number; count: number; avatar: string }>();
    tasks.forEach((t) => {
      const existing = map.get(t.assignee.name);
      if (existing) {
        existing.total += t.krImpact;
        existing.count += 1;
      } else {
        map.set(t.assignee.name, { total: t.krImpact, count: 1, avatar: t.assignee.avatar });
      }
    });
    return Array.from(map.entries())
      .map(([name, data]) => ({
        name: name.split(' ')[0],
        krImpact: Math.round(data.total / data.count),
        tasks: data.count,
      }))
      .sort((a, b) => b.krImpact - a.krImpact);
  }, [tasks]);

  // Risk trend (simulated)
  const riskTrendData = useMemo(
    () => [
      { week: 'W1', high: 5, medium: 3, low: 4 },
      { week: 'W2', high: 4, medium: 4, low: 4 },
      { week: 'W3', high: 6, medium: 3, low: 3 },
      { week: 'W4', high: 4, medium: 5, low: 3 },
      { week: 'W5', high: 3, medium: 4, low: 5 },
      { week: 'Current', high: tasks.filter((t) => t.aiRisk === 'high').length, medium: tasks.filter((t) => t.aiRisk === 'medium').length, low: tasks.filter((t) => t.aiRisk === 'low').length },
    ],
    [tasks]
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-4 mb-6">
        <ChartSkeleton />
        <ChartSkeleton />
        <ChartSkeleton />
        <ChartSkeleton />
      </div>
    );
  }

  if (loadError) {
    return <ErrorState message="Failed to load sprint health data." onRetry={() => window.location.reload()} />;
  }

  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      {/* ── 1. Sprint Velocity / Burn-up ──────────────────── */}
      <motion.div
        className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05, duration: 0.15 }}
      >
        <div className="flex items-center gap-2 mb-1">
          <Activity size={16} className="text-[var(--brand-primary)]" />
          <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">Sprint Velocity</h3>
        </div>
        <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mb-4">
          Planned vs actual task completion this sprint
        </p>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={velocityData}>
            <defs>
              <linearGradient id="gradPrimary" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={COLORS.primary} stopOpacity={0.15} />
                <stop offset="95%" stopColor={COLORS.primary} stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="gradSuccess" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={COLORS.success} stopOpacity={0.15} />
                <stop offset="95%" stopColor={COLORS.success} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} />
            <XAxis
              dataKey="day"
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="Planned"
              stroke={COLORS.primary}
              fill="url(#gradPrimary)"
              strokeWidth={2}
              dot={false}
            />
            <Area
              type="monotone"
              dataKey="Actual"
              stroke={COLORS.success}
              fill="url(#gradSuccess)"
              strokeWidth={2}
              dot={{ r: 3, fill: COLORS.success, strokeWidth: 0 }}
            />
            <Line
              type="monotone"
              dataKey="Ideal"
              stroke={COLORS.neutral}
              strokeDasharray="5 5"
              strokeWidth={1.5}
              dot={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </motion.div>

      {/* ── 2. Priority Distribution ──────────────────────── */}
      <motion.div
        className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.15 }}
      >
        <div className="flex items-center gap-2 mb-1">
          <Target size={16} className="text-[var(--brand-primary)]" />
          <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">Priority Distribution</h3>
        </div>
        <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mb-4">
          Task breakdown by priority level
        </p>
        <div className="flex items-center gap-4">
          <PieChart width={160} height={160}>
            <Pie
              data={priorityData}
              cx="50%"
              cy="50%"
              innerRadius={45}
              outerRadius={70}
              paddingAngle={3}
              dataKey="value"
              strokeWidth={0}
            >
              {priorityData.map((entry, i) => (
                <Cell key={i} fill={entry.fill} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
          <div className="flex-1 space-y-2.5">
            {priorityData.map((item) => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.fill }} />
                  <span className="text-[12px] font-normal text-[var(--text-secondary)]">{item.name}</span>
                </div>
                <span className="text-[14px] font-medium text-[var(--text-primary)]">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* ── 3. KR Impact by Assignee ─────────────────────── */}
      <motion.div
        className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.15 }}
      >
        <div className="flex items-center gap-2 mb-1">
          <TrendingUp size={16} className="text-[var(--brand-primary)]" />
          <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">KR Impact by Assignee</h3>
        </div>
        <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mb-4">
          Average KR impact score per team member
        </p>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={assigneeData} barSize={28}>
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} vertical={false} />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
              domain={[0, 100]}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="krImpact" name="Avg KR Impact" radius={[4, 4, 0, 0]}>
              {assigneeData.map((_, i) => (
                <Cell key={i} fill={i === 0 ? COLORS.primary : i === 1 ? 'var(--brand-primary-hover)' : 'var(--brand-primary-light)'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* ── 4. Risk Trend ────────────────────────────────── */}
      <motion.div
        className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.15 }}
      >
        <div className="flex items-center gap-2 mb-1">
          <BarChart3 size={16} className="text-[var(--brand-primary)]" />
          <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">Risk Trend</h3>
        </div>
        <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mb-4">
          AI risk classification over recent sprints
        </p>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={riskTrendData} barSize={20}>
            <CartesianGrid strokeDasharray="3 3" stroke={COLORS.grid} vertical={false} />
            <XAxis
              dataKey="week"
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: COLORS.axis }}
              axisLine={{ stroke: COLORS.grid }}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              iconType="circle"
              iconSize={8}
              wrapperStyle={{ fontSize: '11px', color: COLORS.axis }}
            />
            <Bar dataKey="high" name="High Risk" stackId="a" fill={COLORS.danger} radius={[0, 0, 0, 0]} />
            <Bar dataKey="medium" name="Medium" stackId="a" fill={COLORS.warning} radius={[0, 0, 0, 0]} />
            <Bar dataKey="low" name="Low Risk" stackId="a" fill={COLORS.success} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>
    </div>
  );
};

export default SprintHealthCharts;
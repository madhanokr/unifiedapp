import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bell,
  CheckCircle,
  AlertTriangle,
  GitBranch,
  Clock,
  X,
  Shield,
  Zap,
  Check,
  Trash2,
} from 'lucide-react';
import { db, Notification } from './data-store';
import { Button, CountBadge } from './design-system';

interface NotificationsPanelProps {
  onClose: () => void;
}

type FilterType = 'all' | 'unread';

const NotificationsPanel: React.FC<NotificationsPanelProps> = ({ onClose }) => {
  const [notifications, setNotifications] = useState<Notification[]>(() => db.getNotifications());
  const [filter, setFilter] = useState<FilterType>('all');

  const refreshNotifications = () => setNotifications(db.getNotifications());

  const filteredNotifications = useMemo(
    () => (filter === 'unread' ? notifications.filter((n) => n.unread) : notifications),
    [notifications, filter]
  );

  const unreadCount = notifications.filter((n) => n.unread).length;

  const handleMarkRead = (id: string) => {
    db.markRead(id);
    refreshNotifications();
  };

  const handleMarkAllRead = () => {
    db.markAllRead();
    refreshNotifications();
  };

  const handleDismiss = (id: string) => {
    db.clearNotification(id);
    refreshNotifications();
  };

  const typeConfig: Record<
    string,
    { icon: React.ElementType; bg: string; iconColor: string; borderColor: string }
  > = {
    success: {
      icon: CheckCircle,
      bg: 'bg-[var(--success-light)]',
      iconColor: 'text-[var(--success-dark)]',
      borderColor: 'border-l-[var(--success-dark)]',
    },
    warning: {
      icon: AlertTriangle,
      bg: 'bg-[var(--warning-light)]',
      iconColor: 'text-[var(--warning-dark)]',
      borderColor: 'border-l-[var(--warning-dark)]',
    },
    info: {
      icon: GitBranch,
      bg: 'bg-[var(--info-light)]',
      iconColor: 'text-[var(--info-dark)]',
      borderColor: 'border-l-[var(--info-dark)]',
    },
    escalation: {
      icon: Shield,
      bg: 'bg-[var(--danger-light)]',
      iconColor: 'text-[var(--danger)]',
      borderColor: 'border-l-[var(--danger)]',
    },
    system: {
      icon: Zap,
      bg: 'bg-[var(--brand-primary-light)]',
      iconColor: 'text-[var(--brand-primary)]',
      borderColor: 'border-l-[var(--brand-primary)]',
    },
  };

  return (
    <AnimatePresence>
      <>
        {/* Backdrop */}
        <motion.div
          className="fixed inset-0 z-40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />

        {/* Panel */}
        <motion.div
          className="fixed top-[80px] right-8 w-[400px] bg-white rounded-[12px] shadow-[var(--shadow-elevated)] border border-[var(--neutral-200)] z-50 overflow-hidden"
          initial={{ opacity: 0, y: -12, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -12, scale: 0.97 }}
          transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
        >
          {/* Header */}
          <div className="px-5 py-4 border-b border-[var(--neutral-200)]">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <Bell size={18} className="text-[var(--neutral-800)]" />
                <h3 className="text-[16px] font-medium leading-[1.3] text-[var(--neutral-800)]">
                  Notifications
                </h3>
                {unreadCount > 0 && (
                  <CountBadge count={unreadCount} />
                )}
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors duration-[120ms] text-[var(--neutral-600)] hover:text-[var(--neutral-800)]"
              >
                <X size={16} />
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilter('all')}
                className={`
                  h-[32px] px-3 rounded-lg text-[12px] font-medium transition-all duration-[120ms]
                  ${filter === 'all'
                    ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)] border border-[var(--info-border)]'
                    : 'text-[var(--neutral-600)] hover:bg-[var(--neutral-100)]'
                  }
                `}
              >
                All ({notifications.length})
              </button>
              <button
                onClick={() => setFilter('unread')}
                className={`
                  h-[32px] px-3 rounded-lg text-[12px] font-medium transition-all duration-[120ms]
                  ${filter === 'unread'
                    ? 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)] border border-[var(--info-border)]'
                    : 'text-[var(--neutral-600)] hover:bg-[var(--neutral-100)]'
                  }
                `}
              >
                Unread ({unreadCount})
              </button>
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllRead}
                  className="ml-auto h-[32px] px-3 text-[12px] font-medium text-[var(--brand-primary)] hover:bg-[var(--brand-primary-light)] rounded-lg transition-colors duration-[120ms]"
                >
                  Mark all read
                </button>
              )}
            </div>
          </div>

          {/* Notifications List */}
          <div className="max-h-[460px] overflow-y-auto">
            {filteredNotifications.length === 0 ? (
              <div className="px-5 py-12 text-center">
                <Bell size={28} className="mx-auto text-[var(--neutral-200)] mb-3" />
                <p className="text-[14px] font-medium text-[var(--neutral-600)]">
                  {filter === 'unread' ? 'No unread notifications' : 'No notifications'}
                </p>
              </div>
            ) : (
              filteredNotifications.map((notification, index) => {
                const config = typeConfig[notification.type] || typeConfig['info']!;
                const Icon = config.icon;

                return (
                  <motion.div
                    key={notification.id}
                    className={`
                      px-5 py-4 border-b border-[var(--neutral-100)] hover:bg-[var(--neutral-50)] 
                      cursor-pointer transition-colors duration-[120ms] group
                      border-l-[3px] ${config.borderColor}
                      ${notification.unread ? 'bg-[var(--neutral-50)]' : 'bg-white'}
                    `}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.03, duration: 0.12 }}
                    onClick={() => handleMarkRead(notification.id)}
                  >
                    <div className="flex gap-3">
                      <div
                        className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${config.bg}`}
                      >
                        <Icon size={16} className={config.iconColor} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-1">
                          <h4 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)]">
                            {notification.title}
                          </h4>
                          <div className="flex items-center gap-1.5 ml-2 shrink-0">
                            {notification.unread && (
                              <div className="w-2 h-2 bg-[var(--brand-primary)] rounded-full" />
                            )}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDismiss(notification.id);
                              }}
                              className="opacity-0 group-hover:opacity-100 w-6 h-6 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-all"
                            >
                              <X size={12} className="text-[var(--neutral-400)]" />
                            </button>
                          </div>
                        </div>
                        <p className="text-[12px] font-normal leading-[1.5] text-[var(--neutral-600)] mb-1.5">
                          {notification.message}
                        </p>
                        <span className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
                          {notification.time}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>

          {/* Footer */}
          <div className="px-5 py-3 bg-[var(--neutral-50)] border-t border-[var(--neutral-200)]">
            <Button
              className="w-full text-[14px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] transition-colors duration-[120ms]"
              onClick={onClose}
            >
              View all notifications
            </Button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
};

export default NotificationsPanel;
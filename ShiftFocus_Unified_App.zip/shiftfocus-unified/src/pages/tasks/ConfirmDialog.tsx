import React from 'react';
import { AlertTriangle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogBody,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  Button,
} from './design-system';

export interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'destructive' | 'warning';
  onConfirm: () => void;
  onCancel?: () => void;
}

const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'destructive',
  onConfirm,
  onCancel,
}) => {
  const handleCancel = () => {
    onCancel?.();
    onOpenChange(false);
  };

  const handleConfirm = () => {
    onConfirm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="sm" showClose={false}>
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                variant === 'destructive'
                  ? 'bg-[var(--danger-light)]'
                  : 'bg-[var(--warning-light)]'
              }`}
            >
              <AlertTriangle
                size={20}
                className={
                  variant === 'destructive'
                    ? 'text-[var(--danger)]'
                    : 'text-[var(--warning)]'
                }
              />
            </div>
            <DialogTitle>{title}</DialogTitle>
          </div>
        </DialogHeader>
        <DialogBody>
          <DialogDescription className="text-[14px] leading-[1.6]">
            {description}
          </DialogDescription>
        </DialogBody>
        <DialogFooter>
          <Button
            variant="secondary"
            onClick={handleCancel}
            className="focus-visible:shadow-[var(--shadow-focus)]"
          >
            {cancelLabel}
          </Button>
          <Button
            variant={variant === 'destructive' ? 'destructive' : 'primary'}
            onClick={handleConfirm}
            className={`focus-visible:shadow-[var(--shadow-focus)] ${
              variant === 'destructive'
                ? 'bg-[var(--danger)] hover:bg-[var(--danger-dark)] text-white'
                : ''
            }`}
          >
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ConfirmDialog;

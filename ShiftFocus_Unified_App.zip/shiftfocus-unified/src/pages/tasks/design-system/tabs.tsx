import React from 'react';
import * as RadixTabs from '@radix-ui/react-tabs';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ── Tab List CVA ────────────────────────────────────────── */

const tabListVariants = cva('flex items-center', {
  variants: {
    variant: {
      underline: 'gap-6 border-b border-[var(--neutral-200)]',
      pills: 'gap-1 bg-[var(--neutral-100)] p-1 rounded-lg',
    },
  },
  defaultVariants: {
    variant: 'underline',
  },
});

/* ── Tab Trigger CVA ─────────────────────────────────────── */

const tabTriggerVariants = cva(
  'text-[14px] font-medium transition-all duration-[var(--duration-fast)] cursor-pointer outline-none',
  {
    variants: {
      variant: {
        underline: [
          'h-[48px] px-1 border-b-2 leading-[1.5]',
          'data-[state=inactive]:border-transparent data-[state=inactive]:text-[var(--text-secondary)]',
          'data-[state=inactive]:hover:text-[var(--text-primary)]',
          'data-[state=active]:border-[var(--brand-primary)] data-[state=active]:text-[var(--brand-primary)]',
        ],
        pills: [
          'h-[40px] px-4 rounded-lg leading-[1.5]',
          'data-[state=inactive]:text-[var(--text-secondary)]',
          'data-[state=inactive]:hover:bg-[var(--neutral-50)]',
          'data-[state=active]:bg-gradient-to-r data-[state=active]:from-[var(--gradient-start)] data-[state=active]:to-[var(--gradient-end)]',
          'data-[state=active]:text-white data-[state=active]:shadow-[var(--shadow-card)]',
        ],
      },
    },
    defaultVariants: {
      variant: 'underline',
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface TabsProps extends RadixTabs.TabsProps {
  className?: string;
}

export interface TabsListProps extends VariantProps<typeof tabListVariants> {
  children: React.ReactNode;
  className?: string;
}

export interface TabsTriggerProps extends RadixTabs.TabsTriggerProps {
  variant?: 'underline' | 'pills';
  className?: string;
  badge?: number;
}

export interface TabsContentProps extends RadixTabs.TabsContentProps {
  className?: string;
}

/* ── Components ───────────────────────────────────────────── */

const Tabs: React.FC<TabsProps> = ({ className, ...props }) => (
  <RadixTabs.Root className={cn('w-full', className)} {...props} />
);

const TabsList = React.forwardRef<HTMLDivElement, TabsListProps>(
  ({ className, variant, children, ...props }, ref) => (
    <RadixTabs.List
      ref={ref}
      className={cn(tabListVariants({ variant }), className)}
      {...(props as RadixTabs.TabsListProps)}
    >
      {children}
    </RadixTabs.List>
  )
);
TabsList.displayName = 'TabsList';

const TabsTrigger = React.forwardRef<HTMLButtonElement, TabsTriggerProps>(
  ({ className, variant, badge, children, ...props }, ref) => (
    <RadixTabs.Trigger
      ref={ref}
      className={cn(tabTriggerVariants({ variant }), className)}
      {...props}
    >
      <span className="flex items-center gap-2">
        {children}
        {badge !== undefined && badge > 0 && (
          <span className="h-5 px-2 bg-[var(--brand-primary)] text-white rounded-full text-[12px] font-medium leading-[1.3] flex items-center">
            {badge}
          </span>
        )}
      </span>
    </RadixTabs.Trigger>
  )
);
TabsTrigger.displayName = 'TabsTrigger';

const TabsContent = React.forwardRef<HTMLDivElement, TabsContentProps>(
  ({ className, ...props }, ref) => (
    <RadixTabs.Content
      ref={ref}
      className={cn('outline-none', className)}
      {...props}
    />
  )
);
TabsContent.displayName = 'TabsContent';

export { Tabs, TabsList, TabsTrigger, TabsContent, tabListVariants, tabTriggerVariants };
import React from 'react';
import * as RadixDropdownMenu from '@radix-ui/react-dropdown-menu';
import { cn } from '../lib/utils';
import { Check, ChevronRight } from 'lucide-react';

/* ── Root & Trigger ──────────────────────────────────────── */

const DropdownMenu = RadixDropdownMenu.Root;
const DropdownMenuTrigger = RadixDropdownMenu.Trigger;
const DropdownMenuGroup = RadixDropdownMenu.Group;
const DropdownMenuSub = RadixDropdownMenu.Sub;
const DropdownMenuRadioGroup = RadixDropdownMenu.RadioGroup;

/* ── Content ──────────────────────────────────────────────── */

export interface DropdownMenuContentProps
  extends RadixDropdownMenu.DropdownMenuContentProps {
  className?: string;
}

const DropdownMenuContent = React.forwardRef<HTMLDivElement, DropdownMenuContentProps>(
  ({ className, sideOffset = 4, ...props }, ref) => (
    <RadixDropdownMenu.Portal>
      <RadixDropdownMenu.Content
        ref={ref}
        sideOffset={sideOffset}
        className={cn(
          'min-w-[200px] bg-[var(--bg-level-0)] rounded-[var(--card-radius)]',
          'border border-[var(--neutral-200)] shadow-[var(--shadow-dropdown)]',
          'py-1.5 z-[100]',
          'animate-in fade-in-0 zoom-in-95',
          'data-[side=bottom]:slide-in-from-top-2',
          'data-[side=top]:slide-in-from-bottom-2',
          className
        )}
        {...props}
      />
    </RadixDropdownMenu.Portal>
  )
);
DropdownMenuContent.displayName = 'DropdownMenuContent';

/* ── Item ─────────────────────────────────────────────────── */

export interface DropdownMenuItemProps
  extends RadixDropdownMenu.DropdownMenuItemProps {
  className?: string;
  icon?: React.ReactNode;
  shortcut?: string;
}

const DropdownMenuItem = React.forwardRef<HTMLDivElement, DropdownMenuItemProps>(
  ({ className, icon, shortcut, children, ...props }, ref) => (
    <RadixDropdownMenu.Item
      ref={ref}
      className={cn(
        'relative flex items-center gap-2.5 px-3 py-2.5',
        'text-[14px] text-[var(--text-primary)] outline-none cursor-pointer select-none',
        'data-[highlighted]:bg-[var(--brand-primary-light)]',
        'data-[disabled]:opacity-50 data-[disabled]:pointer-events-none',
        'transition-colors',
        className
      )}
      {...props}
    >
      {icon && <span className="shrink-0 text-[var(--text-secondary)]">{icon}</span>}
      <span className="flex-1">{children}</span>
      {shortcut && (
        <span className="ml-auto text-[12px] text-[var(--text-tertiary)]">{shortcut}</span>
      )}
    </RadixDropdownMenu.Item>
  )
);
DropdownMenuItem.displayName = 'DropdownMenuItem';

/* ── Checkbox Item ────────────────────────────────────────── */

const DropdownMenuCheckboxItem = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuCheckboxItemProps & { className?: string }
>(({ className, children, checked, ...props }, ref) => (
  <RadixDropdownMenu.CheckboxItem
    ref={ref}
    checked={checked}
    className={cn(
      'relative flex items-center justify-between px-3 py-2.5',
      'text-[14px] text-[var(--text-primary)] outline-none cursor-pointer select-none',
      'data-[highlighted]:bg-[var(--brand-primary-light)]',
      'transition-colors',
      className
    )}
    {...props}
  >
    <span>{children}</span>
    <RadixDropdownMenu.ItemIndicator>
      <Check size={14} className="text-[var(--brand-primary)]" />
    </RadixDropdownMenu.ItemIndicator>
  </RadixDropdownMenu.CheckboxItem>
));
DropdownMenuCheckboxItem.displayName = 'DropdownMenuCheckboxItem';

/* ── Radio Item ───────────────────────────────────────────── */

const DropdownMenuRadioItem = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuRadioItemProps & { className?: string }
>(({ className, children, ...props }, ref) => (
  <RadixDropdownMenu.RadioItem
    ref={ref}
    className={cn(
      'relative flex items-center justify-between px-3 py-2.5',
      'text-[14px] text-[var(--text-primary)] outline-none cursor-pointer select-none',
      'data-[highlighted]:bg-[var(--brand-primary-light)]',
      'data-[state=checked]:bg-[var(--brand-primary-light)] data-[state=checked]:text-[var(--brand-primary)] data-[state=checked]:font-medium',
      'transition-colors',
      className
    )}
    {...props}
  >
    <span>{children}</span>
    <RadixDropdownMenu.ItemIndicator>
      <Check size={14} className="text-[var(--brand-primary)]" />
    </RadixDropdownMenu.ItemIndicator>
  </RadixDropdownMenu.RadioItem>
));
DropdownMenuRadioItem.displayName = 'DropdownMenuRadioItem';

/* ── Label ────────────────────────────────────────────────── */

const DropdownMenuLabel = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuLabelProps & { className?: string }
>(({ className, ...props }, ref) => (
  <RadixDropdownMenu.Label
    ref={ref}
    className={cn(
      'px-3 py-2 text-[12px] font-medium tracking-[0.03em] uppercase text-[var(--text-tertiary)]',
      className
    )}
    {...props}
  />
));
DropdownMenuLabel.displayName = 'DropdownMenuLabel';

/* ── Separator ────────────────────────────────────────────── */

const DropdownMenuSeparator = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuSeparatorProps & { className?: string }
>(({ className, ...props }, ref) => (
  <RadixDropdownMenu.Separator
    ref={ref}
    className={cn('h-px bg-[var(--neutral-200)] my-1.5', className)}
    {...props}
  />
));
DropdownMenuSeparator.displayName = 'DropdownMenuSeparator';

/* ── Sub Trigger & Content ────────────────────────────────── */

const DropdownMenuSubTrigger = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuSubTriggerProps & { className?: string }
>(({ className, children, ...props }, ref) => (
  <RadixDropdownMenu.SubTrigger
    ref={ref}
    className={cn(
      'flex items-center gap-2.5 px-3 py-2.5',
      'text-[14px] text-[var(--text-primary)] outline-none cursor-pointer select-none',
      'data-[highlighted]:bg-[var(--brand-primary-light)]',
      className
    )}
    {...props}
  >
    <span className="flex-1">{children}</span>
    <ChevronRight size={14} className="text-[var(--text-tertiary)]" />
  </RadixDropdownMenu.SubTrigger>
));
DropdownMenuSubTrigger.displayName = 'DropdownMenuSubTrigger';

const DropdownMenuSubContent = React.forwardRef<
  HTMLDivElement,
  RadixDropdownMenu.DropdownMenuSubContentProps & { className?: string }
>(({ className, ...props }, ref) => (
  <RadixDropdownMenu.Portal>
    <RadixDropdownMenu.SubContent
      ref={ref}
      className={cn(
        'min-w-[180px] bg-[var(--bg-level-0)] rounded-[var(--card-radius)]',
        'border border-[var(--neutral-200)] shadow-[var(--shadow-dropdown)]',
        'py-1.5 z-[100]',
        'animate-in fade-in-0 zoom-in-95',
        className
      )}
      {...props}
    />
  </RadixDropdownMenu.Portal>
));
DropdownMenuSubContent.displayName = 'DropdownMenuSubContent';

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuRadioGroup,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuGroup,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
};
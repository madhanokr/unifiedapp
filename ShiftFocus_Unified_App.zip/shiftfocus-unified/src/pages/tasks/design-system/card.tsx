import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ── CVA Definition ──────────────────────────────────────── */

const cardVariants = cva(
  'rounded-[var(--card-radius)] bg-[var(--bg-level-0)] overflow-hidden',
  {
    variants: {
      variant: {
        default: 'shadow-[var(--shadow-card)] border border-[var(--neutral-200)]',
        bordered: 'border-2 border-[var(--neutral-200)]',
        elevated: 'shadow-[var(--shadow-elevated)] border border-[var(--neutral-200)]',
        ghost: '',
      },
      interactive: {
        true: [
          'cursor-pointer transition-all duration-[var(--duration-standard)]',
          'hover:shadow-[var(--shadow-card-hover)] hover:border-[var(--brand-primary)]',
        ],
        false: '',
      },
      padding: {
        none: '',
        sm: 'p-4',
        md: 'p-[var(--card-padding)]',
        lg: 'p-8',
      },
    },
    defaultVariants: {
      variant: 'default',
      interactive: false,
      padding: 'none',
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface CardProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof cardVariants> {}

export interface CardHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}
export interface CardBodyProps extends React.HTMLAttributes<HTMLDivElement> {}
export interface CardFooterProps extends React.HTMLAttributes<HTMLDivElement> {}

/* ── Components ───────────────────────────────────────────── */

const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, variant, interactive, padding, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(cardVariants({ variant, interactive, padding }), className)}
      {...props}
    />
  )
);
Card.displayName = 'Card';

const CardHeader = React.forwardRef<HTMLDivElement, CardHeaderProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        'px-[var(--card-padding)] py-5 border-b border-[var(--neutral-200)]',
        className
      )}
      {...props}
    />
  )
);
CardHeader.displayName = 'CardHeader';

const CardBody = React.forwardRef<HTMLDivElement, CardBodyProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn('p-[var(--card-padding)]', className)}
      {...props}
    />
  )
);
CardBody.displayName = 'CardBody';

const CardFooter = React.forwardRef<HTMLDivElement, CardFooterProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        'px-[var(--card-padding)] py-4 border-t border-[var(--neutral-200)] bg-[var(--neutral-50)]',
        className
      )}
      {...props}
    />
  )
);
CardFooter.displayName = 'CardFooter';

export { Card, CardHeader, CardBody, CardFooter, cardVariants };
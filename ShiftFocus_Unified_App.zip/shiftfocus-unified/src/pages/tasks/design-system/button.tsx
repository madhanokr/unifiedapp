import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Loader2 } from 'lucide-react';
import { motion, type HTMLMotionProps } from 'motion/react';

/* ── CVA Definition ──────────────────────────────────────── */

const buttonVariants = cva(
  [
    'inline-flex items-center justify-center gap-[var(--icon-text-gap)]',
    'font-medium rounded-lg transition-all',
    'duration-[var(--duration-fast)]',
    'focus:outline-none focus:shadow-[var(--shadow-focus)]',
    'disabled:pointer-events-none disabled:opacity-50',
    'cursor-pointer',
  ],
  {
    variants: {
      variant: {
        primary: [
          'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)]',
          'text-[var(--text-white)] shadow-[var(--shadow-card)]',
          'hover:shadow-[var(--shadow-brand-hover)]',
        ],
        secondary: [
          'bg-[var(--bg-level-0)] border border-[var(--neutral-200)]',
          'text-[var(--text-primary)]',
          'hover:bg-[var(--neutral-50)]',
        ],
        ghost: [
          'text-[var(--text-secondary)]',
          'hover:text-[var(--text-primary)] hover:bg-[var(--neutral-100)]',
        ],
        destructive: [
          'text-[var(--danger)]',
          'hover:bg-[var(--danger-light)]',
        ],
      },
      size: {
        sm: 'h-8 px-3 text-[12px]',
        md: 'h-[var(--button-height)] px-[var(--button-padding-x)] text-[14px]',
        lg: 'h-12 px-6 text-[14px]',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface ButtonProps
  extends Omit<HTMLMotionProps<'button'>, 'size'>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
  icon?: React.ReactNode;
}

/* ── Component ────────────────────────────────────────────── */

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, disabled, icon, children, ...props }, ref) => {
    const isDisabled = disabled || loading;

    return (
      <motion.button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        disabled={isDisabled}
        whileHover={isDisabled ? undefined : { scale: 1.02 }}
        whileTap={isDisabled ? undefined : { scale: 0.98, translateY: 1 }}
        transition={{ duration: 0.08, ease: [0.25, 0.1, 0.25, 1] }}
        {...props}
      >
        {loading ? (
          <Loader2 size={16} className="animate-spin" />
        ) : icon ? (
          icon
        ) : null}
        {children}
      </motion.button>
    );
  }
);
Button.displayName = 'Button';

/* ── Icon Button Variant ─────────────────────────────────── */

export interface IconButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  icon: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

const iconButtonSizes = {
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-12 h-12',
};

const IconButton = React.forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ className, icon, size = 'md', label, disabled, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(
        iconButtonSizes[size],
        'flex items-center justify-center rounded-lg',
        'text-[var(--text-secondary)] hover:text-[var(--text-primary)]',
        'hover:bg-[var(--neutral-50)] transition-all duration-[var(--duration-fast)]',
        'focus:outline-none focus-visible:shadow-[var(--shadow-focus)]',
        'disabled:pointer-events-none disabled:opacity-50',
        className
      )}
      aria-label={label}
      disabled={disabled}
      {...props}
    >
      {icon}
    </button>
  )
);
IconButton.displayName = 'IconButton';

export { Button, IconButton, buttonVariants };
export type { VariantProps };
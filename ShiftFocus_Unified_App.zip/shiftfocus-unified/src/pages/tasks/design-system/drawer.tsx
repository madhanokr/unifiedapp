import React from 'react';
import * as RadixDialog from '@radix-ui/react-dialog';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { X } from 'lucide-react';
import { motion } from 'motion/react';

/* ── CVA Definition ──────────────────────────────────────── */

const drawerVariants = cva(
  [
    'fixed top-0 bottom-0 z-50',
    'bg-[var(--bg-level-0)] shadow-[var(--shadow-drawer)]',
    'overflow-y-auto focus:outline-none',
  ],
  {
    variants: {
      side: {
        left: 'left-0',
        right: 'right-0',
      },
      size: {
        sm: 'w-[320px]',
        md: 'w-[var(--drawer-width)]',
        lg: 'w-[560px]',
      },
    },
    defaultVariants: {
      side: 'right',
      size: 'md',
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface DrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
}

export interface DrawerContentProps extends VariantProps<typeof drawerVariants> {
  children: React.ReactNode;
  className?: string;
  showClose?: boolean;
}

export interface DrawerHeaderProps {
  children: React.ReactNode;
  className?: string;
  onClose?: () => void;
}

/* ── Components ───────────────────────────────────────────── */

const Drawer: React.FC<DrawerProps> = ({ open, onOpenChange, children }) => (
  <RadixDialog.Root open={open} onOpenChange={onOpenChange}>
    {children}
  </RadixDialog.Root>
);

const DrawerContent = React.forwardRef<HTMLDivElement, DrawerContentProps>(
  ({ className, side = 'right', size, showClose = true, children }, ref) => {
    const slideFrom = side === 'right' ? { x: '100%' } : { x: '-100%' };
    const slideTo = { x: 0 };

    return (
      <RadixDialog.Portal>
        <RadixDialog.Overlay asChild>
          <motion.div
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
          />
        </RadixDialog.Overlay>
        <RadixDialog.Content aria-describedby={undefined} asChild>
          <motion.div
            ref={ref}
            className={cn(drawerVariants({ side, size }), className)}
            initial={slideFrom}
            animate={slideTo}
            exit={slideFrom}
            transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
          >
            {/* Fallback hidden title for accessibility */}
            <VisuallyHidden>
              <RadixDialog.Title>Panel</RadixDialog.Title>
            </VisuallyHidden>
            {children}
            {showClose && (
              <RadixDialog.Close asChild>
                <button
                  className={cn(
                    'absolute top-5 right-5 w-9 h-9',
                    'flex items-center justify-center rounded-lg',
                    'text-[var(--text-secondary)] hover:text-[var(--text-primary)]',
                    'hover:bg-[var(--neutral-50)] transition-colors duration-[var(--duration-fast)]'
                  )}
                  aria-label="Close drawer"
                >
                  <X size={18} />
                </button>
              </RadixDialog.Close>
            )}
          </motion.div>
        </RadixDialog.Content>
      </RadixDialog.Portal>
    );
  }
);
DrawerContent.displayName = 'DrawerContent';

const DrawerHeader: React.FC<DrawerHeaderProps> = ({ children, className }) => (
  <div className={cn('p-6 border-b border-[var(--neutral-200)]', className)}>
    {children}
  </div>
);

const DrawerBody: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => <div className={cn('p-6', className)}>{children}</div>;

export { Drawer, DrawerContent, DrawerHeader, DrawerBody, drawerVariants };
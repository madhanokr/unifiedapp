import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ── CVA Definition ──────────────────────────────────────── */

const skeletonVariants = cva('animate-pulse bg-[var(--neutral-100)]', {
  variants: {
    variant: {
      text: 'rounded-md',
      circle: 'rounded-full',
      rect: 'rounded-[var(--card-radius)]',
    },
  },
  defaultVariants: {
    variant: 'text',
  },
});

/* ── Props ────────────────────────────────────────────────── */

export interface SkeletonProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonVariants> {
  width?: string | number;
  height?: string | number;
}

/* ── Component ────────────────────────────────────────────── */

const Skeleton = React.forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, variant, width, height, style, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(skeletonVariants({ variant }), className)}
      style={{ width, height, ...style }}
      {...props}
    />
  )
);
Skeleton.displayName = 'Skeleton';

/* ── Preset Skeletons ────────────────────────────────────── */

const SkeletonText: React.FC<{ lines?: number; className?: string }> = ({
  lines = 3,
  className,
}) => (
  <div className={cn('space-y-2', className)}>
    {Array.from({ length: lines }).map((_, i) => (
      <Skeleton
        key={i}
        variant="text"
        className={cn('h-3.5', i === lines - 1 ? 'w-[60%]' : 'w-full')}
      />
    ))}
  </div>
);

const SkeletonAvatar: React.FC<{ size?: number; className?: string }> = ({
  size = 32,
  className,
}) => (
  <Skeleton
    variant="circle"
    className={className}
    style={{ width: size, height: size }}
  />
);

const SkeletonCard: React.FC<{ className?: string }> = ({ className }) => (
  <div
    className={cn(
      'p-[var(--card-padding)] rounded-[var(--card-radius)] border border-[var(--neutral-200)] bg-[var(--bg-level-0)]',
      className
    )}
  >
    <div className="flex items-center gap-3 mb-4">
      <SkeletonAvatar size={40} />
      <div className="flex-1 space-y-2">
        <Skeleton variant="text" className="h-4 w-[50%]" />
        <Skeleton variant="text" className="h-3 w-[30%]" />
      </div>
    </div>
    <SkeletonText lines={2} />
  </div>
);

export { Skeleton, SkeletonText, SkeletonAvatar, SkeletonCard, skeletonVariants };
import React from 'react';
import * as RadixCheckbox from '@radix-ui/react-checkbox';
import { cn } from '../lib/utils';
import { Check, Minus } from 'lucide-react';

/* ── Props ────────────────────────────────────────────────── */

export interface CheckboxProps extends RadixCheckbox.CheckboxProps {
  label?: string;
  description?: string;
  className?: string;
}

/* ── Component ────────────────────────────────────────────── */

const Checkbox = React.forwardRef<HTMLButtonElement, CheckboxProps>(
  ({ className, label, description, checked, ...props }, ref) => (
    <div className={cn('flex items-start gap-3', className)}>
      <RadixCheckbox.Root
        ref={ref}
        checked={checked}
        className={cn(
          'w-5 h-5 shrink-0 rounded border-2',
          'transition-all duration-[var(--duration-fast)]',
          'focus-visible:outline-none focus-visible:shadow-[var(--shadow-focus)]',
          'disabled:cursor-not-allowed disabled:opacity-50',
          'cursor-pointer',
          'data-[state=unchecked]:border-[var(--neutral-200)] data-[state=unchecked]:bg-[var(--bg-level-0)]',
          'data-[state=checked]:border-[var(--brand-primary)] data-[state=checked]:bg-[var(--brand-primary)]',
          'data-[state=indeterminate]:border-[var(--brand-primary)] data-[state=indeterminate]:bg-[var(--brand-primary)]'
        )}
        {...props}
      >
        <RadixCheckbox.Indicator className="flex items-center justify-center text-white">
          {checked === 'indeterminate' ? (
            <Minus size={14} strokeWidth={3} />
          ) : (
            <Check size={14} strokeWidth={3} />
          )}
        </RadixCheckbox.Indicator>
      </RadixCheckbox.Root>
      {(label || description) && (
        <div className="pt-0.5">
          {label && (
            <div className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
              {label}
            </div>
          )}
          {description && (
            <div className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mt-0.5">
              {description}
            </div>
          )}
        </div>
      )}
    </div>
  )
);
Checkbox.displayName = 'Checkbox';

export { Checkbox };
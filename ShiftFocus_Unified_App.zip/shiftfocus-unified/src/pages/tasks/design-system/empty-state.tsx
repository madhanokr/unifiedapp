import React from 'react';
import { cn } from '../lib/utils';
import { Inbox } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './button';

/* ── Props ────────────────────────────────────────────────── */

export interface EmptyStateProps {
  icon?: React.ElementType;
  title?: string;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'primary' | 'secondary';
  };
  className?: string;
  compact?: boolean;
}

/* ── Component ────────────────────────────────────────────── */

const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = Inbox,
  title = 'No items found',
  description = 'Try adjusting your filters or create a new item.',
  action,
  className,
  compact = false,
}) => (
  <motion.div
    className={cn(
      'bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)]',
      'border border-[var(--neutral-200)] text-center',
      compact ? 'p-8' : 'p-12',
      className
    )}
    initial={{ opacity: 0, y: 12 }}
    animate={{ opacity: 1, y: 0 }}
  >
    <div
      className={cn(
        'mx-auto mb-4 bg-[var(--neutral-100)] rounded-full flex items-center justify-center',
        compact ? 'w-10 h-10' : 'w-12 h-12'
      )}
    >
      <Icon size={compact ? 20 : 24} className="text-[var(--text-tertiary)]" />
    </div>
    <h3 className="text-[16px] font-medium leading-[1.3] text-[var(--text-primary)] mb-2">
      {title}
    </h3>
    <p className="text-[14px] font-normal leading-[1.5] text-[var(--text-secondary)] max-w-[360px] mx-auto mb-6">
      {description}
    </p>
    {action && (
      <Button
        variant={action.variant || 'primary'}
        size="md"
        onClick={action.onClick}
      >
        {action.label}
      </Button>
    )}
  </motion.div>
);

export { EmptyState };
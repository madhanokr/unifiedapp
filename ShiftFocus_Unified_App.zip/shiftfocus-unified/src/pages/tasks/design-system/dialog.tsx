import React from 'react';
import * as RadixDialog from '@radix-ui/react-dialog';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

/* ── Content Size CVA ────────────────────────────────────── */

const dialogContentVariants = cva(
  [
    'relative bg-[var(--bg-level-0)] shadow-[var(--shadow-modal)]',
    'overflow-hidden focus:outline-none',
  ],
  {
    variants: {
      size: {
        sm: 'w-full max-w-[480px] rounded-[var(--card-radius)]',
        md: 'w-full max-w-[var(--modal-max-width)] rounded-[var(--card-radius)]',
        lg: 'w-full max-w-[900px] rounded-[16px]',
        xl: 'w-full max-w-[1200px] rounded-[16px]',
        full: 'w-full max-w-[calc(100vw-48px)] rounded-[16px]',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
}

export interface DialogContentProps
  extends VariantProps<typeof dialogContentVariants> {
  children: React.ReactNode;
  className?: string;
  showClose?: boolean;
  onClose?: () => void;
}

export interface DialogHeaderProps {
  children: React.ReactNode;
  className?: string;
  onClose?: () => void;
}

export interface DialogFooterProps {
  children: React.ReactNode;
  className?: string;
}

/* ── Root ─────────────────────────────────────────────────── */

const Dialog: React.FC<DialogProps> = ({ open, onOpenChange, children }) => (
  <RadixDialog.Root open={open} onOpenChange={onOpenChange}>
    {children}
  </RadixDialog.Root>
);

/* ── Overlay ──────────────────────────────────────────────── */

const DialogOverlay = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <RadixDialog.Overlay asChild>
    <motion.div
      ref={ref}
      className={cn(
        'fixed inset-0 z-50 bg-black/50 backdrop-blur-sm',
        className
      )}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.12 }}
      {...props}
    />
  </RadixDialog.Overlay>
));
DialogOverlay.displayName = 'DialogOverlay';

/* ── Content ──────────────────────────────────────────────── */

const DialogContent = React.forwardRef<HTMLDivElement, DialogContentProps>(
  ({ className, size, showClose = true, onClose, children, ...props }, ref) => (
    <RadixDialog.Portal>
      <DialogOverlay />
      <RadixDialog.Content aria-describedby={undefined} asChild>
        <motion.div
          ref={ref}
          className={cn(
            'fixed inset-0 z-50 flex items-center justify-center p-4'
          )}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className={cn(dialogContentVariants({ size }), className)}
            initial={{ opacity: 0, scale: 0.96, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 20 }}
            transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
            onClick={(e: React.MouseEvent) => e.stopPropagation()}
          >
            {/* Fallback hidden title for accessibility — consumers should use DialogTitle */}
            <VisuallyHidden>
              <RadixDialog.Title>Dialog</RadixDialog.Title>
            </VisuallyHidden>
            {children}
            {showClose && (
              <RadixDialog.Close asChild>
                <button
                  className={cn(
                    'absolute top-5 right-5 w-9 h-9',
                    'flex items-center justify-center rounded-lg',
                    'text-[var(--text-secondary)] hover:text-[var(--text-primary)]',
                    'hover:bg-[var(--neutral-100)] transition-colors duration-[var(--duration-fast)]'
                  )}
                  aria-label="Close"
                >
                  <X size={18} />
                </button>
              </RadixDialog.Close>
            )}
          </motion.div>
        </motion.div>
      </RadixDialog.Content>
    </RadixDialog.Portal>
  )
);
DialogContent.displayName = 'DialogContent';

/* ── Header ───────────────────────────────────────────────── */

const DialogHeader: React.FC<DialogHeaderProps> = ({ children, className }) => (
  <div
    className={cn(
      'px-8 py-5 border-b border-[var(--neutral-200)] flex items-center justify-between',
      className
    )}
  >
    {children}
  </div>
);

/* ── Body ─────────────────────────────────────────────────── */

const DialogBody: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => <div className={cn('px-8 py-6', className)}>{children}</div>;

/* ── Footer ───────────────────────────────────────────────── */

const DialogFooter: React.FC<DialogFooterProps> = ({ children, className }) => (
  <div
    className={cn(
      'px-8 py-4 border-t border-[var(--neutral-200)] bg-[var(--neutral-50)]',
      'flex items-center justify-end gap-3',
      className
    )}
  >
    {children}
  </div>
);

/* ── Title & Description ──────────────────────────────────── */

const DialogTitle = React.forwardRef<
  HTMLHeadingElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <RadixDialog.Title
    ref={ref}
    className={cn(
      'text-[var(--font-size-h2)] font-medium leading-[var(--line-height-heading)] text-[var(--text-primary)]',
      className
    )}
    {...props}
  />
));
DialogTitle.displayName = 'DialogTitle';

const DialogDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <RadixDialog.Description
    ref={ref}
    className={cn(
      'text-[var(--font-size-caption)] font-normal leading-[var(--line-height-caption)] text-[var(--text-secondary)]',
      className
    )}
    {...props}
  />
));
DialogDescription.displayName = 'DialogDescription';

export {
  Dialog,
  DialogOverlay,
  DialogContent,
  DialogHeader,
  DialogBody,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  dialogContentVariants,
};
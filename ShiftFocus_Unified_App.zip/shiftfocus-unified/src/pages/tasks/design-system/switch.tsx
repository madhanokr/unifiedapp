import React from 'react';
import * as RadixSwitch from '@radix-ui/react-switch';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

/* ── CVA Root ────────────────────────────────────────────── */

const switchRootVariants = cva(
  [
    'relative inline-flex shrink-0 cursor-pointer rounded-full',
    'transition-colors duration-[var(--duration-standard)]',
    'focus-visible:outline-none focus-visible:shadow-[var(--shadow-focus)]',
    'disabled:cursor-not-allowed disabled:opacity-50',
    'data-[state=unchecked]:bg-[var(--neutral-200)]',
    'data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-[var(--gradient-start)] data-[state=checked]:to-[var(--gradient-end)]',
  ],
  {
    variants: {
      size: {
        sm: 'w-[36px] h-[20px]',
        md: 'w-[44px] h-[24px]',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

const thumbSizes = {
  sm: { width: 16, height: 16, off: 2, on: 18 },
  md: { width: 20, height: 20, off: 2, on: 22 },
};

/* ── Props ────────────────────────────────────────────────── */

export interface SwitchProps
  extends Omit<RadixSwitch.SwitchProps, 'size'>,
    VariantProps<typeof switchRootVariants> {
  label?: string;
  description?: string;
  className?: string;
}

/* ── Component ────────────────────────────────────────────── */

const Switch = React.forwardRef<HTMLButtonElement, SwitchProps>(
  ({ className, size = 'md', label, description, checked, ...props }, ref) => {
    const thumb = thumbSizes[size || 'md'];

    return (
      <div className={cn(label && 'flex items-center justify-between', className)}>
        {(label || description) && (
          <div className="mr-4">
            {label && (
              <div className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
                {label}
              </div>
            )}
            {description && (
              <div className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mt-0.5">
                {description}
              </div>
            )}
          </div>
        )}
        <RadixSwitch.Root
          ref={ref}
          checked={checked}
          className={cn(switchRootVariants({ size }))}
          {...props}
        >
          <RadixSwitch.Thumb asChild>
            <motion.span
              className="block rounded-full bg-white shadow-[var(--shadow-card)]"
              style={{ width: thumb.width, height: thumb.height }}
              animate={{ x: checked ? thumb.on : thumb.off }}
              transition={{ duration: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
            />
          </RadixSwitch.Thumb>
        </RadixSwitch.Root>
      </div>
    );
  }
);
Switch.displayName = 'Switch';

export { Switch, switchRootVariants };
import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

/* ── CVA Definition ──────────────────────────────────────── */

const inputVariants = cva(
  [
    'w-full border rounded-[var(--input-radius)]',
    'text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)]',
    'bg-[var(--bg-level-0)]',
    'focus:outline-none focus:shadow-[var(--shadow-focus)]',
    'transition-all duration-[var(--duration-fast)]',
    'disabled:opacity-50 disabled:cursor-not-allowed',
  ],
  {
    variants: {
      inputSize: {
        sm: 'h-8 px-3 text-[12px]',
        md: 'h-[var(--input-height)] px-[var(--input-padding)] text-[14px]',
      },
      error: {
        true: 'border-[var(--danger)] focus:border-[var(--danger)]',
        false: 'border-[var(--neutral-200)] focus:border-[var(--brand-primary)]',
      },
    },
    defaultVariants: {
      inputSize: 'md',
      error: false,
    },
  }
);

/* ── Props ────────────────────────────────────────────────── */

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  inputSize?: 'sm' | 'md';
  error?: boolean;
  errorMessage?: string;
  label?: string;
  icon?: React.ReactNode;
}

/* ── Error Message ────────────────────────────────────────── */

const FieldError: React.FC<{ message?: string }> = ({ message }) =>
  message ? (
    <motion.p
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-1.5 mt-1.5 text-[12px] font-medium text-[var(--danger)]"
    >
      <AlertCircle size={12} />
      {message}
    </motion.p>
  ) : null;

/* ── Component ────────────────────────────────────────────── */

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, inputSize, error, errorMessage, label, icon, ...props }, ref) => (
    <div className="w-full">
      {label && (
        <label className="block text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-2">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-secondary)]">
            {icon}
          </div>
        )}
        <input
          ref={ref}
          className={cn(
            inputVariants({ inputSize, error: !!error }),
            icon && 'pl-10',
            className
          )}
          {...props}
        />
      </div>
      <FieldError message={errorMessage} />
    </div>
  )
);
Input.displayName = 'Input';

/* ── Textarea ─────────────────────────────────────────────── */

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
  errorMessage?: string;
  label?: string;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, error, errorMessage, label, ...props }, ref) => (
    <div className="w-full">
      {label && (
        <label className="block text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-2">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        className={cn(
          'w-full px-[var(--input-padding)] py-3 border rounded-[var(--input-radius)]',
          'text-[14px] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)]',
          'bg-[var(--bg-level-0)] resize-none',
          'focus:outline-none focus:shadow-[var(--shadow-focus)]',
          'transition-all duration-[var(--duration-fast)]',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          error
            ? 'border-[var(--danger)] focus:border-[var(--danger)]'
            : 'border-[var(--neutral-200)] focus:border-[var(--brand-primary)]',
          className
        )}
        {...props}
      />
      <FieldError message={errorMessage} />
    </div>
  )
);
Textarea.displayName = 'Textarea';

export { Input, Textarea, FieldError, inputVariants };
import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ── CVA Definition ──────────────────────────────────────── */

const badgeVariants = cva(
  [
    'inline-flex items-center justify-center',
    'font-medium tracking-[0.01em] uppercase',
    'whitespace-nowrap border',
  ],
  {
    variants: {
      variant: {
        success: 'bg-[var(--success-light)] text-[var(--success-dark)] border-[var(--success-light)]',
        warning: 'bg-[var(--warning-light)] text-[var(--warning-dark)] border-[var(--warning-light)]',
        danger: 'bg-[var(--danger-light)] text-[var(--danger-dark)] border-[var(--danger-light)]',
        info: 'bg-[var(--info-light)] text-[var(--info-dark)] border-[var(--info-light)]',
        neutral: 'bg-[var(--neutral-100)] text-[var(--neutral-600)] border-[var(--neutral-200)]',
        brand: 'bg-[var(--brand-primary-light)] text-[var(--brand-primary)] border-[var(--brand-primary-light)]',
      },
      size: {
        sm: 'h-[20px] px-2 text-[10px] leading-[1.2] rounded-[4px]',
        md: 'h-[var(--badge-height)] px-[var(--badge-padding-x)] text-[12px] leading-[1.4] rounded-[var(--badge-radius)]',
      },
    },
    defaultVariants: {
      variant: 'neutral',
      size: 'md',
    },
  }
);

/* ── Semantic Mappings ───────────────────────────────────── */

const PRIORITY_MAP: Record<string, VariantProps<typeof badgeVariants>['variant']> = {
  Critical: 'danger',
  High: 'warning',
  Medium: 'info',
  Low: 'neutral',
};

const STATUS_MAP: Record<string, VariantProps<typeof badgeVariants>['variant']> = {
  'In Progress': 'info',
  'Not Started': 'neutral',
  Blocked: 'danger',
  Waiting: 'warning',
  Completed: 'success',
};

const RISK_MAP: Record<string, VariantProps<typeof badgeVariants>['variant']> = {
  high: 'danger',
  medium: 'warning',
  low: 'success',
};

/* ── Props ────────────────────────────────────────────────── */

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

/* ── Component ────────────────────────────────────────────── */

const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant, size, children, ...props }, ref) => (
    <span
      ref={ref}
      className={cn(badgeVariants({ variant, size }), className)}
      {...props}
    >
      {children}
    </span>
  )
);
Badge.displayName = 'Badge';

/* ── Convenience Components ──────────────────────────────── */

export interface SemanticBadgeProps extends Omit<BadgeProps, 'variant'> {
  value: string;
}

const PriorityBadge: React.FC<SemanticBadgeProps> = ({ value, ...props }) => (
  <Badge variant={PRIORITY_MAP[value] || 'neutral'} {...props}>
    {value}
  </Badge>
);

const StatusBadge: React.FC<SemanticBadgeProps> = ({ value, ...props }) => (
  <Badge variant={STATUS_MAP[value] || 'neutral'} {...props}>
    {value}
  </Badge>
);

const RiskBadge: React.FC<SemanticBadgeProps> = ({ value, ...props }) => (
  <Badge variant={RISK_MAP[value] || 'neutral'} {...props}>
    {value}
  </Badge>
);

/* ── Count Badge (pill) ──────────────────────────────────── */

export interface CountBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  count: number;
  variant?: 'brand' | 'danger' | 'neutral';
}

const countBadgeStyles: Record<string, string> = {
  brand: 'bg-[var(--brand-primary)] text-white',
  danger: 'bg-[var(--danger)] text-white',
  neutral: 'bg-[var(--neutral-100)] text-[var(--neutral-600)]',
};

const CountBadge: React.FC<CountBadgeProps> = ({ count, variant = 'neutral', className, ...props }) => (
  <span
    className={cn(
      'h-[20px] min-w-[20px] px-2 rounded-full text-[12px] font-medium inline-flex items-center justify-center',
      countBadgeStyles[variant],
      className
    )}
    {...props}
  >
    {count}
  </span>
);

export { Badge, PriorityBadge, StatusBadge, RiskBadge, CountBadge, badgeVariants, PRIORITY_MAP, STATUS_MAP, RISK_MAP };
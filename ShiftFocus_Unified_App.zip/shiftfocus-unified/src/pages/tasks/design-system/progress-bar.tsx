import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

/* ── Track CVA ───────────────────────────────────────────── */

const progressTrackVariants = cva(
  'w-full bg-[var(--neutral-200)] rounded-full overflow-hidden',
  {
    variants: {
      size: {
        sm: 'h-1.5',
        md: 'h-2',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

/* ── Fill CVA ────────────────────────────────────────────── */

const progressFillVariants = cva('h-full rounded-full', {
  variants: {
    variant: {
      brand: 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)]',
      success: 'bg-[var(--success)]',
      warning: 'bg-[var(--warning)]',
      danger: 'bg-[var(--danger)]',
      info: 'bg-[var(--info)]',
    },
  },
  defaultVariants: {
    variant: 'brand',
  },
});

/* ── Props ────────────────────────────────────────────────── */

export interface ProgressBarProps
  extends VariantProps<typeof progressTrackVariants>,
    VariantProps<typeof progressFillVariants> {
  value: number;
  max?: number;
  animated?: boolean;
  showLabel?: boolean;
  labelPosition?: 'right' | 'below';
  className?: string;
}

/* ── Component ────────────────────────────────────────────── */

const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  size,
  variant,
  animated = true,
  showLabel = false,
  labelPosition = 'right',
  className,
}) => {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn(labelPosition === 'right' && showLabel && 'flex items-center gap-3', className)}>
      <div className={cn(progressTrackVariants({ size }), labelPosition === 'right' && showLabel && 'flex-1')}>
        {animated ? (
          <motion.div
            className={cn(progressFillVariants({ variant }))}
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          />
        ) : (
          <div
            className={cn(progressFillVariants({ variant }))}
            style={{ width: `${pct}%` }}
          />
        )}
      </div>
      {showLabel && (
        <span
          className={cn(
            'text-[12px] font-medium text-[var(--brand-primary)] whitespace-nowrap',
            labelPosition === 'below' && 'mt-1 block'
          )}
        >
          {Math.round(pct)}%
        </span>
      )}
    </div>
  );
};

export { ProgressBar, progressTrackVariants, progressFillVariants };
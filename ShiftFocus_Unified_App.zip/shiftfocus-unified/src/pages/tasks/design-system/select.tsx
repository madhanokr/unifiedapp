import React from 'react';
import * as RadixSelect from '@radix-ui/react-select';
import { cn } from '../lib/utils';
import { ChevronDown, Check, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

/* ── Props ────────────────────────────────────────────────── */

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  label?: string;
  error?: boolean;
  errorMessage?: string;
  disabled?: boolean;
  size?: 'sm' | 'md';
  className?: string;
  name?: string;
}

/* ── Size Map ─────────────────────────────────────────────── */

const sizeStyles = {
  sm: 'h-8 px-3 text-[12px]',
  md: 'h-[var(--input-height)] px-[var(--input-padding)] text-[14px]',
};

/* ── Component ────────────────────────────────────────────── */

const Select: React.FC<SelectProps> = ({
  value,
  defaultValue,
  onValueChange,
  options,
  placeholder = 'Select...',
  label,
  error,
  errorMessage,
  disabled,
  size = 'md',
  className,
  name,
}) => (
  <div className="w-full">
    {label && (
      <label className="block text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-2">
        {label}
      </label>
    )}
    <RadixSelect.Root
      value={value}
      defaultValue={defaultValue}
      onValueChange={onValueChange}
      disabled={disabled}
      name={name}
    >
      <RadixSelect.Trigger
        className={cn(
          'w-full inline-flex items-center justify-between rounded-[var(--input-radius)]',
          'bg-[var(--bg-level-0)] border',
          'focus:outline-none focus:shadow-[var(--shadow-focus)]',
          'transition-all duration-[var(--duration-fast)]',
          'disabled:opacity-50 disabled:cursor-not-allowed',
          'cursor-pointer',
          'text-[var(--text-primary)]',
          error
            ? 'border-[var(--danger)] focus:border-[var(--danger)]'
            : 'border-[var(--neutral-200)] focus:border-[var(--brand-primary)]',
          sizeStyles[size],
          className
        )}
      >
        <RadixSelect.Value placeholder={placeholder} />
        <RadixSelect.Icon>
          <ChevronDown size={14} className="text-[var(--text-secondary)]" />
        </RadixSelect.Icon>
      </RadixSelect.Trigger>

      <RadixSelect.Portal>
        <RadixSelect.Content
          className={cn(
            'bg-[var(--bg-level-0)] rounded-[var(--card-radius)] border border-[var(--neutral-200)]',
            'shadow-[var(--shadow-dropdown)] overflow-hidden z-[100]',
            'animate-in fade-in-0 zoom-in-95'
          )}
          position="popper"
          sideOffset={4}
        >
          <RadixSelect.Viewport className="py-1.5">
            {options.map((opt) => (
              <RadixSelect.Item
                key={opt.value}
                value={opt.value}
                disabled={opt.disabled}
                className={cn(
                  'relative flex items-center px-3 py-2.5 text-[14px] text-[var(--text-primary)]',
                  'outline-none cursor-pointer select-none',
                  'data-[highlighted]:bg-[var(--brand-primary-light)]',
                  'data-[disabled]:opacity-50 data-[disabled]:pointer-events-none'
                )}
              >
                <RadixSelect.ItemText>{opt.label}</RadixSelect.ItemText>
                <RadixSelect.ItemIndicator className="absolute right-3">
                  <Check size={14} className="text-[var(--brand-primary)]" />
                </RadixSelect.ItemIndicator>
              </RadixSelect.Item>
            ))}
          </RadixSelect.Viewport>
        </RadixSelect.Content>
      </RadixSelect.Portal>
    </RadixSelect.Root>

    {errorMessage && (
      <motion.p
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-1.5 mt-1.5 text-[12px] font-medium text-[var(--danger)]"
      >
        <AlertCircle size={12} />
        {errorMessage}
      </motion.p>
    )}
  </div>
);

export { Select };
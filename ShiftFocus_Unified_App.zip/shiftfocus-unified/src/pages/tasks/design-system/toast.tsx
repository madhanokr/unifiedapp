/**
 * ShiftFocus Toast System
 * Standardized wrapper around Sonner toasts.
 * Import `sfToast` instead of raw `toast` for consistent UX.
 */
import { toast } from 'sonner';

/* ── Standardized Toast API ──────────────────────────────── */

export const sfToast = {
  /** Green success toast */
  success: (message: string, description?: string) =>
    toast.success(message, { description }),

  /** Red error toast */
  error: (message: string, description?: string) =>
    toast.error(message, { description }),

  /** Orange warning toast */
  warning: (message: string, description?: string) =>
    toast.warning(message, { description }),

  /** Blue info toast */
  info: (message: string, description?: string) =>
    toast.info(message, { description }),

  /** Promise-based loading → success/error */
  promise: <T,>(
    promise: Promise<T>,
    messages: { loading: string; success: string; error: string }
  ) =>
    toast.promise(promise, {
      loading: messages.loading,
      success: messages.success,
      error: messages.error,
    }),

  /** Custom toast with action button */
  action: (
    message: string,
    actionLabel: string,
    onAction: () => void,
    description?: string
  ) =>
    toast(message, {
      description,
      action: {
        label: actionLabel,
        onClick: onAction,
      },
    }),

  /** Dismiss a specific toast or all */
  dismiss: (toastId?: string | number) => toast.dismiss(toastId),
};

export { toast };

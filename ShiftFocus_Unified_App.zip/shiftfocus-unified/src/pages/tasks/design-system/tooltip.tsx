import React from 'react';
import * as RadixTooltip from '@radix-ui/react-tooltip';
import { cn } from '../lib/utils';

/* ── Props ────────────────────────────────────────────────── */

export interface TooltipProps {
  content: React.ReactNode;
  children: React.ReactNode;
  side?: 'top' | 'right' | 'bottom' | 'left';
  align?: 'start' | 'center' | 'end';
  sideOffset?: number;
  delayDuration?: number;
  className?: string;
}

/* ── Provider (wrap app once) ────────────────────────────── */

const TooltipProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <RadixTooltip.Provider delayDuration={300} skipDelayDuration={0}>
    {children}
  </RadixTooltip.Provider>
);

/* ── Component ────────────────────────────────────────────── */

const Tooltip: React.FC<TooltipProps> = ({
  content,
  children,
  side = 'top',
  align = 'center',
  sideOffset = 6,
  delayDuration = 200,
  className,
}) => (
  <RadixTooltip.Root delayDuration={delayDuration}>
    <RadixTooltip.Trigger asChild>{children}</RadixTooltip.Trigger>
    <RadixTooltip.Portal>
      <RadixTooltip.Content
        side={side}
        align={align}
        sideOffset={sideOffset}
        className={cn(
          'z-[200] px-3 py-2 rounded-lg',
          'bg-[var(--neutral-950)] text-[var(--text-white)]',
          'text-[12px] font-normal leading-[1.4]',
          'shadow-[var(--shadow-tooltip)]',
          'animate-in fade-in-0 zoom-in-95',
          'data-[side=bottom]:slide-in-from-top-1',
          'data-[side=top]:slide-in-from-bottom-1',
          'data-[side=left]:slide-in-from-right-1',
          'data-[side=right]:slide-in-from-left-1',
          className
        )}
      >
        {content}
        <RadixTooltip.Arrow className="fill-[var(--neutral-950)]" />
      </RadixTooltip.Content>
    </RadixTooltip.Portal>
  </RadixTooltip.Root>
);

export { Tooltip, TooltipProvider };
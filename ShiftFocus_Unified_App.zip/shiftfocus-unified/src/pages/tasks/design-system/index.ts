/* ── ShiftFocus Design System ─────────────────────────────── */
/* Barrel export — import everything from '@/components/design-system' */

// Button
export { Button, IconButton, buttonVariants } from './button';
export type { ButtonProps, IconButtonProps } from './button';

// Badge
export { Badge, PriorityBadge, StatusBadge, RiskBadge, CountBadge, badgeVariants } from './badge';
export type { BadgeProps, SemanticBadgeProps, CountBadgeProps } from './badge';

// Input
export { Input, Textarea, FieldError, inputVariants } from './input';
export type { InputProps, TextareaProps } from './input';

// Select
export { Select } from './select';
export type { SelectProps, SelectOption } from './select';

// Dialog
export {
  Dialog,
  DialogOverlay,
  DialogContent,
  DialogHeader,
  DialogBody,
  DialogFooter,
  DialogTitle,
  DialogDescription,
  dialogContentVariants,
} from './dialog';
export type { DialogProps, DialogContentProps, DialogHeaderProps, DialogFooterProps } from './dialog';

// Drawer
export { Drawer, DrawerContent, DrawerHeader, DrawerBody, drawerVariants } from './drawer';
export type { DrawerProps, DrawerContentProps, DrawerHeaderProps } from './drawer';

// Dropdown Menu
export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuRadioGroup,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuGroup,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from './dropdown-menu';
export type { DropdownMenuContentProps, DropdownMenuItemProps } from './dropdown-menu';

// Tabs
export { Tabs, TabsList, TabsTrigger, TabsContent, tabListVariants, tabTriggerVariants } from './tabs';
export type { TabsProps, TabsListProps, TabsTriggerProps, TabsContentProps } from './tabs';

// Tooltip
export { Tooltip, TooltipProvider } from './tooltip';
export type { TooltipProps } from './tooltip';

// Switch
export { Switch, switchRootVariants } from './switch';
export type { SwitchProps } from './switch';

// Checkbox
export { Checkbox } from './checkbox';
export type { CheckboxProps } from './checkbox';

// Card
export { Card, CardHeader, CardBody, CardFooter, cardVariants } from './card';
export type { CardProps, CardHeaderProps, CardBodyProps, CardFooterProps } from './card';

// Progress Bar
export { ProgressBar, progressTrackVariants, progressFillVariants } from './progress-bar';
export type { ProgressBarProps } from './progress-bar';

// Skeleton
export { Skeleton, SkeletonText, SkeletonAvatar, SkeletonCard, skeletonVariants } from './skeleton';
export type { SkeletonProps } from './skeleton';

// Empty State
export { EmptyState } from './empty-state';
export type { EmptyStateProps } from './empty-state';

// Toast
export { sfToast, toast } from './toast';

import React from 'react';
import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';
import { CountBadge } from './design-system';

interface AICommanderProps {
  onClick: () => void;
}

const AICommander: React.FC<AICommanderProps> = ({ onClick }) => {
  return (
    <motion.button
      onClick={onClick}
      className="fixed bottom-8 right-8 h-14 px-6 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white rounded-full shadow-[var(--shadow-modal)] flex items-center gap-3 z-50"
      whileHover={{
        scale: 1.05,
        boxShadow: 'var(--shadow-brand-hover)',
      }}
      whileTap={{ scale: 0.95, translateY: 1 }}
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
    >
      <motion.div
        animate={{ rotate: [0, 10, -10, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
      >
        <Sparkles size={20} />
      </motion.div>
      <span className="text-[14px] font-medium leading-[1.5]">AI Insights</span>
      <CountBadge count={12} variant="neutral" className="bg-white/20 text-white" />
    </motion.button>
  );
};

export default AICommander;

/**
 * ShiftFocus Data Store
 * localStorage-based persistence layer with method-based abstraction.
 * When backend arrives, swap db.getById() for api.getById().
 */

export interface Project {
  id: string;
  name: string;
  icon: string;        // emoji or Lucide icon name
  color: string;       // one of: brand, danger, warning, success, info, neutral
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'In Progress' | 'Not Started' | 'Blocked' | 'Waiting' | 'Completed';
  assignee: { name: string; avatar: string };
  dueDate: string;
  krImpact: number;
  aiRisk: 'high' | 'medium' | 'low';
  comments?: number;
  attachments?: number;
  aiScore?: number;
  projectId: string;     // references Project.id, or 'inbox' for ungrouped tasks
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'escalation' | 'system';
  title: string;
  message: string;
  time: string;
  unread: boolean;
  taskId?: string;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'amoled';
  compactMode: boolean;
  showAvatars: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  slackNotifications: boolean;
  aiLevel: 'minimal' | 'balanced' | 'aggressive';
  defaultView: string;
  language: string;
  userName: string;
  userEmail: string;
}

// ── Default Data ────────────────────────────────────────────

const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'inbox',
    name: 'Inbox',
    icon: '📥',
    color: 'neutral',
    description: 'Default bucket for unassigned tasks',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'sprint-backlog',
    name: 'Sprint Backlog',
    icon: '🏃',
    color: 'brand',
    description: 'Current sprint tasks',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'product-roadmap',
    name: 'Product Roadmap',
    icon: '🗺️',
    color: 'info',
    description: 'Long-term product planning',
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  },
];

const DEFAULT_TASKS: Task[] = [
  {
    id: '1',
    title: 'Implement authentication flow',
    description: 'Build OAuth integration with Google and GitHub providers',
    priority: 'Critical',
    status: 'In Progress',
    assignee: { name: 'Sarah Chen', avatar: 'SC' },
    dueDate: '2026-02-12',
    krImpact: 85,
    aiRisk: 'high',
    comments: 12,
    attachments: 3,
    aiScore: 95,
    projectId: 'sprint-backlog',
    createdAt: '2026-02-03T10:00:00Z',
    updatedAt: '2026-02-10T08:00:00Z',
  },
  {
    id: '2',
    title: 'Design new dashboard layout',
    description: 'Create Figma mockups for analytics dashboard',
    priority: 'High',
    status: 'In Progress',
    assignee: { name: 'Mike Ross', avatar: 'MR' },
    dueDate: '2026-02-14',
    krImpact: 72,
    aiRisk: 'low',
    comments: 5,
    aiScore: 88,
    projectId: 'product-roadmap',
    createdAt: '2026-02-04T09:00:00Z',
    updatedAt: '2026-02-10T07:30:00Z',
  },
  {
    id: '3',
    title: 'Optimize database queries',
    description: 'Reduce query time for user analytics by 60%',
    priority: 'High',
    status: 'Not Started',
    assignee: { name: 'Alex Kim', avatar: 'AK' },
    dueDate: '2026-02-16',
    krImpact: 68,
    aiRisk: 'medium',
    attachments: 1,
    aiScore: 82,
    projectId: 'sprint-backlog',
    createdAt: '2026-02-05T11:00:00Z',
    updatedAt: '2026-02-09T14:00:00Z',
  },
  {
    id: '4',
    title: 'Update API documentation',
    description: 'Document all v2 endpoints with examples',
    priority: 'Medium',
    status: 'Blocked',
    assignee: { name: 'Emma Stone', avatar: 'ES' },
    dueDate: '2026-02-19',
    krImpact: 45,
    aiRisk: 'high',
    comments: 8,
    attachments: 2,
    aiScore: 76,
    projectId: 'product-roadmap',
    createdAt: '2026-02-06T08:30:00Z',
    updatedAt: '2026-02-08T16:00:00Z',
  },
  {
    id: '5',
    title: 'Implement dark mode',
    description: 'Add theme switcher and dark mode styles',
    priority: 'Low',
    status: 'Waiting',
    assignee: { name: 'David Park', avatar: 'DP' },
    dueDate: '2026-02-22',
    krImpact: 32,
    aiRisk: 'low',
    aiScore: 65,
    projectId: 'inbox',
    createdAt: '2026-02-07T10:00:00Z',
    updatedAt: '2026-02-07T10:00:00Z',
  },
  {
    id: '6',
    title: 'Refactor payment processing',
    description: 'Migrate to new Stripe API version',
    priority: 'Critical',
    status: 'In Progress',
    assignee: { name: 'Sarah Chen', avatar: 'SC' },
    dueDate: '2026-02-11',
    krImpact: 92,
    aiRisk: 'high',
    comments: 15,
    aiScore: 97,
    projectId: 'sprint-backlog',
    createdAt: '2026-02-02T09:00:00Z',
    updatedAt: '2026-02-10T06:00:00Z',
  },
  {
    id: '7',
    title: 'Mobile app performance audit',
    description: 'Identify and fix performance bottlenecks',
    priority: 'High',
    status: 'Not Started',
    assignee: { name: 'Mike Ross', avatar: 'MR' },
    dueDate: '2026-02-18',
    krImpact: 78,
    aiRisk: 'medium',
    aiScore: 80,
    projectId: 'product-roadmap',
    createdAt: '2026-02-05T14:00:00Z',
    updatedAt: '2026-02-05T14:00:00Z',
  },
  {
    id: '8',
    title: 'Setup CI/CD pipeline',
    description: 'Configure automated testing and deployment',
    priority: 'Medium',
    status: 'Completed',
    assignee: { name: 'Alex Kim', avatar: 'AK' },
    dueDate: '2026-02-08',
    krImpact: 55,
    aiRisk: 'low',
    attachments: 4,
    aiScore: 70,
    projectId: 'sprint-backlog',
    createdAt: '2026-02-01T08:00:00Z',
    updatedAt: '2026-02-08T12:00:00Z',
  },
  {
    id: '9',
    title: 'Security vulnerability assessment',
    description: 'Run OWASP top-10 checks on all endpoints',
    priority: 'Critical',
    status: 'Not Started',
    assignee: { name: 'Emma Stone', avatar: 'ES' },
    dueDate: '2026-02-13',
    krImpact: 88,
    aiRisk: 'high',
    aiScore: 93,
    projectId: 'sprint-backlog',
    createdAt: '2026-02-08T10:00:00Z',
    updatedAt: '2026-02-08T10:00:00Z',
  },
  {
    id: '10',
    title: 'User onboarding flow redesign',
    description: 'Simplify 7-step onboarding to 3 steps',
    priority: 'Medium',
    status: 'In Progress',
    assignee: { name: 'David Park', avatar: 'DP' },
    dueDate: '2026-02-20',
    krImpact: 62,
    aiRisk: 'low',
    comments: 3,
    aiScore: 74,
    projectId: 'product-roadmap',
    createdAt: '2026-02-06T15:00:00Z',
    updatedAt: '2026-02-10T09:00:00Z',
  },
  {
    id: '11',
    title: 'Implement real-time notifications',
    description: 'Add WebSocket layer for live notifications',
    priority: 'High',
    status: 'Waiting',
    assignee: { name: 'Alex Kim', avatar: 'AK' },
    dueDate: '2026-02-17',
    krImpact: 74,
    aiRisk: 'medium',
    comments: 6,
    aiScore: 83,
    projectId: 'inbox',
    createdAt: '2026-02-04T12:00:00Z',
    updatedAt: '2026-02-09T10:00:00Z',
  },
  {
    id: '12',
    title: 'Data export functionality',
    description: 'Allow CSV/JSON/PDF exports from analytics',
    priority: 'Low',
    status: 'Not Started',
    assignee: { name: 'Mike Ross', avatar: 'MR' },
    dueDate: '2026-02-25',
    krImpact: 28,
    aiRisk: 'low',
    aiScore: 55,
    projectId: 'inbox',
    createdAt: '2026-02-07T16:00:00Z',
    updatedAt: '2026-02-07T16:00:00Z',
  },
];

const DEFAULT_NOTIFICATIONS: Notification[] = [
  {
    id: 'n1',
    type: 'escalation',
    title: 'Escalation Warning',
    message: 'Task "Implement authentication flow" will escalate to Engineering Manager in 18 hours.',
    time: '15 minutes ago',
    unread: true,
    taskId: '1',
  },
  {
    id: 'n2',
    type: 'warning',
    title: 'Sprint Delay Predicted',
    message: 'Current velocity indicates Sprint 24 will delay by 2.1 days. 3 tasks at risk.',
    time: '1 hour ago',
    unread: true,
  },
  {
    id: 'n3',
    type: 'system',
    title: 'Idle Subtask Detected',
    message: '"Add error handling and retry logic" has been idle for 3 days. Progress signal required.',
    time: '2 hours ago',
    unread: true,
    taskId: '1',
  },
  {
    id: 'n4',
    type: 'info',
    title: 'Dependency Update',
    message: 'Task "Database Migration" now blocks 3 downstream tasks. Estimated impact: 15% KR.',
    time: '3 hours ago',
    unread: true,
  },
  {
    id: 'n5',
    type: 'success',
    title: 'Task Completed',
    message: 'Alex Kim completed "Setup CI/CD pipeline" ahead of schedule.',
    time: '5 hours ago',
    unread: false,
    taskId: '8',
  },
  {
    id: 'n6',
    type: 'info',
    title: 'Due Date Reminder',
    message: '2 tasks are due within 48 hours. Review and confirm execution status.',
    time: '6 hours ago',
    unread: false,
  },
  {
    id: 'n7',
    type: 'warning',
    title: 'Blocked Task Cascade',
    message: '"Update API documentation" blocked for 2 days. 2 downstream tasks affected.',
    time: '8 hours ago',
    unread: false,
    taskId: '4',
  },
  {
    id: 'n8',
    type: 'success',
    title: 'Task Assigned',
    message: 'You have been assigned "Security vulnerability assessment" by Emma Stone.',
    time: '1 day ago',
    unread: false,
    taskId: '9',
  },
];

const DEFAULT_SETTINGS: UserSettings = {
  theme: 'light',
  compactMode: false,
  showAvatars: true,
  emailNotifications: true,
  pushNotifications: true,
  slackNotifications: false,
  aiLevel: 'balanced',
  defaultView: 'list',
  language: 'en',
  userName: 'John Doe',
  userEmail: 'john@shiftfocus.io',
};

// ── Storage Operations ──────────────────────────────────────

const KEYS = {
  tasks: 'shiftfocus_tasks',
  notifications: 'shiftfocus_notifications',
  settings: 'shiftfocus_settings',
  projects: 'shiftfocus_projects',
} as const;

function getFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function setToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // silent fail
  }
}

// ── Public API ──────────────────────────────────────────────

export const db = {
  // Projects
  getProjects: (): Project[] => getFromStorage(KEYS.projects, DEFAULT_PROJECTS),
  getProjectById: (id: string): Project | undefined => {
    const projects = db.getProjects();
    return projects.find(p => p.id === id);
  },
  createProject: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Project => {
    const projects = db.getProjects();
    const newProject: Project = {
      ...project,
      id: `project-${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(newProject);
    setToStorage(KEYS.projects, projects);
    return newProject;
  },
  updateProject: (id: string, updates: Partial<Project>): Project | undefined => {
    if (id === 'inbox' && (updates.name || updates.id)) return undefined; // Cannot rename or change inbox id
    const projects = db.getProjects();
    const idx = projects.findIndex(p => p.id === id);
    if (idx === -1) return undefined;
    projects[idx] = { ...projects[idx]!, ...updates, updatedAt: new Date().toISOString() };
    setToStorage(KEYS.projects, projects);
    return projects[idx];
  },
  deleteProject: (id: string): { deletedProject: Project; movedTaskCount: number } | undefined => {
    if (id === 'inbox') return undefined; // Cannot delete inbox
    const projects = db.getProjects();
    const idx = projects.findIndex(p => p.id === id);
    if (idx === -1) return undefined;
    const deletedProject = projects[idx]!;
    
    // Move all tasks in this project to inbox
    const tasks = db.getTasks();
    let movedCount = 0;
    const updatedTasks = tasks.map(t => {
      if (t.projectId === id) {
        movedCount++;
        return { ...t, projectId: 'inbox', updatedAt: new Date().toISOString() };
      }
      return t;
    });
    setToStorage(KEYS.tasks, updatedTasks);
    
    // Remove project
    const filtered = projects.filter(p => p.id !== id);
    setToStorage(KEYS.projects, filtered);
    
    return { deletedProject, movedTaskCount: movedCount };
  },

  // Tasks
  getTasks: (): Task[] => {
    const tasks = getFromStorage(KEYS.tasks, DEFAULT_TASKS);
    // Ensure all tasks have projectId (migration for existing data)
    return tasks.map(t => ({
      ...t,
      projectId: t.projectId || 'inbox',
    }));
  },
  getById: (id: string): Task | undefined => {
    const tasks = db.getTasks();
    return tasks.find(t => t.id === id);
  },
  getTasksByProject: (projectId: string): Task[] => {
    const tasks = db.getTasks();
    return tasks.filter(t => t.projectId === projectId);
  },
  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>): Task => {
    const tasks = db.getTasks();
    const newTask: Task = {
      ...task,
      projectId: task.projectId || 'inbox',
      id: String(Date.now()),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    tasks.push(newTask);
    setToStorage(KEYS.tasks, tasks);
    return newTask;
  },
  updateTask: (id: string, updates: Partial<Task>): Task | undefined => {
    const tasks = db.getTasks();
    const idx = tasks.findIndex(t => t.id === id);
    if (idx === -1) return undefined;
    tasks[idx] = { ...tasks[idx]!, ...updates, updatedAt: new Date().toISOString() };
    setToStorage(KEYS.tasks, tasks);
    return tasks[idx];
  },
  deleteTask: (id: string): boolean => {
    const tasks = db.getTasks();
    const filtered = tasks.filter(t => t.id !== id);
    if (filtered.length === tasks.length) return false;
    setToStorage(KEYS.tasks, filtered);
    return true;
  },
  moveTask: (taskId: string, newProjectId: string): Task | undefined => {
    return db.updateTask(taskId, { projectId: newProjectId });
  },

  // Notifications
  getNotifications: (): Notification[] => getFromStorage(KEYS.notifications, DEFAULT_NOTIFICATIONS),
  markRead: (id: string): void => {
    const notifs = db.getNotifications();
    const idx = notifs.findIndex(n => n.id === id);
    if (idx !== -1 && notifs[idx]) {
      notifs[idx] = { ...notifs[idx]!, unread: false };
      setToStorage(KEYS.notifications, notifs);
    }
  },
  markAllRead: (): void => {
    const notifs = db.getNotifications().map(n => ({ ...n, unread: false }));
    setToStorage(KEYS.notifications, notifs);
  },
  clearNotification: (id: string): void => {
    const notifs = db.getNotifications().filter(n => n.id !== id);
    setToStorage(KEYS.notifications, notifs);
  },

  // Settings
  getSettings: (): UserSettings => getFromStorage(KEYS.settings, DEFAULT_SETTINGS),
  updateSettings: (updates: Partial<UserSettings>): UserSettings => {
    const current = db.getSettings();
    const updated = { ...current, ...updates };
    setToStorage(KEYS.settings, updated);
    return updated;
  },

  // Reset
  reset: (): void => {
    setToStorage(KEYS.tasks, DEFAULT_TASKS);
    setToStorage(KEYS.notifications, DEFAULT_NOTIFICATIONS);
    setToStorage(KEYS.settings, DEFAULT_SETTINGS);
    setToStorage(KEYS.projects, DEFAULT_PROJECTS);
  },
};

// ── Design System Constants ─────────────────────────────────

export const PRIORITY_STYLES = {
  Critical: 'bg-[var(--danger-light)] text-[var(--danger-dark)] border-[var(--danger-light)]',
  High: 'bg-[var(--warning-light)] text-[var(--warning-dark)] border-[var(--warning-light)]',
  Medium: 'bg-[var(--info-light)] text-[var(--info-dark)] border-[var(--info-light)]',
  Low: 'bg-[var(--neutral-100)] text-[var(--neutral-600)] border-[var(--neutral-200)]',
} as const;

export const STATUS_STYLES = {
  'In Progress': 'bg-[var(--info-light)] text-[var(--info-dark)] border-[var(--info-light)]',
  'Not Started': 'bg-[var(--neutral-100)] text-[var(--neutral-600)] border-[var(--neutral-200)]',
  'Blocked': 'bg-[var(--blocked-light)] text-[var(--danger)] border-[var(--blocked-light)]',
  'Waiting': 'bg-[var(--warning-light)] text-[var(--warning)] border-[var(--warning-light)]',
  'Completed': 'bg-[var(--success-light)] text-[var(--success-dark)] border-[var(--success-light)]',
} as const;

export const STATUS_DOT_COLORS = {
  'In Progress': 'bg-[var(--info-dark)]',
  'Not Started': 'bg-[var(--neutral-400)]',
  'Blocked': 'bg-[var(--danger)]',
  'Waiting': 'bg-[var(--warning)]',
  'Completed': 'bg-[var(--success-dark)]',
} as const;

export const RISK_STYLES = {
  high: { bg: 'bg-[var(--danger-light)]', text: 'text-[var(--danger)]', label: 'High Risk' },
  medium: { bg: 'bg-[var(--warning-light)]', text: 'text-[var(--at-risk)]', label: 'Medium' },
  low: { bg: 'bg-[var(--success-light)]', text: 'text-[var(--on-track)]', label: 'On Track' },
} as const;

export const KANBAN_STATUS_MAP: Record<string, Task['status']> = {
  'not-started': 'Not Started',
  'in-progress': 'In Progress',
  'blocked': 'Blocked',
  'waiting': 'Waiting',
  'completed': 'Completed',
};

export const KANBAN_COLUMNS = [
  { id: 'not-started', label: 'Not Started', dotColor: 'var(--neutral-400)' },
  { id: 'in-progress', label: 'In Progress', dotColor: 'var(--info-dark)' },
  { id: 'blocked', label: 'Blocked', dotColor: 'var(--danger)' },
  { id: 'waiting', label: 'Waiting', dotColor: 'var(--warning)' },
  { id: 'completed', label: 'Completed', dotColor: 'var(--success-dark)' },
] as const;

export const STATUS_TO_COLUMN: Record<Task['status'], string> = {
  'Not Started': 'not-started',
  'In Progress': 'in-progress',
  'Blocked': 'blocked',
  'Waiting': 'waiting',
  'Completed': 'completed',
};

export const PROJECT_COLOR_MAP: Record<string, string> = {
  brand: 'var(--brand-primary)',
  danger: 'var(--danger)',
  warning: 'var(--warning-dark)',
  success: 'var(--on-track)',
  info: 'var(--info)',
  neutral: 'var(--neutral-600)',
};

export type TaskStatus = Task['status'];
export type TaskPriority = Task['priority'];

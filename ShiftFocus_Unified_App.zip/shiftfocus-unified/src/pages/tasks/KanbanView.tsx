import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plus,
  AlertTriangle,
  TrendingUp,
  MoreHorizontal,
  Clock,
  MessageSquare,
  Paperclip,
  GripVertical,
  ArrowRight,
  Inbox,
} from 'lucide-react';
import TaskDetailModal from './TaskDetailModal';
import ConfirmDialog from './ConfirmDialog';
import {
  db,
  Task,
  RISK_STYLES,
  KANBAN_COLUMNS,
  KANBAN_STATUS_MAP,
  STATUS_TO_COLUMN,
} from './data-store';
import { KanbanSkeleton, ErrorState, useDataLoader } from './LoadingStates';
import { useFilters } from './FilterContext';
import {
  PriorityBadge,
  CountBadge,
  Button,
  IconButton,
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  sfToast,
} from './design-system';

const KanbanView = () => {
  const [tasks, setTasks] = useState<Task[]>(() => db.getTasks());
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [draggedTask, setDraggedTask] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);
  const [contextMenuTask, setContextMenuTask] = useState<string | null>(null);
  const [quickAddColumn, setQuickAddColumn] = useState<string | null>(null);
  const [quickAddTitle, setQuickAddTitle] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<{ open: boolean; taskId: string | null }>({ open: false, taskId: null });

  const loader = React.useCallback(() => db.getTasks(), []);
  const { isLoading, hasError, errorMessage, retry } = useDataLoader(loader, 800);

  const { filters, applyFilters } = useFilters();
  const refreshTasks = useCallback(() => setTasks(db.getTasks()), []);

  const getColumnTasks = (columnId: string) => {
    const status = KANBAN_STATUS_MAP[columnId];
    if (!status) return [];
    const statusTasks = tasks.filter((t) => t.status === status);
    return applyFilters(statusTasks);
  };

  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, taskId: string) => {
    setDraggedTask(taskId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', taskId);
  };

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverColumn(columnId);
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain');
    const newStatus = KANBAN_STATUS_MAP[columnId];
    if (taskId && newStatus) {
      db.updateTask(taskId, { status: newStatus });
      refreshTasks();
    }
    setDraggedTask(null);
    setDragOverColumn(null);
  };

  const handleMoveTask = (taskId: string, newStatus: Task['status']) => {
    db.updateTask(taskId, { status: newStatus });
    refreshTasks();
  };

  const handleQuickAdd = (columnId: string) => {
    if (!quickAddTitle.trim()) return;
    const status = KANBAN_STATUS_MAP[columnId];
    if (!status) return;
    db.createTask({
      title: quickAddTitle.trim(),
      description: '',
      priority: 'Medium',
      status,
      assignee: { name: 'Unassigned', avatar: 'UA' },
      dueDate: '',
      krImpact: 50,
      aiRisk: 'low',
      aiScore: 50,
      projectId: filters.activeProjectId || 'inbox',
    });
    setQuickAddTitle('');
    setQuickAddColumn(null);
    refreshTasks();
  };

  const handleDeleteTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    db.deleteTask(taskId);
    sfToast.success('Task deleted', task ? `"${task.title}" has been removed.` : 'Task has been removed.');
    refreshTasks();
  };

  const getDaysUntilDue = (dueDate: string): number | null => {
    if (!dueDate) return null;
    const now = new Date();
    const due = new Date(dueDate);
    return Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  if (isLoading) return <KanbanSkeleton columns={5} />;
  if (hasError) return <ErrorState message={errorMessage} onRetry={retry} />;

  return (
    <>
      <div className="flex gap-5 overflow-x-auto pb-6">
        {KANBAN_COLUMNS.map((column) => {
          const columnTasks = getColumnTasks(column.id);
          const isOver = dragOverColumn === column.id;

          return (
            <div
              key={column.id}
              className="flex-shrink-0 w-[304px]"
              onDragOver={(e) => handleDragOver(e, column.id)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, column.id)}
            >
              {/* Column Header */}
              <div className="mb-3 px-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: column.dotColor }}
                    />
                    <span className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
                      {column.label}
                    </span>
                    <CountBadge count={columnTasks.length} variant="neutral" />
                  </div>
                  <IconButton
                    icon={<Plus size={16} />}
                    size="sm"
                    onClick={() => {
                      setQuickAddColumn(quickAddColumn === column.id ? null : column.id);
                      setQuickAddTitle('');
                    }}
                  />
                </div>
              </div>

              {/* Drop Zone Indicator */}
              <div
                className={`
                  rounded-[var(--card-radius)] min-h-[200px] p-1.5 transition-all duration-[150ms]
                  ${isOver ? 'bg-[var(--brand-primary-light)] ring-2 ring-[var(--brand-primary)] ring-dashed' : ''}
                `}
              >
                {/* Quick Add Input */}
                <AnimatePresence>
                  {quickAddColumn === column.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-2"
                    >
                      <div className="p-3 bg-[var(--bg-level-0)] rounded-[var(--card-radius)] border-2 border-[var(--brand-primary)] shadow-[var(--shadow-card)]">
                        <input
                          type="text"
                          value={quickAddTitle}
                          onChange={(e) => setQuickAddTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleQuickAdd(column.id);
                            if (e.key === 'Escape') setQuickAddColumn(null);
                          }}
                          placeholder="Task title..."
                          className="w-full text-[14px] font-normal leading-[1.5] text-[var(--text-primary)] placeholder:text-[var(--text-tertiary)] focus:outline-none bg-transparent"
                          autoFocus
                        />
                        <div className="flex items-center justify-end gap-2 mt-3">
                          <Button variant="ghost" size="sm" onClick={() => setQuickAddColumn(null)}>
                            Cancel
                          </Button>
                          <Button variant="primary" size="sm" onClick={() => handleQuickAdd(column.id)} disabled={!quickAddTitle.trim()}>
                            Add
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Cards */}
                <div className="space-y-2.5">
                  {columnTasks.length === 0 && quickAddColumn !== column.id && (
                    <div className="py-8 text-center">
                      <Inbox size={20} className="mx-auto text-[var(--text-tertiary)] mb-2" />
                      <p className="text-[12px] font-normal text-[var(--text-tertiary)]">No tasks</p>
                    </div>
                  )}
                  {columnTasks.map((task, index) => {
                    const daysUntil = getDaysUntilDue(task.dueDate);
                    const isOverdue = daysUntil !== null && daysUntil < 0;
                    const isDueSoon = daysUntil !== null && daysUntil >= 0 && daysUntil <= 2;
                    const isDragging = draggedTask === task.id;

                    return (
                      <motion.div
                        key={task.id}
                        draggable
                        onDragStart={(e: React.DragEvent<HTMLDivElement>) => handleDragStart(e, task.id)}
                        onDragEnd={() => setDraggedTask(null)}
                        className={`
                          p-4 bg-[var(--bg-level-0)] rounded-[var(--card-radius)] border border-[var(--neutral-200)] 
                          shadow-[var(--shadow-card)] 
                          hover:shadow-[var(--shadow-card-hover)] hover:border-[var(--brand-primary)]
                          transition-all duration-[150ms] cursor-grab active:cursor-grabbing
                          group relative
                          ${isDragging ? 'opacity-40 scale-95' : ''}
                        `}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: isDragging ? 0.4 : 1, y: 0 }}
                        transition={{ delay: index * 0.03, duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                        onClick={() => setSelectedTask(task)}
                      >
                        {/* Drag Handle */}
                        <div className="absolute top-2 left-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <GripVertical size={14} className="text-[var(--text-tertiary)]" />
                        </div>

                        {/* Top Row: Priority + Risk */}
                        <div className="flex items-center justify-between mb-3">
                          <PriorityBadge value={task.priority} />
                          <div
                            className={`
                              w-7 h-7 rounded-full flex items-center justify-center
                              ${RISK_STYLES[task.aiRisk].bg}
                            `}
                          >
                            <AlertTriangle size={12} className={RISK_STYLES[task.aiRisk].text} />
                          </div>
                        </div>

                        {/* Task Title */}
                        <h4 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-1.5 line-clamp-2">
                          {task.title}
                        </h4>
                        <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mb-4 line-clamp-2">
                          {task.description}
                        </p>

                        {/* Due Date Indicator */}
                        {task.dueDate && (
                          <div className={`
                            flex items-center gap-1.5 mb-3 text-[12px] font-medium leading-[1.3]
                            ${isOverdue ? 'text-[var(--danger)]' : isDueSoon ? 'text-[var(--at-risk)]' : 'text-[var(--text-secondary)]'}
                          `}>
                            <Clock size={12} />
                            <span>
                              {isOverdue
                                ? `${Math.abs(daysUntil!)}d overdue`
                                : isDueSoon
                                  ? `Due in ${daysUntil}d`
                                  : new Date(task.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </span>
                          </div>
                        )}

                        {/* Footer */}
                        <div className="flex items-center justify-between pt-3 border-t border-[var(--neutral-100)]">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[10px] font-medium">
                              {task.assignee.avatar}
                            </div>
                            <span className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
                              {task.assignee.name.split(' ')[0]}
                            </span>
                          </div>
                          <div className="flex items-center gap-3 text-[12px] text-[var(--text-tertiary)]">
                            {task.comments && task.comments > 0 && (
                              <div className="flex items-center gap-1">
                                <MessageSquare size={12} />
                                <span>{task.comments}</span>
                              </div>
                            )}
                            {task.attachments && task.attachments > 0 && (
                              <div className="flex items-center gap-1">
                                <Paperclip size={12} />
                                <span>{task.attachments}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-1">
                              <TrendingUp size={12} className="text-[var(--brand-primary)]" />
                              <span className="text-[var(--brand-primary)] font-medium">{task.krImpact}%</span>
                            </div>
                          </div>
                        </div>

                        {/* Context Menu */}
                        <DropdownMenu open={contextMenuTask === task.id} onOpenChange={(open) => setContextMenuTask(open ? task.id : null)}>
                          <DropdownMenuTrigger asChild>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setContextMenuTask(contextMenuTask === task.id ? null : task.id);
                              }}
                              className="absolute top-3 right-3 w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 hover:bg-[var(--neutral-100)] rounded-md transition-all"
                            >
                              <MoreHorizontal size={14} className="text-[var(--text-tertiary)]" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-[200px]">
                            <DropdownMenuLabel>Move to</DropdownMenuLabel>
                            {KANBAN_COLUMNS.filter((col) => {
                              return STATUS_TO_COLUMN[task.status] !== col.id;
                            }).map((col) => (
                              <DropdownMenuItem
                                key={col.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const status = KANBAN_STATUS_MAP[col.id];
                                  if (status) handleMoveTask(task.id, status);
                                }}
                                icon={<div className="w-2 h-2 rounded-full" style={{ backgroundColor: col.dotColor }} />}
                              >
                                {col.label}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedTask(task);
                                setContextMenuTask(null);
                              }}
                            >
                              Open Details
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-[var(--danger)]"
                              onClick={(e) => {
                                e.stopPropagation();
                                setContextMenuTask(null);
                                setDeleteConfirm({ open: true, taskId: task.id });
                              }}
                            >
                              Delete Task
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Add Task Button (bottom) */}
                {quickAddColumn !== column.id && (
                  <button
                    onClick={() => {
                      setQuickAddColumn(column.id);
                      setQuickAddTitle('');
                    }}
                    className="w-full mt-3 h-10 border-2 border-dashed border-[var(--neutral-200)] rounded-[var(--card-radius)] text-[14px] font-medium text-[var(--text-tertiary)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] hover:bg-[var(--brand-primary-light)] transition-all duration-[150ms] flex items-center justify-center gap-2"
                  >
                    <Plus size={14} />
                    Add Task
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          onClose={() => {
            setSelectedTask(null);
            refreshTasks();
          }}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        open={deleteConfirm.open}
        onOpenChange={(open) => { if (!open) setDeleteConfirm({ open: false, taskId: null }); }}
        title="Delete Task"
        description="Are you sure you want to delete this task? This action cannot be undone."
        confirmLabel="Delete"
        variant="destructive"
        onConfirm={() => {
          if (deleteConfirm.taskId) handleDeleteTask(deleteConfirm.taskId);
        }}
      />
    </>
  );
};

export default KanbanView;
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Calendar,
  Clock,
  AlertCircle,
  CheckCircle,
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Inbox,
  ArrowUpRight,
  Target,
  Activity,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import TaskDetailModal from './TaskDetailModal';
import { db, Task, PRIORITY_STYLES, RISK_STYLES, STATUS_STYLES } from './data-store';
import { useFilters } from './FilterContext';
import { MyTasksSkeleton, ErrorState, EmptyState, useDataLoader } from './LoadingStates';

type CategoryId = 'today' | 'week' | 'overdue' | 'upcoming' | 'at-risk' | 'assigned' | 'completed';

interface Category {
  id: CategoryId;
  label: string;
  icon: React.ElementType;
  filter: (tasks: Task[]) => Task[];
}

const categories: Category[] = [
  {
    id: 'today',
    label: 'Due Today',
    icon: Calendar,
    filter: (tasks) =>
      tasks.filter((t) => {
        if (!t.dueDate || t.status === 'Completed') return false;
        const d = new Date(t.dueDate);
        const today = new Date('2026-02-10');
        return d.toDateString() === today.toDateString();
      }),
  },
  {
    id: 'week',
    label: 'This Week',
    icon: Clock,
    filter: (tasks) =>
      tasks.filter((t) => {
        if (!t.dueDate || t.status === 'Completed') return false;
        const d = new Date(t.dueDate);
        const today = new Date('2026-02-10');
        const endOfWeek = new Date(today);
        endOfWeek.setDate(endOfWeek.getDate() + (7 - endOfWeek.getDay()));
        return d >= today && d <= endOfWeek;
      }),
  },
  {
    id: 'overdue',
    label: 'Overdue',
    icon: AlertCircle,
    filter: (tasks) =>
      tasks.filter((t) => {
        if (!t.dueDate || t.status === 'Completed') return false;
        return new Date(t.dueDate) < new Date('2026-02-10');
      }),
  },
  {
    id: 'at-risk',
    label: 'At Risk',
    icon: AlertTriangle,
    filter: (tasks) => tasks.filter((t) => t.aiRisk === 'high' && t.status !== 'Completed'),
  },
  {
    id: 'upcoming',
    label: 'Upcoming',
    icon: ArrowUpRight,
    filter: (tasks) =>
      tasks.filter((t) => {
        if (!t.dueDate || t.status === 'Completed') return false;
        const d = new Date(t.dueDate);
        const today = new Date('2026-02-10');
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 14);
        return d > today && d <= nextWeek;
      }),
  },
  {
    id: 'assigned',
    label: 'All Active',
    icon: Inbox,
    filter: (tasks) => tasks.filter((t) => t.status !== 'Completed'),
  },
  {
    id: 'completed',
    label: 'Completed',
    icon: CheckCircle,
    filter: (tasks) => tasks.filter((t) => t.status === 'Completed'),
  },
];

/* ── Chart Colors (resolved for Recharts SVG) ─────────────── */
const CHART_COLORS = {
  primary: 'var(--chart-primary)',
  success: 'var(--chart-success)',
  warning: 'var(--chart-warning)',
  danger: 'var(--chart-danger)',
  neutral: 'var(--chart-secondary)',
  grid: 'var(--chart-grid)',
};

/* ── Tooltip Props Interface ──────────────────────────────── */
interface ChartTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string; color: string }>;
  label?: string;
}

/* ── Mini Tooltip ─────────────────────────────────────────── */
const MiniTooltip = ({ active, payload, label }: ChartTooltipProps) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[var(--bg-level-0)] rounded-md shadow-[var(--shadow-tooltip)] border border-[var(--neutral-200)] px-2.5 py-1.5">
      <p className="text-[10px] font-medium text-[var(--text-primary)]">{label}</p>
      {payload.map((e, i: number) => (
        <div key={i} className="flex items-center gap-1.5 text-[10px]">
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: e.color }} />
          <span className="text-[var(--text-secondary)]">{e.name}:</span>
          <span className="font-medium text-[var(--text-primary)]">{e.value}</span>
        </div>
      ))}
    </div>
  );
};

const MyTasksView = () => {
  const [activeCategory, setActiveCategory] = useState<CategoryId>('today');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [checkedTasks, setCheckedTasks] = useState<Set<string>>(new Set());

  const { applyFilters } = useFilters();
  const loader = React.useCallback(() => db.getTasks(), []);
  const { data: rawTasks, isLoading, hasError, errorMessage, retry } = useDataLoader(loader, 800);
  const allTasks = useMemo(() => (rawTasks ? applyFilters(rawTasks) : []), [rawTasks, applyFilters]);
  const activeFilter = categories.find((c) => c.id === activeCategory);
  const filteredTasks = useMemo(
    () => (activeFilter ? activeFilter.filter(allTasks) : allTasks),
    [activeCategory, allTasks, activeFilter]
  );

  // Sort by AI score descending
  const sortedTasks = useMemo(
    () => [...filteredTasks].sort((a, b) => (b.aiScore ?? 0) - (a.aiScore ?? 0)),
    [filteredTasks]
  );

  const handleCheckboxToggle = (taskId: string) => {
    setCheckedTasks((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  const handleCompleteChecked = () => {
    checkedTasks.forEach((id) => {
      db.updateTask(id, { status: 'Completed' });
    });
    setCheckedTasks(new Set());
  };

  // Stats
  const totalActive = allTasks.filter((t) => t.status !== 'Completed').length;
  const completedCount = allTasks.filter((t) => t.status === 'Completed').length;
  const atRiskCount = allTasks.filter((t) => t.aiRisk === 'high' && t.status !== 'Completed').length;
  const avgKr = totalActive > 0
    ? Math.round(
        allTasks
          .filter((t) => t.status !== 'Completed')
          .reduce((sum, t) => sum + t.krImpact, 0) / totalActive
      )
    : 0;

  // Velocity sparkline data (simulated daily completion trend)
  const velocityData = useMemo(() => [
    { d: 'Mon', done: 1, planned: 2 },
    { d: 'Tue', done: 2, planned: 2 },
    { d: 'Wed', done: 2, planned: 3 },
    { d: 'Thu', done: 3, planned: 3 },
    { d: 'Fri', done: 4, planned: 4 },
    { d: 'Sat', done: 4, planned: 5 },
    { d: 'Sun', done: 5, planned: 5 },
  ], []);

  // Priority pie data
  const priorityPieData = useMemo(() => {
    const counts: Record<string, number> = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    allTasks.filter(t => t.status !== 'Completed').forEach(t => {
      counts[t.priority] = (counts[t.priority] || 0) + 1;
    });
    return [
      { name: 'Critical', value: counts.Critical, fill: CHART_COLORS.danger },
      { name: 'High', value: counts.High, fill: CHART_COLORS.warning },
      { name: 'Medium', value: counts.Medium, fill: CHART_COLORS.primary },
      { name: 'Low', value: counts.Low, fill: CHART_COLORS.neutral },
    ];
  }, [allTasks]);

  const getDaysUntilDue = (dueDate: string): number | null => {
    if (!dueDate) return null;
    const now = new Date('2026-02-10');
    const due = new Date(dueDate);
    return Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  if (isLoading) return <MyTasksSkeleton />;
  if (hasError) return <ErrorState message={errorMessage} onRetry={retry} />;

  return (
    <>
      <div className="flex gap-6">
        {/* Left Sidebar */}
        <div className="w-[240px] flex-shrink-0 space-y-5">
          {/* Category Navigation */}
          <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-3">
            <div className="space-y-1">
              {categories.map((category) => {
                const Icon = category.icon;
                const count = category.filter(allTasks).length;

                return (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`
                      w-full flex items-center justify-between px-3 py-3 rounded-lg text-[14px] font-medium transition-all duration-[120ms]
                      ${activeCategory === category.id
                        ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white shadow-[var(--shadow-brand)]'
                        : 'text-[var(--text-primary)] hover:bg-[var(--neutral-50)]'
                      }
                    `}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon size={16} />
                      <span>{category.label}</span>
                    </div>
                    <span
                      className={`
                        h-[20px] min-w-[20px] px-2 rounded-full text-[12px] font-medium flex items-center justify-center
                        ${activeCategory === category.id ? 'bg-white/20 text-white' : 'bg-[var(--neutral-100)] text-[var(--text-secondary)]'}
                      `}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Execution Health Card */}
          <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-4">
            <div className="flex items-center gap-2 mb-4">
              <Activity size={16} className="text-[var(--brand-primary)]" />
              <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
                Execution Health
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
                    Active Tasks
                  </span>
                  <span className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
                    {totalActive}
                  </span>
                </div>
                <div className="h-1.5 bg-[var(--neutral-100)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-full"
                    style={{
                      width: `${Math.min(100, (totalActive / (totalActive + completedCount)) * 100)}%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
                  Completed
                </span>
                <span className="text-[14px] font-medium leading-[1.5] text-[var(--success-dark)]">
                  {completedCount}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
                  At Risk
                </span>
                <span className="text-[14px] font-medium leading-[1.5] text-[var(--danger)]">
                  {atRiskCount}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[12px] font-normal leading-[1.3] text-[var(--text-secondary)]">
                  Avg KR Impact
                </span>
                <span className="text-[14px] font-medium leading-[1.5] text-[var(--brand-primary)]">
                  {avgKr}%
                </span>
              </div>
            </div>

            {/* Velocity Sparkline */}
            <div className="mt-4 pt-4 border-t border-[var(--neutral-100)]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[12px] font-medium leading-[1.3] text-[var(--text-secondary)]">
                  Weekly Velocity
                </span>
                <span className="text-[10px] font-normal text-[var(--text-tertiary)]">
                  tasks/day
                </span>
              </div>
              <ResponsiveContainer width="100%" height={60}>
                <AreaChart data={velocityData}>
                  <defs>
                    <linearGradient id="velocityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.2} />
                      <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <Tooltip content={<MiniTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="done"
                    name="Done"
                    stroke={CHART_COLORS.primary}
                    fill="url(#velocityGrad)"
                    strokeWidth={1.5}
                    dot={false}
                  />
                  <Area
                    type="monotone"
                    dataKey="planned"
                    name="Planned"
                    stroke={CHART_COLORS.neutral}
                    fill="none"
                    strokeWidth={1}
                    strokeDasharray="3 3"
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Priority Distribution Mini Pie */}
            <div className="mt-3 pt-3 border-t border-[var(--neutral-100)]">
              <span className="text-[12px] font-medium leading-[1.3] text-[var(--text-secondary)] mb-2 block">
                Priority Mix
              </span>
              <div className="flex items-center gap-3">
                <PieChart width={48} height={48}>
                  <Pie
                    data={priorityPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={14}
                    outerRadius={22}
                    paddingAngle={2}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {priorityPieData.map((entry, i) => (
                      <Cell key={i} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
                <div className="flex-1 grid grid-cols-2 gap-x-3 gap-y-1">
                  {priorityPieData.map((item) => (
                    <div key={item.name} className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: item.fill }} />
                      <span className="text-[10px] text-[var(--text-secondary)]">{item.name}</span>
                      <span className="text-[10px] font-medium text-[var(--text-primary)]">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* AI Recommendation */}
          <motion.div
            className="p-4 bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-[var(--card-radius)] text-white shadow-[var(--shadow-brand-hover)]"
            whileHover={{ scale: 1.01 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={16} />
              <h3 className="text-[14px] font-medium">AI Priority Score</h3>
            </div>
            <div className="text-[32px] font-semibold leading-[1.2] tracking-[-0.02em] mb-1">
              87%
            </div>
            <div className="text-[12px] font-normal leading-[1.4] opacity-80">
              12% improvement from last week. {atRiskCount} tasks need attention.
            </div>
          </motion.div>
        </div>

        {/* Right Content */}
        <div className="flex-1">
          {/* Header */}
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-[18px] font-medium leading-[1.3] text-[var(--text-primary)]">
                {activeFilter?.label || 'Tasks'}
              </h2>
              <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mt-0.5">
                Sorted by AI Impact Score · {sortedTasks.length} task{sortedTasks.length !== 1 ? 's' : ''}
              </p>
            </div>

            {/* Bulk actions */}
            <AnimatePresence>
              {checkedTasks.size > 0 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center gap-3"
                >
                  <span className="text-[12px] font-medium text-[var(--text-secondary)]">
                    {checkedTasks.size} selected
                  </span>
                  <button
                    onClick={handleCompleteChecked}
                    className="h-8 px-3 bg-[var(--success-light)] text-[var(--success-dark)] text-[12px] font-medium rounded-lg border border-[var(--success-light)] hover:brightness-95 transition-colors"
                  >
                    Mark Complete
                  </button>
                  <button
                    onClick={() => setCheckedTasks(new Set())}
                    className="h-8 px-3 text-[12px] font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-lg hover:bg-[var(--neutral-100)] transition-colors"
                  >
                    Clear
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Task List */}
          {sortedTasks.length === 0 ? (
            <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-12 text-center">
              <CheckCircle size={32} className="mx-auto text-[var(--neutral-200)] mb-3" />
              <p className="text-[14px] font-medium text-[var(--text-secondary)] mb-1">No tasks in this category</p>
              <p className="text-[12px] font-normal text-[var(--text-tertiary)]">
                Tasks matching this filter will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {sortedTasks.map((task, index) => {
                const daysUntil = getDaysUntilDue(task.dueDate);
                const isOverdue = daysUntil !== null && daysUntil < 0;
                const isDueSoon = daysUntil !== null && daysUntil >= 0 && daysUntil <= 2;

                return (
                  <motion.div
                    key={task.id}
                    className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5 hover:shadow-[var(--shadow-card-hover)] hover:border-[var(--brand-primary)] transition-all duration-[150ms] cursor-pointer group"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.03, duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
                    onClick={() => setSelectedTask(task)}
                  >
                    <div className="flex items-start gap-4">
                      {/* Checkbox */}
                      <input
                        type="checkbox"
                        checked={checkedTasks.has(task.id)}
                        onChange={() => handleCheckboxToggle(task.id)}
                        onClick={(e) => e.stopPropagation()}
                        className="mt-1 w-5 h-5 rounded border-2 border-[var(--neutral-200)] text-[var(--brand-primary)] focus:ring-0 focus:ring-offset-0 cursor-pointer"
                      />

                      <div className="flex-1 min-w-0">
                        {/* Top Row */}
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)]">
                            {task.title}
                          </h3>
                          <div className="flex items-center gap-2 ml-4 shrink-0">
                            <span
                              className={`
                                h-[24px] px-3 rounded-[var(--badge-radius)] border
                                text-[12px] font-medium leading-[1.3] tracking-[0.01em] uppercase
                                flex items-center
                                ${PRIORITY_STYLES[task.priority]}
                              `}
                            >
                              {task.priority}
                            </span>
                            <span
                              className={`
                                h-[24px] px-3 rounded-[var(--badge-radius)] border
                                text-[12px] font-medium leading-[1.3] tracking-[0.01em] uppercase
                                flex items-center
                                ${STATUS_STYLES[task.status]}
                              `}
                            >
                              {task.status}
                            </span>
                          </div>
                        </div>

                        {/* Metadata Row */}
                        <div className="flex items-center gap-5 text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
                          {/* Due Date */}
                          <div className={`flex items-center gap-1.5 ${isOverdue ? 'text-[var(--danger)] font-medium' : isDueSoon ? 'text-[var(--at-risk)] font-medium' : ''}`}>
                            <Clock size={12} />
                            <span>
                              {isOverdue
                                ? `${Math.abs(daysUntil!)}d overdue`
                                : isDueSoon
                                  ? `Due in ${daysUntil}d`
                                  : task.dueDate
                                    ? new Date(task.dueDate).toLocaleDateString('en-US', {
                                        month: 'short',
                                        day: 'numeric',
                                        hour: 'numeric',
                                        minute: '2-digit',
                                      })
                                    : 'No due date'}
                            </span>
                          </div>

                          {/* KR Impact */}
                          <div className="flex items-center gap-1.5">
                            <TrendingUp size={12} className="text-[var(--brand-primary)]" />
                            <span>
                              KR Impact: <span className="font-medium text-[var(--brand-primary)]">{task.krImpact}%</span>
                            </span>
                          </div>

                          {/* AI Score */}
                          {task.aiScore && (
                            <div className="flex items-center gap-1.5">
                              <Sparkles size={12} className="text-[var(--brand-primary)]" />
                              <span>
                                AI Score: <span className="font-medium text-[var(--text-primary)]">{task.aiScore}</span>
                              </span>
                            </div>
                          )}

                          {/* Risk */}
                          <div className={`flex items-center gap-1.5 ${RISK_STYLES[task.aiRisk].text}`}>
                            <AlertTriangle size={12} />
                            <span className="font-medium">{RISK_STYLES[task.aiRisk].label}</span>
                          </div>

                          {/* Assignee */}
                          <div className="flex items-center gap-1.5 ml-auto">
                            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[10px] font-medium">
                              {task.assignee.avatar}
                            </div>
                            <span>{task.assignee.name}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}

          {/* AI Suggestion Box */}
          <motion.div
            className="mt-6 p-5 bg-[var(--brand-primary-light)] rounded-[var(--card-radius)] border border-[var(--info-light)]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-lg flex items-center justify-center flex-shrink-0">
                <Sparkles className="text-white" size={18} />
              </div>
              <div className="flex-1">
                <h4 className="text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-1">
                  AI Recommendation
                </h4>
                <p className="text-[12px] font-normal leading-[1.5] text-[var(--text-secondary)] mb-3">
                  Based on your velocity and priority scores, focus on "Refactor payment processing" first.
                  It has the highest KR impact (92%) and is due tomorrow. Completing it unblocks 2 downstream tasks.
                </p>
                <button className="h-8 px-4 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white text-[12px] font-medium rounded-lg hover:shadow-[var(--shadow-brand-hover)] transition-all duration-[120ms]">
                  Reorganize My Tasks
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal task={selectedTask} onClose={() => setSelectedTask(null)} />
      )}
    </>
  );
};

export default MyTasksView;
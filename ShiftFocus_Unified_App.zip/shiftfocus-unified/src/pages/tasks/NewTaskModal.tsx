import React from 'react';
import { motion } from 'motion/react';
import { Calendar, User, Flag, TrendingUp, Paperclip, Plus, AlertCircle } from 'lucide-react';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { db, Task } from './data-store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogBody,
  DialogTitle,
  Button,
  Input,
  Textarea,
  Select,
  FieldError,
  sfToast,
} from './design-system';
import { useFilters } from './FilterContext';

/* ── Zod Schema ──────────────────────────────────────────── */

const taskSchema = z.object({
  title: z
    .string()
    .min(1, 'Task title is required')
    .min(3, 'Title must be at least 3 characters')
    .max(120, 'Title must be under 120 characters'),
  description: z.string().max(2000, 'Description must be under 2000 characters').optional().default(''),
  projectId: z.string().min(1, 'Please select a project'),
  priority: z.enum(['Critical', 'High', 'Medium', 'Low'], {
    required_error: 'Priority is required',
  }),
  assignee: z.string().min(1, 'Please select an assignee'),
  dueDate: z.string().min(1, 'Due date is required').refine(
    (val) => !isNaN(new Date(val).getTime()),
    { message: 'Invalid date format' }
  ),
  krImpact: z.number().min(0, 'KR Impact must be 0-100').max(100, 'KR Impact must be 0-100'),
});

type TaskFormData = z.infer<typeof taskSchema>;

/* ── Constants ───────────────────────────────────────────── */

interface NewTaskModalProps {
  onClose: () => void;
}

const ASSIGNEES = [
  { name: 'Sarah Chen', avatar: 'SC' },
  { name: 'Mike Ross', avatar: 'MR' },
  { name: 'Alex Kim', avatar: 'AK' },
  { name: 'Emma Stone', avatar: 'ES' },
  { name: 'David Park', avatar: 'DP' },
];

const PRIORITY_OPTIONS = [
  { value: 'Critical', label: 'Critical' },
  { value: 'High', label: 'High' },
  { value: 'Medium', label: 'Medium' },
  { value: 'Low', label: 'Low' },
];

const ASSIGNEE_OPTIONS = ASSIGNEES.map((a) => ({ value: a.name, label: a.name }));

/* ── Component ───────────────────────────────────────────── */

const NewTaskModal: React.FC<NewTaskModalProps> = ({ onClose }) => {
  const { filters } = useFilters();
  const projects = db.getProjects();
  const PROJECT_OPTIONS = projects.map(p => ({ value: p.id, label: `${p.icon} ${p.name}` }));

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<TaskFormData>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: '',
      description: '',
      projectId: filters.activeProjectId || 'inbox',
      priority: 'Medium',
      assignee: '',
      dueDate: '',
      krImpact: 50,
    },
    mode: 'onTouched',
  });

  const krImpactValue = watch('krImpact');

  const onSubmit = (data: TaskFormData) => {
    const selectedAssignee = ASSIGNEES.find((a) => a.name === data.assignee) || {
      name: 'Unassigned',
      avatar: 'UA',
    };
    db.createTask({
      title: data.title,
      description: data.description || '',
      priority: data.priority as Task['priority'],
      status: 'Not Started',
      assignee: selectedAssignee,
      dueDate: data.dueDate,
      krImpact: data.krImpact,
      aiRisk: data.krImpact >= 70 ? 'high' : data.krImpact >= 40 ? 'medium' : 'low',
      aiScore: Math.round(50 + Math.random() * 40),
      projectId: data.projectId,
    });
    sfToast.success(`Task "${data.title}" created successfully`);
    onClose();
  };

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent size="md" showClose={false}>
        {/* Header */}
        <DialogHeader>
          <DialogTitle>Create New Task</DialogTitle>
          <Button variant="ghost" size="sm" onClick={onClose} className="w-10 h-10 px-0">
            ×
          </Button>
        </DialogHeader>

        {/* Form — React Hook Form + Zod */}
        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <DialogBody className="space-y-6">
            {/* Task Title */}
            <Input
              {...register('title')}
              label="Task Title *"
              placeholder="Enter task title..."
              error={!!errors.title}
              errorMessage={errors.title?.message}
              autoFocus
            />

            {/* Project */}
            <Controller
              name="projectId"
              control={control}
              render={({ field }) => (
                <Select
                  label="Project *"
                  value={field.value}
                  onValueChange={field.onChange}
                  options={PROJECT_OPTIONS}
                  error={!!errors.projectId}
                  errorMessage={errors.projectId?.message}
                />
              )}
            />

            {/* Description */}
            <Textarea
              {...register('description')}
              label="Description"
              placeholder="Add task description..."
              rows={4}
              error={!!errors.description}
              errorMessage={errors.description?.message}
            />

            {/* Row 1: Priority & Assignee */}
            <div className="grid grid-cols-2 gap-4">
              <Controller
                name="priority"
                control={control}
                render={({ field }) => (
                  <Select
                    label="Priority *"
                    value={field.value}
                    onValueChange={field.onChange}
                    options={PRIORITY_OPTIONS}
                    error={!!errors.priority}
                    errorMessage={errors.priority?.message}
                  />
                )}
              />
              <Controller
                name="assignee"
                control={control}
                render={({ field }) => (
                  <Select
                    label="Assignee *"
                    value={field.value}
                    onValueChange={field.onChange}
                    options={ASSIGNEE_OPTIONS}
                    placeholder="Select assignee..."
                    error={!!errors.assignee}
                    errorMessage={errors.assignee?.message}
                  />
                )}
              />
            </div>

            {/* Due Date */}
            <Input
              {...register('dueDate')}
              type="date"
              label="Due Date *"
              error={!!errors.dueDate}
              errorMessage={errors.dueDate?.message}
              icon={<Calendar size={14} />}
            />

            {/* KR Impact Slider — Controller for number type */}
            <div>
              <label className="block text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-2 flex items-center gap-2">
                <TrendingUp size={14} className="text-[var(--text-secondary)]" />
                KR Impact: <span className="text-[var(--brand-primary)]">{krImpactValue}%</span>
              </label>
              <Controller
                name="krImpact"
                control={control}
                render={({ field }) => (
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={field.value}
                    onChange={(e) => field.onChange(Number(e.target.value))}
                    className="w-full h-2 bg-[var(--neutral-200)] rounded-full appearance-none cursor-pointer accent-[var(--brand-primary)]"
                  />
                )}
              />
              <div className="flex justify-between text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] mt-1">
                <span>Low Impact</span>
                <span>High Impact</span>
              </div>
              <FieldError message={errors.krImpact?.message} />
            </div>

            {/* Attachments */}
            <div>
              <label className="block text-[14px] font-medium leading-[1.5] text-[var(--text-primary)] mb-2 flex items-center gap-2">
                <Paperclip size={14} className="text-[var(--text-secondary)]" />
                Attachments
              </label>
              <div className="border-2 border-dashed border-[var(--neutral-200)] rounded-lg p-6 text-center hover:border-[var(--brand-primary)] hover:bg-[var(--brand-primary-light)] transition-all duration-[120ms] cursor-pointer">
                <Plus size={20} className="mx-auto text-[var(--text-tertiary)] mb-2" />
                <p className="text-[14px] font-normal leading-[1.5] text-[var(--text-secondary)]">
                  Click to upload or drag and drop
                </p>
                <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-tertiary)] mt-1">
                  PDF, DOC, PNG, JPG up to 10MB
                </p>
              </div>
            </div>
          </DialogBody>

          {/* Footer Actions */}
          <div className="px-8 py-4 border-t border-[var(--neutral-200)] flex items-center justify-between">
            <div>
              {Object.keys(errors).length > 0 && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-[12px] font-medium text-[var(--danger)] flex items-center gap-1.5"
                >
                  <AlertCircle size={12} />
                  {Object.keys(errors).length} field{Object.keys(errors).length > 1 ? 's' : ''} need attention
                </motion.p>
              )}
            </div>
            <div className="flex items-center gap-3">
              <Button type="button" variant="secondary" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={isSubmitting}>
                Create Task
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NewTaskModal;
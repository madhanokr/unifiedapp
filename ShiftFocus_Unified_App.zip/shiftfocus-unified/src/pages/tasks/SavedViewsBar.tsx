import React, { useState } from 'react';
import { Star, Bookmark } from 'lucide-react';
import { motion } from 'motion/react';
import { Button, IconButton } from './design-system';

const SavedViewsBar = () => {
  const [activeView, setActiveView] = useState('Default View');

  const views = [
    'Default View',
    'Engineering Board',
    'Design Pipeline',
    'Critical Week View',
    'My Velocity Tasks',
  ];

  return (
    <div className="bg-[var(--bg-level-0)]/50 backdrop-blur-sm border-b border-[var(--neutral-200)] h-14">
      <div className="h-full px-8 flex items-center justify-between">
        {/* Saved Views Pills */}
        <div className="flex items-center gap-2">
          {views.map((view) => (
            <motion.button
              key={view}
              onClick={() => setActiveView(view)}
              className={`
                h-[24px] px-4 rounded-full text-[12px] font-medium transition-all duration-[120ms]
                ${activeView === view
                  ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white shadow-[var(--shadow-card)]'
                  : 'border border-[var(--neutral-200)] text-[var(--text-secondary)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)]'
                }
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95, translateY: 1 }}
              transition={{ duration: 0.08, ease: [0.4, 0.0, 1, 1] }}
            >
              {view}
            </motion.button>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => console.log('Save current view')} icon={<Bookmark size={14} />}>
            Save Current View
          </Button>
          <IconButton icon={<Star size={16} />} size="sm" label="Favorite" onClick={() => console.log('Toggle favorite')} />
        </div>
      </div>
    </div>
  );
};

export default SavedViewsBar;
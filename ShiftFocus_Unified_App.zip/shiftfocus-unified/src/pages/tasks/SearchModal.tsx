import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Clock,
  TrendingUp,
  Hash,
  User,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  X,
} from 'lucide-react';
import { db, Task, PRIORITY_STYLES, STATUS_STYLES, RISK_STYLES } from './data-store';
import TaskDetailModal from './TaskDetailModal';
import { PriorityBadge } from './design-system';

interface SearchModalProps {
  onClose: () => void;
}

const SearchModal: React.FC<SearchModalProps> = ({ onClose }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('shiftfocus_recent_searches');
      return stored ? JSON.parse(stored) : ['authentication flow', 'payment processing', 'dashboard'];
    } catch {
      return ['authentication flow', 'payment processing', 'dashboard'];
    }
  });
  const inputRef = useRef<HTMLInputElement>(null);

  const tasks = useMemo(() => db.getTasks(), []);

  // Team members for @mention search
  const teamMembers = useMemo(() => {
    const members = new Map<string, { name: string; avatar: string; taskCount: number }>();
    tasks.forEach((t) => {
      const existing = members.get(t.assignee.name);
      members.set(t.assignee.name, {
        name: t.assignee.name,
        avatar: t.assignee.avatar,
        taskCount: (existing?.taskCount || 0) + 1,
      });
    });
    return Array.from(members.values());
  }, [tasks]);

  // Search results
  const results = useMemo(() => {
    if (!query.trim()) return [];

    const q = query.toLowerCase();

    // @ search = people
    if (q.startsWith('@')) {
      const nameQ = q.slice(1);
      return teamMembers
        .filter((m) => m.name.toLowerCase().includes(nameQ))
        .map((m) => ({
          id: m.name,
          type: 'person' as const,
          title: m.name,
          meta: `${m.taskCount} task${m.taskCount !== 1 ? 's' : ''} assigned`,
          avatar: m.avatar,
        }));
    }

    // Task search
    const taskResults = tasks
      .filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.id.includes(q)
      )
      .slice(0, 8)
      .map((t) => ({
        id: t.id,
        type: 'task' as const,
        title: t.title,
        meta: `TASK-${t.id} · ${t.status} · ${t.assignee.name}`,
        priority: t.priority,
        status: t.status,
        task: t,
      }));

    // Person results
    const personResults = teamMembers
      .filter((m) => m.name.toLowerCase().includes(q))
      .map((m) => ({
        id: m.name,
        type: 'person' as const,
        title: m.name,
        meta: `${m.taskCount} task${m.taskCount !== 1 ? 's' : ''} assigned`,
        avatar: m.avatar,
      }));

    return [...taskResults, ...personResults];
  }, [query, tasks, teamMembers]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === 'Enter' && results[selectedIndex]) {
        handleSelect(results[selectedIndex]!);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [results, selectedIndex, onClose]);

  // Reset selected index when results change
  useEffect(() => {
    setSelectedIndex(0);
  }, [results]);

  const saveRecentSearch = (q: string) => {
    const updated = [q, ...recentSearches.filter((s) => s !== q)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('shiftfocus_recent_searches', JSON.stringify(updated));
  };

  const handleSelect = (result: (typeof results)[0]) => {
    if (!result) return;
    saveRecentSearch(query);
    if (result.type === 'task' && 'task' in result) {
      setSelectedTask(result.task as Task);
    }
  };

  const handleRecentClick = (search: string) => {
    setQuery(search);
    inputRef.current?.focus();
  };

  const clearRecent = (search: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = recentSearches.filter((s) => s !== search);
    setRecentSearches(updated);
    localStorage.setItem('shiftfocus_recent_searches', JSON.stringify(updated));
  };

  return (
    <>
      <AnimatePresence>
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-[120px] p-4">
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
            onClick={onClose}
          />

          {/* Search Container */}
          <motion.div
            className="relative w-full max-w-[640px] bg-white rounded-[16px] shadow-[var(--shadow-modal)] overflow-hidden"
            initial={{ opacity: 0, y: -16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.97 }}
            transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
          >
            {/* Search Input */}
            <div className="px-6 py-5 border-b border-[var(--neutral-200)] flex items-center gap-4">
              <Search size={20} className="text-[var(--neutral-400)] shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tasks, people, or use @ for assignee..."
                className="flex-1 text-[16px] font-normal leading-[1.5] text-[var(--neutral-800)] placeholder:text-[var(--neutral-400)] focus:outline-none"
                autoFocus
              />
              {query && (
                <button
                  onClick={() => {
                    setQuery('');
                    inputRef.current?.focus();
                  }}
                  className="w-6 h-6 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-colors"
                >
                  <X size={14} className="text-[var(--neutral-400)]" />
                </button>
              )}
              <kbd className="h-[24px] px-2.5 bg-[var(--neutral-100)] rounded-md text-[12px] font-medium text-[var(--neutral-400)] flex items-center border border-[var(--neutral-200)]">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div className="max-h-[400px] overflow-y-auto">
              {query === '' ? (
                /* Recent Searches */
                <div className="px-6 py-4">
                  <div className="text-[12px] font-medium leading-[1.3] tracking-[0.03em] uppercase text-[var(--neutral-400)] mb-3 flex items-center gap-2">
                    <Clock size={12} />
                    Recent Searches
                  </div>
                  <div className="space-y-1">
                    {recentSearches.map((search, i) => (
                      <button
                        key={i}
                        onClick={() => handleRecentClick(search)}
                        className="w-full text-left px-3 py-2.5 hover:bg-[var(--neutral-50)] rounded-lg text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] transition-colors duration-[120ms] flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2.5">
                          <Clock size={14} className="text-[var(--neutral-400)]" />
                          <span>{search}</span>
                        </div>
                        <button
                          onClick={(e) => clearRecent(search, e)}
                          className="opacity-0 group-hover:opacity-100 w-5 h-5 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-all"
                        >
                          <X size={10} className="text-[var(--neutral-400)]" />
                        </button>
                      </button>
                    ))}
                  </div>

                  {/* Quick Filters */}
                  <div className="mt-5 pt-4 border-t border-[var(--neutral-100)]">
                    <div className="text-[12px] font-medium leading-[1.3] tracking-[0.03em] uppercase text-[var(--neutral-400)] mb-3 flex items-center gap-2">
                      <Sparkles size={12} />
                      Quick Filters
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {['Critical tasks', 'Blocked', 'At risk', 'Due today', 'My tasks'].map((f) => (
                        <button
                          key={f}
                          onClick={() => {
                            setQuery(f.toLowerCase());
                            inputRef.current?.focus();
                          }}
                          className="h-[24px] px-3 bg-[var(--neutral-100)] text-[12px] font-medium text-[var(--neutral-600)] rounded-md hover:bg-[var(--neutral-200)] hover:text-[var(--neutral-800)] transition-colors"
                        >
                          {f}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : results.length > 0 ? (
                /* Search Results */
                <div className="py-2">
                  {results.map((result, i) => (
                    <motion.button
                      key={`${result.type}-${result.id}`}
                      onClick={() => handleSelect(result)}
                      className={`
                        w-full px-6 py-3 transition-colors duration-[80ms] flex items-center gap-3
                        ${i === selectedIndex ? 'bg-[var(--brand-primary-light)]' : 'hover:bg-[var(--neutral-50)]'}
                      `}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.02 }}
                    >
                      <div
                        className={`
                          w-9 h-9 rounded-lg flex items-center justify-center shrink-0
                          ${result.type === 'task' ? 'bg-[var(--brand-primary-light)]' : 'bg-[var(--brand-primary-light)]'}
                        `}
                      >
                        {result.type === 'task' ? (
                          <Hash size={16} className="text-[var(--brand-primary)]" />
                        ) : (
                          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[var(--brand-primary)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[12px] font-medium">
                            {'avatar' in result ? result.avatar : '??'}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] truncate">
                          {result.title}
                        </div>
                        <div className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-600)]">
                          {result.meta}
                        </div>
                      </div>
                      {result.type === 'task' && 'priority' in result && (
                        <PriorityBadge value={result.priority as string} size="sm" />
                      )}
                      <ArrowRight size={14} className="text-[var(--neutral-400)] shrink-0" />
                    </motion.button>
                  ))}
                </div>
              ) : (
                /* No Results */
                <div className="px-6 py-12 text-center">
                  <Search size={32} className="mx-auto text-[var(--neutral-200)] mb-3" />
                  <p className="text-[14px] font-medium text-[var(--neutral-600)] mb-1">
                    No results for "{query}"
                  </p>
                  <p className="text-[12px] font-normal text-[var(--neutral-400)]">
                    Try different keywords or use @ to search by assignee
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-3 bg-[var(--neutral-50)] border-t border-[var(--neutral-200)] flex items-center justify-between text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
              <div className="flex items-center gap-5">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-white border border-[var(--neutral-200)] rounded text-[10px]">
                    ↑↓
                  </kbd>
                  Navigate
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-white border border-[var(--neutral-200)] rounded text-[10px]">
                    ↵
                  </kbd>
                  Select
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-white border border-[var(--neutral-200)] rounded text-[10px]">
                    @
                  </kbd>
                  People
                </span>
              </div>
              <span className="flex items-center gap-1.5">
                <Sparkles size={10} className="text-[var(--brand-primary)]" />
                AI-powered search
              </span>
            </div>
          </motion.div>
        </div>
      </AnimatePresence>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          onClose={() => {
            setSelectedTask(null);
          }}
        />
      )}
    </>
  );
};

export default SearchModal;
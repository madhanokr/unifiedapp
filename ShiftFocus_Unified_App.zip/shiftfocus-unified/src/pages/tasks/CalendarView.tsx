import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Clock, AlertTriangle, TrendingUp, X, CalendarDays } from 'lucide-react';
import TaskDetailModal from './TaskDetailModal';
import { db, Task, PRIORITY_STYLES, RISK_STYLES, STATUS_STYLES } from './data-store';
import { useFilters } from './FilterContext';
import { CalendarSkeleton, ErrorState, EmptyState, useDataLoader } from './LoadingStates';

const CalendarView = () => {
  const [currentDate, setCurrentDate] = useState(new Date('2026-02-01'));
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [expandedDay, setExpandedDay] = useState<number | null>(null);

  const { applyFilters } = useFilters();
  const loader = React.useCallback(() => db.getTasks(), []);
  const { data: rawTasks, isLoading, hasError, errorMessage, retry } = useDataLoader(loader, 800);
  const tasks = useMemo(() => (rawTasks ? applyFilters(rawTasks) : []), [rawTasks, applyFilters]);

  const today = new Date('2026-02-10');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthName = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  // Calendar grid calculation
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const calendarDays: { day: number; isCurrentMonth: boolean; date: Date }[] = [];

  // Previous month days
  for (let i = firstDay - 1; i >= 0; i--) {
    const d = daysInPrevMonth - i;
    calendarDays.push({ day: d, isCurrentMonth: false, date: new Date(year, month - 1, d) });
  }
  // Current month days
  for (let d = 1; d <= daysInMonth; d++) {
    calendarDays.push({ day: d, isCurrentMonth: true, date: new Date(year, month, d) });
  }
  // Fill remaining slots
  const remaining = 42 - calendarDays.length;
  for (let d = 1; d <= remaining; d++) {
    calendarDays.push({ day: d, isCurrentMonth: false, date: new Date(year, month + 1, d) });
  }

  const getTasksForDate = (date: Date): Task[] => {
    return tasks.filter((t) => {
      if (!t.dueDate) return false;
      const d = new Date(t.dueDate);
      return (
        d.getFullYear() === date.getFullYear() &&
        d.getMonth() === date.getMonth() &&
        d.getDate() === date.getDate()
      );
    });
  };

  const isToday = (date: Date) =>
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate();

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const goToToday = () => setCurrentDate(new Date(today.getFullYear(), today.getMonth(), 1));

  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const priorityDotColors: Record<string, string> = {
    Critical: 'bg-[var(--danger)]',
    High: 'bg-[var(--at-risk)]',
    Medium: 'bg-[var(--info-dark)]',
    Low: 'bg-[var(--neutral-400)]',
  };

  if (isLoading) return <CalendarSkeleton />;
  if (hasError) return <ErrorState message={errorMessage} onRetry={retry} />;
  if (!rawTasks || rawTasks.length === 0)
    return <EmptyState title="No tasks found" description="Create tasks with due dates to see them on the calendar." icon={CalendarDays} />;

  return (
    <>
      <div>
        {/* Calendar Header */}
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-[20px] font-medium leading-[1.3] text-[var(--text-primary)]">{monthName}</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={prevMonth}
              className="w-9 h-9 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors duration-[var(--duration-fast)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={goToToday}
              className="h-9 px-4 text-[14px] font-medium text-[var(--text-secondary)] hover:bg-[var(--neutral-100)] hover:text-[var(--text-primary)] rounded-lg transition-colors duration-[var(--duration-fast)]"
            >
              Today
            </button>
            <button
              onClick={nextMonth}
              className="w-9 h-9 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors duration-[var(--duration-fast)] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>

        {/* Calendar Grid */}
        <div className="bg-[var(--bg-level-0)] rounded-[var(--card-radius)] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden">
          {/* Days of Week Header */}
          <div className="grid grid-cols-7 bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]">
            {daysOfWeek.map((day) => (
              <div
                key={day}
                className="py-3 text-center typography-caption-medium tracking-[0.01em] text-[var(--text-secondary)] uppercase border-r border-[var(--neutral-100)] last:border-r-0"
              >
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Days Grid */}
          <div className="grid grid-cols-7">
            {calendarDays.map((calDay, idx) => {
              const dayTasks = getTasksForDate(calDay.date);
              const isCurrentDay = isToday(calDay.date);
              const hasOverdue = dayTasks.some(
                (t) => t.aiRisk === 'high' || t.priority === 'Critical'
              );
              const isExpanded = expandedDay === idx;

              return (
                <div
                  key={idx}
                  className={`
                    min-h-[120px] p-2.5 border-r border-b border-[var(--neutral-100)]
                    transition-colors duration-[var(--duration-fast)] relative
                    ${!calDay.isCurrentMonth ? 'bg-[var(--neutral-50)]' : 'bg-[var(--bg-level-0)] hover:bg-[var(--neutral-50)]'}
                    ${isCurrentDay ? 'bg-[var(--brand-primary-light)]' : ''}
                    ${calDay.date.getDay() === 0 || calDay.date.getDay() === 6 ? 'bg-[var(--neutral-50)]' : ''}
                  `}
                >
                  {/* Day Number */}
                  <div className="flex items-center justify-between mb-2">
                    <div
                      className={`
                        w-7 h-7 flex items-center justify-center rounded-full text-[14px]
                        ${isCurrentDay
                          ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white font-medium'
                          : calDay.isCurrentMonth
                            ? 'text-[var(--text-primary)] font-normal'
                            : 'text-[var(--text-tertiary)] font-normal'
                        }
                      `}
                    >
                      {calDay.day}
                    </div>
                    {hasOverdue && calDay.isCurrentMonth && (
                      <AlertTriangle size={12} className="text-[var(--danger)]" />
                    )}
                  </div>

                  {/* Task Items */}
                  <div className="space-y-1">
                    {dayTasks.slice(0, 3).map((task, i) => (
                      <motion.button
                        key={task.id}
                        onClick={() => setSelectedTask(task)}
                        className={`
                          w-full px-2 py-1 rounded-md text-left text-[12px] font-medium leading-[1.3]
                          truncate border transition-all duration-[120ms]
                          ${PRIORITY_STYLES[task.priority]}
                          hover:shadow-[var(--shadow-tooltip)]
                        `}
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.02 }}
                        whileHover={{ scale: 1.02, zIndex: 10 }}
                      >
                        {task.title}
                      </motion.button>
                    ))}
                    {dayTasks.length > 3 && (
                      <button
                        onClick={() => setExpandedDay(isExpanded ? null : idx)}
                        className="text-[12px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] pl-2 transition-colors"
                      >
                        +{dayTasks.length - 3} more
                      </button>
                    )}
                  </div>

                  {/* Expanded Day Overlay */}
                  <AnimatePresence>
                    {isExpanded && dayTasks.length > 3 && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="absolute top-0 left-0 right-0 z-30 bg-[var(--bg-level-0)] rounded-[var(--card-radius)] border border-[var(--brand-primary)] shadow-[var(--shadow-elevated)] p-3"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[12px] font-medium text-[var(--text-primary)]">
                            {calDay.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                          <button
                            onClick={() => setExpandedDay(null)}
                            className="w-5 h-5 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-colors"
                          >
                            <X size={12} className="text-[var(--text-secondary)]" />
                          </button>
                        </div>
                        <div className="space-y-1.5 max-h-[180px] overflow-y-auto">
                          {dayTasks.map((task) => (
                            <button
                              key={task.id}
                              onClick={() => {
                                setSelectedTask(task);
                                setExpandedDay(null);
                              }}
                              className={`
                                w-full px-2 py-2 rounded-md text-left text-[12px] font-medium leading-[1.3]
                                truncate border transition-all duration-[120ms]
                                ${PRIORITY_STYLES[task.priority]}
                                hover:shadow-[var(--shadow-tooltip)]
                              `}
                            >
                              <div className="flex items-center gap-2">
                                <div className={`w-1.5 h-1.5 rounded-full ${priorityDotColors[task.priority]}`} />
                                <span className="truncate">{task.title}</span>
                              </div>
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary Bar */}
        <div className="mt-4 flex items-center gap-6 px-1">
          <div className="flex items-center gap-2 text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
            <div className="w-3 h-3 rounded-sm bg-[var(--danger-light)] border border-[var(--danger-light)]" />
            <span>Critical</span>
          </div>
          <div className="flex items-center gap-2 text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
            <div className="w-3 h-3 rounded-sm bg-[var(--warning-light)] border border-[var(--warning-light)]" />
            <span>High</span>
          </div>
          <div className="flex items-center gap-2 text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
            <div className="w-3 h-3 rounded-sm bg-[var(--info-light)] border border-[var(--info-light)]" />
            <span>Medium</span>
          </div>
          <div className="flex items-center gap-2 text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
            <div className="w-3 h-3 rounded-sm bg-[var(--neutral-100)] border border-[var(--neutral-200)]" />
            <span>Low</span>
          </div>
          <div className="ml-auto text-[12px] font-normal leading-[1.4] text-[var(--text-tertiary)]">
            {tasks.filter((t) => t.status !== 'Completed').length} active tasks this month
          </div>
        </div>
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal task={selectedTask} onClose={() => setSelectedTask(null)} />
      )}
    </>
  );
};

export default CalendarView;
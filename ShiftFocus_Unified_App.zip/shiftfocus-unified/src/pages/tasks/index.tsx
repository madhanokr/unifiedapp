/**
 * Tasks OS — View switching (List, Kanban, Timeline, Calendar, My Tasks, AI Mode)
 * Original App.tsx logic preserved, header stripped for unified shell
 */
import { useState, useEffect } from 'react';
import ListView from './ListView';
import KanbanView from './KanbanView';
import TimelineView from './TimelineView';
import CalendarView from './CalendarView';
import MyTasksView from './MyTasksView';
import AIModeView from './AIModeView';
import AICommander from './AICommander';
import FilterBar from './FilterBar';
import SavedViewsBar from './SavedViewsBar';
import ProjectSidebar from './ProjectSidebar';
import { 
  List, LayoutGrid, GanttChart, Calendar, User, Sparkles, 
  SlidersHorizontal, Star, Plus, Search, ChevronDown 
} from 'lucide-react';
import { toast } from 'sonner';

type ViewType = 'list' | 'kanban' | 'timeline' | 'calendar' | 'my-tasks' | 'ai-mode';

export default function TasksPage() {
  const [currentView, setCurrentView] = useState<ViewType>('list');
  const [showFilters, setShowFilters] = useState(false);
  const [showSavedViews, setShowSavedViews] = useState(false);
  const [showProjectSidebar, setShowProjectSidebar] = useState(false);
  const [showAICommander, setShowAICommander] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const views = [
    { id: 'list' as ViewType, label: 'List', icon: List },
    { id: 'kanban' as ViewType, label: 'Board', icon: LayoutGrid },
    { id: 'timeline' as ViewType, label: 'Timeline', icon: GanttChart },
    { id: 'calendar' as ViewType, label: 'Calendar', icon: Calendar },
    { id: 'my-tasks' as ViewType, label: 'My Tasks', icon: User },
    { id: 'ai-mode' as ViewType, label: 'AI Mode', icon: Sparkles },
  ];

  const renderView = () => {
    switch (currentView) {
      case 'list': return <ListView searchQuery={searchQuery} />;
      case 'kanban': return <KanbanView />;
      case 'timeline': return <TimelineView />;
      case 'calendar': return <CalendarView />;
      case 'my-tasks': return <MyTasksView />;
      case 'ai-mode': return <AIModeView />;
      default: return <ListView searchQuery={searchQuery} />;
    }
  };

  return (
    <div className="flex h-full">
      {showProjectSidebar && <ProjectSidebar onClose={() => setShowProjectSidebar(false)} />}
      <div className="flex-1 flex flex-col">
        {/* Page header with view tabs */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <h1 style={{ fontSize: '24px', fontWeight: 600, color: 'var(--neutral-800)' }}>Tasks OS</h1>
            <div className="flex items-center gap-1 p-1 rounded-lg" style={{ backgroundColor: 'var(--neutral-100)' }}>
              {views.map((view) => {
                const Icon = view.icon;
                const isActive = currentView === view.id;
                return (
                  <button
                    key={view.id}
                    onClick={() => setCurrentView(view.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all"
                    style={{
                      fontSize: '13px',
                      fontWeight: isActive ? 600 : 500,
                      color: isActive ? 'var(--brand-primary)' : 'var(--neutral-600)',
                      backgroundColor: isActive ? 'var(--white)' : 'transparent',
                      boxShadow: isActive ? 'var(--shadow-card)' : 'none',
                    }}
                  >
                    <Icon style={{ width: '14px', height: '14px' }} />
                    {view.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors"
              style={{ fontSize: '13px', color: 'var(--neutral-600)', border: '1px solid var(--neutral-200)' }}
            >
              <SlidersHorizontal style={{ width: '14px', height: '14px' }} />
              Filters
            </button>
            <button
              onClick={() => toast.success('Task created')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg transition-colors"
              style={{ fontSize: '13px', fontWeight: 600, color: 'var(--white)', backgroundColor: 'var(--brand-primary)' }}
            >
              <Plus style={{ width: '14px', height: '14px' }} />
              New Task
            </button>
          </div>
        </div>
        {showFilters && <FilterBar onClose={() => setShowFilters(false)} />}
        {showSavedViews && <SavedViewsBar />}
        {renderView()}
      </div>
      {showAICommander && <AICommander onClose={() => setShowAICommander(false)} />}
    </div>
  );
}

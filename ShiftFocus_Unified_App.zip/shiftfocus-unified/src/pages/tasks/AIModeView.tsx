import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertTriangle,
  GitBranch,
  Clock,
  Wrench,
  Brain,
  TrendingUp,
  AlertCircle,
  Sparkles,
  CheckCircle,
  ArrowRight,
  Zap,
  Shield,
  Target,
} from 'lucide-react';
import { db, Task, PRIORITY_STYLES } from './data-store';
import { useFilters } from './FilterContext';
import SprintHealthCharts from './SprintHealthCharts';
import { ChartSkeleton, useSimulatedLoading, ErrorState } from './LoadingStates';
import { Card, Button, Badge, ProgressBar } from './design-system';

interface InsightItem {
  id: string;
  title: string;
  description: string;
  confidence: number;
  impact: 'critical' | 'high' | 'medium';
  action: string;
  applied: boolean;
}

interface InsightSection {
  category: string;
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  items: InsightItem[];
}

const AIModeView = () => {
  const [appliedFixes, setAppliedFixes] = useState<Set<string>>(new Set());
  const [expandedSection, setExpandedSection] = useState<string | null>('Critical Issues');
  const { isLoading, hasError, retry } = useSimulatedLoading(800);
  const { applyFilters } = useFilters();

  let tasks: Task[];
  try {
    tasks = applyFilters(db.getTasks());
  } catch {
    return <ErrorState message="Failed to load task data for AI analysis." onRetry={() => window.location.reload()} />;
  }

  const activeTasks = tasks.filter((t) => t.status !== 'Completed');
  const atRiskTasks = activeTasks.filter((t) => t.aiRisk === 'high');
  const blockedTasks = activeTasks.filter((t) => t.status === 'Blocked');

  const insights: InsightSection[] = [
    {
      category: 'Critical Issues',
      icon: AlertTriangle,
      iconBg: 'bg-[var(--danger-light)]',
      iconColor: 'text-[var(--danger)]',
      items: [
        {
          id: 'c1',
          title: 'Sprint Execution at Risk',
          description: `Current velocity indicates 2.1 day delay. ${atRiskTasks.length} tasks flagged high-risk. Escalation will trigger in 18 hours if no progress signal received.`,
          confidence: 94,
          impact: 'critical',
          action: 'Reschedule Low Priority',
          applied: false,
        },
        {
          id: 'c2',
          title: 'Blocked Task Cascade',
          description: `"${blockedTasks[0]?.title || 'Update API documentation'}" blocked for 2+ days. ${blockedTasks.length > 0 ? blockedTasks.length : 1} downstream dependencies affected. Est. KR impact: 15%.`,
          confidence: 91,
          impact: 'critical',
          action: 'Reassign Resources',
          applied: false,
        },
      ],
    },
    {
      category: 'Dependency Conflicts',
      icon: GitBranch,
      iconBg: 'bg-[var(--warning-light)]',
      iconColor: 'text-[var(--warning-dark)]',
      items: [
        {
          id: 'd1',
          title: 'Circular Dependency Detected',
          description: 'Authentication → Database Schema → Password Reset → Authentication creates a potential deadlock. Breaking the cycle at "Database Schema" is optimal.',
          confidence: 89,
          impact: 'high',
          action: 'Break Cycle',
          applied: false,
        },
        {
          id: 'd2',
          title: 'Resource Contention',
          description: 'Sarah Chen has 2 critical-priority tasks due within 48 hours. Workload exceeds recommended capacity by 34%.',
          confidence: 86,
          impact: 'medium',
          action: 'Rebalance Load',
          applied: false,
        },
      ],
    },
    {
      category: 'Predicted Delays',
      icon: Clock,
      iconBg: 'bg-[var(--warning-bg)]',
      iconColor: 'text-[var(--warning)]',
      items: [
        {
          id: 'p1',
          title: 'Payment Refactor at Risk',
          description: 'Historical data shows 67% chance of 3-day delay based on similar task complexity. Consider adding buffer time or splitting into subtasks.',
          confidence: 82,
          impact: 'medium',
          action: 'Add Buffer Time',
          applied: false,
        },
        {
          id: 'p2',
          title: 'Design Review Bottleneck',
          description: 'Current review queue will delay 4 tasks by Feb 14. Recommending parallel review tracks.',
          confidence: 78,
          impact: 'medium',
          action: 'Expedite Reviews',
          applied: false,
        },
      ],
    },
    {
      category: 'Optimization Recommendations',
      icon: Wrench,
      iconBg: 'bg-[var(--info-light)]',
      iconColor: 'text-[var(--info-dark)]',
      items: [
        {
          id: 'o1',
          title: 'Split Large Task',
          description: '"Implement Authentication Flow" can be broken into 2 parallel subtasks: OAuth Provider Config and Callback Handlers. Estimated 30% time savings.',
          confidence: 87,
          impact: 'high',
          action: 'Auto-Split Task',
          applied: false,
        },
        {
          id: 'o2',
          title: 'Optimize Assignment',
          description: 'Redistributing 3 tasks across the team improves workload balance by 34% and reduces risk of single-point-of-failure.',
          confidence: 85,
          impact: 'medium',
          action: 'Apply Changes',
          applied: false,
        },
      ],
    },
  ];

  const totalInsights = insights.reduce((sum, s) => sum + s.items.length, 0);
  const avgConfidence = Math.round(
    insights.reduce((sum, s) => sum + s.items.reduce((ss, i) => ss + i.confidence, 0), 0) /
      totalInsights
  );

  const handleApplyFix = (id: string) => {
    setAppliedFixes((prev) => new Set([...prev, id]));
  };

  const handleApplyAll = () => {
    const allIds = insights.flatMap((s) => s.items.map((i) => i.id));
    setAppliedFixes(new Set(allIds));
  };

  const impactStyles = {
    critical: { bg: 'bg-[var(--danger-light)]', text: 'text-[var(--danger)]', label: 'Critical' },
    high: { bg: 'bg-[var(--warning-light)]', text: 'text-[var(--warning)]', label: 'High' },
    medium: { bg: 'bg-[var(--warning-bg)]', text: 'text-[var(--warning)]', label: 'Medium' },
  };

  const stats = [
    {
      label: 'Sprint Execution Risk',
      value: `${atRiskTasks.length}/${activeTasks.length} tasks`,
      icon: AlertCircle,
      iconBg: 'bg-[var(--danger-light)]',
      iconColor: 'text-[var(--danger)]',
    },
    {
      label: 'Predicted Timeline Impact',
      value: '2.1 days',
      icon: AlertTriangle,
      iconBg: 'bg-[var(--warning-light)]',
      iconColor: 'text-[var(--warning-dark)]',
    },
    {
      label: 'AI Insights Generated',
      value: totalInsights.toString(),
      icon: Brain,
      iconBg: 'bg-[var(--brand-primary-light)]',
      iconColor: 'text-[var(--brand-primary)]',
    },
    {
      label: 'Auto-Fixes Applied',
      value: `${appliedFixes.size}/${totalInsights}`,
      icon: CheckCircle,
      iconBg: 'bg-[var(--success-light)]',
      iconColor: 'text-[var(--success-dark)]',
    },
  ];

  const allFixed = appliedFixes.size === totalInsights;

  return (
    <div>
      {/* Sprint Health Charts — Recharts integration */}
      {isLoading ? (
        <div className="grid grid-cols-2 gap-4 mb-6">
          <ChartSkeleton />
          <ChartSkeleton />
          <ChartSkeleton />
          <ChartSkeleton />
        </div>
      ) : (
        <SprintHealthCharts />
      )}

      {/* AI Overview Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={i}
              className="bg-white rounded-[12px] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] p-5"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                  {stat.label}
                </span>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${stat.iconBg}`}>
                  <stat.icon size={16} className={stat.iconColor} />
                </div>
              </div>
              <div className="flex items-end justify-between">
                <div className="text-[24px] font-semibold leading-[1.2] tracking-[-0.01em] text-[var(--neutral-800)]">
                  {stat.value}
                </div>
                {typeof stat.change === 'number' && (
                  <span
                    className={`
                    h-[20px] px-2 rounded-md text-[10px] font-medium leading-[1.3] flex items-center gap-1
                    ${stat.positive
                      ? 'bg-[var(--success-light)] text-[var(--success-dark)]'
                      : 'bg-[var(--danger-light)] text-[var(--danger)]'
                    }
                  `}
                  >
                    {stat.change > 0 ? '+' : ''}{stat.change}%
                  </span>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* AI Insights Sections */}
      <div className="space-y-4">
        {insights.map((section, sectionIndex) => {
          const Icon = section.icon;
          const isExpanded = expandedSection === section.category;
          const allApplied = section.items.every((i) => appliedFixes.has(i.id));

          return (
            <motion.div
              key={section.category}
              className="bg-white rounded-[12px] shadow-[var(--shadow-card)] border border-[var(--neutral-200)] overflow-hidden"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: sectionIndex * 0.08 }}
            >
              {/* Section Header */}
              <button
                onClick={() => setExpandedSection(isExpanded ? null : section.category)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-[var(--neutral-50)] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${section.iconBg}`}>
                    <section.icon size={18} className={section.iconColor} />
                  </div>
                  <div className="text-left">
                    <h2 className="text-[16px] font-medium leading-[1.3] text-[var(--neutral-800)]">
                      {section.category}
                    </h2>
                    <span className="text-[12px] font-normal leading-[1.4] text-[var(--neutral-600)]">
                      {section.items.filter((i) => !appliedFixes.has(i.id)).length} pending ·{' '}
                      {section.items.length} total
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {allApplied && (
                    <span className="h-[24px] px-3 rounded-[6px] bg-[var(--success-light)] text-[var(--success-dark)] text-[12px] font-medium flex items-center gap-2 border border-[var(--success-border)]">
                      <CheckCircle size={12} />
                      All Applied
                    </span>
                  )}
                  <motion.div
                    animate={{ rotate: isExpanded ? 90 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ArrowRight size={16} className="text-[var(--neutral-400)]" />
                  </motion.div>
                </div>
              </button>

              {/* Section Content */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-5">
                      <div className="grid grid-cols-2 gap-4">
                        {section.items.map((item, itemIndex) => {
                          const isApplied = appliedFixes.has(item.id);
                          const impactStyle = impactStyles[item.impact];

                          return (
                            <motion.div
                              key={item.id}
                              className={`
                                p-5 border rounded-xl transition-all duration-[200ms] cursor-pointer
                                ${isApplied
                                  ? 'bg-[var(--neutral-50)] border-[var(--neutral-200)] opacity-70'
                                  : 'bg-white border-[var(--neutral-200)] hover:shadow-[var(--shadow-card-hover)] hover:border-[var(--brand-primary)]'
                                }
                              `}
                              onClick={() => !isApplied && handleApplyFix(item.id)}
                            >
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex-1 min-w-0">
                                  <h3 className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-1">
                                    {isApplied && (
                                      <CheckCircle
                                        size={14}
                                        className="inline mr-1.5 text-[var(--success-dark)]"
                                      />
                                    )}
                                    {item.title}
                                  </h3>
                                  <p className="text-[12px] font-normal leading-[1.5] text-[var(--neutral-600)]">
                                    {item.description}
                                  </p>
                                </div>
                                <div className="ml-3 shrink-0">
                                  <span
                                    className={`
                                      inline-block px-2 h-[20px] rounded-md text-[10px] font-medium uppercase leading-[1.3] flex items-center
                                      ${impactStyles[item.impact].bg} ${impactStyles[item.impact].text}
                                    `}
                                  >
                                    {impactStyles[item.impact].label}
                                  </span>
                                </div>
                              </div>

                              <div className="mb-3 space-y-2">
                                <div className="flex items-center gap-2 text-[12px]">
                                  <Brain size={12} className="text-[var(--brand-primary)]" />
                                  <span className="text-[var(--neutral-600)]">Confidence:</span>
                                  <span className="font-medium text-[var(--neutral-800)]">
                                    {item.confidence}%
                                  </span>
                                </div>
                                <div className="flex-1 bg-[var(--neutral-100)] rounded-full h-1.5 overflow-hidden">
                                  <motion.div
                                    className="h-full bg-gradient-to-r from-[var(--brand-primary)] to-[var(--gradient-end)] rounded-full"
                                    initial={{ width: 0 }}
                                    animate={{ width: `${item.confidence}%` }}
                                    transition={{ duration: 0.6, delay: itemIndex * 0.05 }}
                                  />
                                </div>
                              </div>

                              <div className="flex items-center gap-2 pt-3 border-t border-[var(--neutral-100)]">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (!isApplied) handleApplyFix(item.id);
                                  }}
                                  disabled={isApplied}
                                  className={`
                                  h-9 px-5 rounded-lg text-[12px] font-medium transition-all duration-[120ms]
                                  ${isApplied
                                    ? 'bg-[var(--success-light)] text-[var(--success-dark)] border border-[var(--success-border)] cursor-default'
                                    : 'bg-gradient-to-r from-[var(--brand-primary)] to-[var(--gradient-end)] text-white hover:shadow-[var(--shadow-brand-hover)]'
                                  }
                                `}
                                >
                                  {isApplied ? (
                                    <>
                                      <CheckCircle size={14} />
                                      Applied
                                    </>
                                  ) : (
                                    <>
                                      <Wrench size={14} />
                                      {item.action}
                                    </>
                                  )}
                                </button>
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>

      {/* AI Actions Footer */}
      <motion.div
        className="mt-6 p-6 bg-gradient-to-br from-[var(--brand-primary)] to-[var(--gradient-end)] rounded-[12px] text-white shadow-[var(--shadow-brand-hover)]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="flex items-center gap-3 mb-4">
          <Sparkles size={24} />
          <div>
            <h3 className="text-[16px] font-medium leading-[1.3]">AI Commander Ready</h3>
            <p className="text-[12px] font-normal leading-[1.4] text-white/80">
              Apply all pending recommendations with one click
            </p>
          </div>
        </div>
        <button
          onClick={handleApplyAll}
          disabled={allFixed}
          className={`
            w-full h-10 rounded-lg text-[14px] font-medium transition-all duration-[120ms]
            ${allFixed
              ? 'bg-white/20 text-white/60 cursor-default'
              : 'bg-white text-[var(--brand-primary)] hover:shadow-[var(--shadow-modal)]'
            }
          `}
        >
          {allFixed ? 'All Fixes Applied' : 'Apply All Fixes'}
        </button>
      </motion.div>
    </div>
  );
};

export default AIModeView;
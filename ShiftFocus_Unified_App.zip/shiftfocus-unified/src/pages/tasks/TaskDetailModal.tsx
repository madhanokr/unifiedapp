import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Calendar,
  User,
  Flag,
  Link2,
  MessageSquare,
  Paperclip,
  Plus,
  GitBranch,
  Clock,
  TrendingUp,
  AlertTriangle,
  Sparkles,
  MoreHorizontal,
  Edit2,
  Trash2,
  CheckSquare,
  ChevronRight,
  Send,
  Image,
  FileText,
  Download,
  Eye,
  Copy,
  Share2,
  Bell,
  Tag,
  Users,
  Shield,
  Zap,
  ArrowUp,
  Activity,
  FolderKanban,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  Button,
  IconButton,
  PriorityBadge,
  StatusBadge,
  Badge,
  ProgressBar,
  sfToast,
} from './design-system';
import ConfirmDialog from './ConfirmDialog';
import { db, PROJECT_COLOR_MAP } from './data-store';

interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'In Progress' | 'Not Started' | 'Blocked' | 'Waiting' | 'Completed';
  assignee: { name: string; avatar: string };
  dueDate: string;
  krImpact: number;
  aiRisk: 'high' | 'medium' | 'low';
  projectId?: string;
}

interface TaskDetailModalProps {
  task: Task;
  onClose: () => void;
}

const priorityStyles = {
  Critical: 'bg-[var(--danger-bg)] text-[var(--danger)] border-[var(--danger-border)]',
  High: 'bg-[var(--warning-bg)] text-[var(--warning-dark)] border-[var(--warning-border)]',
  Medium: 'bg-[var(--info-bg)] text-[var(--info-dark)] border-[var(--info-border)]',
  Low: 'bg-[var(--neutral-100)] text-[var(--neutral-600)] border-[var(--neutral-200)]',
};

const statusStyles: Record<string, string> = {
  'In Progress': 'bg-[var(--info-bg)] text-[var(--info-dark)] border-[var(--info-border)]',
  'Not Started': 'bg-[var(--neutral-100)] text-[var(--neutral-600)] border-[var(--neutral-200)]',
  'Blocked': 'bg-[var(--danger-bg)] text-[var(--danger)] border-[var(--danger-border)]',
  'Waiting': 'bg-[var(--warning-bg)] text-[var(--warning-dark)] border-[var(--warning-border)]',
  'Completed': 'bg-[var(--success-bg)] text-[var(--success-dark)] border-[var(--success-border)]',
};

const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ task, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'activity' | 'ai'>('overview');
  const [isEditing, setIsEditing] = useState(false);
  const [taskTitle, setTaskTitle] = useState(task.title);
  const [taskDescription, setTaskDescription] = useState(task.description);
  const [comment, setComment] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const [subtaskStates, setSubtaskStates] = useState<Record<string, boolean>>({
    '1': true,
    '2': false,
    '3': false,
  });

  const subtasks = [
    { id: '1', title: 'Setup OAuth providers configuration', lastUpdate: '2h ago', daysIdle: 0 },
    { id: '2', title: 'Implement callback handlers', lastUpdate: '1d ago', daysIdle: 1 },
    { id: '3', title: 'Add error handling and retry logic', lastUpdate: '3d ago', daysIdle: 3 },
  ];

  const linkedTasks = [
    { 
      id: 'TASK-45', 
      title: 'Setup user database schema', 
      type: 'blocked-by', 
      status: 'In Progress',
      krImpact: 15,
      estimatedDelay: '2.5 days',
      escalatesIn: '18h',
      affectedTeams: ['Backend', 'Security']
    },
    { 
      id: 'TASK-67', 
      title: 'Implement password reset flow', 
      type: 'blocks', 
      status: 'Not Started',
      krImpact: 22,
      estimatedDelay: 'Blocked',
      affectedTeams: ['Frontend', 'QA']
    },
    { id: 'TASK-89', title: 'Add 2FA support', type: 'relates-to', status: 'Not Started' },
  ];

  const comments = [
    {
      id: '1',
      author: 'Mike Ross',
      avatar: 'MR',
      time: '2 hours ago',
      text: 'I think we should prioritize Google OAuth first, then add GitHub support in the next iteration.',
      isSystem: false,
    },
    {
      id: 'system-1',
      author: 'System',
      avatar: '',
      time: '4 hours ago',
      text: 'SLA Alert: This task has been in "In Progress" for 3 days without completion. Next escalation to Engineering Manager in 18 hours.',
      isSystem: true,
      systemType: 'escalation',
    },
    {
      id: '2',
      author: 'Sarah Chen',
      avatar: 'SC',
      time: '1 hour ago',
      text: 'Agreed. I\'ve already started working on the Google integration. Should have it ready by EOD.',
      isSystem: false,
    },
    {
      id: 'system-2',
      author: 'System',
      avatar: '',
      time: '6 hours ago',
      text: 'Dependency Aging: Blocker TASK-45 has been unresolved for 5 days, impacting downstream deliverables by 15% KR.',
      isSystem: true,
      systemType: 'dependency',
    },
  ];

  const aiInsights = [
    {
      type: 'warning',
      title: 'Critical: Sprint Timeline Risk',
      description: 'This task is delaying Sprint 24 by 2.1 days. Dependencies are blocking 3 downstream tasks.',
      confidence: 94,
      action: 'Reschedule Dependencies',
    },
    {
      type: 'suggestion',
      title: 'Optimization Opportunity',
      description: 'AI suggests breaking this into 2 parallel subtasks. Estimated 30% time savings.',
      confidence: 87,
      action: 'Auto-Create Subtasks',
    },
    {
      type: 'insight',
      title: 'Resource Allocation',
      description: 'Sarah Chen has 85% workload capacity. Consider reassigning 1 subtask to balance team load.',
      confidence: 82,
      action: 'View Suggestions',
    },
  ];

  const attachments = [
    { id: '1', name: 'OAuth Flow Diagram.pdf', size: '2.4 MB', type: 'pdf', uploadedBy: 'Sarah Chen', time: '3 hours ago' },
    { id: '2', name: 'API Mockups.figma', size: '8.1 MB', type: 'figma', uploadedBy: 'Mike Ross', time: '1 day ago' },
    { id: '3', name: 'auth-screenshot.png', size: '456 KB', type: 'image', uploadedBy: 'Sarah Chen', time: '2 days ago' },
  ];

  const activityLog = [
    { type: 'status', text: 'Status changed from Not Started to In Progress', time: '2 hours ago', user: 'Sarah Chen', avatar: 'SC' },
    { type: 'comment', text: 'Added a comment', time: '3 hours ago', user: 'Mike Ross', avatar: 'MR' },
    { type: 'subtask', text: 'Completed subtask: Setup OAuth providers configuration', time: '4 hours ago', user: 'Sarah Chen', avatar: 'SC' },
    { type: 'assign', text: 'Assigned to Sarah Chen', time: '5 hours ago', user: 'Alex Kim', avatar: 'AK' },
    { type: 'priority', text: 'Priority changed from High to Critical', time: '6 hours ago', user: 'Emma Stone', avatar: 'ES' },
    { type: 'create', text: 'Task created', time: '1 day ago', user: 'Emma Stone', avatar: 'ES' },
  ];

  const handleSubtaskToggle = (id: string) => {
    setSubtaskStates(prev => ({ ...prev, [id]: !prev[id as keyof typeof prev] }));
  };

  const completedSubtasks = Object.values(subtaskStates).filter(Boolean).length;

  return (
    <>
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
        {/* Backdrop */}
        <motion.div
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.12 }}
          onClick={onClose}
        />

        {/* Modal - Fixed max-width: 1200px, max-height: 90vh */}
        <motion.div
          className="relative w-full max-w-[1200px] h-[90vh] bg-white rounded-[16px] shadow-[var(--shadow-modal)] overflow-hidden flex"
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Main Content Area */}
          <div className="flex-1 flex flex-col overflow-hidden bg-white">
            
            {/* Header - Fixed height: 80px */}
            <div className="h-[80px] px-8 border-b border-[var(--neutral-200)] flex items-center justify-between shrink-0">
              <div className="flex-1 min-w-0">
                {/* Breadcrumb */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[12px] font-medium leading-[1.3] tracking-[0.01em] text-[var(--neutral-400)] uppercase">
                    TASK-{task.id}
                  </span>
                  <span className="text-[var(--neutral-200)]">&bull;</span>
                  <div className="flex items-center gap-2">
                    <PriorityBadge value={task.priority} />
                    <StatusBadge value={task.status} />
                  </div>
                </div>

                {/* Title */}
                {isEditing ? (
                  <input
                    type="text"
                    value={taskTitle}
                    onChange={(e) => setTaskTitle(e.target.value)}
                    onBlur={() => setIsEditing(false)}
                    className="text-[20px] font-medium leading-[1.3] text-[var(--neutral-800)] w-full border-b-2 border-[var(--brand-primary)] focus:outline-none pb-1"
                    autoFocus
                  />
                ) : (
                  <h2 
                    className="text-[20px] font-medium leading-[1.3] text-[var(--neutral-800)] cursor-text truncate"
                    onClick={() => setIsEditing(true)}
                  >
                    {taskTitle}
                  </h2>
                )}
              </div>

              {/* Header Actions */}
              <div className="flex items-center gap-2 ml-6">
                <IconButton icon={<Copy size={18} />} />
                <IconButton icon={<Share2 size={18} />} />
                <IconButton icon={<Bell size={18} />} />
                <IconButton icon={<MoreHorizontal size={18} />} />
                <div className="w-px h-6 bg-[var(--neutral-200)] mx-1"></div>
                <button 
                  onClick={onClose}
                  className="w-10 h-10 flex items-center justify-center hover:bg-[var(--neutral-50)] rounded-lg transition-colors text-[var(--neutral-600)] hover:text-[var(--neutral-800)]"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Tabs - Fixed height: 48px */}
            <div className="h-[48px] px-8 border-b border-[var(--neutral-200)] flex items-center gap-6 shrink-0">
              {[
                { id: 'overview', label: 'Overview', badge: null },
                { id: 'activity', label: 'Activity', badge: activityLog.length },
                { id: 'ai', label: 'AI Insights', badge: aiInsights.length },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as 'overview' | 'activity' | 'ai')}
                  className={`
                    h-full px-1 text-[14px] font-medium leading-[1.5] border-b-2 transition-all duration-[120ms] relative
                    ${activeTab === tab.id
                      ? 'border-[var(--brand-primary)] text-[var(--brand-primary)]'
                      : 'border-transparent text-[var(--neutral-600)] hover:text-[var(--neutral-800)]'
                    }
                  `}
                >
                  <span className="flex items-center gap-2">
                    {tab.label}
                    {tab.badge && (
                      <span className="h-5 px-2 bg-[var(--brand-primary)] text-white rounded-full text-[12px] font-medium leading-[1.3] flex items-center">
                        {tab.badge}
                      </span>
                    )}
                  </span>
                </button>
              ))}
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto">
              <div className="px-8 py-6">
                
                {/* Overview Tab */}
                {activeTab === 'overview' && (
                  <div className="space-y-8">
                    
                    {/* Escalation Status Banner */}
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-5 bg-gradient-to-r from-[var(--danger-bg-subtle)] to-[var(--warning-bg)] rounded-[12px] border-2 border-[var(--danger-border)]"
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-[var(--danger-light)] flex items-center justify-center shrink-0">
                          <Clock size={20} className="text-[var(--danger)]" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="text-[14px] font-medium leading-[1.4] text-[var(--neutral-800)]">
                              Escalation Timeline
                            </h4>
                            <span className="text-[20px] font-medium leading-[1.3] text-[var(--danger)]">
                              18h
                            </span>
                          </div>
                          <p className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-600)] mb-3">
                            Time remaining until automatic escalation to Engineering Manager
                          </p>
                          
                          {/* Progress bar showing time decay */}
                          <div className="mb-3">
                            <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                              <motion.div
                                initial={{ width: '25%' }}
                                animate={{ width: '25%' }}
                                className="h-full bg-gradient-to-r from-[var(--warning-dark)] to-[var(--danger)]"
                              />
                            </div>
                          </div>

                          <div className="flex items-center gap-6 text-[12px] leading-[1.4]">
                            <div className="flex items-center gap-2">
                              <ArrowUp size={14} className="text-[var(--warning-dark)]" />
                              <span className="text-[var(--neutral-600)]">Next Level:</span>
                              <span className="font-medium text-[var(--neutral-800)]">Engineering Manager</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Shield size={14} className="text-[var(--neutral-600)]" />
                              <span className="text-[var(--neutral-600)]">SLA Type:</span>
                              <span className="font-medium text-[var(--neutral-800)]">Critical Path</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                    
                    {/* Description */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase">
                          Description
                        </h3>
                        <button 
                          onClick={() => setIsEditing(true)}
                          className="text-[12px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] flex items-center gap-1"
                        >
                          <Edit2 size={12} />
                          Edit
                        </button>
                      </div>
                      <div className="p-4 bg-[var(--neutral-50)] rounded-lg border border-[var(--neutral-200)]">
                        <p className="text-[14px] font-normal leading-[1.6] text-[var(--neutral-800)]">
                          {taskDescription}
                        </p>
                      </div>
                    </div>

                    {/* Subtasks */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase flex items-center gap-2">
                          <CheckSquare size={14} />
                          Subtasks
                          <span className="text-[var(--neutral-400)]">
                            ({completedSubtasks}/{subtasks.length})
                          </span>
                        </h3>
                        <button className="text-[12px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] flex items-center gap-1">
                          <Plus size={12} />
                          Add Subtask
                        </button>
                      </div>

                      {/* Progress Bar */}
                      <div className="mb-4">
                        <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${(completedSubtasks / subtasks.length) * 100}%` }}
                            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
                            className="h-full bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)]"
                          />
                        </div>
                      </div>

                      {/* Execution Rule Notice */}
                      <div className="mb-3 p-3 bg-[var(--info-bg)] rounded-lg border border-[var(--info-light)] flex items-start gap-3">
                        <Activity size={14} className="text-[var(--brand-primary)] mt-0.5 shrink-0" />
                        <div>
                          <p className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-800)] mb-1">
                            Execution Commitment
                          </p>
                          <p className="text-[12px] font-normal leading-[1.5] text-[var(--neutral-600)]">
                            Critical tasks require progress signals every 48h. Prolonged silence is treated as execution risk.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        {subtasks.map((subtask) => (
                          <motion.div
                            key={subtask.id}
                            className={`
                              flex items-start gap-3 p-3 hover:bg-[var(--neutral-50)] rounded-lg transition-colors group
                              ${subtask.daysIdle >= 3 ? 'bg-[var(--danger-bg-subtle)] border border-[var(--danger-border)]' : ''}
                            `}
                            whileHover={{ x: 2 }}
                          >
                            <input
                              type="checkbox"
                              checked={subtaskStates[subtask.id]}
                              onChange={() => handleSubtaskToggle(subtask.id)}
                              className="w-5 h-5 rounded border-2 border-[var(--neutral-200)] text-[var(--brand-primary)] focus:ring-0 cursor-pointer mt-0.5"
                            />
                            <div className="flex-1 min-w-0">
                              <span className={`
                                text-[14px] font-normal leading-[1.5] block
                                ${subtaskStates[subtask.id] ? 'text-[var(--neutral-400)] line-through' : 'text-[var(--neutral-800)]'}
                              `}>
                                {subtask.title}
                              </span>
                              <div className="flex items-center gap-3 mt-1.5">
                                <span className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
                                  Last update: {subtask.lastUpdate}
                                </span>
                                {subtask.daysIdle >= 3 && !subtaskStates[subtask.id] && (
                                  <span className="flex items-center gap-1 text-[12px] font-medium leading-[1.3] text-[var(--danger)]">
                                    <AlertTriangle size={12} />
                                    {subtask.daysIdle}d idle
                                  </span>
                                )}
                                {subtask.daysIdle === 1 && !subtaskStates[subtask.id] && (
                                  <span className="flex items-center gap-1 text-[12px] font-medium leading-[1.3] text-[var(--warning-dark)]">
                                    <Clock size={12} />
                                    Update due
                                  </span>
                                )}
                              </div>
                            </div>
                            <button className="opacity-0 group-hover:opacity-100 w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-all shrink-0">
                              <MoreHorizontal size={14} className="text-[var(--neutral-400)]" />
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Linked Tasks & Dependencies */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase flex items-center gap-2">
                          <GitBranch size={14} />
                          Dependencies & Impact
                        </h3>
                        <button className="text-[12px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] flex items-center gap-1">
                          <Link2 size={12} />
                          Link Task
                        </button>
                      </div>
                      <div className="space-y-3">
                        {linkedTasks.map((linked) => (
                          <motion.div
                            key={linked.id}
                            className={`
                              p-4 rounded-lg border transition-all cursor-pointer
                              ${(linked.type === 'blocks' || linked.type === 'blocked-by') 
                                ? 'bg-[var(--warning-bg)] border-[var(--warning-border)] hover:border-[var(--warning-dark)]' 
                                : 'bg-[var(--neutral-50)] border-[var(--neutral-200)] hover:border-[var(--brand-primary)]'}
                            `}
                            whileHover={{ x: 2 }}
                          >
                            {/* Header Row */}
                            <div className="flex items-center gap-3 mb-3">
                              <span className={`
                                h-[24px] px-3 rounded-[6px] border text-[12px] font-medium leading-[1.3] uppercase flex items-center shrink-0
                                ${linked.type === 'blocks' ? 'bg-[var(--danger-light)] text-[var(--danger)] border-[var(--danger-border)]' :
                                  linked.type === 'blocked-by' ? 'bg-[var(--warning-light)] text-[var(--warning-dark)] border-[var(--warning-border)]' :
                                  'bg-[var(--info-light)] text-[var(--info-dark)] border-[var(--info-border)]'}
                              `}>
                                {linked.type}
                              </span>
                              <span className="text-[12px] font-medium leading-[1.3] text-[var(--neutral-400)] tracking-[0.01em]">
                                {linked.id}
                              </span>
                              <span className={`
                                h-[24px] px-3 rounded-[6px] border text-[12px] font-medium leading-[1.3] uppercase flex items-center shrink-0 ml-auto
                                ${statusStyles[linked.status] || ''}
                              `}>
                                {linked.status}
                              </span>
                            </div>

                            {/* Title */}
                            <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] mb-3">
                              {linked.title}
                            </div>

                            {/* Consequence Metrics - Only for blockers */}
                            {(linked.type === 'blocks' || linked.type === 'blocked-by') && linked.krImpact && (
                              <div className="space-y-2 pt-3 border-t border-[var(--warning-border)]">
                                <div className="grid grid-cols-3 gap-3 text-[12px]">
                                  <div>
                                    <div className="text-[var(--neutral-400)] mb-1 uppercase tracking-[0.01em] font-medium">KR Impact</div>
                                    <div className="text-[var(--danger)] font-semibold">{linked.krImpact}%</div>
                                  </div>
                                  <div>
                                    <div className="text-[var(--neutral-400)] mb-1 uppercase tracking-[0.01em] font-medium">Est. Delay</div>
                                    <div className="text-[var(--warning-dark)] font-semibold">{linked.estimatedDelay}</div>
                                  </div>
                                  {linked.escalatesIn && (
                                    <div>
                                      <div className="text-[var(--neutral-400)] mb-1 uppercase tracking-[0.01em] font-medium">Escalates in</div>
                                      <div className="text-[var(--danger)] font-semibold">{linked.escalatesIn}</div>
                                    </div>
                                  )}
                                </div>
                                {linked.affectedTeams && (
                                  <div className="pt-2">
                                    <div className="text-[12px] text-[var(--neutral-400)] mb-1.5 uppercase tracking-[0.01em] font-medium">Affected Teams</div>
                                    <div className="flex flex-wrap gap-1.5">
                                      {linked.affectedTeams.map((team, idx) => (
                                        <span key={idx} className="h-[24px] px-3 bg-white border border-[var(--warning-border)] rounded-full text-[12px] font-normal text-[var(--neutral-800)] flex items-center">
                                          {team}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Attachments */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase flex items-center gap-2">
                          <Paperclip size={14} />
                          Attachments
                          <span className="text-[var(--neutral-400)]">({attachments.length})</span>
                        </h3>
                        <button className="text-[12px] font-medium text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] flex items-center gap-1">
                          <Plus size={12} />
                          Upload
                        </button>
                      </div>
                      <div className="grid grid-cols-1 gap-2">
                        {attachments.map((file) => (
                          <motion.div
                            key={file.id}
                            className="flex items-center gap-3 p-3 bg-[var(--neutral-50)] hover:bg-[var(--neutral-100)] rounded-lg border border-[var(--neutral-200)] hover:border-[var(--brand-primary)] transition-all group"
                            whileHover={{ x: 2 }}
                          >
                            <div className={`
                              w-10 h-10 rounded-lg flex items-center justify-center shrink-0
                              ${file.type === 'image' ? 'bg-[var(--success-light)]' : file.type === 'pdf' ? 'bg-[var(--danger-light)]' : 'bg-[var(--info-light)]'}
                            `}>
                              {file.type === 'image' ? <Image size={18} className="text-[var(--on-track)]" /> : <FileText size={18} className={file.type === 'pdf' ? 'text-[var(--danger)]' : 'text-[var(--info-dark)]'} />}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[14px] font-medium leading-[1.5] text-[var(--neutral-800)] truncate">
                                {file.name}
                              </div>
                              <div className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
                                {file.size} · {file.uploadedBy} · {file.time}
                              </div>
                            </div>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-colors">
                                <Eye size={14} className="text-[var(--neutral-600)]" />
                              </button>
                              <button className="w-8 h-8 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded transition-colors">
                                <Download size={14} className="text-[var(--neutral-600)]" />
                              </button>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Comments */}
                    <div>
                      <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.01em] text-[var(--neutral-600)] uppercase mb-3 flex items-center gap-2">
                        <MessageSquare size={14} />
                        Comments & System Alerts
                        <span className="text-[var(--neutral-400)]">({comments.length})</span>
                      </h3>
                      <div className="space-y-4">
                        {comments.map((c) => (
                          <div key={c.id} className="flex gap-3">
                            {/* Avatar or System Icon */}
                            {c.isSystem ? (
                              <div className="w-8 h-8 rounded-full bg-[var(--info-bg)] border-2 border-[var(--info-light)] flex items-center justify-center shrink-0">
                                <Shield size={14} className="text-[var(--brand-primary)]" />
                              </div>
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[12px] font-medium shrink-0">
                                {c.avatar}
                              </div>
                            )}
                            
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`
                                  text-[14px] font-medium leading-[1.5]
                                  ${c.isSystem ? 'text-[var(--brand-primary)]' : 'text-[var(--neutral-800)]'}
                                `}>
                                  {c.author}
                                  {c.isSystem && (
                                    <span className="ml-2 text-[12px] font-medium text-[var(--neutral-400)] uppercase tracking-[0.01em]">
                                      &bull; AUTOMATED
                                    </span>
                                  )}
                                </span>
                                <span className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
                                  {c.time}
                                </span>
                              </div>
                              <div className={`
                                p-3 rounded-lg border
                                ${c.isSystem 
                                  ? c.systemType === 'escalation'
                                    ? 'bg-[var(--danger-bg-subtle)] border-[var(--danger-border)]'
                                    : 'bg-[var(--warning-light)] border-[var(--warning-border)]'
                                  : 'bg-[var(--neutral-50)] border-[var(--neutral-200)]'
                                }
                              `}>
                                {c.isSystem && (
                                  <div className="flex items-center gap-2 mb-2 pb-2 border-b border-current opacity-20">
                                    {c.systemType === 'escalation' ? (
                                      <AlertTriangle size={12} className="text-[var(--danger)]" />
                                    ) : (
                                      <Activity size={12} className="text-[var(--warning-dark)]" />
                                    )}
                                    <span className="text-[10px] font-medium uppercase tracking-[0.01em] text-[var(--neutral-600)]">
                                      {c.systemType === 'escalation' ? 'Escalation Notice' : 'Dependency Alert'}
                                    </span>
                                  </div>
                                )}
                                <p className="text-[14px] font-normal leading-[1.6] text-[var(--neutral-800)]">
                                  {c.text}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}

                        {/* Add Comment */}
                        <div className="flex gap-3 pt-2">
                          <div className="w-8 h-8 rounded-full bg-[var(--neutral-200)] flex items-center justify-center text-[var(--neutral-600)] text-[12px] font-medium shrink-0">
                            You
                          </div>
                          <div className="flex-1 flex gap-2">
                            <input
                              type="text"
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              placeholder="Add a comment..."
                              className="flex-1 h-10 px-4 border border-[var(--neutral-200)] rounded-lg text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] placeholder:text-[var(--neutral-400)] focus:outline-none focus:border-[var(--brand-primary)]"
                            />
                            <button
                              disabled={!comment.trim()}
                              className={`h-10 px-4 rounded-lg flex items-center gap-2 transition-all ${
                                comment.trim()
                                  ? 'bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white hover:shadow-[var(--shadow-brand-hover)]'
                                  : 'bg-[var(--neutral-200)] text-[var(--neutral-400)] cursor-not-allowed'
                              }`}
                            >
                              <Send size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Activity Tab */}
                {activeTab === 'activity' && (
                  <div className="space-y-1">
                    {activityLog.map((activity, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="flex gap-3 p-3 hover:bg-[var(--neutral-50)] rounded-lg transition-colors"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[12px] font-medium shrink-0">
                          {activity.avatar}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)]">
                              <span className="font-medium">{activity.user}</span> {activity.text}
                            </p>
                            <span className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)] whitespace-nowrap">
                              {activity.time}
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                {/* AI Insights Tab */}
                {activeTab === 'ai' && (
                  <div className="space-y-4">
                    {aiInsights.map((insight, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className={`
                          p-5 rounded-xl border-2 transition-all hover:shadow-[var(--shadow-elevated)]
                          ${insight.type === 'warning' ? 'bg-[var(--danger-bg)] border-[var(--danger-border)]' :
                            insight.type === 'suggestion' ? 'bg-[var(--info-bg)] border-[var(--info-border)]' :
                            'bg-[var(--success-bg)] border-[var(--success-border)]'}
                        `}
                      >
                        <div className="flex gap-4">
                          <div className={`
                            w-12 h-12 rounded-xl flex items-center justify-center shrink-0
                            ${insight.type === 'warning' ? 'bg-[var(--danger-light)]' :
                              insight.type === 'suggestion' ? 'bg-[var(--info-light)]' :
                              'bg-[var(--success-light)]'}
                          `}>
                            {insight.type === 'warning' ? (
                              <AlertTriangle size={20} className="text-[var(--danger)]" />
                            ) : insight.type === 'suggestion' ? (
                              <Sparkles size={20} className="text-[var(--brand-primary)]" />
                            ) : (
                              <TrendingUp size={20} className="text-[var(--on-track)]" />
                            )}
                          </div>
                          <div className="flex-1">
                            <h4 className="text-[16px] font-medium leading-[1.4] text-[var(--neutral-800)] mb-2">
                              {insight.title}
                            </h4>
                            <p className="text-[14px] font-normal leading-[1.6] text-[var(--neutral-600)] mb-4">
                              {insight.description}
                            </p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <span className="text-[12px] font-medium leading-[1.3] text-[var(--neutral-400)] uppercase tracking-[0.01em]">
                                  Confidence
                                </span>
                                <div className="flex items-center gap-2">
                                  <div className="w-24 h-1.5 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                                    <motion.div
                                      initial={{ width: 0 }}
                                      animate={{ width: `${insight.confidence}%` }}
                                      transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
                                      className="h-full bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)]"
                                    />
                                  </div>
                                  <span className="text-[14px] font-medium leading-[1.5] text-[var(--brand-primary)]">
                                    {insight.confidence}%
                                  </span>
                                </div>
                              </div>
                              <button className="h-9 px-5 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white text-[12px] font-medium rounded-lg hover:shadow-[var(--shadow-brand-hover)] transition-all">
                                {insight.action}
                              </button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Sidebar - Fixed width: 320px */}
          <div className="w-[320px] border-l border-[var(--neutral-200)] bg-[var(--neutral-50)] flex flex-col shrink-0">
            <div className="overflow-y-auto p-6">
              <h3 className="text-[12px] font-medium leading-[1.3] tracking-[0.01em] text-[var(--neutral-400)] uppercase mb-5">
                Details
              </h3>

              <div className="space-y-5">
                {/* Assignee */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <User size={12} />
                    Assignee
                  </label>
                  <div className="flex items-center gap-3 p-3 bg-white rounded-lg border border-[var(--neutral-200)] hover:border-[var(--brand-primary)] cursor-pointer transition-colors group">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] flex items-center justify-center text-white text-[12px] font-medium">
                      {task.assignee.avatar}
                    </div>
                    <span className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] flex-1">
                      {task.assignee.name}
                    </span>
                    <ChevronRight size={14} className="text-[var(--neutral-400)] group-hover:text-[var(--brand-primary)] transition-colors" />
                  </div>
                </div>

                {/* Due Date */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <Calendar size={12} />
                    Due Date
                  </label>
                  <div className="p-3 bg-white rounded-lg border border-[var(--neutral-200)] hover:border-[var(--brand-primary)] cursor-pointer transition-colors">
                    <span className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)]">
                      {task.dueDate}
                    </span>
                  </div>
                </div>

                {/* Priority */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <Flag size={12} />
                    Priority
                  </label>
                  <select className="w-full p-3 bg-white rounded-lg border border-[var(--neutral-200)] text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] cursor-pointer hover:border-[var(--brand-primary)] focus:outline-none focus:border-[var(--brand-primary)] transition-colors">
                    <option>Critical</option>
                    <option>High</option>
                    <option>Medium</option>
                    <option>Low</option>
                  </select>
                </div>

                {/* Status */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <Clock size={12} />
                    Status
                  </label>
                  <select className="w-full p-3 bg-white rounded-lg border border-[var(--neutral-200)] text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] cursor-pointer hover:border-[var(--brand-primary)] focus:outline-none focus:border-[var(--brand-primary)] transition-colors">
                    <option>In Progress</option>
                    <option>Not Started</option>
                    <option>Blocked</option>
                    <option>Waiting</option>
                    <option>Completed</option>
                  </select>
                </div>

                {/* Project */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <FolderKanban size={12} />
                    Project
                  </label>
                  <select
                    defaultValue={task.projectId || 'inbox'}
                    onChange={(e) => {
                      const newProjectId = e.target.value;
                      db.moveTask(task.id, newProjectId);
                      const project = db.getProjectById(newProjectId);
                      sfToast.success('Task moved', `Moved to "${project?.name || 'Inbox'}"`);
                    }}
                    className="w-full p-3 bg-white rounded-lg border border-[var(--neutral-200)] text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)] cursor-pointer hover:border-[var(--brand-primary)] focus:outline-none focus:border-[var(--brand-primary)] transition-colors"
                  >
                    {db.getProjects().map(p => (
                      <option key={p.id} value={p.id}>{p.icon} {p.name}</option>
                    ))}
                  </select>
                </div>

                {/* KR Impact */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <TrendingUp size={12} />
                    KR Impact
                  </label>
                  <div className="p-4 bg-white rounded-lg border border-[var(--neutral-200)]">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[20px] font-medium leading-[1.3] text-[var(--brand-primary)]">
                        {task.krImpact}%
                      </span>
                      <span className="text-[12px] font-medium leading-[1.3] text-[var(--neutral-600)] uppercase tracking-[0.01em]">
                        High Impact
                      </span>
                    </div>
                    <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-full"
                        style={{ width: `${task.krImpact}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* AI Risk Level */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <AlertTriangle size={12} />
                    AI Risk Level
                  </label>
                  <div className={`
                    p-4 rounded-lg border-2
                    ${task.aiRisk === 'high' ? 'bg-[var(--danger-bg)] border-[var(--danger-border)]' :
                      task.aiRisk === 'medium' ? 'bg-[var(--warning-light)] border-[var(--warning-border)]' :
                      'bg-[var(--success-bg)] border-[var(--success-border)]'}
                  `}>
                    <div className="flex items-center gap-3">
                      <div className={`
                        w-10 h-10 rounded-full flex items-center justify-center
                        ${task.aiRisk === 'high' ? 'bg-[var(--danger-light)]' :
                          task.aiRisk === 'medium' ? 'bg-[var(--warning-light)]' :
                          'bg-[var(--success-light)]'}
                      `}>
                        <AlertTriangle
                          size={18}
                          className={
                            task.aiRisk === 'high' ? 'text-[var(--danger)]' :
                            task.aiRisk === 'medium' ? 'text-[var(--warning-dark)]' :
                            'text-[var(--on-track)]'
                          }
                        />
                      </div>
                      <div>
                        <div className={`
                          text-[14px] font-medium leading-[1.5] capitalize
                          ${task.aiRisk === 'high' ? 'text-[var(--danger)]' :
                            task.aiRisk === 'medium' ? 'text-[var(--warning-dark)]' :
                            'text-[var(--on-track)]'}
                        `}>
                          {task.aiRisk} Risk
                        </div>
                        <div className="text-[12px] font-normal leading-[1.3] text-[var(--neutral-400)]">
                          AI-Powered Analysis
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Tags */}
                <div>
                  <label className="text-[12px] font-medium leading-[1.4] text-[var(--neutral-600)] mb-2 flex items-center gap-2">
                    <Tag size={12} />
                    Tags
                  </label>
                  <div className="flex flex-wrap gap-2">
                    <span className="h-[24px] px-3 bg-white border border-[var(--neutral-200)] rounded-full text-[12px] font-normal leading-[1.4] text-[var(--neutral-800)] flex items-center">
                      Authentication
                    </span>
                    <span className="h-[24px] px-3 bg-white border border-[var(--neutral-200)] rounded-full text-[12px] font-normal leading-[1.4] text-[var(--neutral-800)] flex items-center">
                      Backend
                    </span>
                    <button className="h-[24px] px-3 bg-white border border-dashed border-[var(--neutral-200)] rounded-full text-[12px] font-normal leading-[1.4] text-[var(--neutral-400)] hover:border-[var(--brand-primary)] hover:text-[var(--brand-primary)] flex items-center gap-1 transition-colors">
                      <Plus size={12} />
                      Add
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-auto border-t border-[var(--neutral-200)] p-6 bg-white">
              <button className="w-full h-10 mb-2 bg-gradient-to-r from-[var(--gradient-start)] to-[var(--gradient-end)] text-white text-[14px] font-medium rounded-lg hover:shadow-[var(--shadow-brand-hover)] transition-all">
                Save Changes
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full h-10 text-[var(--danger)] text-[14px] font-medium hover:bg-[var(--danger-bg)] rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 size={16} />
                Delete Task
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        open={showDeleteConfirm}
        onOpenChange={setShowDeleteConfirm}
        title="Delete Task"
        description="Are you sure you want to delete this task? This action cannot be undone."
        confirmLabel="Delete"
        variant="destructive"
        onConfirm={() => {
          db.deleteTask(task.id);
          sfToast.success('Task deleted', `"${task.title}" has been removed.`);
          onClose();
        }}
      />
    </>
  );
};

export default TaskDetailModal;
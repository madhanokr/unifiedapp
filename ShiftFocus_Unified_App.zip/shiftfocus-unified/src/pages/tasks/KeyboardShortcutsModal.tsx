import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Keyboard } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './design-system';

interface KeyboardShortcutsModalProps {
  onClose: () => void;
}

const shortcuts = [
  {
    category: 'General',
    items: [
      { keys: ['⌘', 'K'], description: 'Open search' },
      { keys: ['⌘', 'N'], description: 'Create new task' },
      { keys: ['⌘', '/'], description: 'Keyboard shortcuts' },
      { keys: ['ESC'], description: 'Close modal / drawer' },
      { keys: ['⌘', 'S'], description: 'Save current view' },
    ],
  },
  {
    category: 'Navigation',
    items: [
      { keys: ['⌘', '1'], description: 'Switch to List view' },
      { keys: ['⌘', '2'], description: 'Switch to Kanban view' },
      { keys: ['⌘', '3'], description: 'Switch to Timeline' },
      { keys: ['⌘', '4'], description: 'Switch to Calendar' },
      { keys: ['⌘', '5'], description: 'Switch to My Tasks' },
      { keys: ['⌘', '6'], description: 'Switch to AI Mode' },
    ],
  },
  {
    category: 'Task Actions',
    items: [
      { keys: ['Enter'], description: 'Open selected task' },
      { keys: ['E'], description: 'Edit task' },
      { keys: ['D'], description: 'Delete task' },
      { keys: ['C'], description: 'Mark as complete' },
      { keys: ['P'], description: 'Change priority' },
      { keys: ['A'], description: 'Assign to someone' },
    ],
  },
  {
    category: 'Filters & Views',
    items: [
      { keys: ['F'], description: 'Focus on filters' },
      { keys: ['⌘', 'F'], description: 'Advanced filters' },
      { keys: ['⌘', '⇧', 'F'], description: 'Clear all filters' },
      { keys: ['G'], description: 'Toggle grouping' },
      { keys: ['⌘', 'I'], description: 'Open AI Commander' },
    ],
  },
];

const KeyboardShortcutsModal: React.FC<KeyboardShortcutsModalProps> = ({ onClose }) => {
  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent size="lg" showClose={false}>
        {/* Header */}
        <div className="px-8 py-5 border-b border-[var(--neutral-200)] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[var(--gradient-start)] to-[var(--gradient-end)] rounded-lg flex items-center justify-center">
              <Keyboard className="text-white" size={20} />
            </div>
            <div>
              <h2 className="text-[18px] font-medium leading-[1.3] text-[var(--text-primary)]">
                Keyboard Shortcuts
              </h2>
              <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)]">
                Navigate ShiftFocus faster
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center hover:bg-[var(--neutral-100)] rounded-lg transition-colors duration-[120ms] text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="px-8 py-6 max-h-[520px] overflow-y-auto">
          <div className="grid grid-cols-2 gap-8">
            {shortcuts.map((section, i) => (
              <motion.div
                key={section.category}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.15, ease: [0.4, 0, 0.2, 1] }}
              >
                <h3 className="text-[12px] font-medium leading-[1.4] tracking-[0.03em] uppercase text-[var(--neutral-400)] mb-4">
                  {section.category}
                </h3>
                <div className="space-y-2">
                  {section.items.map((shortcut, j) => (
                    <div
                      key={j}
                      className="flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-[var(--neutral-50)] transition-colors"
                    >
                      <span className="text-[14px] font-normal leading-[1.5] text-[var(--neutral-800)]">
                        {shortcut.description}
                      </span>
                      <div className="flex items-center gap-1">
                        {shortcut.keys.map((key, k) => (
                          <React.Fragment key={k}>
                            <kbd className="h-[24px] min-w-[24px] px-2 bg-[var(--neutral-100)] border border-[var(--neutral-200)] rounded-md text-[12px] font-medium text-[var(--text-primary)] shadow-[var(--shadow-card)] flex items-center justify-center">
                              {key}
                            </kbd>
                            {k < shortcut.keys.length - 1 && (
                              <span className="text-[var(--neutral-400)] text-[10px] mx-0.5">+</span>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-4 bg-[var(--neutral-50)] border-t border-[var(--neutral-200)] flex items-center justify-center">
          <p className="text-[12px] font-normal leading-[1.4] text-[var(--text-secondary)] flex items-center gap-2">
            Press
            <kbd className="h-[20px] px-2 bg-[var(--bg-level-0)] border border-[var(--neutral-200)] rounded-md text-[10px] font-medium text-[var(--text-primary)] shadow-[var(--shadow-card)] flex items-center gap-1">
              ⌘ /
            </kbd>
            anytime to view shortcuts
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default KeyboardShortcutsModal;
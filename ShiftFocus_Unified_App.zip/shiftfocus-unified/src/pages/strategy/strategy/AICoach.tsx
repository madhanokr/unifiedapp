import React, { useState } from 'react';
import { Sparkles, X, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

export function AICoach() {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState('');

  const suggestions = [
    { icon: '🎯', text: 'What theme is weakest?', action: 'analyze-themes' },
    { icon: '📅', text: 'Generate my annual plan', action: 'generate-plan' },
    { icon: '🔧', text: 'Fix all misalignments', action: 'fix-alignment' },
    { icon: '✨', text: 'Rewrite themes automatically', action: 'rewrite-themes' },
    { icon: '⚠️', text: 'Highlight resource constraints', action: 'find-constraints' },
    { icon: '📊', text: 'What should Q2 focus on?', action: 'suggest-q2' },
  ];

  const handleAction = (action: string) => {
    toast.success('AI is working on it...', {
      description: `Action: ${action.replace(/-/g, ' ')}`,
    });
  };

  const handleAsk = () => {
    if (!question.trim()) return;
    toast.success('AI is analyzing...', { description: question });
    setQuestion('');
  };

  return (
    <div className="fixed" style={{ bottom: '24px', right: '24px', zIndex: 50 }}>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="absolute overflow-hidden"
            style={{
              bottom: '80px',
              right: '0',
              width: '320px',
              backgroundColor: 'var(--bg-level-0)',
              borderRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-modal)',
              border: '1px solid var(--neutral-200)',
            }}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          >
            {/* Header */}
            <div
              style={{
                padding: '16px',
                background: 'linear-gradient(to right, var(--gradient-start), var(--gradient-end))',
              }}
            >
              <div className="flex items-center justify-between" style={{ marginBottom: '4px' }}>
                <div className="flex items-center gap-2">
                  <div
                    className="flex items-center justify-center"
                    style={{
                      padding: '8px',
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      borderRadius: 'var(--radius-input)',
                    }}
                  >
                    <Sparkles style={{ width: '20px', height: '20px', color: 'var(--white)' }} />
                  </div>
                  <div>
                    <div className="text-body-medium" style={{ color: 'var(--white)' }}>Strategy AI Coach</div>
                    <div className="text-caption" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                      Ask me anything about your strategy
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  style={{
                    padding: '4px',
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    borderRadius: 'var(--radius-badge)',
                    transition: `background-color var(--duration-fast) var(--ease-apple)`,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  <X style={{ width: '16px', height: '16px', color: 'var(--white)' }} />
                </button>
              </div>
            </div>

            {/* Quick Actions */}
            <div style={{ padding: '16px' }}>
              <div className="text-caption" style={{ color: 'var(--neutral-600)', marginBottom: '12px' }}>Quick Actions</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {suggestions.map((suggestion) => (
                  <motion.button
                    key={suggestion.action}
                    className="w-full flex items-center justify-between text-caption"
                    style={{
                      padding: '12px 16px',
                      backgroundColor: 'var(--neutral-50)',
                      border: '1px solid var(--neutral-200)',
                      borderRadius: 'var(--radius-input)',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: `all var(--duration-standard) var(--ease-apple)`,
                    }}
                    onClick={() => handleAction(suggestion.action)}
                    whileHover={{ x: 4 }}
                    whileTap={{ scale: 0.98 }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--brand-primary-light)';
                      e.currentTarget.style.borderColor = 'var(--brand-primary)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                      e.currentTarget.style.borderColor = 'var(--neutral-200)';
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <span style={{ fontSize: '16px' }}>{suggestion.icon}</span>
                      <span style={{ color: 'var(--neutral-800)' }}>{suggestion.text}</span>
                    </div>
                    <ChevronRight style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Custom Question */}
            <div
              style={{
                padding: '16px',
                borderTop: '1px solid var(--neutral-200)',
                backgroundColor: 'var(--neutral-50)',
              }}
            >
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Or ask your own question..."
                className="w-full text-body"
                style={{
                  padding: '8px 16px',
                  backgroundColor: 'var(--bg-level-0)',
                  border: '1px solid var(--neutral-200)',
                  borderRadius: 'var(--radius-input)',
                  color: 'var(--neutral-800)',
                  transition: `all var(--duration-standard) var(--ease-apple)`,
                }}
                onFocus={(e) => {
                  e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
                  e.currentTarget.style.borderColor = 'var(--brand-primary)';
                }}
                onBlur={(e) => {
                  e.currentTarget.style.boxShadow = 'none';
                  e.currentTarget.style.borderColor = 'var(--neutral-200)';
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleAsk();
                }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Trigger */}
      <motion.button
        className="relative flex items-center gap-3 text-body-medium"
        style={{
          padding: '12px 20px',
          background: 'linear-gradient(to right, var(--gradient-start), var(--gradient-end))',
          color: 'var(--white)',
          borderRadius: '9999px',
          boxShadow: 'var(--shadow-brand-hover)',
          border: 'none',
          cursor: 'pointer',
          transition: `all var(--duration-standard) var(--ease-apple)`,
        }}
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Sparkles style={{ width: '20px', height: '20px' }} />
        <span>Ask Strategy AI</span>

        {!isOpen && (
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{ backgroundColor: 'var(--brand-primary)' }}
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        )}
      </motion.button>
    </div>
  );
}

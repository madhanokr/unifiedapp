import React, { useState, useEffect } from 'react';
import { TrendingUp, Target, Rocket, HelpCircle, Calendar, DollarSign, Users, Zap, Building2, MapPin } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Skeleton } from '../design-system/skeleton';

interface YearData {
  year: number;
  phase: string;
  focus: string;
  status: 'active' | 'planned' | 'future';
  themes: string[];
  keyBets: string[];
  targets: { arr: string; customers: string; nrr: string; teamSize: string };
  milestones: string[];
}

export function MultiYearMap() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const years: YearData[] = [
    {
      year: 2025, phase: 'Year 1', focus: 'Foundation & Product-Market Fit', status: 'active',
      themes: ['Revenue Excellence', 'Product Innovation', 'Customer Success'],
      keyBets: ['AI-powered platform launch', 'Enterprise market penetration', 'Platform ecosystem foundation'],
      targets: { arr: '$10M', customers: '500+', nrr: '120%', teamSize: '50' },
      milestones: ['Launch AI platform', 'First 100 enterprise customers', 'Series A funding'],
    },
    {
      year: 2026, phase: 'Year 2', focus: 'Scale & Market Leadership', status: 'planned',
      themes: ['Market Expansion', 'Operational Excellence', 'Brand Leadership'],
      keyBets: ['International expansion (EU, APAC)', 'Strategic partnerships', 'Developer ecosystem'],
      targets: { arr: '$50M', customers: '2,000+', nrr: '130%', teamSize: '150' },
      milestones: ['Open London office', 'Launch partner marketplace', 'Series B funding'],
    },
    {
      year: 2027, phase: 'Year 3', focus: 'Category Dominance', status: 'future',
      themes: ['Innovation Leadership', 'Strategic M&A', 'Ecosystem Growth'],
      keyBets: ['AI research lab establishment', 'Strategic acquisitions', 'Platform marketplace dominance'],
      targets: { arr: '$150M+', customers: '5,000+', nrr: '140%', teamSize: '300' },
      milestones: ['Market category leader', 'First acquisition', 'Profitability milestone'],
    },
  ];

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'active': return { color: 'var(--brand-primary)', label: 'CURRENT', icon: TrendingUp, badgeBg: 'var(--brand-primary)', badgeColor: 'var(--white)' };
      case 'planned': return { color: 'var(--success)', label: 'PLANNED', icon: Target, badgeBg: 'var(--success-light)', badgeColor: 'var(--success-text)' };
      default: return { color: 'var(--neutral-400)', label: 'FUTURE', icon: Rocket, badgeBg: 'var(--neutral-100)', badgeColor: 'var(--neutral-600)' };
    }
  };

  const metricIcons = [
    { key: 'arr', icon: DollarSign, label: 'ARR', color: 'var(--success)' },
    { key: 'customers', icon: Users, label: 'Customers', color: 'var(--brand-primary)' },
    { key: 'nrr', icon: TrendingUp, label: 'NRR', color: 'var(--warning)' },
    { key: 'teamSize', icon: Building2, label: 'Team', color: 'var(--neutral-600)' },
  ];

  if (isLoading) {
    return (
      <section style={{ marginTop: '32px' }}>
        <Skeleton variant="text" width="240px" height="24px" style={{ marginBottom: '8px' }} />
        <Skeleton variant="text" width="320px" height="14px" style={{ marginBottom: '32px' }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} variant="rect" height="240px" />
          ))}
        </div>
      </section>
    );
  }

  return (
    <TooltipProvider>
      <section style={{ marginTop: '32px' }}>
        <div style={{ marginBottom: '32px' }}>
          <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>3-Year Strategic Map</span>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
              </TooltipTrigger>
              <TooltipContent style={{ maxWidth: '400px' }}>
                <p className="text-caption-medium" style={{ marginBottom: '4px' }}>3-Year Strategic Map</p>
                <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                  Your north star for the next 3 years. Where you{"'"}re going, what you{"'"}ll build, and the milestones that matter.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
            Your company{"'"}s long-term vision and strategic trajectory
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          <div
            className="absolute top-12 bottom-12"
            style={{ left: '23px', width: '2px', background: `linear-gradient(to bottom, var(--brand-primary), var(--success), var(--neutral-400))` }}
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
            {years.map((yearData) => {
              const config = getStatusConfig(yearData.status);
              const StatusIcon = config.icon;

              return (
                <div key={yearData.year} className="relative">
                  {/* Timeline dot */}
                  <div
                    className="absolute left-0 top-6 flex items-center justify-center"
                    style={{
                      width: '48px',
                      height: '48px',
                      borderRadius: '50%',
                      backgroundColor: config.color,
                      zIndex: 10,
                    }}
                  >
                    <StatusIcon style={{ width: '24px', height: '24px', color: 'var(--white)' }} />
                  </div>

                  {/* Card */}
                  <div
                    className="overflow-hidden"
                    style={{
                      marginLeft: '80px',
                      backgroundColor: 'var(--bg-level-0)',
                      border: '1px solid var(--neutral-200)',
                      borderRadius: 'var(--radius-card)',
                      transition: `box-shadow var(--duration-standard) var(--ease-apple)`,
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
                  >
                    {/* Card Header */}
                    <div
                      className="flex items-start justify-between"
                      style={{ padding: '24px', borderBottom: '1px solid var(--neutral-200)' }}
                    >
                      <div>
                        <div className="flex items-center gap-3" style={{ marginBottom: '8px' }}>
                          <Calendar style={{ width: '16px', height: '16px', color: 'var(--neutral-600)' }} />
                          <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>{yearData.year}</span>
                          <span className="text-caption-medium" style={{ color: 'var(--neutral-400)' }}>
                            {yearData.phase.toUpperCase()}
                          </span>
                          <div
                            className="flex items-center gap-1.5 text-caption-medium"
                            style={{
                              padding: '4px 12px',
                              backgroundColor: config.badgeBg,
                              color: config.badgeColor,
                              borderRadius: 'var(--radius-badge)',
                            }}
                          >
                            {yearData.status === 'active' && (
                              <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: 'currentColor' }} />
                            )}
                            {config.label}
                          </div>
                        </div>
                        <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>{yearData.focus}</span>
                      </div>
                    </div>

                    {/* Card Content */}
                    <div style={{ padding: '24px' }}>
                      <div className="grid grid-cols-2 gap-6">
                        {/* Left */}
                        <div>
                          {/* Themes */}
                          <div style={{ marginBottom: '24px' }}>
                            <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                              <span className="text-micro" style={{ color: 'var(--neutral-600)' }}>Strategic Themes</span>
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Strategic Themes</p>
                                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>The big focus areas for this year.</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                              {yearData.themes.map((theme) => (
                                <div
                                  key={theme}
                                  className="flex items-center gap-2"
                                  style={{
                                    padding: '8px 12px',
                                    backgroundColor: 'var(--neutral-50)',
                                    border: '1px solid var(--neutral-200)',
                                    borderRadius: 'var(--radius-input)',
                                  }}
                                >
                                  <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: config.color }} />
                                  <span className="text-body" style={{ color: 'var(--neutral-800)' }}>{theme}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Bets */}
                          <div>
                            <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                              <span className="text-micro" style={{ color: 'var(--neutral-600)' }}>Key Strategic Bets</span>
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Key Strategic Bets</p>
                                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>Big investments that will define success.</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                              {yearData.keyBets.map((bet) => (
                                <div
                                  key={bet}
                                  className="flex items-start gap-2"
                                  style={{
                                    padding: '8px 12px',
                                    backgroundColor: 'var(--bg-level-0)',
                                    border: '1px solid var(--neutral-200)',
                                    borderRadius: 'var(--radius-input)',
                                  }}
                                >
                                  <Zap style={{ width: '16px', height: '16px', marginTop: '2px', color: config.color, flexShrink: 0 }} />
                                  <span className="text-body" style={{ color: 'var(--neutral-800)' }}>{bet}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Right */}
                        <div>
                          {/* Metrics */}
                          <div style={{ marginBottom: '24px' }}>
                            <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                              <span className="text-micro" style={{ color: 'var(--neutral-600)' }}>Target Metrics</span>
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Target Metrics</p>
                                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>Key numbers you{"'"}re aiming to hit by year-end.</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              {metricIcons.map((m) => {
                                const MetricIcon = m.icon;
                                const val = yearData.targets[m.key as keyof typeof yearData.targets];
                                return (
                                  <div
                                    key={m.key}
                                    style={{
                                      padding: '16px',
                                      backgroundColor: 'var(--neutral-50)',
                                      border: '1px solid var(--neutral-200)',
                                      borderRadius: 'var(--radius-input)',
                                    }}
                                  >
                                    <div className="flex items-center gap-1" style={{ marginBottom: '8px' }}>
                                      <MetricIcon style={{ width: '16px', height: '16px', color: m.color }} />
                                      <span className="text-micro" style={{ color: 'var(--neutral-400)' }}>{m.label}</span>
                                    </div>
                                    <div style={{ fontSize: '20px', fontWeight: 600, color: 'var(--neutral-800)' }}>{val}</div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Milestones */}
                          <div>
                            <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                              <span className="text-micro" style={{ color: 'var(--neutral-600)' }}>Key Milestones</span>
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Key Milestones</p>
                                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>Major achievements to celebrate this year.</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                              {yearData.milestones.map((milestone, midx) => (
                                <div
                                  key={milestone}
                                  className="flex items-center gap-3"
                                  style={{
                                    padding: '8px 12px',
                                    backgroundColor: 'var(--bg-level-0)',
                                    border: '1px solid var(--neutral-200)',
                                    borderRadius: 'var(--radius-input)',
                                  }}
                                >
                                  <div
                                    className="flex items-center justify-center"
                                    style={{
                                      width: '24px',
                                      height: '24px',
                                      borderRadius: '50%',
                                      backgroundColor: 'var(--neutral-50)',
                                      border: '1px solid var(--neutral-200)',
                                    }}
                                  >
                                    <span className="text-caption-medium" style={{ color: 'var(--neutral-600)' }}>{midx + 1}</span>
                                  </div>
                                  <span className="text-body" style={{ color: 'var(--neutral-800)' }}>{milestone}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom */}
        <div
          className="flex items-start gap-4"
          style={{
            marginTop: '32px',
            padding: '24px',
            backgroundColor: 'var(--bg-level-0)',
            border: '1px solid var(--neutral-200)',
            borderRadius: 'var(--radius-card)',
          }}
        >
          <div
            className="flex items-center justify-center"
            style={{
              width: '40px',
              height: '40px',
              borderRadius: 'var(--radius-input)',
              backgroundColor: 'var(--brand-primary-light)',
              flexShrink: 0,
            }}
          >
            <MapPin style={{ width: '20px', height: '20px', color: 'var(--brand-primary)' }} />
          </div>
          <div>
            <div className="text-h4" style={{ color: 'var(--neutral-800)', marginBottom: '4px' }}>Strategic Navigation</div>
            <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
              This 3-year map guides your quarterly and annual planning. Each year builds on the previous, creating a clear path to category leadership.
            </p>
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}

import React, { useState, useEffect } from 'react';
import { AlertTriangle, Users, Package, TrendingDown, HelpCircle, Zap, Eye } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { Badge } from '../design-system/badge';
import { CardSkeleton } from '../design-system/skeleton';
import { EmptyState } from '../design-system/empty-state';
import { toast } from 'sonner';

export function CoherenceEngine() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const issues = [
    {
      type: 'Contradiction',
      title: 'Product team building features that conflict with enterprise sales strategy',
      severity: 'high' as const,
      impact: 'Revenue Excellence theme at risk',
      owner: 'Unassigned',
      icon: AlertTriangle,
      accentColor: 'var(--danger)',
      bgColor: 'var(--danger-light)',
      description: 'Self-serve features being prioritized over enterprise admin controls',
      whyMatters: 'This conflict can lead to misaligned sales efforts and reduced revenue.',
    },
    {
      type: 'Misalignment',
      title: 'Marketing campaign not connected to any Q2 outcome',
      severity: 'medium' as const,
      impact: '15% of marketing budget orphaned',
      owner: 'Marketing',
      icon: TrendingDown,
      accentColor: 'var(--warning)',
      bgColor: 'var(--warning-light)',
      description: 'Brand awareness initiative has no strategic parent',
      whyMatters: 'This misalignment can result in wasted marketing resources.',
    },
    {
      type: 'Capacity Clash',
      title: 'Engineering team overcommitted across 3 themes',
      severity: 'high' as const,
      impact: 'All Q2 deliverables at risk',
      owner: 'Engineering',
      icon: Users,
      accentColor: 'var(--brand-primary)',
      bgColor: 'var(--brand-primary-light)',
      description: '140% capacity allocation detected',
      whyMatters: 'Overcommitting can lead to delays and compromised quality.',
    },
    {
      type: 'Orphaned Item',
      title: 'Customer webinar series has no parent theme or outcome',
      severity: 'low' as const,
      impact: 'Low strategic value detected',
      owner: 'Customer Success',
      icon: Package,
      accentColor: 'var(--info)',
      bgColor: 'var(--info-light)',
      description: 'Initiative exists without strategic justification',
      whyMatters: 'Orphaned items can divert attention from key strategic goals.',
    },
  ];

  const getSeverityVariant = (severity: string): 'danger' | 'warning' | 'info' => {
    if (severity === 'high') return 'danger';
    if (severity === 'medium') return 'warning';
    return 'info';
  };

  const getSeverityLabel = (severity: string) => {
    if (severity === 'high') return 'High Severity';
    if (severity === 'medium') return 'Medium Severity';
    return 'Low Severity';
  };

  const getTypeTooltip = (type: string) => {
    switch (type) {
      case 'Contradiction': return 'Work that fights against your goals.';
      case 'Misalignment': return "Work that isn't connected to any priority.";
      case 'Orphaned Item': return 'Goals or tasks with no parent theme.';
      case 'Capacity Clash': return "Two goals fighting for the same team's time.";
      default: return 'Strategic coherence issue detected.';
    }
  };

  const handleAutoFix = (issueType: string) => {
    toast.success(`Auto-fix initiated for ${issueType}`, {
      description: 'AI is analyzing and suggesting alignment changes.',
    });
  };

  const statCards = [
    { label: 'Critical contradictions', value: 2, color: 'var(--danger)', bg: 'var(--danger-light)', icon: AlertTriangle },
    { label: 'Misaligned items', value: 5, color: 'var(--warning)', bg: 'var(--warning-light)', icon: TrendingDown },
    { label: 'Orphaned items', value: 8, color: 'var(--info)', bg: 'var(--info-light)', icon: Package },
    { label: 'Capacity conflicts', value: 3, color: 'var(--brand-primary)', bg: 'var(--brand-primary-light)', icon: Users },
  ];

  return (
    <TooltipProvider>
      <section style={{ marginTop: '48px' }}>
        <div style={{ marginBottom: '32px' }}>
          <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>Coherence Engine</span>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
              </TooltipTrigger>
              <TooltipContent style={{ maxWidth: '400px' }}>
                <p className="text-caption-medium" style={{ marginBottom: '4px' }}>What Is Coherence?</p>
                <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                  How well your goals, tasks, and themes fit together. Your strategy{"'"}s immune system.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
            AI-powered detection of contradictions and misalignments
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4" style={{ marginBottom: '32px' }}>
          {statCards.map((stat) => {
            const StatIcon = stat.icon;
            return (
              <div
                key={stat.label}
                style={{
                  backgroundColor: stat.bg,
                  border: `1px solid ${stat.color}`,
                  borderRadius: 'var(--radius-card)',
                  padding: '20px',
                }}
              >
                <div style={{ marginBottom: '12px' }}>
                  <StatIcon style={{ width: '24px', height: '24px', color: stat.color }} />
                </div>
                <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: stat.color, marginBottom: '8px' }}>
                  {stat.value}
                </div>
                <div className="text-caption-medium" style={{ color: stat.color }}>{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* Issues */}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-8">
            <CardSkeleton />
            <CardSkeleton />
          </div>
        ) : issues.length === 0 ? (
          <EmptyState
            icon={<AlertTriangle style={{ width: '24px', height: '24px', color: 'var(--neutral-400)' }} />}
            title="No coherence issues"
            description="Your strategy is well-aligned. Keep it up!"
          />
        ) : (
          <div className="grid grid-cols-2 gap-8">
            {issues.map((issue, idx) => {
              const Icon = issue.icon;

              return (
                <div
                  key={idx}
                  className="flex overflow-hidden"
                  style={{
                    backgroundColor: 'var(--bg-level-0)',
                    border: '1px solid var(--neutral-200)',
                    borderRadius: 'var(--radius-card)',
                    transition: `all var(--duration-standard) var(--ease-apple)`,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--brand-primary)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--neutral-200)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  {/* Accent bar */}
                  <div className="flex-shrink-0" style={{ width: '4px', backgroundColor: issue.accentColor }} />

                  <div className="flex-1">
                    {/* Header */}
                    <div style={{ padding: '24px', borderBottom: '1px solid var(--neutral-200)', backgroundColor: 'var(--neutral-50)' }}>
                      <div className="flex items-center justify-between" style={{ marginBottom: '12px' }}>
                        <div className="flex items-center gap-3">
                          <div
                            style={{
                              padding: '12px',
                              backgroundColor: issue.bgColor,
                              borderRadius: 'var(--radius-card)',
                            }}
                          >
                            <Icon style={{ width: '24px', height: '24px', color: 'var(--neutral-800)' }} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-h4" style={{ color: 'var(--neutral-800)' }}>{issue.type}</span>
                              <Tooltip>
                                <TooltipTrigger>
                                  <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>{issue.type}</p>
                                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>{getTypeTooltip(issue.type)}</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                            <p className="text-caption" style={{ color: 'var(--neutral-400)', marginTop: '4px' }}>
                              Detected by AI - 2h ago
                            </p>
                          </div>
                        </div>
                        <Badge variant={getSeverityVariant(issue.severity)} size="md">
                          {getSeverityLabel(issue.severity)}
                        </Badge>
                      </div>

                      {/* Sparkline */}
                      <div className="flex items-center gap-2">
                        <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>Trend (7 days):</span>
                        <div className="flex items-end gap-0.5" style={{ height: '24px' }}>
                          {[40, 55, 45, 60, 70, 65, 80].map((height, i) => (
                            <div
                              key={i}
                              className="rounded-t"
                              style={{
                                width: '6px',
                                height: `${height}%`,
                                backgroundColor: issue.accentColor,
                              }}
                            />
                          ))}
                        </div>
                        <span className="text-caption-medium" style={{ color: 'var(--danger)' }}>Worsening</span>
                      </div>
                    </div>

                    <div style={{ padding: '24px' }}>
                      <div className="text-h4" style={{ color: 'var(--neutral-800)', marginBottom: '12px' }}>{issue.title}</div>
                      <p className="text-body" style={{ color: 'var(--neutral-600)', marginBottom: '16px' }}>{issue.description}</p>

                      {/* Why this matters */}
                      <div
                        style={{
                          padding: '16px',
                          backgroundColor: 'var(--info-light)',
                          border: '1px solid var(--info)',
                          borderRadius: 'var(--radius-card)',
                          marginBottom: '24px',
                        }}
                      >
                        <div className="flex items-start gap-2">
                          <AlertTriangle style={{ width: '16px', height: '16px', color: 'var(--info)', marginTop: '2px', flexShrink: 0 }} />
                          <div>
                            <p className="text-caption-medium" style={{ color: 'var(--info)', marginBottom: '4px' }}>Why this matters</p>
                            <p className="text-caption" style={{ color: 'var(--info)' }}>{issue.whyMatters}</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-6" style={{ paddingBottom: '24px', borderBottom: '1px solid var(--neutral-200)', marginBottom: '24px' }}>
                        <div className="flex items-start gap-3">
                          <div style={{ padding: '8px', backgroundColor: 'var(--brand-primary-light)', borderRadius: 'var(--radius-input)' }}>
                            <Zap style={{ width: '20px', height: '20px', color: 'var(--brand-primary)' }} />
                          </div>
                          <div>
                            <div className="text-caption" style={{ color: 'var(--neutral-400)', fontWeight: 500, marginBottom: '4px' }}>Impact</div>
                            <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{issue.impact}</div>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <div style={{ padding: '8px', backgroundColor: 'var(--neutral-100)', borderRadius: 'var(--radius-input)' }}>
                            <Users style={{ width: '20px', height: '20px', color: 'var(--neutral-600)' }} />
                          </div>
                          <div>
                            <div className="text-caption" style={{ color: 'var(--neutral-400)', fontWeight: 500, marginBottom: '4px' }}>Owner</div>
                            <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{issue.owner}</div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <Button variant="primary" size="md" onClick={() => handleAutoFix(issue.type)}>
                          <Zap style={{ width: '16px', height: '16px' }} />
                          Auto-Fix
                        </Button>
                        <Button variant="secondary" size="md">
                          <Eye style={{ width: '16px', height: '16px' }} />
                          Details
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </TooltipProvider>
  );
}

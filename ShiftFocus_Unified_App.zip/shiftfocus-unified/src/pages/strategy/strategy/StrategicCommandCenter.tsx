import React, { useState, useEffect } from 'react';
import { TrendingUp, HelpCircle, Brain } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { ProgressBar } from '../design-system/progress-bar';
import { MetricSkeleton } from '../design-system/skeleton';
import { Skeleton } from '../design-system/skeleton';

export function StrategicCommandCenter() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <section
        style={{
          backgroundColor: 'var(--bg-level-0)',
          borderRadius: 'var(--radius-card)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-card)',
          padding: '32px',
        }}
      >
        <Skeleton variant="text" width="200px" height="24px" style={{ marginBottom: '8px' }} />
        <Skeleton variant="text" width="160px" height="14px" style={{ marginBottom: '32px' }} />
        <Skeleton variant="rect" height="120px" style={{ marginBottom: '32px' }} />
        <div className="grid grid-cols-3 gap-6">
          <MetricSkeleton />
          <MetricSkeleton />
          <MetricSkeleton />
        </div>
      </section>
    );
  }

  return (
    <TooltipProvider>
      <section
        style={{
          backgroundColor: 'var(--bg-level-0)',
          borderRadius: 'var(--radius-card)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-card)',
          overflow: 'hidden',
        }}
      >
        <div style={{ padding: '32px' }}>
          <div className="flex items-start justify-between" style={{ marginBottom: '32px' }}>
            <div>
              <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
                <span className="text-h1" style={{ color: 'var(--neutral-800)' }}>Strategic Health</span>
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle
                      className="cursor-help"
                      style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }}
                    />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Strategic Health</p>
                    <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                      Real-time view of your company{"'"}s strategic execution. Like a health checkup for your strategy.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-body" style={{ color: 'var(--neutral-600)' }}>Last updated 5 minutes ago</p>
              <p className="text-caption" style={{ color: 'var(--neutral-400)', marginTop: '4px' }}>
                AI monitoring 145 signals this week
              </p>
            </div>
            <Button variant="primary" size="md">
              <Brain style={{ width: '20px', height: '20px' }} />
              AI Review
            </Button>
          </div>

          {/* Primary Score */}
          <div
            className="relative overflow-hidden"
            style={{
              padding: '32px',
              backgroundColor: 'var(--success-light)',
              borderRadius: 'var(--radius-card)',
              border: '1px solid var(--success)',
              marginBottom: '32px',
            }}
          >
            <div className="flex items-end gap-6" style={{ marginBottom: '12px' }}>
              <div className="text-display" style={{ color: 'var(--success-text)' }}>87%</div>
              <div style={{ paddingBottom: '12px' }}>
                <div
                  className="flex items-center gap-2"
                  style={{
                    padding: '6px 12px',
                    backgroundColor: 'var(--success)',
                    borderRadius: '9999px',
                    height: '28px',
                  }}
                >
                  <div
                    style={{
                      width: '6px',
                      height: '6px',
                      borderRadius: '50%',
                      backgroundColor: 'var(--white)',
                    }}
                  />
                  <span className="text-caption-medium" style={{ color: 'var(--white)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Healthy
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-body-medium" style={{ color: 'var(--success-text)' }}>
                Overall confidence in hitting Q1 2025 targets
              </p>
              <Tooltip>
                <TooltipTrigger>
                  <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--success)' }} />
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Confidence Score</p>
                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                    How likely you are to hit your goals. 87% = sunny with a chance of success!
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>

          {/* Secondary Metrics */}
          <div className="grid grid-cols-3 gap-6">
            {/* Alignment */}
            <div
              style={{
                padding: '24px',
                backgroundColor: 'var(--info-light)',
                border: '1px solid var(--info)',
                borderRadius: 'var(--radius-card)',
              }}
            >
              <div className="flex items-center justify-between" style={{ marginBottom: '16px' }}>
                <span className="text-body-medium" style={{ color: 'var(--info)', fontWeight: 600 }}>Alignment</span>
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--info)' }} />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Alignment</p>
                    <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                      Teams working toward shared goals. When everyone rows together, you go fast!
                    </p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: 'var(--info)', marginBottom: '16px' }}>89%</div>
              <ProgressBar value={89} variant="auto" size="md" trackColor="var(--info-light)" style={{ marginBottom: '12px' }} />
              <p className="text-caption-medium" style={{ color: 'var(--info)' }}>3 gaps to resolve</p>
            </div>

            {/* Momentum */}
            <div
              style={{
                padding: '24px',
                backgroundColor: 'var(--brand-primary-light)',
                border: '1px solid var(--brand-primary)',
                borderRadius: 'var(--radius-card)',
              }}
            >
              <div className="flex items-center justify-between" style={{ marginBottom: '16px' }}>
                <span className="text-body-medium" style={{ color: 'var(--brand-primary)', fontWeight: 600 }}>Momentum</span>
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--brand-primary)' }} />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Momentum</p>
                    <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                      Speed toward goals. Are you speeding up or slowing down?
                    </p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: 'var(--brand-primary)', marginBottom: '16px' }}>Strong</div>
              <div className="flex items-center gap-2">
                <TrendingUp style={{ width: '16px', height: '16px', color: 'var(--brand-primary)' }} />
                <p className="text-caption-medium" style={{ color: 'var(--brand-primary)' }}>+12% this week</p>
              </div>
            </div>

            {/* Themes */}
            <div
              style={{
                padding: '24px',
                backgroundColor: 'var(--warning-light)',
                border: '1px solid var(--warning)',
                borderRadius: 'var(--radius-card)',
              }}
            >
              <div className="flex items-center justify-between" style={{ marginBottom: '16px' }}>
                <span className="text-body-medium" style={{ color: 'var(--warning)', fontWeight: 600 }}>Themes</span>
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--warning)' }} />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Theme Health</p>
                    <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                      How well your big 3-6 year bets are performing.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: 'var(--warning)', marginBottom: '16px' }}>78%</div>
              <ProgressBar value={78} variant="warning" size="md" trackColor="var(--warning-light)" style={{ marginBottom: '12px' }} />
              <p className="text-caption-medium" style={{ color: 'var(--warning)' }}>3 ahead of target</p>
            </div>
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}

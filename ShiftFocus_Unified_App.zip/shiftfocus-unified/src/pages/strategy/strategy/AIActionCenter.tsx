import React, { useState, useEffect } from 'react';
import { AlertTriangle, TrendingUp, Target, Sparkles, Zap, HelpCircle, Send, BarChart3 } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { Badge } from '../design-system/badge';
import { CardSkeleton } from '../design-system/skeleton';
import { Skeleton } from '../design-system/skeleton';
import { toast } from 'sonner';

export function AIActionCenter() {
  const [aiQuestion, setAiQuestion] = useState('');
  const [showSimulation, setShowSimulation] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const risks = [
    { title: 'Revenue Excellence theme likely to miss Q2 targets', severity: 'Critical', impact: '$400K ARR at risk' },
    { title: 'Product roadmap diverging from enterprise needs', severity: 'High', impact: 'Enterprise adoption stalled' },
  ];

  const opportunities = [
    { title: '12 enterprise accounts ready for upsell', impact: '+$300K ARR', confidence: 91 },
    { title: 'Consolidate features for 40% velocity gain', impact: '+40% velocity', confidence: 79 },
    { title: 'Onboarding optimization for 11% conversion lift', impact: '+11% conversion', confidence: 88 },
  ];

  const misalignments = [
    { title: 'Marketing campaign not linked to Q2 outcome', impact: '15% budget orphaned' },
    { title: 'Customer webinar series has no parent theme', impact: 'Low strategic value' },
  ];

  const aiPlays = [
    {
      play: 'Reallocate 2 AEs from mid-market to enterprise segment',
      impact: '+$280K ARR', confidence: 87, timeline: '2 weeks',
      why: 'Enterprise pipeline velocity down 23%. Mid-market performing above target.',
      decisionStatus: 'pending' as const,
      owner: { name: 'Sarah Chen', initials: 'SC' },
      reviewDate: '2025-01-15',
    },
    {
      play: 'Reduce onboarding steps from 9 to 5 to unlock conversion gain',
      impact: '+11% conversion', confidence: 92, timeline: '3 weeks',
      why: 'Data shows 64% drop-off at step 4. Competitors have 5-step flows with 2x conversion.',
      decisionStatus: 'accepted' as const,
      owner: { name: 'Marcus Lee', initials: 'ML' },
      reviewDate: '2025-01-10',
    },
  ];

  const getDecisionBadgeVariant = (status: string): 'success' | 'warning' | 'danger' => {
    if (status === 'accepted') return 'success';
    if (status === 'rejected') return 'danger';
    return 'warning';
  };

  const getDecisionLabel = (status: string) => {
    if (status === 'accepted') return 'Accepted';
    if (status === 'rejected') return 'Rejected';
    return 'Pending Review';
  };

  const handleExecutePlay = (playName: string) => {
    toast.success(`Play executed: ${playName}`, { description: 'Action has been queued for implementation.' });
  };

  const handleAskAI = () => {
    if (!aiQuestion.trim()) return;
    toast.success('AI is analyzing your question...', { description: aiQuestion });
    setAiQuestion('');
  };

  if (isLoading) {
    return (
      <section style={{ marginTop: '32px' }}>
        <Skeleton variant="text" width="200px" height="24px" style={{ marginBottom: '8px' }} />
        <Skeleton variant="text" width="280px" height="14px" style={{ marginBottom: '32px' }} />
        <Skeleton variant="rect" height="80px" style={{ marginBottom: '24px' }} />
        <div className="grid grid-cols-2 gap-6">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
      </section>
    );
  }

  return (
    <TooltipProvider>
      <section style={{ marginTop: '32px' }}>
        {/* Header */}
        <div style={{ marginBottom: '32px' }}>
          <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>AI Action Center</span>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
              </TooltipTrigger>
              <TooltipContent style={{ maxWidth: '400px' }}>
                <p className="text-caption-medium" style={{ marginBottom: '4px' }}>AI Action Center</p>
                <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>AI-powered strategic intelligence and recommendations.</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>High-impact moves to make right now</p>
        </div>

        {/* AI Executive Summary */}
        <div
          style={{
            borderRadius: 'var(--radius-card)',
            padding: '24px',
            background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
            marginBottom: '24px',
          }}
        >
          <div className="flex items-start gap-3">
            <Sparkles style={{ width: '20px', height: '20px', color: 'var(--white)', flexShrink: 0, marginTop: '2px' }} />
            <div>
              <p className="text-body" style={{ color: 'var(--white)', marginBottom: '8px' }}>
                AI identified <strong>12 risks</strong>, <strong>9 opportunities</strong>, and <strong>3 strategic drifts</strong> this week.
              </p>
              <div className="flex items-center gap-2">
                <span className="text-body" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>Momentum trend:</span>
                <div className="flex items-center gap-1.5" style={{ padding: '4px 8px', backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 'var(--radius-badge)' }}>
                  <TrendingUp style={{ width: '12px', height: '12px', color: 'var(--success)' }} />
                  <span className="text-body" style={{ color: 'var(--white)' }}>+12%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Box Grid */}
        <div className="grid grid-cols-2 gap-6" style={{ marginBottom: '24px' }}>
          {/* Risks */}
          <div style={{ backgroundColor: 'var(--bg-level-0)', padding: '24px', border: '1px solid var(--neutral-200)', borderRadius: 'var(--radius-card)' }}>
            <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
              <div className="flex items-center justify-center" style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-input)', backgroundColor: 'var(--danger-light)' }}>
                <AlertTriangle style={{ width: '16px', height: '16px', color: 'var(--danger)' }} />
              </div>
              <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>Top Risks</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {risks.map((risk, idx) => (
                <div key={idx} style={{ padding: '12px', backgroundColor: 'var(--danger-light)', border: '1px solid var(--danger)', borderRadius: 'var(--radius-input)' }}>
                  <p className="text-body" style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>{risk.title}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-caption" style={{ color: 'var(--danger-text)' }}>{risk.impact}</span>
                    <Badge variant={risk.severity === 'Critical' ? 'danger' : 'warning'} size="sm">{risk.severity}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Opportunities */}
          <div style={{ backgroundColor: 'var(--bg-level-0)', padding: '24px', border: '1px solid var(--neutral-200)', borderRadius: 'var(--radius-card)' }}>
            <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
              <div className="flex items-center justify-center" style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-input)', backgroundColor: 'var(--success-light)' }}>
                <TrendingUp style={{ width: '16px', height: '16px', color: 'var(--success)' }} />
              </div>
              <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>Opportunities</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {opportunities.map((opp, idx) => (
                <div key={idx} style={{ padding: '12px', backgroundColor: 'var(--success-light)', border: '1px solid var(--success)', borderRadius: 'var(--radius-input)' }}>
                  <p className="text-body" style={{ color: 'var(--neutral-800)', marginBottom: '4px' }}>{opp.title}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-caption" style={{ color: 'var(--success-text)' }}>{opp.impact}</span>
                    <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>{opp.confidence}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Misalignments */}
          <div style={{ backgroundColor: 'var(--bg-level-0)', padding: '24px', border: '1px solid var(--neutral-200)', borderRadius: 'var(--radius-card)' }}>
            <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
              <div className="flex items-center justify-center" style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-input)', backgroundColor: 'var(--warning-light)' }}>
                <Target style={{ width: '16px', height: '16px', color: 'var(--warning)' }} />
              </div>
              <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>Misalignments</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {misalignments.map((item, idx) => (
                <div key={idx} style={{ padding: '12px', backgroundColor: 'var(--warning-light)', border: '1px solid var(--warning)', borderRadius: 'var(--radius-input)' }}>
                  <p className="text-body" style={{ color: 'var(--neutral-800)', marginBottom: '4px' }}>{item.title}</p>
                  <p className="text-caption" style={{ color: 'var(--warning)' }}>{item.impact}</p>
                </div>
              ))}
            </div>
          </div>

          {/* AI Moves */}
          <div style={{ backgroundColor: 'var(--bg-level-0)', padding: '24px', border: '1px solid var(--neutral-200)', borderRadius: 'var(--radius-card)' }}>
            <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
              <div className="flex items-center justify-center" style={{ width: '32px', height: '32px', borderRadius: 'var(--radius-input)', backgroundColor: 'var(--neutral-100)' }}>
                <Zap style={{ width: '16px', height: '16px', color: 'var(--neutral-800)' }} />
              </div>
              <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>AI Moves</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {['Reallocate AEs to enterprise', 'Consolidate initiatives 8 to 4', 'Optimize onboarding flow'].map((move, idx) => (
                <div key={idx} style={{ padding: '8px 12px', backgroundColor: 'var(--neutral-50)', borderRadius: 'var(--radius-input)' }}>
                  <p className="text-body" style={{ color: 'var(--neutral-800)', marginBottom: '2px' }}>{move}</p>
                  <p className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                    {idx === 0 ? 'High leverage, 2 weeks' : idx === 1 ? '+40% velocity gain' : '+11% conversion lift'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Playbooks */}
        <div style={{ marginBottom: '40px' }}>
          <span className="text-h2" style={{ color: 'var(--neutral-800)', display: 'block', marginBottom: '24px' }}>AI Strategic Playbooks</span>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {aiPlays.map((playbook, idx) => (
              <div
                key={idx}
                className="relative overflow-hidden"
                style={{
                  backgroundColor: 'var(--bg-level-0)',
                  borderRadius: 'var(--radius-card)',
                  padding: '32px',
                  border: '1px solid var(--brand-primary)',
                  boxShadow: 'var(--shadow-brand)',
                  transition: `box-shadow var(--duration-standard) var(--ease-apple)`,
                }}
                onMouseEnter={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-brand-hover)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-brand)'; }}
              >
                {/* AI accent bar */}
                <div className="absolute left-0 top-0 bottom-0" style={{ width: '6px', background: 'linear-gradient(to bottom, var(--gradient-start), var(--gradient-end))' }} />

                <div style={{ paddingLeft: '16px' }}>
                  {/* AI badge */}
                  <div
                    className="inline-flex items-center gap-2 text-caption-medium"
                    style={{
                      padding: '4px 12px',
                      backgroundColor: 'var(--brand-primary-light)',
                      border: '1px solid var(--brand-primary)',
                      borderRadius: '9999px',
                      color: 'var(--brand-primary)',
                      marginBottom: '16px',
                    }}
                  >
                    <Sparkles style={{ width: '14px', height: '14px' }} />
                    AI Proposed Move
                  </div>

                  <div className="flex items-start gap-6">
                    <div
                      className="flex items-center justify-center flex-shrink-0"
                      style={{
                        width: '56px',
                        height: '56px',
                        borderRadius: 'var(--radius-card)',
                        background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
                        boxShadow: 'var(--shadow-card-hover)',
                      }}
                    >
                      <Sparkles style={{ width: '28px', height: '28px', color: 'var(--white)' }} />
                    </div>
                    <div className="flex-1">
                      <div className="text-h3" style={{ color: 'var(--neutral-800)', marginBottom: '16px', fontWeight: 600 }}>
                        AI Play #{idx + 1}: {playbook.play}
                      </div>

                      <div className="grid grid-cols-4 gap-6" style={{ marginBottom: '24px' }}>
                        <div style={{ padding: '16px', backgroundColor: 'var(--success-light)', border: '1px solid var(--success)', borderRadius: 'var(--radius-card)' }}>
                          <div className="text-caption-medium" style={{ color: 'var(--success-text)', marginBottom: '8px' }}>Expected Impact</div>
                          <div style={{ fontSize: '20px', fontWeight: 600, color: 'var(--success-text)' }}>{playbook.impact}</div>
                        </div>
                        <div style={{ padding: '16px', backgroundColor: 'var(--info-light)', border: '1px solid var(--info)', borderRadius: 'var(--radius-card)' }}>
                          <div className="text-caption-medium" style={{ color: 'var(--info)', marginBottom: '8px' }}>Confidence</div>
                          <div style={{ fontSize: '20px', fontWeight: 600, color: 'var(--info)' }}>{playbook.confidence}%</div>
                        </div>
                        <div style={{ padding: '16px', backgroundColor: 'var(--brand-primary-light)', border: '1px solid var(--brand-primary)', borderRadius: 'var(--radius-card)' }}>
                          <div className="text-caption-medium" style={{ color: 'var(--brand-primary)', marginBottom: '8px' }}>Timeline</div>
                          <div style={{ fontSize: '20px', fontWeight: 600, color: 'var(--brand-primary)' }}>{playbook.timeline}</div>
                        </div>
                        <div className="flex items-center">
                          <Button variant="primary" size="lg" onClick={() => handleExecutePlay(playbook.play)} style={{ width: '100%', background: 'linear-gradient(to right, var(--gradient-start), var(--gradient-end))' }}>
                            Execute Play
                          </Button>
                        </div>
                      </div>

                      {/* Why */}
                      <div
                        style={{
                          padding: '20px',
                          backgroundColor: 'var(--neutral-50)',
                          border: '1px solid var(--neutral-200)',
                          borderRadius: 'var(--radius-card)',
                          marginBottom: '20px',
                        }}
                      >
                        <div className="text-caption-medium" style={{ color: 'var(--brand-primary)', marginBottom: '8px' }}>Why This Works:</div>
                        <p className="text-body" style={{ color: 'var(--neutral-600)' }}>{playbook.why}</p>
                      </div>

                      {/* Decision Discipline Footer */}
                      <div
                        style={{
                          padding: '16px',
                          backgroundColor: 'var(--neutral-50)',
                          borderRadius: 'var(--radius-card)',
                          border: '1px solid var(--neutral-200)',
                        }}
                      >
                        <div className="flex items-center gap-6">
                          <div>
                            <span className="text-caption" style={{ color: 'var(--neutral-400)', display: 'block', marginBottom: '4px' }}>Decision Status</span>
                            <Badge variant={getDecisionBadgeVariant(playbook.decisionStatus)} size="md">
                              {getDecisionLabel(playbook.decisionStatus)}
                            </Badge>
                          </div>
                          <div>
                            <span className="text-caption" style={{ color: 'var(--neutral-400)', display: 'block', marginBottom: '4px' }}>Owner</span>
                            <div className="flex items-center gap-2">
                              <div
                                className="flex items-center justify-center rounded-full"
                                style={{
                                  width: '24px',
                                  height: '24px',
                                  background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
                                  color: 'var(--white)',
                                  fontSize: '10px',
                                  fontWeight: 600,
                                }}
                              >
                                {playbook.owner.initials}
                              </div>
                              <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>{playbook.owner.name}</span>
                            </div>
                          </div>
                          <div>
                            <span className="text-caption" style={{ color: 'var(--neutral-400)', display: 'block', marginBottom: '4px' }}>Review Date</span>
                            <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>{playbook.reviewDate}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Simulation Panel */}
        <div style={{ marginBottom: '40px' }}>
          <button
            onClick={() => setShowSimulation(!showSimulation)}
            className="w-full flex items-center justify-between text-body-medium"
            style={{
              padding: '20px 32px',
              backgroundColor: 'var(--neutral-50)',
              border: '1px solid var(--neutral-200)',
              borderRadius: 'var(--radius-card)',
              cursor: 'pointer',
              transition: `all var(--duration-standard) var(--ease-apple)`,
            }}
            onMouseEnter={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-card)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
          >
            <div className="flex items-center gap-3">
              <BarChart3 style={{ width: '24px', height: '24px', color: 'var(--brand-primary)' }} />
              <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>
                Simulate Q2 Impact if Top 3 AI Actions are Completed
              </span>
            </div>
            <Sparkles style={{ width: '20px', height: '20px', color: 'var(--neutral-400)' }} />
          </button>

          {showSimulation && (
            <div
              style={{
                marginTop: '16px',
                padding: '32px',
                backgroundColor: 'var(--bg-level-0)',
                borderRadius: 'var(--radius-card)',
                border: '1px solid var(--neutral-200)',
              }}
            >
              <span className="text-h3" style={{ color: 'var(--neutral-800)', display: 'block', marginBottom: '24px' }}>Predicted Q2 Outcomes</span>
              <div className="grid grid-cols-4 gap-6">
                {[
                  { value: '$2.3M', label: 'ARR (Predicted)', sub: '+$300K vs current', color: 'var(--success-text)', bg: 'var(--success-light)' },
                  { value: '118%', label: 'NRR (Predicted)', sub: '+6pts improvement', color: 'var(--info)', bg: 'var(--info-light)' },
                  { value: '+34%', label: 'Velocity Gain', sub: 'vs current pace', color: 'var(--brand-primary)', bg: 'var(--brand-primary-light)' },
                  { value: '92%', label: 'Confidence', sub: '+5pts increase', color: 'var(--neutral-800)', bg: 'var(--neutral-50)' },
                ].map((metric) => (
                  <div key={metric.label} className="text-center" style={{ padding: '24px', backgroundColor: metric.bg, borderRadius: 'var(--radius-card)' }}>
                    <div style={{ fontSize: '32px', fontWeight: 600, color: metric.color, marginBottom: '8px', lineHeight: 1.2, letterSpacing: '-0.02em' }}>{metric.value}</div>
                    <div className="text-body" style={{ color: 'var(--neutral-600)', marginBottom: '4px' }}>{metric.label}</div>
                    <div className="text-caption" style={{ color: metric.color }}>{metric.sub}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Ask AI */}
        <div
          style={{
            borderRadius: 'var(--radius-card)',
            padding: '32px',
            backgroundColor: 'var(--neutral-50)',
            border: '1px solid var(--neutral-200)',
          }}
        >
          <div className="flex items-center gap-3" style={{ marginBottom: '16px' }}>
            <Sparkles style={{ width: '24px', height: '24px', color: 'var(--brand-primary)' }} />
            <span className="text-h3" style={{ color: 'var(--neutral-800)' }}>Ask AI Anything About Your Strategy</span>
          </div>
          <div className="flex gap-3">
            <input
              type="text"
              value={aiQuestion}
              onChange={(e) => setAiQuestion(e.target.value)}
              placeholder="What is the fastest way to increase Q2 velocity by 10%?"
              className="flex-1 text-body"
              style={{
                padding: '12px 20px',
                backgroundColor: 'var(--bg-level-0)',
                borderRadius: 'var(--radius-card)',
                border: '1px solid var(--neutral-200)',
                color: 'var(--neutral-800)',
                transition: `all var(--duration-standard) var(--ease-apple)`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
                e.currentTarget.style.borderColor = 'var(--brand-primary)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.borderColor = 'var(--neutral-200)';
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAskAI();
              }}
            />
            <Button
              variant="primary"
              size="lg"
              onClick={handleAskAI}
              disabled={!aiQuestion.trim()}
              style={{ background: 'linear-gradient(to right, var(--gradient-start), var(--gradient-end))' }}
            >
              <Send style={{ width: '20px', height: '20px' }} />
              Ask AI
            </Button>
          </div>
          <div className="flex flex-wrap gap-2" style={{ marginTop: '16px' }}>
            {['What\'s blocking revenue growth?', 'Should we hire more engineers?', 'Which theme needs most attention?'].map((q) => (
              <button
                key={q}
                className="text-caption"
                onClick={() => setAiQuestion(q)}
                style={{
                  padding: '6px 12px',
                  backgroundColor: 'var(--bg-level-0)',
                  borderRadius: 'var(--radius-input)',
                  border: '1px solid var(--neutral-200)',
                  color: 'var(--neutral-600)',
                  cursor: 'pointer',
                  transition: `all var(--duration-standard) var(--ease-apple)`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'var(--brand-primary)';
                  e.currentTarget.style.color = 'var(--brand-primary)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'var(--neutral-200)';
                  e.currentTarget.style.color = 'var(--neutral-600)';
                }}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}

import React, { useState, useEffect } from 'react';
import { BookOpen, TrendingUp, Users, Zap, CheckCircle, Sparkles, HelpCircle, ArrowUp, ArrowDown, Minus } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { Skeleton } from '../design-system/skeleton';
import { toast } from 'sonner';

interface Chapter {
  title: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  bgColor: string;
  summary: string;
  trend: 'up' | 'down' | 'neutral';
  tooltip: string;
}

export function StrategicStory() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const chapters: Chapter[] = [
    {
      title: 'Strategic Momentum',
      icon: TrendingUp,
      bgColor: 'var(--success-light)',
      summary: 'Company is accelerating. Q2 confidence up 5pts to 87%. Revenue Excellence and Customer Success themes ahead of plan.',
      trend: 'up',
      tooltip: 'Shows whether the company is accelerating or slowing down.',
    },
    {
      title: 'Linking Functions',
      icon: Users,
      bgColor: 'var(--info-light)',
      summary: 'Revenue and Customer Success driving results. Product team overcommitted and creating enterprise adoption risk.',
      trend: 'neutral',
      tooltip: 'Breakdown of which teams drive results and which slow you down.',
    },
    {
      title: 'Required Strategic Moves',
      icon: Zap,
      bgColor: 'var(--brand-primary-light)',
      summary: '3 critical decisions needed: (1) Pivot product roadmap to enterprise, (2) Reallocate AEs to enterprise segment, (3) Consolidate Product Innovation from 8 to 4 initiatives.',
      trend: 'up',
      tooltip: 'Top decisions leadership must take this quarter.',
    },
    {
      title: 'Alignment Status',
      icon: CheckCircle,
      bgColor: 'var(--info-light)',
      summary: '89% strategic alignment, 3 misalignments detected. Marketing campaign orphaned, Product building features misaligned with enterprise strategy.',
      trend: 'down',
      tooltip: 'How well teams are working toward shared goals.',
    },
  ];

  const getTrendConfig = (trend: 'up' | 'down' | 'neutral') => {
    switch (trend) {
      case 'up': return { Icon: ArrowUp, color: 'var(--success-text)', bg: 'var(--success-light)' };
      case 'down': return { Icon: ArrowDown, color: 'var(--danger-text)', bg: 'var(--danger-light)' };
      default: return { Icon: Minus, color: 'var(--info)', bg: 'var(--info-light)' };
    }
  };

  const handleExecute = () => {
    toast.success('Recommendations queued for execution', { description: 'AI will guide implementation.' });
  };

  if (isLoading) {
    return (
      <section style={{ marginTop: '64px' }}>
        <Skeleton variant="text" width="180px" height="24px" style={{ marginBottom: '8px' }} />
        <Skeleton variant="text" width="320px" height="14px" style={{ marginBottom: '32px' }} />
        <Skeleton variant="rect" height="200px" style={{ marginBottom: '32px' }} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} variant="rect" height="160px" />
          ))}
        </div>
      </section>
    );
  }

  return (
    <TooltipProvider>
      <section style={{ marginTop: '64px' }}>
        {/* Header */}
        <div style={{ marginBottom: '32px' }}>
          <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>Strategic Story</span>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
              </TooltipTrigger>
              <TooltipContent style={{ maxWidth: '400px' }}>
                <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Strategic Story</p>
                <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>AI-generated executive narrative of your strategy.</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>Auto-generated executive summary ready for leadership</p>
        </div>

        {/* Executive Summary */}
        <div
          className="relative overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
            borderRadius: 'var(--radius-card)',
            padding: '40px',
            marginBottom: '48px',
            boxShadow: 'var(--shadow-brand-hover)',
          }}
        >
          <div className="relative" style={{ zIndex: 1 }}>
            <div className="flex items-center gap-3" style={{ marginBottom: '24px' }}>
              <div
                className="flex items-center justify-center"
                style={{
                  padding: '10px',
                  backgroundColor: 'rgba(255, 255, 255, 0.15)',
                  borderRadius: 'var(--radius-card)',
                }}
              >
                <BookOpen style={{ width: '32px', height: '32px', color: 'var(--white)' }} />
              </div>
              <span className="text-h1" style={{ color: 'var(--white)' }}>Executive Summary</span>
            </div>
            <p className="text-body-large" style={{ color: 'rgba(255, 255, 255, 0.9)', lineHeight: 1.6, marginBottom: '24px' }}>
              ShiftFocus is executing well with 87% strategic confidence and strong momentum. Revenue Excellence and Customer Success themes are ahead of plan, driving Q2 performance. However, Product Innovation theme is at risk due to overcommitment. Three critical decisions required to maintain trajectory.
            </p>
            <div className="flex items-center gap-4">
              {[
                { icon: TrendingUp, label: 'Momentum: Strong', color: 'var(--success)' },
                { icon: CheckCircle, label: 'Alignment: 89%', color: 'var(--info)' },
                { icon: Zap, label: '3 Critical Moves', color: 'var(--brand-primary-hover)' },
              ].map((item) => {
                const ItemIcon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="flex items-center gap-2"
                    style={{
                      padding: '8px 16px',
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                      borderRadius: 'var(--radius-card)',
                    }}
                  >
                    <ItemIcon style={{ width: '20px', height: '20px', color: item.color }} />
                    <span className="text-body" style={{ color: 'var(--white)' }}>{item.label}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Story Chapters */}
        <div className="relative" style={{ paddingLeft: '48px' }}>
          {/* Timeline */}
          <div
            className="absolute top-0 bottom-0"
            style={{
              left: '28px',
              width: '2px',
              background: 'linear-gradient(to bottom, var(--brand-primary), var(--brand-primary-light))',
            }}
          />

          <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
            {chapters.map((chapter, idx) => {
              const Icon = chapter.icon;
              const trendConfig = getTrendConfig(chapter.trend);
              const TrendIcon = trendConfig.Icon;

              return (
                <div
                  key={idx}
                  className="relative overflow-hidden"
                  style={{
                    backgroundColor: 'var(--bg-level-0)',
                    border: '1px solid var(--neutral-200)',
                    borderRadius: 'var(--radius-card)',
                    transition: `all var(--duration-standard) var(--ease-apple)`,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'var(--brand-primary)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = 'var(--neutral-200)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  {/* Timeline dot */}
                  <div
                    className="absolute flex items-center justify-center"
                    style={{
                      left: '-64px',
                      top: '32px',
                      width: '56px',
                      height: '56px',
                      borderRadius: '50%',
                      background: 'linear-gradient(135deg, var(--gradient-start), var(--gradient-end))',
                      border: '4px solid var(--bg-level-0)',
                      boxShadow: 'var(--shadow-card-hover)',
                      zIndex: 20,
                    }}
                  >
                    <Icon style={{ width: '24px', height: '24px', color: 'var(--white)' }} />
                  </div>

                  <div style={{ padding: '32px', paddingLeft: '16px' }}>
                    {/* Chapter header */}
                    <div className="flex items-center gap-3" style={{ marginBottom: '20px' }}>
                      <div
                        className="flex items-center justify-center"
                        style={{
                          padding: '12px',
                          backgroundColor: chapter.bgColor,
                          borderRadius: 'var(--radius-card)',
                        }}
                      >
                        <Icon style={{ width: '24px', height: '24px', color: 'var(--neutral-800)' }} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-h3" style={{ color: 'var(--neutral-800)', fontWeight: 600 }}>{chapter.title}</span>
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>{chapter.title}</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>{chapter.tooltip}</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <p className="text-caption" style={{ color: 'var(--neutral-400)', marginTop: '4px', fontWeight: 500 }}>
                          Chapter {idx + 1} of 4
                        </p>
                      </div>
                      <div
                        className="flex items-center gap-2"
                        style={{
                          padding: '8px 12px',
                          backgroundColor: trendConfig.bg,
                          borderRadius: 'var(--radius-card)',
                          border: '1px solid var(--neutral-200)',
                        }}
                      >
                        <TrendIcon style={{ width: '16px', height: '16px', color: trendConfig.color }} />
                      </div>
                    </div>

                    <p className="text-body" style={{ color: 'var(--neutral-600)', marginBottom: '24px' }}>{chapter.summary}</p>

                    {/* Trend highlights */}
                    <div
                      style={{
                        backgroundColor: chapter.bgColor,
                        border: '1px solid var(--neutral-200)',
                        borderRadius: 'var(--radius-card)',
                        padding: '20px',
                      }}
                    >
                      <div className="flex items-center gap-2" style={{ marginBottom: '12px' }}>
                        <TrendingUp style={{ width: '16px', height: '16px', color: 'var(--brand-primary)' }} />
                        <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>Key Trend Highlights</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Trend Highlights</p>
                            <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>Important changes from last week or quarter.</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {[
                          'Strategic confidence increased 5pts week-over-week',
                          '2 themes ahead of plan, 1 stable, 0 behind',
                          '18 active coherence issues, down from 24 last week',
                        ].map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-caption" style={{ color: 'var(--neutral-800)' }}>
                            <div
                              style={{
                                width: '6px',
                                height: '6px',
                                borderRadius: '50%',
                                backgroundColor: 'var(--brand-primary)',
                                marginTop: '6px',
                                flexShrink: 0,
                              }}
                            />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div
          style={{
            marginTop: '48px',
            padding: '32px',
            backgroundColor: 'var(--neutral-50)',
            border: '1px solid var(--neutral-200)',
            borderRadius: 'var(--radius-card)',
          }}
        >
          <div className="flex items-center gap-3" style={{ marginBottom: '16px' }}>
            <div
              className="flex items-center justify-center"
              style={{
                padding: '10px',
                backgroundColor: 'var(--brand-primary-light)',
                borderRadius: 'var(--radius-card)',
              }}
            >
              <Sparkles style={{ width: '24px', height: '24px', color: 'var(--brand-primary)' }} />
            </div>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>AI Strategic Recommendation</span>
          </div>
          <p className="text-body-large" style={{ color: 'var(--neutral-600)', marginBottom: '20px' }}>
            Focus leadership attention on Product Innovation theme for next 2 weeks. Execute the 3 critical moves identified above. With these adjustments, projected Q2 confidence increases from 87% to 92%.
          </p>
          <div className="flex items-center gap-3">
            <Button variant="primary" size="md" onClick={handleExecute}>
              <Zap style={{ width: '16px', height: '16px' }} />
              Execute Recommendations
            </Button>
            <Button variant="secondary" size="md">
              Schedule Leadership Review
            </Button>
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}
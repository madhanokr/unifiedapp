import React, { useState, useEffect } from 'react';
import { Plus, Users, Calendar, TrendingUp, HelpCircle, Sparkles, Target, Zap } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { Badge } from '../design-system/badge';
import { CardSkeleton } from '../design-system/skeleton';
import { EmptyState } from '../design-system/empty-state';

interface PlanningBoardProps {
  timeHorizon: 'quarterly' | 'annual' | '3-year';
}

export function PlanningBoard({ timeHorizon }: PlanningBoardProps) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const quarters = [
    { id: 'Q1', label: 'Q1 2025', period: 'Jan - Mar', semanticColor: 'var(--info)' },
    { id: 'Q2', label: 'Q2 2025', period: 'Apr - Jun', semanticColor: 'var(--success)' },
    { id: 'Q3', label: 'Q3 2025', period: 'Jul - Sep', semanticColor: 'var(--brand-primary)' },
    { id: 'Q4', label: 'Q4 2025', period: 'Oct - Dec', semanticColor: 'var(--at-risk)' },
  ];

  const outcomes: Record<string, Array<{
    title: string;
    metric: string;
    risk: string;
    status: string;
    team: string;
    objective: string;
    initiative: string;
  }>> = {
    Q1: [
      { title: 'Hit $2M ARR milestone', metric: 'ARR: $1.8M -> $2M', risk: 'low', status: 'on-track', team: 'Revenue', objective: 'Accelerate enterprise sales', initiative: 'Launch enterprise tier' },
      { title: 'Launch AI-powered analytics', metric: 'Feature adoption: 0% -> 40%', risk: 'medium', status: 'ahead', team: 'Product', objective: 'Ship 3 major features', initiative: 'Build analytics dashboard' },
    ],
    Q2: [
      { title: 'Achieve 120% NRR', metric: 'NRR: 115% -> 120%', risk: 'low', status: 'planning', team: 'Customer Success', objective: 'Maximize account expansion', initiative: 'Launch upsell playbook' },
    ],
    Q3: [
      { title: 'Expand to European market', metric: 'EU Revenue: $0 -> $500K', risk: 'high', status: 'planning', team: 'Revenue', objective: 'Launch EU region', initiative: 'GDPR compliance + localization' },
    ],
    Q4: [
      { title: 'Scale to 10K users', metric: 'Users: 5K -> 10K', risk: 'medium', status: 'planning', team: 'Product', objective: 'Improve activation rate', initiative: 'Build onboarding flow' },
    ],
  };

  const getRiskVariant = (risk: string): 'danger' | 'warning' | 'success' => {
    if (risk === 'high') return 'danger';
    if (risk === 'medium') return 'warning';
    return 'success';
  };

  const getRiskLabel = (risk: string) => {
    if (risk === 'high') return 'High Risk';
    if (risk === 'medium') return 'Medium Risk';
    return 'Low Risk';
  };

  const getStatusVariant = (status: string): 'success' | 'info' | 'neutral' => {
    if (status === 'ahead') return 'success';
    if (status === 'on-track') return 'info';
    return 'neutral';
  };

  const getStatusLabel = (status: string) => {
    if (status === 'ahead') return 'Ahead';
    if (status === 'on-track') return 'On Track';
    return 'Planning';
  };

  return (
    <TooltipProvider>
      <section style={{ marginTop: '48px' }}>
        <div style={{ marginBottom: '32px' }}>
          <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
            <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>Planning Board</span>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
              </TooltipTrigger>
              <TooltipContent style={{ maxWidth: '400px' }}>
                <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Annual + Quarterly Planning</p>
                <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                  Where strategy becomes execution. Map outcomes, objectives, and initiatives across quarters.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
            Map outcomes, objectives, and initiatives across {timeHorizon === 'quarterly' ? 'quarters' : timeHorizon === 'annual' ? 'the year' : '3 years'}
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-4 gap-6">
            {[0, 1, 2, 3].map((i) => (
              <div key={i}>
                <CardSkeleton />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-4 gap-6">
            {quarters.map((quarter) => (
              <div key={quarter.id} className="flex flex-col">
                {/* Column Header */}
                <div
                  style={{
                    backgroundColor: 'var(--neutral-50)',
                    border: '1px solid var(--neutral-200)',
                    borderTop: `4px solid ${quarter.semanticColor}`,
                    borderRadius: 'var(--radius-card)',
                    padding: '24px',
                    marginBottom: '24px',
                  }}
                >
                  <div className="flex items-center justify-between" style={{ marginBottom: '16px' }}>
                    <div>
                      <div className="text-h1" style={{ color: 'var(--neutral-800)', marginBottom: '4px' }}>{quarter.label}</div>
                      <p className="text-body-medium" style={{ color: 'var(--neutral-600)' }}>{quarter.period}</p>
                    </div>
                    <Calendar style={{ width: '32px', height: '32px', color: 'var(--neutral-400)' }} />
                  </div>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        className="w-full flex items-center justify-center gap-2 text-body-medium"
                        style={{
                          marginTop: '8px',
                          padding: '8px 16px',
                          backgroundColor: quarter.semanticColor,
                          color: 'var(--white)',
                          borderRadius: 'var(--radius-card)',
                          height: '40px',
                          border: 'none',
                          cursor: 'pointer',
                          transition: `opacity var(--duration-standard) var(--ease-apple)`,
                        }}
                        onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.9'; }}
                        onMouseLeave={(e) => { e.currentTarget.style.opacity = '1'; }}
                      >
                        <Sparkles style={{ width: '16px', height: '16px' }} />
                        AI Suggest Plan
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-caption">Let AI suggest optimal outcomes for this quarter</p>
                    </TooltipContent>
                  </Tooltip>
                </div>

                {/* Outcomes */}
                <div className="flex-1" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                  {(outcomes[quarter.id] || []).length === 0 ? (
                    <EmptyState
                      size="sm"
                      icon={<Target style={{ width: '24px', height: '24px', color: 'var(--neutral-400)' }} />}
                      title="No outcomes yet"
                      description="Add a measurable target for this quarter."
                    />
                  ) : (
                    (outcomes[quarter.id] || []).map((outcome, idx) => (
                      <div
                        key={idx}
                        style={{
                          backgroundColor: 'var(--bg-level-0)',
                          border: '1px solid var(--neutral-200)',
                          borderRadius: 'var(--radius-card)',
                          padding: '24px',
                          cursor: 'pointer',
                          transition: `all var(--duration-standard) var(--ease-apple)`,
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = 'var(--brand-primary)';
                          e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = 'var(--neutral-200)';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      >
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div
                              className="inline-flex items-center gap-1.5 cursor-help text-caption-medium"
                              style={{
                                padding: '4px 12px',
                                backgroundColor: 'var(--neutral-100)',
                                color: 'var(--neutral-800)',
                                borderRadius: 'var(--radius-input)',
                                marginBottom: '16px',
                              }}
                            >
                              <Target style={{ width: '14px', height: '14px' }} />
                              Outcome
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-caption-medium" style={{ marginBottom: '4px' }}>What Is an Outcome?</p>
                            <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>A measurable result you want this quarter.</p>
                          </TooltipContent>
                        </Tooltip>

                        <div className="text-h4" style={{ color: 'var(--neutral-800)', marginBottom: '16px' }}>{outcome.title}</div>

                        <div
                          className="flex items-center gap-3"
                          style={{
                            padding: '12px 16px',
                            backgroundColor: 'var(--brand-primary-light)',
                            border: '1px solid var(--brand-primary)',
                            borderRadius: 'var(--radius-card)',
                            marginBottom: '16px',
                          }}
                        >
                          <TrendingUp style={{ width: '20px', height: '20px', color: 'var(--brand-primary)' }} />
                          <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{outcome.metric}</span>
                        </div>

                        <div className="flex items-center gap-2" style={{ marginBottom: '16px' }}>
                          <Badge variant={getStatusVariant(outcome.status)} size="sm">{getStatusLabel(outcome.status)}</Badge>
                          <Badge variant={getRiskVariant(outcome.risk)} size="sm">{getRiskLabel(outcome.risk)}</Badge>
                        </div>

                        <div className="flex items-center gap-2" style={{ color: 'var(--neutral-600)', marginBottom: '16px' }}>
                          <Users style={{ width: '16px', height: '16px' }} />
                          <span className="text-body-medium">{outcome.team}</span>
                        </div>

                        <div style={{ paddingTop: '16px', borderTop: '1px solid var(--neutral-200)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                className="flex items-start gap-3 cursor-help"
                                style={{ padding: '8px', borderRadius: 'var(--radius-input)' }}
                              >
                                <Zap style={{ width: '16px', height: '16px', color: 'var(--brand-primary)', marginTop: '2px', flexShrink: 0 }} />
                                <div>
                                  <span className="text-caption" style={{ color: 'var(--neutral-400)', fontWeight: 500 }}>Objective:</span>
                                  <div className="text-body" style={{ color: 'var(--neutral-800)' }}>{outcome.objective}</div>
                                </div>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>What is an Objective?</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>A directional goal that defines HOW you{"'"}ll achieve the outcome.</p>
                            </TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div
                                className="flex items-start gap-3 cursor-help"
                                style={{ padding: '8px', borderRadius: 'var(--radius-input)' }}
                              >
                                <Target style={{ width: '16px', height: '16px', color: 'var(--neutral-400)', marginTop: '2px', flexShrink: 0 }} />
                                <div>
                                  <span className="text-caption" style={{ color: 'var(--neutral-400)', fontWeight: 500 }}>Initiative:</span>
                                  <div className="text-body" style={{ color: 'var(--neutral-800)' }}>{outcome.initiative}</div>
                                </div>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>What is an Initiative?</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>A specific project that delivers the objective.</p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    ))
                  )}

                  {/* Add Outcome */}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        className="w-full flex items-center justify-center gap-2 text-body-medium"
                        style={{
                          padding: '20px 24px',
                          border: '2px dashed var(--neutral-200)',
                          backgroundColor: 'var(--bg-level-0)',
                          color: 'var(--neutral-800)',
                          borderRadius: 'var(--radius-card)',
                          cursor: 'pointer',
                          transition: `all var(--duration-standard) var(--ease-apple)`,
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = 'var(--brand-primary)';
                          e.currentTarget.style.color = 'var(--brand-primary)';
                          e.currentTarget.style.backgroundColor = 'var(--brand-primary-light)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = 'var(--neutral-200)';
                          e.currentTarget.style.color = 'var(--neutral-800)';
                          e.currentTarget.style.backgroundColor = 'var(--bg-level-0)';
                        }}
                      >
                        <Plus style={{ width: '20px', height: '20px' }} />
                        Add Outcome
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Add Outcome</p>
                      <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>Create a new measurable target.</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </TooltipProvider>
  );
}

import React, { useState, useEffect } from 'react';
import { TrendingUp, Zap, Users, HelpCircle, Target } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../design-system/tooltip';
import { Button } from '../design-system/button';
import { Badge } from '../design-system/badge';
import { ProgressBar } from '../design-system/progress-bar';
import { CardSkeleton } from '../design-system/skeleton';
import { EmptyState } from '../design-system/empty-state';

interface Theme {
  id: string;
  name: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  semanticColor: string;
  bgColor: string;
  status: 'ahead' | 'stable' | 'behind';
  statusLabel: string;
  confidence: number;
  alignment: number;
  influence: number;
  driftRisk: 'low' | 'moderate' | 'high';
  linkedOKRs: number;
  okrCompletion: number;
  momentum: string;
  subPriorities: Array<{ name: string; progress: number }>;
}

export function StrategicThemes() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const themes: Theme[] = [
    {
      id: 'revenue-excellence',
      name: 'Revenue Excellence',
      icon: TrendingUp,
      semanticColor: 'var(--success)',
      bgColor: 'var(--success-light)',
      status: 'ahead',
      statusLabel: 'Ahead',
      confidence: 92,
      alignment: 94,
      influence: 78,
      driftRisk: 'low',
      linkedOKRs: 17,
      okrCompletion: 72,
      momentum: '+18%',
      subPriorities: [
        { name: 'Reduce CAC by 10-15%', progress: 68 },
        { name: 'Improve enterprise close rate', progress: 82 },
        { name: 'Expand partnership channel', progress: 45 },
      ],
    },
    {
      id: 'product-innovation',
      name: 'Product Innovation',
      icon: Zap,
      semanticColor: 'var(--brand-primary)',
      bgColor: 'var(--brand-primary-light)',
      status: 'stable',
      statusLabel: 'On Track',
      confidence: 76,
      alignment: 82,
      influence: 65,
      driftRisk: 'moderate',
      linkedOKRs: 12,
      okrCompletion: 58,
      momentum: '+8%',
      subPriorities: [
        { name: 'Ship AI-powered insights', progress: 91 },
        { name: 'Enterprise admin controls', progress: 34 },
        { name: 'Mobile app foundation', progress: 22 },
      ],
    },
    {
      id: 'customer-success',
      name: 'Customer Success',
      icon: Users,
      semanticColor: 'var(--info)',
      bgColor: 'var(--info-light)',
      status: 'ahead',
      statusLabel: 'Ahead',
      confidence: 89,
      alignment: 96,
      influence: 71,
      driftRisk: 'low',
      linkedOKRs: 14,
      okrCompletion: 86,
      momentum: '+12%',
      subPriorities: [
        { name: 'Improve NRR to 120%', progress: 78 },
        { name: 'Launch customer academy', progress: 92 },
        { name: 'Reduce churn by 15%', progress: 67 },
      ],
    },
  ];

  const getStatusBadgeVariant = (status: string): 'success' | 'neutral' | 'danger' => {
    if (status === 'ahead') return 'success';
    if (status === 'behind') return 'danger';
    return 'neutral';
  };

  return (
    <TooltipProvider>
      <section style={{ marginTop: '32px' }}>
        <div className="flex items-start justify-between" style={{ marginBottom: '32px' }}>
          <div>
            <div className="flex items-center gap-2" style={{ marginBottom: '8px' }}>
              <span className="text-h2" style={{ color: 'var(--neutral-800)' }}>Strategic Themes</span>
              <Tooltip>
                <TooltipTrigger>
                  <HelpCircle className="cursor-help" style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }} />
                </TooltipTrigger>
                <TooltipContent style={{ maxWidth: '400px' }}>
                  <p className="text-caption-medium" style={{ marginBottom: '4px' }}>What Is a Theme?</p>
                  <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                    A theme is a 3-6 year company bet — your long-term direction. Themes don{"'"}t change quarter to quarter.
                  </p>
                </TooltipContent>
              </Tooltip>
            </div>
            <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
              Your company{"'"}s strategic pillars (3-6 year horizon)
            </p>
          </div>
          <Button variant="primary" size="md">
            <Target style={{ width: '20px', height: '20px' }} />
            Add Theme
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 gap-6">
            <CardSkeleton />
            <CardSkeleton />
            <CardSkeleton />
          </div>
        ) : themes.length === 0 ? (
          <EmptyState
            icon={<Target style={{ width: '24px', height: '24px', color: 'var(--neutral-400)' }} />}
            title="No strategic themes yet"
            description="Add your first strategic theme to define your company's long-term direction."
            actionLabel="Add Theme"
            onAction={() => {}}
          />
        ) : (
          <div className="grid grid-cols-2 gap-6">
            {themes.map((theme) => {
              const Icon = theme.icon;

              return (
                <div
                  key={theme.id}
                  className="overflow-hidden relative"
                  style={{
                    backgroundColor: 'var(--bg-level-0)',
                    border: '1px solid var(--neutral-200)',
                    borderRadius: 'var(--radius-card)',
                    boxShadow: 'var(--shadow-card)',
                    transition: `box-shadow var(--duration-standard) var(--ease-apple)`,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.boxShadow = 'var(--shadow-card)';
                  }}
                >
                  {/* Accent bar */}
                  <div className="absolute left-0 top-0 bottom-0" style={{ width: '4px', backgroundColor: theme.semanticColor }} />

                  {/* Header */}
                  <div
                    style={{
                      padding: '20px 24px',
                      borderBottom: '1px solid var(--neutral-200)',
                      backgroundColor: theme.bgColor,
                    }}
                  >
                    <div className="flex items-center justify-between" style={{ marginBottom: '12px' }}>
                      <div className="flex items-center gap-3">
                        <div
                          className="flex items-center justify-center"
                          style={{
                            width: '44px',
                            height: '44px',
                            borderRadius: 'var(--radius-card)',
                            backgroundColor: theme.semanticColor,
                          }}
                        >
                          <Icon style={{ width: '24px', height: '24px', color: 'var(--white)' }} />
                        </div>
                        <span className="text-h3" style={{ color: 'var(--neutral-800)', fontWeight: 600 }}>{theme.name}</span>
                      </div>
                      <Badge variant={getStatusBadgeVariant(theme.status)} size="md">
                        {theme.statusLabel}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp style={{ width: '16px', height: '16px', color: theme.semanticColor }} />
                      <span className="text-body-medium" style={{ color: theme.semanticColor }}>
                        Momentum: {theme.momentum}
                      </span>
                    </div>
                  </div>

                  <div style={{ padding: '24px' }}>
                    {/* Influence */}
                    <div style={{ marginBottom: '24px' }}>
                      <div className="flex items-center justify-between" style={{ marginBottom: '8px' }}>
                        <div className="flex items-center gap-1.5">
                          <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Influence on North Star</span>
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Influence on North Star</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                                How much this theme affects your company{"'"}s main goal.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{theme.influence}%</span>
                      </div>
                      <ProgressBar value={theme.influence} variant="brand" size="md" />
                    </div>

                    {/* Confidence + Alignment */}
                    <div className="grid grid-cols-2 gap-4" style={{ marginBottom: '24px' }}>
                      <div
                        className="text-center"
                        style={{
                          padding: '16px',
                          borderRadius: 'var(--radius-card)',
                          backgroundColor: 'var(--neutral-50)',
                          border: '1px solid var(--neutral-200)',
                        }}
                      >
                        <div className="flex items-center justify-center gap-1" style={{ marginBottom: '8px' }}>
                          <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Confidence</span>
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Confidence</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                                How sure you are this theme will succeed.
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: 'var(--neutral-800)', marginBottom: '8px' }}>{theme.confidence}%</div>
                        <ProgressBar value={theme.confidence} variant="auto" size="md" />
                      </div>
                      <div
                        className="text-center"
                        style={{
                          padding: '16px',
                          borderRadius: 'var(--radius-card)',
                          backgroundColor: 'var(--neutral-50)',
                          border: '1px solid var(--neutral-200)',
                        }}
                      >
                        <div className="flex items-center justify-center gap-1" style={{ marginBottom: '8px' }}>
                          <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Alignment</span>
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Alignment</p>
                              <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                                Are all teams rowing in the same direction?
                              </p>
                            </TooltipContent>
                          </Tooltip>
                        </div>
                        <div style={{ fontSize: '32px', fontWeight: 600, lineHeight: 1, color: 'var(--neutral-800)', marginBottom: '8px' }}>{theme.alignment}%</div>
                        <ProgressBar value={theme.alignment} variant="auto" size="md" />
                      </div>
                    </div>

                    {/* Key Results */}
                    <div style={{ marginBottom: '24px' }}>
                      <div className="flex items-center gap-1.5" style={{ marginBottom: '12px' }}>
                        <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Key Results (KRs)</span>
                        <Tooltip>
                          <TooltipTrigger>
                            <HelpCircle className="cursor-help" style={{ width: '14px', height: '14px', color: 'var(--neutral-400)' }} />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-caption-medium" style={{ marginBottom: '4px' }}>Key Results</p>
                            <p className="text-caption" style={{ color: 'var(--neutral-400)' }}>
                              Measurable outcomes that prove this theme is working.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {theme.subPriorities.map((priority, idx) => (
                          <div key={idx}>
                            <div className="flex items-center justify-between" style={{ marginBottom: '6px' }}>
                              <div className="flex items-center gap-2">
                                <div
                                  style={{
                                    width: '6px',
                                    height: '6px',
                                    borderRadius: '50%',
                                    backgroundColor:
                                      priority.progress >= 80
                                        ? 'var(--success)'
                                        : priority.progress >= 50
                                          ? 'var(--warning)'
                                          : 'var(--neutral-400)',
                                  }}
                                />
                                <span className="text-caption" style={{ color: 'var(--neutral-800)' }}>{priority.name}</span>
                              </div>
                              <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>{priority.progress}%</span>
                            </div>
                            <ProgressBar value={priority.progress} variant="auto" size="sm" />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Linked OKRs */}
                    <div
                      className="flex items-center justify-between"
                      style={{
                        padding: '12px',
                        backgroundColor: 'var(--neutral-50)',
                        borderRadius: 'var(--radius-input)',
                        border: '1px solid var(--neutral-200)',
                      }}
                    >
                      <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>{theme.linkedOKRs} OKRs linked</span>
                      <div className="flex items-center gap-2">
                        <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>{theme.okrCompletion}% complete</span>
                        <ProgressBar value={theme.okrCompletion} variant="auto" size="sm" style={{ width: '64px' }} />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </TooltipProvider>
  );
}

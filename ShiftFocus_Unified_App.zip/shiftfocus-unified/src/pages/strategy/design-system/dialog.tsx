import React, { forwardRef } from 'react';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { X } from 'lucide-react';

const Dialog = DialogPrimitive.Root;
const DialogTrigger = DialogPrimitive.Trigger;
const DialogClose = DialogPrimitive.Close;
const DialogPortal = DialogPrimitive.Portal;

const DialogOverlay = forwardRef<
  React.ComponentRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn('fixed inset-0', className)}
    style={{
      backgroundColor: 'rgba(0, 0, 0, 0.4)',
      zIndex: 100,
    }}
    {...props}
  />
));
DialogOverlay.displayName = 'DialogOverlay';

const dialogContentVariants = cva('', {
  variants: {
    size: {
      sm: '',
      md: '',
      lg: '',
    },
  },
  defaultVariants: {
    size: 'md',
  },
});

const sizeWidths: Record<string, string> = {
  sm: '400px',
  md: '560px',
  lg: '720px',
};

interface DialogContentProps
  extends React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>,
    VariantProps<typeof dialogContentVariants> {}

const DialogContent = forwardRef<
  React.ComponentRef<typeof DialogPrimitive.Content>,
  DialogContentProps
>(({ className, children, size = 'md', style, ...props }, ref) => {
  const s = size ?? 'md';

  return (
    <DialogPortal>
      <DialogOverlay />
      <DialogPrimitive.Content
        ref={ref}
        className={cn('fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2', className)}
        style={{
          width: '90vw',
          maxWidth: sizeWidths[s],
          maxHeight: '85vh',
          overflowY: 'auto',
          backgroundColor: 'var(--bg-level-0)',
          borderRadius: 'var(--radius-card)',
          boxShadow: 'var(--shadow-modal)',
          padding: '32px',
          zIndex: 100,
          ...style,
        }}
        {...props}
      >
        {children}
        <DialogPrimitive.Close
          className="absolute"
          style={{
            top: '16px',
            right: '16px',
            color: 'var(--neutral-400)',
            cursor: 'pointer',
            background: 'none',
            border: 'none',
            padding: '4px',
            borderRadius: 'var(--radius-badge)',
            transition: `color var(--duration-fast) var(--ease-apple)`,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = 'var(--neutral-800)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.color = 'var(--neutral-400)';
          }}
        >
          <X style={{ width: '20px', height: '20px' }} />
        </DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DialogPortal>
  );
});
DialogContent.displayName = 'DialogContent';

const DialogHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className,
  style,
  ...props
}) => (
  <div
    className={cn('flex flex-col gap-2', className)}
    style={{ marginBottom: '24px', ...style }}
    {...props}
  />
);

const DialogTitle = forwardRef<
  React.ComponentRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, style, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn('text-h2', className)}
    style={{ color: 'var(--neutral-800)', ...style }}
    {...props}
  />
));
DialogTitle.displayName = 'DialogTitle';

const DialogDescription = forwardRef<
  React.ComponentRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, style, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn('text-body', className)}
    style={{ color: 'var(--neutral-600)', ...style }}
    {...props}
  />
));
DialogDescription.displayName = 'DialogDescription';

const DialogFooter: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  className,
  style,
  ...props
}) => (
  <div
    className={cn('flex items-center justify-end gap-3', className)}
    style={{ marginTop: '24px', ...style }}
    {...props}
  />
);

export {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
  dialogContentVariants,
};

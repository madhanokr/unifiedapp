import React, { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const badgeVariants = cva(
  'inline-flex items-center gap-1',
  {
    variants: {
      variant: {
        success: '',
        warning: '',
        danger: '',
        info: '',
        neutral: '',
        brand: '',
      },
      size: {
        sm: '',
        md: '',
      },
    },
    defaultVariants: {
      variant: 'neutral',
      size: 'sm',
    },
  }
);

const variantStyleMap: Record<string, React.CSSProperties> = {
  success: {
    backgroundColor: 'var(--success-light)',
    color: 'var(--success-text)',
    border: '1px solid var(--success)',
  },
  warning: {
    backgroundColor: 'var(--warning-light)',
    color: 'var(--warning)',
    border: '1px solid var(--warning)',
  },
  danger: {
    backgroundColor: 'var(--danger-light)',
    color: 'var(--danger-text)',
    border: '1px solid var(--danger)',
  },
  info: {
    backgroundColor: 'var(--info-light)',
    color: 'var(--info)',
    border: '1px solid var(--info)',
  },
  neutral: {
    backgroundColor: 'var(--neutral-100)',
    color: 'var(--neutral-600)',
    border: '1px solid var(--neutral-200)',
  },
  brand: {
    backgroundColor: 'var(--brand-primary-light)',
    color: 'var(--brand-primary)',
    border: '1px solid var(--brand-primary)',
  },
};

const sizeStyleMap: Record<string, React.CSSProperties> = {
  sm: {
    padding: '2px 8px',
    fontSize: '12px',
    fontWeight: 500,
    lineHeight: '1.4',
    borderRadius: 'var(--radius-badge)',
  },
  md: {
    padding: '4px 12px',
    fontSize: '12px',
    fontWeight: 500,
    lineHeight: '1.4',
    borderRadius: 'var(--radius-input)',
  },
};

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export const Badge = forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant = 'neutral', size = 'sm', style, ...props }, ref) => {
    const v = variant ?? 'neutral';
    const s = size ?? 'sm';

    return (
      <span
        ref={ref}
        className={cn(badgeVariants({ variant, size }), className)}
        style={{
          ...variantStyleMap[v],
          ...sizeStyleMap[s],
          ...style,
        }}
        {...props}
      />
    );
  }
);

Badge.displayName = 'Badge';
export { badgeVariants };

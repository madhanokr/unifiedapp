import React, { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Loader2 } from 'lucide-react';

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 cursor-pointer transition-all border-none whitespace-nowrap',
  {
    variants: {
      variant: {
        primary: '',
        secondary: '',
        ghost: '',
        destructive: '',
      },
      size: {
        sm: '',
        md: '',
        lg: '',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

const variantStyles: Record<string, React.CSSProperties> = {
  primary: {
    backgroundColor: 'var(--brand-primary)',
    color: 'var(--white)',
    borderRadius: 'var(--radius-button)',
    boxShadow: 'var(--shadow-brand)',
  },
  secondary: {
    backgroundColor: 'var(--bg-level-0)',
    color: 'var(--neutral-800)',
    borderRadius: 'var(--radius-button)',
    border: '1px solid var(--neutral-200)',
  },
  ghost: {
    backgroundColor: 'transparent',
    color: 'var(--neutral-800)',
    borderRadius: 'var(--radius-button)',
  },
  destructive: {
    backgroundColor: 'var(--danger)',
    color: 'var(--white)',
    borderRadius: 'var(--radius-button)',
  },
};

const hoverStyles: Record<string, Partial<React.CSSProperties>> = {
  primary: { backgroundColor: 'var(--brand-primary-hover)', boxShadow: 'var(--shadow-brand-hover)' },
  secondary: { backgroundColor: 'var(--neutral-50)' },
  ghost: { backgroundColor: 'var(--neutral-100)' },
  destructive: { backgroundColor: 'var(--danger-text)' },
};

const sizeStyles: Record<string, React.CSSProperties> = {
  sm: { height: '32px', padding: '0 12px', fontSize: '12px', fontWeight: 500, lineHeight: '1.4' },
  md: { height: '40px', padding: '0 20px', fontSize: '14px', fontWeight: 500, lineHeight: '1.5' },
  lg: { height: '48px', padding: '0 24px', fontSize: '14px', fontWeight: 500, lineHeight: '1.5' },
};

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', loading, disabled, children, style, ...props }, ref) => {
    const v = variant ?? 'primary';
    const s = size ?? 'md';
    const isDisabled = disabled || loading;

    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        disabled={isDisabled}
        style={{
          ...variantStyles[v],
          ...sizeStyles[s],
          opacity: isDisabled ? 0.5 : 1,
          cursor: isDisabled ? 'not-allowed' : 'pointer',
          transitionDuration: 'var(--duration-standard)',
          transitionTimingFunction: 'var(--ease-apple)',
          ...style,
        }}
        onMouseEnter={(e) => {
          if (!isDisabled) {
            const hover = hoverStyles[v];
            if (hover) {
              Object.assign(e.currentTarget.style, hover);
            }
          }
          props.onMouseEnter?.(e);
        }}
        onMouseLeave={(e) => {
          if (!isDisabled) {
            Object.assign(e.currentTarget.style, variantStyles[v]);
          }
          props.onMouseLeave?.(e);
        }}
        {...props}
      >
        {loading && <Loader2 style={{ width: '16px', height: '16px', animation: 'spin 1s linear infinite' }} />}
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
export { buttonVariants };

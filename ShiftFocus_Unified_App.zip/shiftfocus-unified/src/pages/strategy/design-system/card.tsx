import React, { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const cardVariants = cva('overflow-hidden', {
  variants: {
    variant: {
      default: '',
      bordered: '',
      elevated: '',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
});

const variantStyleMap: Record<string, React.CSSProperties> = {
  default: {
    backgroundColor: 'var(--bg-level-0)',
    borderRadius: 'var(--radius-card)',
    border: '1px solid var(--neutral-200)',
    boxShadow: 'var(--shadow-card)',
  },
  bordered: {
    backgroundColor: 'var(--bg-level-0)',
    borderRadius: 'var(--radius-card)',
    border: '1px solid var(--neutral-200)',
  },
  elevated: {
    backgroundColor: 'var(--bg-level-0)',
    borderRadius: 'var(--radius-card)',
    boxShadow: 'var(--shadow-elevated)',
  },
};

export interface CardProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof cardVariants> {}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className, variant = 'default', style, ...props }, ref) => {
    const v = variant ?? 'default';

    return (
      <div
        ref={ref}
        className={cn(cardVariants({ variant }), className)}
        style={{
          ...variantStyleMap[v],
          ...style,
        }}
        {...props}
      />
    );
  }
);

Card.displayName = 'Card';

export const CardHeader = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, style, ...props }, ref) => (
    <div
      ref={ref}
      className={cn('flex flex-col gap-1', className)}
      style={{ padding: '24px 24px 0', ...style }}
      {...props}
    />
  )
);
CardHeader.displayName = 'CardHeader';

export const CardContent = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, style, ...props }, ref) => (
    <div
      ref={ref}
      className={className}
      style={{ padding: '24px', ...style }}
      {...props}
    />
  )
);
CardContent.displayName = 'CardContent';

export { cardVariants };

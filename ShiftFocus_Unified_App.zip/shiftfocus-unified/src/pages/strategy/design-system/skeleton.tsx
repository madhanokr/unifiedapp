import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const skeletonVariants = cva('animate-pulse', {
  variants: {
    variant: {
      text: '',
      circle: '',
      rect: '',
    },
  },
  defaultVariants: {
    variant: 'rect',
  },
});

const variantStyles: Record<string, React.CSSProperties> = {
  text: {
    height: '14px',
    borderRadius: 'var(--radius-badge)',
    backgroundColor: 'var(--neutral-100)',
  },
  circle: {
    borderRadius: '50%',
    backgroundColor: 'var(--neutral-100)',
  },
  rect: {
    borderRadius: 'var(--radius-input)',
    backgroundColor: 'var(--neutral-100)',
  },
};

export interface SkeletonProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonVariants> {
  width?: string | number;
  height?: string | number;
}

export function Skeleton({
  className,
  variant = 'rect',
  width,
  height,
  style,
  ...props
}: SkeletonProps) {
  const v = variant ?? 'rect';

  return (
    <div
      className={cn(skeletonVariants({ variant }), className)}
      style={{
        ...variantStyles[v],
        width: width || '100%',
        height: height || variantStyles[v].height || '40px',
        ...style,
      }}
      {...props}
    />
  );
}

export function CardSkeleton() {
  return (
    <div
      style={{
        padding: '24px',
        backgroundColor: 'var(--bg-level-0)',
        borderRadius: 'var(--radius-card)',
        border: '1px solid var(--neutral-200)',
      }}
    >
      <Skeleton variant="text" width="60%" style={{ marginBottom: '16px', height: '20px' }} />
      <Skeleton variant="text" width="100%" style={{ marginBottom: '8px' }} />
      <Skeleton variant="text" width="80%" style={{ marginBottom: '24px' }} />
      <Skeleton variant="rect" height="8px" style={{ marginBottom: '16px' }} />
      <div className="flex gap-3">
        <Skeleton variant="rect" width="80px" height="28px" />
        <Skeleton variant="rect" width="80px" height="28px" />
      </div>
    </div>
  );
}

export function MetricSkeleton() {
  return (
    <div
      style={{
        padding: '20px',
        backgroundColor: 'var(--bg-level-0)',
        borderRadius: 'var(--radius-card)',
        border: '1px solid var(--neutral-200)',
      }}
    >
      <Skeleton variant="text" width="40%" style={{ marginBottom: '12px', height: '12px' }} />
      <Skeleton variant="text" width="50%" style={{ marginBottom: '8px', height: '32px' }} />
      <Skeleton variant="rect" height="8px" />
    </div>
  );
}

export { skeletonVariants };

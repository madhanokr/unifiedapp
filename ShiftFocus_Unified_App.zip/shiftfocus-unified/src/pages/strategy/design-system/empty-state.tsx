import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Inbox } from 'lucide-react';
import { Button } from './button';

const emptyStateVariants = cva('flex flex-col items-center justify-center text-center', {
  variants: {
    size: {
      sm: '',
      md: '',
      lg: '',
    },
  },
  defaultVariants: {
    size: 'md',
  },
});

const sizePadding: Record<string, string> = {
  sm: '24px',
  md: '48px',
  lg: '64px',
};

export interface EmptyStateProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof emptyStateVariants> {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({
  className,
  size = 'md',
  icon,
  title,
  description,
  actionLabel,
  onAction,
  style,
  ...props
}: EmptyStateProps) {
  const s = size ?? 'md';

  return (
    <div
      className={cn(emptyStateVariants({ size }), className)}
      style={{
        padding: sizePadding[s],
        backgroundColor: 'var(--bg-level-0)',
        borderRadius: 'var(--radius-card)',
        border: '1px solid var(--neutral-200)',
        ...style,
      }}
      {...props}
    >
      <div
        className="flex items-center justify-center"
        style={{
          width: '48px',
          height: '48px',
          borderRadius: 'var(--radius-card)',
          backgroundColor: 'var(--neutral-100)',
          marginBottom: '16px',
        }}
      >
        {icon || <Inbox style={{ width: '24px', height: '24px', color: 'var(--neutral-400)' }} />}
      </div>
      <div
        className="text-body-medium"
        style={{ color: 'var(--neutral-800)', marginBottom: '4px' }}
      >
        {title}
      </div>
      {description && (
        <p
          className="text-caption"
          style={{ color: 'var(--neutral-600)', marginBottom: actionLabel ? '16px' : '0', maxWidth: '320px' }}
        >
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <Button variant="primary" size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}

export { emptyStateVariants };

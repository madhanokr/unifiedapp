import React, { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const progressVariants = cva('w-full rounded-full', {
  variants: {
    variant: {
      success: '',
      warning: '',
      danger: '',
      brand: '',
      auto: '',
    },
    size: {
      sm: '',
      md: '',
    },
  },
  defaultVariants: {
    variant: 'brand',
    size: 'sm',
  },
});

const fillColorMap: Record<string, string> = {
  success: 'var(--success)',
  warning: 'var(--warning)',
  danger: 'var(--danger)',
  brand: 'var(--brand-primary)',
  auto: 'var(--brand-primary)',
};

const sizeMap: Record<string, string> = {
  sm: '6px',
  md: '8px',
};

function getAutoColor(value: number): string {
  if (value >= 80) return 'var(--success)';
  if (value >= 50) return 'var(--warning)';
  return 'var(--danger)';
}

export interface ProgressBarProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof progressVariants> {
  value: number;
  trackColor?: string;
}

export const ProgressBar = forwardRef<HTMLDivElement, ProgressBarProps>(
  ({ className, variant = 'brand', size = 'sm', value, trackColor, style, ...props }, ref) => {
    const v = variant ?? 'brand';
    const s = size ?? 'sm';
    const fillColor = v === 'auto' ? getAutoColor(value) : fillColorMap[v];

    return (
      <div
        ref={ref}
        className={cn(progressVariants({ variant, size }), className)}
        style={{
          height: sizeMap[s],
          backgroundColor: trackColor || 'var(--neutral-100)',
          ...style,
        }}
        {...props}
      >
        <div
          className="h-full rounded-full"
          style={{
            width: `${Math.min(100, Math.max(0, value))}%`,
            backgroundColor: fillColor,
            transition: `width var(--duration-standard) var(--ease-apple)`,
          }}
        />
      </div>
    );
  }
);

ProgressBar.displayName = 'ProgressBar';
export { progressVariants };

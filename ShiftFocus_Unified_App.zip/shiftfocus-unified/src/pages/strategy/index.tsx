import { useState } from 'react';
import { StrategicCommandCenter } from './strategy/StrategicCommandCenter';
import { StrategicThemes } from './strategy/StrategicThemes';
import { PlanningBoard } from './strategy/PlanningBoard';
import { CoherenceEngine } from './strategy/CoherenceEngine';
import { MultiYearMap } from './strategy/MultiYearMap';
import { StrategicStory } from './strategy/StrategicStory';
import { AICoach } from './strategy/AICoach';
import { Target, Calendar, AlertTriangle, Sparkles, BookOpen } from 'lucide-react';

export default function StrategyPage() {
  const [timeHorizon, setTimeHorizon] = useState<'quarterly' | 'annual' | '3-year'>('quarterly');
  const [activeSection, setActiveSection] = useState('command');

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="max-w-[1400px] mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <h1 style={{ fontSize: '24px', fontWeight: 600, color: 'var(--neutral-800)' }}>Strategy Planning</h1>
        <div className="flex items-center gap-2">
          {(['quarterly', 'annual', '3-year'] as const).map((h) => (
            <button
              key={h}
              onClick={() => setTimeHorizon(h)}
              className="px-3 py-1.5 rounded-lg transition-all"
              style={{
                fontSize: '13px',
                fontWeight: timeHorizon === h ? 600 : 500,
                color: timeHorizon === h ? 'var(--brand-primary)' : 'var(--neutral-600)',
                backgroundColor: timeHorizon === h ? 'var(--brand-primary-light)' : 'transparent',
                border: timeHorizon === h ? '1px solid var(--brand-primary)' : '1px solid var(--neutral-200)',
              }}
            >
              {h.charAt(0).toUpperCase() + h.slice(1)}
            </button>
          ))}
        </div>
      </div>
      <div id="command"><StrategicCommandCenter timeHorizon={timeHorizon} /></div>
      <div id="themes"><StrategicThemes timeHorizon={timeHorizon} /></div>
      <div id="planning"><PlanningBoard timeHorizon={timeHorizon} /></div>
      <div id="coherence"><CoherenceEngine /></div>
      <div id="story"><StrategicStory /></div>
      <AICoach />
    </div>
  );
}

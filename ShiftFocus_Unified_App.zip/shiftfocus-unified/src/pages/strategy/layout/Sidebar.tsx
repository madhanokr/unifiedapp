import React, { useState } from 'react';
import {
  LayoutDashboard,
  Target,
  Users,
  TrendingUp,
  Brain,
  Settings,
  ChevronLeft,
  ChevronRight,
  FileText,
  Calendar,
  BarChart3,
  CheckSquare,
  Sparkles,
  Layers,
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const [activeItem, setActiveItem] = useState('strategy-room');

  const navSections = [
    {
      label: 'MAIN MENU',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
        { id: 'timeline', label: 'Timeline', icon: Calendar },
        { id: 'health', label: 'OKR Health', icon: TrendingUp },
        { id: 'team-intelligence', label: 'Team Intelligence', icon: Brain },
        { id: 'team-comparison', label: 'Team Comparison', icon: Users },
        { id: 'activity', label: 'Activity', icon: FileText },
        { id: 'weekly-report', label: 'Weekly Report', icon: BarChart3 },
      ],
    },
    {
      label: 'OKRs',
      items: [
        { id: 'objectives', label: 'Objectives', icon: Target },
        { id: 'results', label: 'Results', icon: CheckSquare },
        { id: 'strategy-room', label: 'Strategy Room', icon: Sparkles },
        { id: 'kr-intelligence', label: 'KR Intelligence', icon: Brain },
        { id: 'okr-list', label: 'OKR List', icon: Layers },
      ],
    },
    {
      label: 'ADMIN & SETTINGS',
      items: [{ id: 'settings', label: 'Settings', icon: Settings }],
    },
  ];

  return (
    <aside
      className="fixed left-0 top-0 h-full"
      style={{
        width: collapsed ? '64px' : '240px',
        backgroundColor: 'var(--bg-level-0)',
        borderRight: '1px solid var(--neutral-200)',
        transition: `width var(--duration-standard) var(--ease-apple)`,
        zIndex: 50,
      }}
    >
      <div className="flex flex-col h-full">
        <div
          className="flex items-center"
          style={{
            height: '64px',
            padding: '0 16px',
            borderBottom: '1px solid var(--neutral-200)',
          }}
        >
          {!collapsed && (
            <span
              className="text-h3"
              style={{ color: 'var(--neutral-800)', letterSpacing: '-0.01em' }}
            >
              ShiftFocus
            </span>
          )}
          {collapsed && (
            <span
              className="text-h2"
              style={{ color: 'var(--brand-primary)', margin: '0 auto' }}
            >
              S
            </span>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto" style={{ padding: '16px 8px' }}>
          {navSections.map((section, sectionIdx) => (
            <div
              key={section.label}
              style={{ marginBottom: sectionIdx < navSections.length - 1 ? '32px' : '0' }}
            >
              {!collapsed && (
                <div style={{ padding: '0 12px', marginBottom: '8px' }}>
                  <span
                    className="text-micro"
                    style={{ color: 'var(--neutral-400)', fontWeight: 600, letterSpacing: '0.08em' }}
                  >
                    {section.label}
                  </span>
                </div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeItem === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveItem(item.id)}
                      className="w-full flex items-center gap-3 rounded-lg"
                      style={{
                        height: '40px',
                        padding: collapsed ? '0' : '0 12px',
                        justifyContent: collapsed ? 'center' : 'flex-start',
                        backgroundColor: isActive ? 'var(--brand-primary)' : 'transparent',
                        color: isActive ? 'var(--white)' : 'var(--neutral-600)',
                        border: 'none',
                        cursor: 'pointer',
                        transition: `all var(--duration-standard) var(--ease-apple)`,
                      }}
                      title={collapsed ? item.label : ''}
                      onMouseEnter={(e) => {
                        if (!isActive) {
                          e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                          e.currentTarget.style.color = 'var(--neutral-800)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!isActive) {
                          e.currentTarget.style.backgroundColor = 'transparent';
                          e.currentTarget.style.color = 'var(--neutral-600)';
                        }
                      }}
                    >
                      <Icon style={{ width: '20px', height: '20px', flexShrink: 0 }} />
                      {!collapsed && (
                        <span className="text-body-medium truncate">{item.label}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div style={{ borderTop: '1px solid var(--neutral-200)', padding: '8px' }}>
          <button
            onClick={onToggle}
            className="w-full flex items-center justify-center rounded-lg"
            style={{
              height: '40px',
              color: 'var(--neutral-600)',
              border: 'none',
              backgroundColor: 'transparent',
              cursor: 'pointer',
              transition: `background-color var(--duration-standard) var(--ease-apple)`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            {collapsed ? (
              <ChevronRight style={{ width: '20px', height: '20px' }} />
            ) : (
              <ChevronLeft style={{ width: '20px', height: '20px' }} />
            )}
          </button>
        </div>
      </div>
    </aside>
  );
}
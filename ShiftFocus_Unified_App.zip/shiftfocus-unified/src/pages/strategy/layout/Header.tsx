import React from 'react';
import { Search, Bell, Sparkles, ChevronDown } from 'lucide-react';
import { Button } from '../design-system/button';

export function Header() {
  return (
    <header
      className="sticky top-0"
      style={{
        height: '64px',
        backgroundColor: 'var(--bg-level-0)',
        borderBottom: '1px solid var(--neutral-200)',
        boxShadow: 'var(--shadow-card)',
        zIndex: 60,
      }}
    >
      <div className="h-full px-6 flex items-center justify-between">
        <div className="flex-1 max-w-lg">
          <div className="relative">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              style={{ width: '16px', height: '16px', color: 'var(--neutral-400)' }}
            />
            <input
              type="text"
              placeholder="Search..."
              className="w-full text-body"
              style={{
                height: '40px',
                paddingLeft: '40px',
                paddingRight: '56px',
                backgroundColor: 'var(--neutral-50)',
                border: '1px solid var(--neutral-200)',
                borderRadius: 'var(--radius-input)',
                color: 'var(--neutral-800)',
                transition: `all var(--duration-standard) var(--ease-apple)`,
              }}
              onFocus={(e) => {
                e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
                e.currentTarget.style.borderColor = 'var(--brand-primary)';
                e.currentTarget.style.backgroundColor = 'var(--bg-level-0)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.borderColor = 'var(--neutral-200)';
                e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
              }}
            />
            <kbd
              className="absolute right-3 top-1/2 -translate-y-1/2 px-2 py-1 text-caption-medium pointer-events-none"
              style={{
                backgroundColor: 'var(--bg-level-0)',
                border: '1px solid var(--neutral-200)',
                borderRadius: 'var(--radius-badge)',
                color: 'var(--neutral-400)',
                height: '24px',
                display: 'inline-flex',
                alignItems: 'center',
              }}
            >
              /
            </kbd>
          </div>
        </div>

        <div className="flex items-center gap-2 ml-6">
          <Button variant="ghost" size="sm">
            Make a note
          </Button>
          <Button variant="primary" size="sm">
            Save
          </Button>

          <div
            style={{
              width: '1px',
              height: '24px',
              backgroundColor: 'var(--neutral-200)',
              margin: '0 8px',
            }}
          />

          <button
            className="relative rounded-lg"
            style={{
              width: '36px',
              height: '36px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--neutral-600)',
              border: 'none',
              backgroundColor: 'transparent',
              cursor: 'pointer',
              transition: `background-color var(--duration-standard) var(--ease-apple)`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <Bell style={{ width: '20px', height: '20px' }} />
            <span
              className="absolute rounded-full"
              style={{
                top: '6px',
                right: '6px',
                width: '8px',
                height: '8px',
                backgroundColor: 'var(--danger)',
                border: '2px solid var(--bg-level-0)',
              }}
            />
          </button>

          <button
            className="flex items-center gap-2 rounded-lg"
            style={{
              height: '36px',
              padding: '0 12px',
              color: 'var(--neutral-600)',
              border: 'none',
              backgroundColor: 'transparent',
              cursor: 'pointer',
              transition: `background-color var(--duration-standard) var(--ease-apple)`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <Sparkles style={{ width: '20px', height: '20px' }} />
            <span className="text-body-medium">Ask AI</span>
          </button>

          <button
            className="flex items-center gap-2 rounded-lg"
            style={{
              height: '36px',
              padding: '0 8px',
              border: 'none',
              backgroundColor: 'transparent',
              cursor: 'pointer',
              transition: `background-color var(--duration-standard) var(--ease-apple)`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
            }}
          >
            <div
              className="rounded-full flex items-center justify-center"
              style={{
                width: '32px',
                height: '32px',
                backgroundColor: 'var(--brand-primary)',
              }}
            >
              <span className="text-caption-medium" style={{ color: 'var(--white)' }}>
                JD
              </span>
            </div>
            <ChevronDown style={{ width: '16px', height: '16px', color: 'var(--neutral-600)' }} />
          </button>
        </div>
      </div>
    </header>
  );
}

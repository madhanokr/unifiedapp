/**
 * useSimulatedLoad — Phase 3: Simulated async fetch with loading/error/retry
 * 
 * Wraps a synchronous localStorage read in an 800ms simulated delay
 * to represent future API calls. Provides loading, error, and retry states.
 * 
 * Usage:
 *   const { data, state, error, retry, setData } = useSimulatedLoad(() => db.getKeyResults());
 */
import { useState, useEffect, useCallback, useRef } from 'react';

export type LoadState = 'loading' | 'error' | 'ready';

export interface UseSimulatedLoadResult<T> {
  data: T | null;
  state: LoadState;
  error: string | null;
  retry: () => void;
  /** Optimistic setter — directly mutate data without re-triggering load */
  setData: React.Dispatch<React.SetStateAction<T | null>>;
}

export function useSimulatedLoad<T>(
  loader: () => T,
  /** Duration of simulated loading in ms (default 800) */
  duration?: number,
): UseSimulatedLoadResult<T> {
  const [data, setData] = useState<T | null>(null);
  const [state, setState] = useState<LoadState>('loading');
  const [error, setError] = useState<string | null>(null);
  const mountedRef = useRef(true);
  const loadDuration = duration ?? 800;

  const load = useCallback(() => {
    setState('loading');
    setError(null);

    const timer = setTimeout(() => {
      if (!mountedRef.current) return;
      try {
        const result = loader();
        setData(result);
        setState('ready');
      } catch (e) {
        const msg = e instanceof Error ? e.message : 'Failed to load data from localStorage';
        setError(msg);
        setState('error');
      }
    }, loadDuration);

    return timer;
  }, [loader, loadDuration]);

  useEffect(() => {
    mountedRef.current = true;
    const timer = load();
    return () => {
      mountedRef.current = false;
      clearTimeout(timer);
    };
  }, []); // Only on mount — no re-triggers from deps

  const retry = useCallback(() => {
    load();
  }, [load]);

  return { data, state, error, retry, setData };
}

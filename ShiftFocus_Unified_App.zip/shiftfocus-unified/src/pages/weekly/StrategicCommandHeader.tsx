import { useState, useEffect } from 'react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger, OkrSkeleton } from './design-system';
import { db } from './db';

function HeaderSkeleton() {
  return (
    <div className="bg-white/80 backdrop-blur-xl border-b border-[var(--neutral-200)]">
      <div className="max-w-[1320px] mx-auto px-8">
        <div className="flex items-center h-[72px]">
          <div className="flex-shrink-0 mr-12">
            <OkrSkeleton variant="text" height={10} width={100} />
          </div>
          <div className="flex items-center gap-8 flex-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-baseline gap-2">
                <OkrSkeleton variant="text" height={10} width={60} />
                <OkrSkeleton variant="text" height={14} width={40} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function StrategicCommandHeader() {
  const [, setTick] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initial simulated load
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 800);
    return () => clearTimeout(timer);
  }, []);

  // Poll for changes every 2 seconds (lightweight) — only after initial load
  useEffect(() => {
    if (!isLoaded) return;
    const interval = setInterval(() => setTick(t => t + 1), 2000);
    return () => clearInterval(interval);
  }, [isLoaded]);

  if (!isLoaded) return <HeaderSkeleton />;

  let krs, kpis, teams, risks, alerts;
  try {
    krs = db.getKeyResults();
    kpis = db.getKPIs();
    teams = db.getTeams();
    risks = db.getRisks();
    alerts = db.getAlerts();
  } catch {
    // If localStorage fails, show skeleton as fallback
    return <HeaderSkeleton />;
  }

  const avgProgress = krs.length > 0 ? Math.round(krs.reduce((s, k) => s + k.progress, 0) / krs.length) : 0;
  const avgConfidence = teams.length > 0 ? Math.round(teams.reduce((s, t) => s + t.confidence, 0) / teams.length) : 0;
  const executionHealth = krs.length > 0
    ? Math.round((krs.filter(k => k.status === 'on-track').length / krs.length) * 100)
    : 0;
  const activeRisks = risks.filter(r => !r.resolved);
  const riskLevel = activeRisks.filter(r => r.severity === 'critical').length >= 2 ? 'High'
    : activeRisks.filter(r => r.severity === 'critical').length === 1 ? 'Medium'
    : 'Low';

  const updatedKRs = krs.filter(k => k.updatedAt).length;
  const velocityPct = krs.length > 0 ? Math.round((updatedKRs / krs.length) * 100) : 0;

  const metrics = [
    {
      label: 'Momentum',
      value: `+${Math.max(0, avgProgress - 60)}%`,
      trend: 'up' as const,
      tooltip: `Overall company execution velocity: ${avgProgress}% average KR progress`,
      color: 'text-[var(--brand-primary)]',
    },
    {
      label: 'Confidence',
      value: `${avgConfidence}%`,
      trend: avgConfidence >= 85 ? 'up' as const : 'down' as const,
      tooltip: `Team confidence score in achieving this quarter's outcomes: ${avgConfidence}%`,
      color: 'text-[var(--info)]',
    },
    {
      label: 'Execution Health',
      value: `${executionHealth}%`,
      trend: executionHealth >= 70 ? 'up' as const : 'down' as const,
      tooltip: `${krs.filter(k => k.status === 'on-track').length}/${krs.length} KRs on-track`,
      color: 'text-[var(--success-on-track)]',
    },
    {
      label: 'Predictive Velocity',
      value: `${velocityPct > 0 ? velocityPct + '%' : '91%'}`,
      trend: 'up' as const,
      tooltip: `Updated KRs this session: ${updatedKRs}/${krs.length}`,
      color: 'text-[var(--brand-primary)]',
    },
    {
      label: 'Weekly Risk',
      value: riskLevel,
      trend: riskLevel === 'Low' ? 'down' as const : 'up' as const,
      tooltip: `${activeRisks.length} active risks (${activeRisks.filter(r => r.severity === 'critical').length} critical)`,
      color: 'text-[var(--at-risk)]',
    }
  ];

  return (
    <div className="bg-white/80 backdrop-blur-xl border-b border-[var(--neutral-200)]">
      <div className="max-w-[1320px] mx-auto px-8">
        <TooltipProvider>
          <div className="flex items-center h-[72px]">
            {/* Label */}
            <div className="flex-shrink-0 mr-12">
              <div className="text-[10px] tracking-[0.05em] text-[var(--neutral-600)] uppercase font-medium">
                Strategic Telemetry
              </div>
            </div>

            {/* Metrics */}
            <div className="flex items-center gap-8 flex-1">
              {metrics.map((metric) => (
                <Tooltip key={metric.label}>
                  <TooltipTrigger asChild>
                    <div className="flex items-baseline gap-2 cursor-help hover:opacity-70 transition-opacity duration-120 transition-apple">
                      <span className="text-[10px] tracking-[0.05em] text-[var(--neutral-400)] uppercase font-medium">
                        {metric.label}
                      </span>
                      <span className={`text-[14px] font-[500] tabular-nums ${metric.color}`}>
                        {metric.value}
                      </span>
                      {metric.trend === 'up' && (
                        <span className="text-[10px] text-[var(--success-on-track)]">↗</span>
                      )}
                      {metric.trend === 'down' && (
                        <span className="text-[10px] text-[var(--at-risk)]">↘</span>
                      )}
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="text-[12px] max-w-[240px]">
                    <p>{metric.tooltip}</p>
                  </TooltipContent>
                </Tooltip>
              ))}
            </div>
          </div>
        </TooltipProvider>
      </div>
    </div>
  );
}
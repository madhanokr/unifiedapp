import { useState } from 'react';
import { StrategicCommandHeader } from './StrategicCommandHeader';
import { WeeklyNavigation } from './WeeklyNavigation';
import { HabitLoopRow } from './HabitLoopRow';
import { ThisWeekSnapshot } from './ThisWeekSnapshot';
import { LeadershipPulse } from './LeadershipPulse';
import { KRCheckInLane } from './KRCheckInLane';
import { KPIPulseLane } from './KPIPulseLane';
import { AICheckInAssistant } from './AICheckInAssistant';
import { WeeklyPredictionBox } from './WeeklyPredictionBox';

export default function WeeklyPage() {
  const [activeSection, setActiveSection] = useState('check-in');
  return (
    <div className="max-w-[1400px] mx-auto space-y-6">
      <StrategicCommandHeader />
      <WeeklyNavigation activeSection={activeSection} onSectionChange={setActiveSection} />
      <ThisWeekSnapshot />
      <LeadershipPulse />
      <HabitLoopRow />
      <KRCheckInLane />
      <KPIPulseLane />
      <AICheckInAssistant />
      <WeeklyPredictionBox />
    </div>
  );
}

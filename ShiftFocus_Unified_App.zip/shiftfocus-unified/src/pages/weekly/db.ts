/**
 * ShiftFocus localStorage Database Abstraction
 * ==========================================
 * Method-based db layer so when backend arrives,
 * it's just swapping db.getById() for api.getById().
 *
 * All data persists across sessions via localStorage.
 * Each entity uses a namespaced key: "shiftfocus:{entity}"
 */

// ─── Types ────────────────────────────────────────────

export interface Ritual {
  id: number;
  label: string;
  completed: boolean;
  tooltip: string;
}

export interface KeyResult {
  id: number;
  name: string;
  objective: string;
  owner: string;
  ownerAvatar: string;
  progress: number;
  change: string;
  confidence: 'High' | 'Medium' | 'Low';
  confidenceColor: string;
  lastUpdate: string;
  status: 'on-track' | 'at-risk' | 'blocked';
  updatedAt: string | null;
  progressHistory: number[];
}

export interface KPI {
  id: number;
  name: string;
  value: string;
  target: string;
  trend: 'up' | 'down' | 'stable';
  stability: 'STABLE' | 'MODERATE' | 'DRIFT';
  badge: 'AHEAD' | 'BEHIND' | 'PREDICTABLE' | 'DRIFT';
  iconBg: string;
  badgeColor: { bg: string; text: string };
  tooltip: string;
  updatedAt: string | null;
}

export interface Team {
  id: number;
  name: string;
  confidence: number;
  velocity: string;
  velocityTrend: 'up' | 'down';
  updates: string;
  completedItems: number;
  plannedItems: number;
  redFlags: number;
  verified: boolean;
  verifiedAt: string | null;
  tooltip: string;
}

export interface AccountabilityAlert {
  id: number;
  type: string;
  teams: string[];
  message: string;
  description: string;
  severity: string;
  bgColor: string;
  borderColor: string;
  iconBg: string;
  badgeColor: { bg: string; text: string };
  tooltip: string;
  action: string;
  resolved: boolean;
  resolvedAt: string | null;
}

export interface Risk {
  id: number;
  severity: 'critical' | 'moderate' | 'low';
  title: string;
  description: string;
  impact: string;
  probability: string;
  category: string;
  riskType: string;
  resolved: boolean;
  resolvedAt: string | null;
}

export interface Prediction {
  momentum: 'up' | 'down' | 'stable' | null;
  confidence: 'up' | 'down' | 'stable' | null;
  risk: 'up' | 'down' | 'stable' | null;
  savedAt: string | null;
}

export interface CEONotes {
  content: string;
  savedAt: string | null;
  history: { content: string; savedAt: string }[];
}

export interface WeeklyStreak {
  count: number;
  lastCompletedWeek: string | null;
}

export interface Blocker {
  id: number;
  type: string;
  title: string;
  source: string;
  severity: 'high' | 'medium' | 'low';
  aiSolution: string;
  applied: boolean;
  dismissed: boolean;
}

export interface LeadershipPulseItem {
  id: number;
  count: number;
  label: string;
  description: string;
  bgColor: string;
  borderColor: string;
  iconBg: string;
  tooltip: string;
  resolved: boolean;
}

export interface AlignmentIssue {
  id: number;
  type: string;
  count: number;
  description: string;
  iconBg: string;
  bgColor: string;
  borderColor: string;
  badgeColor: { bg: string; text: string };
  details: string[];
  resolved: boolean;
  resolvedAt: string | null;
}

export interface GradeState {
  sentToLeadership: boolean;
  sentAt: string | null;
  exported: boolean;
  exportedAt: string | null;
}

export interface ComputedGrade {
  grade: string;
  score: number;
  previousGrade: string;
  trend: 'up' | 'down' | 'stable';
  breakdown: { metric: string; score: number; weight: number }[];
  insights: string[];
}

export interface ComputedStory {
  improved: string[];
  slowedDown: string[];
  changed: string[];
  newBlockers: string[];
  aiRecommendations: string[];
}

// ─── Week Snapshot Types ──────────────────────────────

export interface WeekSnapshot {
  rituals: Ritual[];
  streak: WeeklyStreak;
  keyResults: KeyResult[];
  kpis: KPI[];
  teams: Team[];
  alerts: AccountabilityAlert[];
  risks: Risk[];
  prediction: Prediction;
  ceoNotes: CEONotes;
  blockers: Blocker[];
  pulseItems: LeadershipPulseItem[];
  alignmentIssues: AlignmentIssue[];
  gradeState: GradeState;
  computedGrade: ComputedGrade;
  computedStory: ComputedStory;
}

export interface WeekOption {
  id: string;
  label: string;
  dateRange: string;
  isHistorical: boolean;
  grade?: string;
  status?: 'completed' | 'in-progress' | 'missed';
}

// ─── Module-level View State ──────────────────────────

let _activeViewWeek: string | null = null;

// ─── Default Seeds ────────────────────────────────────

const DEFAULT_RITUALS: Ritual[] = [
  { id: 1, label: 'Update KRs', completed: false, tooltip: 'Keep your Key Results current to maintain strategic visibility' },
  { id: 2, label: 'Update KPIs', completed: false, tooltip: 'Fresh KPI data ensures accurate performance tracking' },
  { id: 3, label: 'Resolve blockers', completed: false, tooltip: 'Clear obstacles to maintain momentum and velocity' },
  { id: 4, label: 'Review team confidence', completed: false, tooltip: 'Check team morale and belief in achieving outcomes' },
  { id: 5, label: 'Run "Fix My Week"', completed: false, tooltip: 'Let AI analyze and prioritize your weekly execution plan' },
];

const DEFAULT_KEY_RESULTS: KeyResult[] = [
  {
    id: 1, name: 'Launch AI-Powered Execution Intelligence Platform',
    objective: 'Scale Enterprise Customer Success Program', owner: 'Sarah Chen', ownerAvatar: 'SC',
    progress: 72, change: '+12', confidence: 'High', confidenceColor: '#40C78C',
    lastUpdate: '2 days ago: Completed user testing phase', status: 'on-track',
    updatedAt: null, progressHistory: [40, 48, 55, 60, 68, 72]
  },
  {
    id: 2, name: 'Ship 6 core AI prediction features',
    objective: 'Scale Enterprise Customer Success Program', owner: 'Mike Johnson', ownerAvatar: 'MJ',
    progress: 85, change: '+8', confidence: 'High', confidenceColor: '#40C78C',
    lastUpdate: 'Yesterday: 5 of 6 features shipped', status: 'on-track',
    updatedAt: null, progressHistory: [50, 58, 65, 72, 78, 85]
  },
  {
    id: 3, name: 'Achieve Product-Market Fit in Enterprise Segment',
    objective: 'Build Strategic Partnership Ecosystem', owner: 'Emily Davis', ownerAvatar: 'ED',
    progress: 40, change: '-3', confidence: 'Medium', confidenceColor: '#F98B2B',
    lastUpdate: '3 days ago: Delayed due to resource constraints', status: 'at-risk',
    updatedAt: null, progressHistory: [30, 35, 38, 42, 43, 40]
  },
  {
    id: 4, name: 'Scale Platform Performance & Reliability',
    objective: 'Scale Enterprise Customer Success Program', owner: 'David Kim', ownerAvatar: 'DK',
    progress: 91, change: '+5', confidence: 'High', confidenceColor: '#40C78C',
    lastUpdate: 'Today: Performance benchmarks exceeded', status: 'on-track',
    updatedAt: null, progressHistory: [70, 75, 80, 84, 88, 91]
  }
];

const DEFAULT_KPIS: KPI[] = [
  { id: 1, name: 'Customer Success Rate', value: '+18%', target: '15%', trend: 'up', stability: 'STABLE', badge: 'AHEAD', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Customer retention and success metrics trending above target', updatedAt: null },
  { id: 2, name: 'Revenue Growth', value: '$2.4M', target: '$2.5M', trend: 'up', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Monthly recurring revenue growth rate vs target', updatedAt: null },
  { id: 3, name: 'Platform Uptime', value: '99.8%', target: '99.5%', trend: 'stable', stability: 'STABLE', badge: 'PREDICTABLE', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'System availability and reliability metrics', updatedAt: null },
  { id: 4, name: 'Customer NPS', value: '67', target: '70', trend: 'down', stability: 'DRIFT', badge: 'DRIFT', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Net Promoter Score showing customer satisfaction trends', updatedAt: null },
  { id: 5, name: 'Team Velocity', value: '94%', target: '90%', trend: 'up', stability: 'STABLE', badge: 'AHEAD', iconBg: '#6A3DE8', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Team execution speed and delivery rate', updatedAt: null },
];

const DEFAULT_TEAMS: Team[] = [
  { id: 1, name: 'Engineering', confidence: 92, velocity: '+15%', velocityTrend: 'up', updates: 'Shipped 5/6 AI prediction features ahead of schedule', completedItems: 12, plannedItems: 8, redFlags: 0, verified: true, verifiedAt: null, tooltip: 'Engineering team showing strong upward momentum with consistent delivery' },
  { id: 2, name: 'Product', confidence: 87, velocity: '+8%', velocityTrend: 'up', updates: 'User testing completed, incorporating feedback', completedItems: 9, plannedItems: 11, redFlags: 1, verified: false, verifiedAt: null, tooltip: 'Product team maintaining steady progress with one minor blocker' },
  { id: 3, name: 'Sales', confidence: 78, velocity: '-3%', velocityTrend: 'down', updates: 'Pipeline healthy but conversion rate dipping', completedItems: 6, plannedItems: 9, redFlags: 2, verified: false, verifiedAt: null, tooltip: 'Sales team experiencing temporary slowdown, requires attention' },
  { id: 4, name: 'Marketing', confidence: 94, velocity: '+12%', velocityTrend: 'up', updates: 'Campaign performance exceeding targets', completedItems: 14, plannedItems: 7, redFlags: 0, verified: true, verifiedAt: null, tooltip: 'Marketing team on fire with exceptional performance this week' },
  { id: 5, name: 'Customer Success', confidence: 85, velocity: '+5%', velocityTrend: 'up', updates: 'NPS recovery initiatives launched', completedItems: 10, plannedItems: 10, redFlags: 1, verified: false, verifiedAt: null, tooltip: 'Customer Success showing gradual improvement with consistent execution' },
  { id: 6, name: 'Operations', confidence: 90, velocity: '+10%', velocityTrend: 'up', updates: 'Process standardization delivering results', completedItems: 8, plannedItems: 6, redFlags: 0, verified: true, verifiedAt: null, tooltip: 'Operations driving efficiency gains with strong upward trajectory' },
];

const DEFAULT_ALERTS: AccountabilityAlert[] = [
  { id: 1, type: 'missing-checkin', teams: ['Sales', 'Operations'], message: '2 teams — check-in overdue', description: 'Sales and Operations teams have not submitted required weekly updates', severity: 'requires intervention', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Teams that haven\'t completed their weekly check-in ritual', action: 'Escalate Now', resolved: false, resolvedAt: null },
  { id: 2, type: 'zero-movement', teams: ['Customer Success'], message: '1 team — silence breach detected', description: 'Customer Success has made no progress on assigned KRs this week', severity: 'verification failed', bgColor: '#FFE5E5', borderColor: '#E53935', iconBg: '#E53935', badgeColor: { bg: '#FFE5E5', text: '#E53935' }, tooltip: 'Teams with no measurable progress on their objectives', action: 'Fix Now', resolved: false, resolvedAt: null },
  { id: 3, type: 'blocked-dependencies', teams: ['Product'], message: '1 team — escalation pending', description: 'Product team blocked by Engineering resource allocation', severity: 'pending verification', bgColor: '#FFF2E6', borderColor: '#F5A623', iconBg: '#F5A623', badgeColor: { bg: '#FFF2E6', text: '#F5A623' }, tooltip: 'Teams waiting on other teams to unblock their work', action: 'Verify Now', resolved: false, resolvedAt: null },
];

const DEFAULT_RISKS: Risk[] = [
  { id: 1, severity: 'critical', title: 'Q1 Revenue Target At Risk', description: 'Current pipeline conversion rate 12% below target, may impact quarterly revenue goal', impact: 'High', probability: '78%', category: 'Revenue', riskType: 'critical', resolved: false, resolvedAt: null },
  { id: 2, severity: 'critical', title: 'Key Engineering Resource Leaving', description: 'Lead platform engineer gave notice, critical knowledge transfer needed', impact: 'High', probability: '95%', category: 'Team', riskType: 'critical', resolved: false, resolvedAt: null },
  { id: 3, severity: 'moderate', title: 'Customer Churn Trending Up', description: 'NPS scores declining, early indicator of potential churn increase', impact: 'Medium', probability: '65%', category: 'Customer', riskType: 'business', resolved: false, resolvedAt: null },
  { id: 4, severity: 'moderate', title: 'Feature Delivery Timeline Slipping', description: 'AI prediction features delayed by 1 week due to integration complexity', impact: 'Medium', probability: '70%', category: 'Product', riskType: 'technical', resolved: false, resolvedAt: null },
  { id: 5, severity: 'moderate', title: 'Marketing Campaign Budget Overrun', description: 'Q1 marketing spend 15% over budget, may need reallocation', impact: 'Medium', probability: '60%', category: 'Finance', riskType: 'business', resolved: false, resolvedAt: null },
  { id: 6, severity: 'moderate', title: 'Strategic Partnership Negotiations Stalled', description: 'Key partnership discussions paused, may delay market expansion', impact: 'Medium', probability: '55%', category: 'Strategy', riskType: 'business', resolved: false, resolvedAt: null },
  { id: 7, severity: 'moderate', title: 'Platform Performance Degradation', description: 'Response times increasing as user base grows, scaling required', impact: 'Medium', probability: '50%', category: 'Technical', riskType: 'technical', resolved: false, resolvedAt: null },
  { id: 8, severity: 'low', title: 'Office Lease Renewal Due', description: 'Current lease expires in 60 days, need to finalize renewal', impact: 'Low', probability: '40%', category: 'Operations', riskType: 'operational', resolved: false, resolvedAt: null },
];

const DEFAULT_PREDICTION: Prediction = {
  momentum: null,
  confidence: null,
  risk: null,
  savedAt: null,
};

const DEFAULT_CEO_NOTES: CEONotes = {
  content: "This week we made significant progress on the AI features, but the Enterprise PMF timeline is concerning. Need to have a serious conversation with the team about resource allocation.\n\nKey decisions for next week:\n- Approve budget reallocation for PMF push\n- Review engineering hiring pipeline\n- Schedule all-hands on Q1 priorities",
  savedAt: null,
  history: [],
};

const DEFAULT_STREAK: WeeklyStreak = {
  count: 12,
  lastCompletedWeek: null,
};

const DEFAULT_BLOCKERS: Blocker[] = [
  { id: 1, type: 'KR', title: 'Resource constraints delaying PMF achievement', source: 'Achieve Product-Market Fit in Enterprise Segment', severity: 'high', aiSolution: 'Reassign 2 engineers from Platform team for 2 weeks', applied: false, dismissed: false },
  { id: 2, type: 'KPI', title: 'Customer NPS trending below target', source: 'Customer NPS', severity: 'medium', aiSolution: 'Launch customer success initiative with automated check-ins', applied: false, dismissed: false },
  { id: 3, type: 'Risk', title: 'Q1 targets may slip due to velocity drop', source: 'Strategic Risk Radar', severity: 'high', aiSolution: 'Adjust timeline by 1 week and communicate to stakeholders', applied: false, dismissed: false },
];

const DEFAULT_PULSE_ITEMS: LeadershipPulseItem[] = [
  { id: 1, count: 3, label: 'overdue updates', description: '2 KRs and 1 KPI need your attention', bgColor: '#FFE5E5', borderColor: '#E53935', iconBg: '#E53935', tooltip: 'Key Results and KPIs that haven\'t been updated in 7+ days', resolved: false },
  { id: 2, count: 2, label: 'blockers assigned to you', description: 'Resource allocation and budget approval', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', tooltip: 'Active blockers that require your direct intervention to resolve', resolved: false },
  { id: 3, count: 1, label: 'misalignment requires CEO approval', description: 'Sales-Product priority conflict', bgColor: 'rgba(106, 61, 232, 0.08)', borderColor: '#6A3DE8', iconBg: '#6A3DE8', tooltip: 'Cross-team conflicts that need executive decision-making', resolved: false },
  { id: 4, count: 4, label: 'items awaiting leadership decision', description: 'Strategic pivots and resource requests', bgColor: '#E5ECFF', borderColor: '#3E8BFF', iconBg: '#3E8BFF', tooltip: 'Pending decisions that are blocking team progress', resolved: false },
];

const DEFAULT_ALIGNMENT_ISSUES: AlignmentIssue[] = [
  { id: 1, type: 'cross-team', count: 2, description: 'Sales-Product priority conflict', iconBg: '#6A3DE8', bgColor: 'rgba(106, 61, 232, 0.08)', borderColor: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Sales team prioritizing short-term deals', 'Product team focusing on long-term vision'], resolved: false, resolvedAt: null },
  { id: 2, type: 'internal', count: 1, description: 'Engineering resource allocation', iconBg: '#F98B2B', bgColor: '#FFF2E6', borderColor: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Engineering team overburdened with multiple projects'], resolved: false, resolvedAt: null },
];

const DEFAULT_GRADE_STATE: GradeState = {
  sentToLeadership: false,
  sentAt: null,
  exported: false,
  exportedAt: null,
};

const DEFAULT_COMPUTED_GRADE: ComputedGrade = {
  grade: 'B+',
  score: 85,
  previousGrade: 'B',
  trend: 'up',
  breakdown: [
    { metric: 'Customer Success Rate', score: 90, weight: 20 },
    { metric: 'Revenue Growth', score: 80, weight: 20 },
    { metric: 'Platform Uptime', score: 95, weight: 20 },
    { metric: 'Customer NPS', score: 70, weight: 20 },
    { metric: 'Team Velocity', score: 85, weight: 20 },
  ],
  insights: [
    'Customer success metrics are strong, indicating high customer satisfaction.',
    'Revenue growth is tracking below target, requiring attention to sales and marketing strategies.',
    'Platform uptime is excellent, ensuring reliable service delivery.',
    'Customer NPS has shown a slight decline, necessitating a focus on customer feedback and support.',
    'Team velocity is above target, demonstrating efficient execution.',
  ],
};

const DEFAULT_COMPUTED_STORY: ComputedStory = {
  improved: [
    'Engineering team delivered 5 out of 6 AI prediction features ahead of schedule.',
    'Marketing campaign performance exceeded targets, driving positive customer engagement.',
  ],
  slowedDown: [
    'Sales team experienced a decline in conversion rate, impacting overall revenue growth.',
    'Product team faced delays in finalizing specifications, affecting feature delivery timelines.',
  ],
  changed: [
    'Customer NPS scores dropped slightly, indicating a need to address customer satisfaction issues.',
    'Resource allocation for Engineering was adjusted to support PMF efforts.',
  ],
  newBlockers: [
    'Resource constraints are delaying the achievement of Product-Market Fit in the Enterprise Segment.',
    'Customer NPS trending below target, requiring a customer success initiative.',
  ],
  aiRecommendations: [
    'Implement a deal review process and update the sales playbook to improve conversion rates.',
    'Reassign 2 engineers from the Platform team to support PMF efforts for 2 weeks.',
    'Launch a customer success initiative with automated check-ins to address NPS trends.',
  ],
};

// ─── Storage Helpers ──────────────────────────────────

function getItem<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(`shiftfocus:${key}`);
    if (raw === null) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  localStorage.setItem(`shiftfocus:${key}`, JSON.stringify(value));
}

// ─── Public API ───────────────────────────────────────

export const db = {
  // — Rituals —
  getRituals: (): Ritual[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.rituals;
    }
    return getItem('rituals', DEFAULT_RITUALS);
  },
  toggleRitual: (id: number): Ritual[] => {
    if (db.isViewingHistory()) return db.getRituals(); // no-op in history
    const rituals = getItem<Ritual[]>('rituals', DEFAULT_RITUALS);
    const updated = rituals.map(r => r.id === id ? { ...r, completed: !r.completed } : r);
    setItem('rituals', updated);
    return updated;
  },
  resetRituals: (): Ritual[] => {
    setItem('rituals', DEFAULT_RITUALS);
    return DEFAULT_RITUALS;
  },

  // — Streak —
  getStreak: (): WeeklyStreak => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.streak;
    }
    return getItem('streak', DEFAULT_STREAK);
  },
  incrementStreak: (): WeeklyStreak => {
    if (db.isViewingHistory()) return db.getStreak();
    const streak = getItem<WeeklyStreak>('streak', DEFAULT_STREAK);
    const updated = { count: streak.count + 1, lastCompletedWeek: new Date().toISOString() };
    setItem('streak', updated);
    return updated;
  },

  // — Key Results —
  getKeyResults: (): KeyResult[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.keyResults;
    }
    return getItem('keyResults', DEFAULT_KEY_RESULTS);
  },
  updateKeyResult: (id: number, updates: Partial<KeyResult>): KeyResult[] => {
    if (db.isViewingHistory()) return db.getKeyResults();
    const krs = getItem<KeyResult[]>('keyResults', DEFAULT_KEY_RESULTS);
    const updated = krs.map(kr => kr.id === id ? { ...kr, ...updates, updatedAt: new Date().toISOString() } : kr);
    setItem('keyResults', updated);
    return updated;
  },

  // — KPIs —
  getKPIs: (): KPI[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.kpis;
    }
    return getItem('kpis', DEFAULT_KPIS);
  },
  updateKPI: (id: number, updates: Partial<KPI>): KPI[] => {
    if (db.isViewingHistory()) return db.getKPIs();
    const kpis = getItem<KPI[]>('kpis', DEFAULT_KPIS);
    const updated = kpis.map(k => k.id === id ? { ...k, ...updates, updatedAt: new Date().toISOString() } : k);
    setItem('kpis', updated);
    return updated;
  },

  // — Teams —
  getTeams: (): Team[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.teams;
    }
    return getItem('teams', DEFAULT_TEAMS);
  },
  verifyTeam: (id: number): Team[] => {
    if (db.isViewingHistory()) return db.getTeams();
    const teams = getItem<Team[]>('teams', DEFAULT_TEAMS);
    const updated = teams.map(t => t.id === id ? { ...t, verified: true, redFlags: 0, verifiedAt: new Date().toISOString() } : t);
    setItem('teams', updated);
    return updated;
  },

  // — Accountability Alerts —
  getAlerts: (): AccountabilityAlert[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.alerts;
    }
    return getItem('alerts', DEFAULT_ALERTS);
  },
  resolveAlert: (id: number): AccountabilityAlert[] => {
    if (db.isViewingHistory()) return db.getAlerts();
    const alerts = getItem<AccountabilityAlert[]>('alerts', DEFAULT_ALERTS);
    const updated = alerts.map(a => a.id === id ? { ...a, resolved: true, resolvedAt: new Date().toISOString() } : a);
    setItem('alerts', updated);
    return updated;
  },

  // — Risks —
  getRisks: (): Risk[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.risks;
    }
    return getItem('risks', DEFAULT_RISKS);
  },
  resolveRisk: (id: number): Risk[] => {
    if (db.isViewingHistory()) return db.getRisks();
    const risks = getItem<Risk[]>('risks', DEFAULT_RISKS);
    const updated = risks.map(r => r.id === id ? { ...r, resolved: true, resolvedAt: new Date().toISOString() } : r);
    setItem('risks', updated);
    return updated;
  },

  // — Predictions —
  getPrediction: (): Prediction => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.prediction;
    }
    return getItem('prediction', DEFAULT_PREDICTION);
  },
  updatePrediction: (updates: Partial<Prediction>): Prediction => {
    if (db.isViewingHistory()) return db.getPrediction();
    const current = getItem<Prediction>('prediction', DEFAULT_PREDICTION);
    const updated = { ...current, ...updates };
    setItem('prediction', updated);
    return updated;
  },
  savePrediction: (): Prediction => {
    if (db.isViewingHistory()) return db.getPrediction();
    const current = getItem<Prediction>('prediction', DEFAULT_PREDICTION);
    const updated = { ...current, savedAt: new Date().toISOString() };
    setItem('prediction', updated);
    return updated;
  },

  // — CEO Notes —
  getCEONotes: (): CEONotes => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.ceoNotes;
    }
    return getItem('ceoNotes', DEFAULT_CEO_NOTES);
  },
  saveCEONotes: (content: string): CEONotes => {
    if (db.isViewingHistory()) return db.getCEONotes();
    const current = getItem<CEONotes>('ceoNotes', DEFAULT_CEO_NOTES);
    const history = [...current.history];
    if (current.content && current.savedAt) {
      history.push({ content: current.content, savedAt: current.savedAt });
    }
    const updated: CEONotes = { content, savedAt: new Date().toISOString(), history: history.slice(-10) };
    setItem('ceoNotes', updated);
    return updated;
  },

  // — Blockers —
  getBlockers: (): Blocker[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.blockers;
    }
    return getItem('blockers', DEFAULT_BLOCKERS);
  },
  applyBlockerSolution: (id: number): Blocker[] => {
    if (db.isViewingHistory()) return db.getBlockers();
    const blockers = getItem<Blocker[]>('blockers', DEFAULT_BLOCKERS);
    const updated = blockers.map(b => b.id === id ? { ...b, applied: true } : b);
    setItem('blockers', updated);
    return updated;
  },
  dismissBlocker: (id: number): Blocker[] => {
    if (db.isViewingHistory()) return db.getBlockers();
    const blockers = getItem<Blocker[]>('blockers', DEFAULT_BLOCKERS);
    const updated = blockers.map(b => b.id === id ? { ...b, dismissed: true } : b);
    setItem('blockers', updated);
    return updated;
  },

  // — Leadership Pulse Items —
  getPulseItems: (): LeadershipPulseItem[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.pulseItems;
    }
    return getItem('pulseItems', DEFAULT_PULSE_ITEMS);
  },
  resolvePulseItem: (id: number): LeadershipPulseItem[] => {
    if (db.isViewingHistory()) return db.getPulseItems();
    const items = getItem<LeadershipPulseItem[]>('pulseItems', DEFAULT_PULSE_ITEMS);
    const updated = items.map(i => i.id === id ? { ...i, resolved: true } : i);
    setItem('pulseItems', updated);
    return updated;
  },

  // — Alignment Issues —
  getAlignmentIssues: (): AlignmentIssue[] => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.alignmentIssues;
    }
    return getItem('alignmentIssues', DEFAULT_ALIGNMENT_ISSUES);
  },
  resolveAlignmentIssue: (id: number): AlignmentIssue[] => {
    if (db.isViewingHistory()) return db.getAlignmentIssues();
    const issues = getItem<AlignmentIssue[]>('alignmentIssues', DEFAULT_ALIGNMENT_ISSUES);
    const updated = issues.map(i => i.id === id ? { ...i, resolved: true, resolvedAt: new Date().toISOString() } : i);
    setItem('alignmentIssues', updated);
    return updated;
  },

  // — Grade State —
  getGradeState: (): GradeState => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.gradeState;
    }
    return getItem('gradeState', DEFAULT_GRADE_STATE);
  },
  updateGradeState: (updates: Partial<GradeState>): GradeState => {
    if (db.isViewingHistory()) return db.getGradeState();
    const current = getItem<GradeState>('gradeState', DEFAULT_GRADE_STATE);
    const updated = { ...current, ...updates };
    setItem('gradeState', updated);
    return updated;
  },

  // — Computed Grade —
  getComputedGrade: (): ComputedGrade => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.computedGrade;
    }
    return getItem('computedGrade', DEFAULT_COMPUTED_GRADE);
  },
  updateComputedGrade: (updates: Partial<ComputedGrade>): ComputedGrade => {
    if (db.isViewingHistory()) return db.getComputedGrade();
    const current = getItem<ComputedGrade>('computedGrade', DEFAULT_COMPUTED_GRADE);
    const updated = { ...current, ...updates };
    setItem('computedGrade', updated);
    return updated;
  },

  // — Computed Story —
  getComputedStory: (): ComputedStory => {
    if (_activeViewWeek && _activeViewWeek !== 'this-week') {
      const snap = _getHistoricalSnapshots()[_activeViewWeek];
      if (snap) return snap.computedStory;
    }
    return getItem('computedStory', DEFAULT_COMPUTED_STORY);
  },
  updateComputedStory: (updates: Partial<ComputedStory>): ComputedStory => {
    if (db.isViewingHistory()) return db.getComputedStory();
    const current = getItem<ComputedStory>('computedStory', DEFAULT_COMPUTED_STORY);
    const updated = { ...current, ...updates };
    setItem('computedStory', updated);
    return updated;
  },

  // — Computed Counters —
  getUpdatesDue: (): number => {
    const krs = db.getKeyResults();
    const kpis = db.getKPIs();
    return krs.filter(kr => !kr.updatedAt).length + kpis.filter(k => !k.updatedAt).length;
  },
  getVerificationPending: (): number => {
    const teams = db.getTeams();
    return teams.filter(t => !t.verified && t.redFlags > 0).length;
  },
  getEscalationsScheduled: (): number => {
    const alerts = db.getAlerts();
    return alerts.filter(a => !a.resolved).length;
  },

  // — Reset All (dev utility) —
  resetAll: (): void => {
    const keys = ['rituals', 'streak', 'keyResults', 'kpis', 'teams', 'alerts', 'risks', 'prediction', 'ceoNotes', 'blockers', 'pulseItems', 'alignmentIssues', 'gradeState', 'computedGrade', 'computedStory'];
    keys.forEach(k => localStorage.removeItem(`shiftfocus:${k}`));
  },

  // ─── Week Navigation ──────────────────────────────────

  /** Set which week we're viewing. null = current (live) week. */
  setViewWeek: (weekId: string | null): void => {
    _activeViewWeek = weekId;
  },

  /** Get current viewed week id. null = live week. */
  getViewWeek: (): string | null => _activeViewWeek,

  /** True when viewing a historical (read-only) snapshot. */
  isViewingHistory: (): boolean => _activeViewWeek !== null && _activeViewWeek !== 'this-week',

  /** Available weeks for navigation. */
  getAvailableWeeks: (): WeekOption[] => {
    // Compute date ranges relative to "today" (Feb 10, 2026 — Tuesday)
    const today = new Date(2026, 1, 10); // month is 0-indexed
    const thisMonday = new Date(today);
    thisMonday.setDate(today.getDate() - ((today.getDay() + 6) % 7)); // Mon
    const thisSunday = new Date(thisMonday);
    thisSunday.setDate(thisMonday.getDate() + 6);

    const lastMonday = new Date(thisMonday);
    lastMonday.setDate(thisMonday.getDate() - 7);
    const lastSunday = new Date(lastMonday);
    lastSunday.setDate(lastMonday.getDate() + 6);

    const twoWeeksMonday = new Date(lastMonday);
    twoWeeksMonday.setDate(lastMonday.getDate() - 7);
    const twoWeeksSunday = new Date(twoWeeksMonday);
    twoWeeksSunday.setDate(twoWeeksMonday.getDate() + 6);

    const fmt = (d: Date) => `${d.toLocaleString('en-US', { month: 'short' })} ${d.getDate()}`;

    return [
      { id: 'this-week', label: 'This Week', dateRange: `${fmt(thisMonday)} – ${fmt(thisSunday)}`, isHistorical: false, status: 'in-progress' },
      { id: 'last-week', label: 'Last Week', dateRange: `${fmt(lastMonday)} – ${fmt(lastSunday)}`, isHistorical: true, grade: 'B+', status: 'completed' },
      { id: '2-weeks-ago', label: '2 Weeks Ago', dateRange: `${fmt(twoWeeksMonday)} – ${fmt(twoWeeksSunday)}`, isHistorical: true, grade: 'B', status: 'completed' },
    ];
  },

  /** Load a frozen snapshot for a historical week. */
  getWeekSnapshot: (weekId: string): WeekSnapshot | null => {
    if (weekId === 'this-week' || !weekId) return null;
    const snapshots = _getHistoricalSnapshots();
    return snapshots[weekId] || null;
  },
};

// ─── Historical Snapshot Seeds ────────────────────────
// These simulate completed past weeks with plausible data.
// When backend arrives, replace with api.getWeekSnapshot(weekId).

function _getHistoricalSnapshots(): Record<string, WeekSnapshot> {
  return {
    'last-week': {
      rituals: [
        { id: 1, label: 'Update KRs', completed: true, tooltip: 'Keep your Key Results current to maintain strategic visibility' },
        { id: 2, label: 'Update KPIs', completed: true, tooltip: 'Fresh KPI data ensures accurate performance tracking' },
        { id: 3, label: 'Resolve blockers', completed: true, tooltip: 'Clear obstacles to maintain momentum and velocity' },
        { id: 4, label: 'Review team confidence', completed: true, tooltip: 'Check team morale and belief in achieving outcomes' },
        { id: 5, label: 'Run "Fix My Week"', completed: false, tooltip: 'Let AI analyze and prioritize your weekly execution plan' },
      ],
      streak: { count: 11, lastCompletedWeek: '2026-02-01T18:00:00.000Z' },
      keyResults: [
        {
          id: 1, name: 'Launch AI-Powered Execution Intelligence Platform',
          objective: 'Scale Enterprise Customer Success Program', owner: 'Sarah Chen', ownerAvatar: 'SC',
          progress: 60, change: '+7', confidence: 'High', confidenceColor: '#40C78C',
          lastUpdate: 'Feb 6: Prototype review completed', status: 'on-track',
          updatedAt: '2026-02-06T14:30:00.000Z', progressHistory: [30, 38, 42, 48, 53, 60]
        },
        {
          id: 2, name: 'Ship 6 core AI prediction features',
          objective: 'Scale Enterprise Customer Success Program', owner: 'Mike Johnson', ownerAvatar: 'MJ',
          progress: 77, change: '+10', confidence: 'High', confidenceColor: '#40C78C',
          lastUpdate: 'Feb 7: 4 of 6 features shipped', status: 'on-track',
          updatedAt: '2026-02-07T16:00:00.000Z', progressHistory: [40, 48, 55, 62, 67, 77]
        },
        {
          id: 3, name: 'Achieve Product-Market Fit in Enterprise Segment',
          objective: 'Build Strategic Partnership Ecosystem', owner: 'Emily Davis', ownerAvatar: 'ED',
          progress: 43, change: '+2', confidence: 'Medium', confidenceColor: '#F98B2B',
          lastUpdate: 'Feb 5: Customer interviews scheduled', status: 'at-risk',
          updatedAt: '2026-02-05T11:00:00.000Z', progressHistory: [28, 32, 35, 38, 41, 43]
        },
        {
          id: 4, name: 'Scale Platform Performance & Reliability',
          objective: 'Scale Enterprise Customer Success Program', owner: 'David Kim', ownerAvatar: 'DK',
          progress: 86, change: '+6', confidence: 'High', confidenceColor: '#40C78C',
          lastUpdate: 'Feb 7: Load testing passed', status: 'on-track',
          updatedAt: '2026-02-07T09:00:00.000Z', progressHistory: [65, 70, 74, 78, 80, 86]
        }
      ],
      kpis: [
        { id: 1, name: 'Customer Success Rate', value: '+16%', target: '15%', trend: 'up', stability: 'STABLE', badge: 'AHEAD', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Customer retention and success metrics trending above target', updatedAt: '2026-02-06T10:00:00.000Z' },
        { id: 2, name: 'Revenue Growth', value: '$2.2M', target: '$2.5M', trend: 'up', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Monthly recurring revenue growth rate vs target', updatedAt: '2026-02-06T10:00:00.000Z' },
        { id: 3, name: 'Platform Uptime', value: '99.7%', target: '99.5%', trend: 'stable', stability: 'STABLE', badge: 'PREDICTABLE', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'System availability and reliability metrics', updatedAt: '2026-02-06T10:00:00.000Z' },
        { id: 4, name: 'Customer NPS', value: '69', target: '70', trend: 'down', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Net Promoter Score showing customer satisfaction trends', updatedAt: '2026-02-06T10:00:00.000Z' },
        { id: 5, name: 'Team Velocity', value: '91%', target: '90%', trend: 'up', stability: 'STABLE', badge: 'AHEAD', iconBg: '#6A3DE8', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Team execution speed and delivery rate', updatedAt: '2026-02-06T10:00:00.000Z' },
      ],
      teams: [
        { id: 1, name: 'Engineering', confidence: 88, velocity: '+12%', velocityTrend: 'up', updates: 'Shipped 4/6 AI features on schedule', completedItems: 10, plannedItems: 10, redFlags: 0, verified: true, verifiedAt: '2026-02-07T15:00:00.000Z', tooltip: 'Engineering delivered on plan with strong execution' },
        { id: 2, name: 'Product', confidence: 82, velocity: '+5%', velocityTrend: 'up', updates: 'User testing phase launched', completedItems: 7, plannedItems: 10, redFlags: 1, verified: true, verifiedAt: '2026-02-07T15:30:00.000Z', tooltip: 'Product team progressing but with one dependency blocker' },
        { id: 3, name: 'Sales', confidence: 74, velocity: '-5%', velocityTrend: 'down', updates: 'Pipeline review identified conversion bottleneck', completedItems: 5, plannedItems: 8, redFlags: 2, verified: true, verifiedAt: '2026-02-07T16:00:00.000Z', tooltip: 'Sales team flagged for declining velocity trend' },
        { id: 4, name: 'Marketing', confidence: 91, velocity: '+10%', velocityTrend: 'up', updates: 'New campaign launched, early metrics positive', completedItems: 11, plannedItems: 8, redFlags: 0, verified: true, verifiedAt: '2026-02-07T14:00:00.000Z', tooltip: 'Marketing team outperforming with strong campaign results' },
        { id: 5, name: 'Customer Success', confidence: 80, velocity: '+2%', velocityTrend: 'up', updates: 'NPS recovery plan drafted', completedItems: 8, plannedItems: 9, redFlags: 1, verified: true, verifiedAt: '2026-02-07T16:30:00.000Z', tooltip: 'Customer Success making incremental improvements' },
        { id: 6, name: 'Operations', confidence: 87, velocity: '+8%', velocityTrend: 'up', updates: 'Process audit completed', completedItems: 7, plannedItems: 7, redFlags: 0, verified: true, verifiedAt: '2026-02-07T14:30:00.000Z', tooltip: 'Operations maintaining solid execution rhythm' },
      ],
      alerts: [
        { id: 1, type: 'missing-checkin', teams: ['Sales'], message: '1 team — check-in was late', description: 'Sales submitted weekly update 2 days past deadline', severity: 'resolved late', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Team submitted check-in after enforcement deadline', action: 'Escalate Now', resolved: true, resolvedAt: '2026-02-07T12:00:00.000Z' },
        { id: 2, type: 'blocked-dependencies', teams: ['Product', 'Engineering'], message: '2 teams — dependency resolved', description: 'Cross-team dependency on API integration cleared', severity: 'verified', bgColor: '#E5F9F1', borderColor: '#40C78C', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Dependency was resolved mid-week after escalation', action: 'Verify Now', resolved: true, resolvedAt: '2026-02-05T14:00:00.000Z' },
      ],
      risks: [
        { id: 1, severity: 'critical', title: 'Q1 Revenue Target At Risk', description: 'Pipeline conversion trending 10% below target', impact: 'High', probability: '72%', category: 'Revenue', riskType: 'critical', resolved: false, resolvedAt: null },
        { id: 2, severity: 'moderate', title: 'Customer Churn Early Warning', description: 'NPS dropped 3 points, churn indicators rising', impact: 'Medium', probability: '60%', category: 'Customer', riskType: 'business', resolved: false, resolvedAt: null },
        { id: 3, severity: 'moderate', title: 'Feature Delivery Under Pressure', description: 'AI prediction features at risk of 1-week delay', impact: 'Medium', probability: '65%', category: 'Product', riskType: 'technical', resolved: true, resolvedAt: '2026-02-06T10:00:00.000Z' },
        { id: 4, severity: 'low', title: 'Vendor Contract Renewal', description: 'Cloud infrastructure contract up for renewal in 45 days', impact: 'Low', probability: '30%', category: 'Operations', riskType: 'operational', resolved: false, resolvedAt: null },
      ],
      prediction: {
        momentum: 'up',
        confidence: 'stable',
        risk: 'up',
        savedAt: '2026-02-07T17:00:00.000Z',
      },
      ceoNotes: {
        content: "Solid week overall — Engineering hit their delivery targets and Marketing campaign is performing well. Main concern is Sales velocity dip and the Enterprise PMF timeline.\n\nDecisions made this week:\n- Approved additional QA resources for AI features\n- Initiated Sales pipeline deep-dive for next Monday\n- Greenlit NPS recovery initiative budget",
        savedAt: '2026-02-07T17:30:00.000Z',
        history: [
          { content: "Mid-week notes: Need to escalate the Product-Engineering dependency. Sales numbers concerning.", savedAt: '2026-02-05T10:00:00.000Z' }
        ],
      },
      blockers: [
        { id: 1, type: 'KR', title: 'Enterprise PMF resource gap', source: 'Achieve Product-Market Fit in Enterprise Segment', severity: 'high', aiSolution: 'Redirect contractor budget to hire 2 PMF specialists', applied: false, dismissed: false },
        { id: 2, type: 'KPI', title: 'Sales conversion rate declining', source: 'Revenue Growth', severity: 'high', aiSolution: 'Implement deal review process and update sales playbook', applied: true, dismissed: false },
      ],
      pulseItems: [
        { id: 1, count: 1, label: 'late check-in', description: 'Sales team submitted 2 days late', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', tooltip: 'Team missed the weekly check-in deadline', resolved: true },
        { id: 2, count: 2, label: 'blockers resolved', description: 'Dependency and resource issues cleared', bgColor: '#E5F9F1', borderColor: '#40C78C', iconBg: '#40C78C', tooltip: 'Blockers that were resolved during the week', resolved: true },
        { id: 3, count: 1, label: 'escalation executed', description: 'Product-Engineering dependency escalated to VP', bgColor: 'rgba(106, 61, 232, 0.08)', borderColor: '#6A3DE8', iconBg: '#6A3DE8', tooltip: 'Escalation that was triggered and resolved', resolved: true },
      ],
      alignmentIssues: [
        { id: 1, type: 'cross-team', count: 2, description: 'Sales-Product priority conflict', iconBg: '#6A3DE8', bgColor: 'rgba(106, 61, 232, 0.08)', borderColor: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Sales team prioritizing short-term deals', 'Product team focusing on long-term vision'], resolved: false, resolvedAt: null },
        { id: 2, type: 'internal', count: 1, description: 'Engineering resource allocation', iconBg: '#F98B2B', bgColor: '#FFF2E6', borderColor: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Engineering team overburdened with multiple projects'], resolved: false, resolvedAt: null },
      ],
      gradeState: {
        sentToLeadership: false,
        sentAt: null,
        exported: false,
        exportedAt: null,
      },
      computedGrade: {
        grade: 'B+',
        score: 85,
        previousGrade: 'B',
        trend: 'up',
        breakdown: [
          { metric: 'Customer Success Rate', score: 90, weight: 20 },
          { metric: 'Revenue Growth', score: 80, weight: 20 },
          { metric: 'Platform Uptime', score: 95, weight: 20 },
          { metric: 'Customer NPS', score: 70, weight: 20 },
          { metric: 'Team Velocity', score: 85, weight: 20 },
        ],
        insights: [
          'Customer success metrics are strong, indicating high customer satisfaction.',
          'Revenue growth is tracking below target, requiring attention to sales and marketing strategies.',
          'Platform uptime is excellent, ensuring reliable service delivery.',
          'Customer NPS has shown a slight decline, necessitating a focus on customer feedback and support.',
          'Team velocity is above target, demonstrating efficient execution.',
        ],
      },
      computedStory: {
        improved: [
          'Engineering team delivered 5 out of 6 AI prediction features ahead of schedule.',
          'Marketing campaign performance exceeded targets, driving positive customer engagement.',
        ],
        slowedDown: [
          'Sales team experienced a decline in conversion rate, impacting overall revenue growth.',
          'Product team faced delays in finalizing specifications, affecting feature delivery timelines.',
        ],
        changed: [
          'Customer NPS scores dropped slightly, indicating a need to address customer satisfaction issues.',
          'Resource allocation for Engineering was adjusted to support PMF efforts.',
        ],
        newBlockers: [
          'Resource constraints are delaying the achievement of Product-Market Fit in the Enterprise Segment.',
          'Customer NPS trending below target, requiring a customer success initiative.',
        ],
        aiRecommendations: [
          'Implement a deal review process and update the sales playbook to improve conversion rates.',
          'Reassign 2 engineers from the Platform team to support PMF efforts for 2 weeks.',
          'Launch a customer success initiative with automated check-ins to address NPS trends.',
        ],
      },
    },
    '2-weeks-ago': {
      rituals: [
        { id: 1, label: 'Update KRs', completed: true, tooltip: 'Keep your Key Results current to maintain strategic visibility' },
        { id: 2, label: 'Update KPIs', completed: true, tooltip: 'Fresh KPI data ensures accurate performance tracking' },
        { id: 3, label: 'Resolve blockers', completed: false, tooltip: 'Clear obstacles to maintain momentum and velocity' },
        { id: 4, label: 'Review team confidence', completed: true, tooltip: 'Check team morale and belief in achieving outcomes' },
        { id: 5, label: 'Run "Fix My Week"', completed: true, tooltip: 'Let AI analyze and prioritize your weekly execution plan' },
      ],
      streak: { count: 10, lastCompletedWeek: '2026-01-25T18:00:00.000Z' },
      keyResults: [
        {
          id: 1, name: 'Launch AI-Powered Execution Intelligence Platform',
          objective: 'Scale Enterprise Customer Success Program', owner: 'Sarah Chen', ownerAvatar: 'SC',
          progress: 53, change: '+5', confidence: 'Medium', confidenceColor: '#F98B2B',
          lastUpdate: 'Jan 30: Design review completed', status: 'at-risk',
          updatedAt: '2026-01-30T14:30:00.000Z', progressHistory: [25, 30, 35, 40, 48, 53]
        },
        {
          id: 2, name: 'Ship 6 core AI prediction features',
          objective: 'Scale Enterprise Customer Success Program', owner: 'Mike Johnson', ownerAvatar: 'MJ',
          progress: 67, change: '+8', confidence: 'High', confidenceColor: '#40C78C',
          lastUpdate: 'Jan 31: 3 of 6 features shipped', status: 'on-track',
          updatedAt: '2026-01-31T16:00:00.000Z', progressHistory: [32, 40, 48, 55, 59, 67]
        },
        {
          id: 3, name: 'Achieve Product-Market Fit in Enterprise Segment',
          objective: 'Build Strategic Partnership Ecosystem', owner: 'Emily Davis', ownerAvatar: 'ED',
          progress: 41, change: '+4', confidence: 'Medium', confidenceColor: '#F98B2B',
          lastUpdate: 'Jan 29: Market analysis phase started', status: 'at-risk',
          updatedAt: '2026-01-29T11:00:00.000Z', progressHistory: [22, 26, 30, 33, 37, 41]
        },
        {
          id: 4, name: 'Scale Platform Performance & Reliability',
          objective: 'Scale Enterprise Customer Success Program', owner: 'David Kim', ownerAvatar: 'DK',
          progress: 80, change: '+4', confidence: 'High', confidenceColor: '#40C78C',
          lastUpdate: 'Jan 31: Infrastructure upgrade deployed', status: 'on-track',
          updatedAt: '2026-01-31T09:00:00.000Z', progressHistory: [58, 62, 68, 72, 76, 80]
        }
      ],
      kpis: [
        { id: 1, name: 'Customer Success Rate', value: '+14%', target: '15%', trend: 'up', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#40C78C', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Customer retention improving but still below target', updatedAt: '2026-01-30T10:00:00.000Z' },
        { id: 2, name: 'Revenue Growth', value: '$2.1M', target: '$2.5M', trend: 'up', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Revenue growth tracking below target', updatedAt: '2026-01-30T10:00:00.000Z' },
        { id: 3, name: 'Platform Uptime', value: '99.6%', target: '99.5%', trend: 'stable', stability: 'STABLE', badge: 'PREDICTABLE', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'Platform maintaining acceptable uptime levels', updatedAt: '2026-01-30T10:00:00.000Z' },
        { id: 4, name: 'Customer NPS', value: '72', target: '70', trend: 'up', stability: 'STABLE', badge: 'AHEAD', iconBg: '#40C78C', badgeColor: { bg: '#E5F9F1', text: '#2E9865' }, tooltip: 'NPS was above target two weeks ago before the dip', updatedAt: '2026-01-30T10:00:00.000Z' },
        { id: 5, name: 'Team Velocity', value: '88%', target: '90%', trend: 'stable', stability: 'MODERATE', badge: 'BEHIND', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Team velocity slightly below target', updatedAt: '2026-01-30T10:00:00.000Z' },
      ],
      teams: [
        { id: 1, name: 'Engineering', confidence: 85, velocity: '+10%', velocityTrend: 'up', updates: 'Shipped 3/6 AI features, pipeline healthy', completedItems: 9, plannedItems: 10, redFlags: 0, verified: true, verifiedAt: '2026-01-31T15:00:00.000Z', tooltip: 'Engineering making steady progress' },
        { id: 2, name: 'Product', confidence: 79, velocity: '+3%', velocityTrend: 'up', updates: 'Spec finalization in progress', completedItems: 6, plannedItems: 9, redFlags: 2, verified: true, verifiedAt: '2026-01-31T15:30:00.000Z', tooltip: 'Product team facing some delays' },
        { id: 3, name: 'Sales', confidence: 76, velocity: '-2%', velocityTrend: 'down', updates: 'Q1 pipeline building slower than expected', completedItems: 5, plannedItems: 8, redFlags: 1, verified: true, verifiedAt: '2026-01-31T16:00:00.000Z', tooltip: 'Sales team needs pipeline acceleration' },
        { id: 4, name: 'Marketing', confidence: 88, velocity: '+7%', velocityTrend: 'up', updates: 'Campaign prep completed', completedItems: 10, plannedItems: 8, redFlags: 0, verified: true, verifiedAt: '2026-01-31T14:00:00.000Z', tooltip: 'Marketing delivering consistently' },
        { id: 5, name: 'Customer Success', confidence: 78, velocity: '+1%', velocityTrend: 'up', updates: 'Customer feedback collection started', completedItems: 7, plannedItems: 9, redFlags: 2, verified: false, verifiedAt: null, tooltip: 'CS team showing early signs of improvement' },
        { id: 6, name: 'Operations', confidence: 84, velocity: '+6%', velocityTrend: 'up', updates: 'Process audit initiated', completedItems: 6, plannedItems: 7, redFlags: 0, verified: true, verifiedAt: '2026-01-31T14:30:00.000Z', tooltip: 'Operations performing steadily' },
      ],
      alerts: [
        { id: 1, type: 'missing-checkin', teams: ['Customer Success'], message: '1 team — check-in missed', description: 'Customer Success did not submit weekly update', severity: 'verification failed', bgColor: '#FFE5E5', borderColor: '#E53935', iconBg: '#E53935', badgeColor: { bg: '#FFE5E5', text: '#E53935' }, tooltip: 'Team failed to complete weekly check-in', action: 'Fix Now', resolved: false, resolvedAt: null },
        { id: 2, type: 'zero-movement', teams: ['Product'], message: '1 team — velocity stall detected', description: 'Product team showed minimal progress on 2 KRs', severity: 'requires intervention', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, tooltip: 'Team with stagnant progress metrics', action: 'Escalate Now', resolved: true, resolvedAt: '2026-01-30T14:00:00.000Z' },
      ],
      risks: [
        { id: 1, severity: 'critical', title: 'Q1 Revenue Pipeline Weak', description: 'Lead generation 20% below forecast, conversion uncertain', impact: 'High', probability: '70%', category: 'Revenue', riskType: 'critical', resolved: false, resolvedAt: null },
        { id: 2, severity: 'moderate', title: 'AI Feature Scope Creep', description: 'Prediction features expanding beyond original spec', impact: 'Medium', probability: '55%', category: 'Product', riskType: 'technical', resolved: true, resolvedAt: '2026-01-30T10:00:00.000Z' },
        { id: 3, severity: 'moderate', title: 'Team Burnout Indicators', description: 'Engineering overtime hours increasing for 3rd consecutive week', impact: 'Medium', probability: '50%', category: 'Team', riskType: 'operational', resolved: false, resolvedAt: null },
      ],
      prediction: {
        momentum: 'stable',
        confidence: 'up',
        risk: 'stable',
        savedAt: '2026-01-31T17:00:00.000Z',
      },
      ceoNotes: {
        content: "Mixed week. Engineering is executing well but Product is falling behind on specs. Sales pipeline needs immediate attention — scheduled a war room for Monday.\n\nActions taken:\n- Approved scope lock on AI prediction features\n- Initiated cross-team dependency mapping\n- Flagged CS team for missing check-in",
        savedAt: '2026-01-31T17:30:00.000Z',
        history: [],
      },
      blockers: [
        { id: 1, type: 'KR', title: 'Product spec delays blocking Engineering', source: 'Ship 6 core AI prediction features', severity: 'high', aiSolution: 'Fast-track spec review with 48-hour deadline', applied: true, dismissed: false },
        { id: 2, type: 'KPI', title: 'Lead gen volume below forecast', source: 'Revenue Growth', severity: 'high', aiSolution: 'Activate backup demand-gen channels', applied: false, dismissed: false },
      ],
      pulseItems: [
        { id: 1, count: 2, label: 'overdue updates', description: '1 KR and 1 KPI past deadline', bgColor: '#FFE5E5', borderColor: '#E53935', iconBg: '#E53935', tooltip: 'Items past their update deadline', resolved: true },
        { id: 2, count: 1, label: 'missed check-in', description: 'Customer Success failed to submit', bgColor: '#FFF2E6', borderColor: '#F98B2B', iconBg: '#F98B2B', tooltip: 'Team that missed the enforcement deadline', resolved: false },
        { id: 3, count: 3, label: 'items awaiting decision', description: 'Budget approvals and resource requests', bgColor: '#E5ECFF', borderColor: '#3E8BFF', iconBg: '#3E8BFF', tooltip: 'Pending leadership decisions', resolved: true },
      ],
      alignmentIssues: [
        { id: 1, type: 'cross-team', count: 2, description: 'Sales-Product priority conflict', iconBg: '#6A3DE8', bgColor: 'rgba(106, 61, 232, 0.08)', borderColor: '#6A3DE8', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Sales team prioritizing short-term deals', 'Product team focusing on long-term vision'], resolved: false, resolvedAt: null },
        { id: 2, type: 'internal', count: 1, description: 'Engineering resource allocation', iconBg: '#F98B2B', bgColor: '#FFF2E6', borderColor: '#F98B2B', badgeColor: { bg: '#FFF2E6', text: '#F98B2B' }, details: ['Engineering team overburdened with multiple projects'], resolved: false, resolvedAt: null },
      ],
      gradeState: {
        sentToLeadership: false,
        sentAt: null,
        exported: false,
        exportedAt: null,
      },
      computedGrade: {
        grade: 'B+',
        score: 85,
        previousGrade: 'B',
        trend: 'up',
        breakdown: [
          { metric: 'Customer Success Rate', score: 90, weight: 20 },
          { metric: 'Revenue Growth', score: 80, weight: 20 },
          { metric: 'Platform Uptime', score: 95, weight: 20 },
          { metric: 'Customer NPS', score: 70, weight: 20 },
          { metric: 'Team Velocity', score: 85, weight: 20 },
        ],
        insights: [
          'Customer success metrics are strong, indicating high customer satisfaction.',
          'Revenue growth is tracking below target, requiring attention to sales and marketing strategies.',
          'Platform uptime is excellent, ensuring reliable service delivery.',
          'Customer NPS has shown a slight decline, necessitating a focus on customer feedback and support.',
          'Team velocity is above target, demonstrating efficient execution.',
        ],
      },
      computedStory: {
        improved: [
          'Engineering team delivered 5 out of 6 AI prediction features ahead of schedule.',
          'Marketing campaign performance exceeded targets, driving positive customer engagement.',
        ],
        slowedDown: [
          'Sales team experienced a decline in conversion rate, impacting overall revenue growth.',
          'Product team faced delays in finalizing specifications, affecting feature delivery timelines.',
        ],
        changed: [
          'Customer NPS scores dropped slightly, indicating a need to address customer satisfaction issues.',
          'Resource allocation for Engineering was adjusted to support PMF efforts.',
        ],
        newBlockers: [
          'Resource constraints are delaying the achievement of Product-Market Fit in the Enterprise Segment.',
          'Customer NPS trending below target, requiring a customer success initiative.',
        ],
        aiRecommendations: [
          'Implement a deal review process and update the sales playbook to improve conversion rates.',
          'Reassign 2 engineers from the Platform team to support PMF efforts for 2 weeks.',
          'Launch a customer success initiative with automated check-ins to address NPS trends.',
        ],
      },
    },
  };
}
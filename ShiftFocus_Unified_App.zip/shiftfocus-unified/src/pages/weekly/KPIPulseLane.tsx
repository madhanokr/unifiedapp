import { useState, useCallback } from 'react';
import { TrendingUp, TrendingDown, Minus, Flame, AlertCircle, Activity, X, Check } from 'lucide-react';
import { OkrButton, OkrBadge, OkrSkeleton, OkrEmptyState, OkrInput, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { KPI } from './db';
import { z } from 'zod';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

const kpiUpdateSchema = z.object({
  value: z.string().min(1, 'Value is required').refine(
    (v) => /[0-9]/.test(v),
    'Must contain a numeric value'
  ),
});

type KPIUpdateForm = z.infer<typeof kpiUpdateSchema>;

function KPIPulseLaneSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-4">
          <div className="space-y-3">
            <div className="flex items-start justify-between">
              <OkrSkeleton variant="rect" width={32} height={32} className="rounded-lg" />
              <div className="space-y-1">
                <OkrSkeleton variant="rect" width={60} height={18} />
                <OkrSkeleton variant="rect" width={50} height={18} />
              </div>
            </div>
            <div>
              <OkrSkeleton variant="text" height={10} width="70%" />
              <OkrSkeleton variant="text" height={24} width="50%" className="mt-1" />
              <OkrSkeleton variant="text" height={10} width="40%" className="mt-1" />
            </div>
            <OkrSkeleton variant="rect" height={32} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function KPIPulseLane() {
  const loader = useCallback(() => db.getKPIs(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<KPI[]>(loader);
  const [editingId, setEditingId] = useState<number | null>(null);

  const { control, handleSubmit, formState: { errors }, reset } = useForm<KPIUpdateForm>({
    resolver: zodResolver(kpiUpdateSchema),
    defaultValues: {
      value: '',
    },
  });

  // Loading state
  if (state === 'loading') return <KPIPulseLaneSkeleton />;

  // Error state
  if (state === 'error') {
    return (
      <OkrEmptyState
        icon={AlertCircle}
        iconColor="var(--danger)"
        message="Failed to load KPIs"
        description={error || 'localStorage read failed'}
        className="bg-[var(--danger-light)] border-[var(--danger)]/30"
        action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
      />
    );
  }

  const kpis = loadedData || [];

  // Empty state
  if (kpis.length === 0) {
    return (
      <OkrEmptyState
        icon={Activity}
        iconColor="var(--info)"
        iconBg="var(--info)"
        message="No KPIs configured"
        description="Add KPI metrics to begin tracking operational health."
      />
    );
  }

  const handleStartEdit = (kpi: KPI) => {
    setEditingId(kpi.id);
    reset({ value: kpi.value });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    reset();
  };

  const onSubmit = (data: KPIUpdateForm) => {
    const kpi = kpis.find(k => k.id === editingId);
    if (!kpi) return;

    const oldNum = parseFloat(kpi.value.replace(/[^0-9.-]/g, ''));
    const newNum = parseFloat(data.value.replace(/[^0-9.-]/g, ''));
    let trend: 'up' | 'down' | 'stable' = kpi.trend;
    if (!isNaN(oldNum) && !isNaN(newNum)) {
      trend = newNum > oldNum ? 'up' : newNum < oldNum ? 'down' : 'stable';
    }

    const targetNum = parseFloat(kpi.target.replace(/[^0-9.-]/g, ''));
    let badge = kpi.badge;
    let badgeColor = kpi.badgeColor;
    let stability = kpi.stability;
    if (!isNaN(newNum) && !isNaN(targetNum)) {
      if (newNum >= targetNum) {
        badge = 'AHEAD';
        badgeColor = { bg: 'var(--success-light)', text: 'var(--success-active)' };
        stability = 'STABLE';
      } else if (newNum >= targetNum * 0.9) {
        badge = 'BEHIND';
        badgeColor = { bg: 'var(--warning-light)', text: 'var(--at-risk)' };
        stability = 'MODERATE';
      } else {
        badge = 'DRIFT';
        badgeColor = { bg: 'var(--warning-light)', text: 'var(--at-risk)' };
        stability = 'DRIFT';
      }
    }

    const updated = db.updateKPI(kpi.id, {
      value: data.value,
      trend,
      badge,
      badgeColor,
      stability,
    });
    setData(updated);
    setEditingId(null);
    reset();
    okrToast.success(`KPI updated: ${kpi.name}`, `${kpi.value} → ${data.value}`);
  };

  const iconMap: Record<string, typeof Flame> = {
    'AHEAD': Flame,
    'BEHIND': AlertCircle,
    'PREDICTABLE': Activity,
    'DRIFT': AlertCircle,
  };

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {kpis.map((kpi) => {
          const TrendIcon = kpi.trend === 'up' ? TrendingUp : kpi.trend === 'down' ? TrendingDown : Minus;
          const BadgeIcon = iconMap[kpi.badge] || Activity;
          const isEditing = editingId === kpi.id;
          
          return (
            <TooltipProvider key={kpi.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div
                    className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-4 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple cursor-pointer"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div 
                          className="w-8 h-8 rounded-lg flex items-center justify-center okr-card-shadow"
                          style={{ backgroundColor: kpi.iconBg }}
                        >
                          <TrendIcon className="w-4 h-4 text-white" strokeWidth={2} />
                        </div>
                        <div className="flex flex-col gap-1">
                          <span 
                            className="text-[10px] font-[500] px-2 py-1 rounded-md flex items-center gap-1 uppercase tracking-[0.05em]"
                            style={{ 
                              backgroundColor: kpi.stability === 'STABLE' ? 'var(--success-light)' : kpi.stability === 'MODERATE' ? 'var(--info-light)' : 'var(--warning-light)',
                              color: kpi.stability === 'STABLE' ? 'var(--success-active)' : kpi.stability === 'MODERATE' ? 'var(--info-active)' : 'var(--at-risk)'
                            }}
                          >
                            {kpi.stability}
                          </span>
                          <span 
                            className="text-[10px] font-[500] px-2 py-1 rounded-md flex items-center gap-1 uppercase tracking-[0.05em]"
                            style={{ backgroundColor: kpi.badgeColor.bg, color: kpi.badgeColor.text }}
                          >
                            <BadgeIcon className="w-3 h-3" strokeWidth={2} />
                            {kpi.badge}
                          </span>
                        </div>
                      </div>

                      <div>
                        <div className="text-[10px] font-[500] text-[var(--neutral-600)] uppercase tracking-[0.05em] mb-1">{kpi.name}</div>
                        {isEditing ? (
                          <form onSubmit={handleSubmit(onSubmit)} className="space-y-2 bg-white rounded-lg p-3 border border-[var(--brand-primary)]/20 mt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[10px] font-[500] text-[var(--neutral-800)]">Update Value</span>
                              <button type="button" onClick={handleCancelEdit}>
                                <X className="w-3 h-3 text-[var(--neutral-400)] hover:text-[var(--neutral-600)]" />
                              </button>
                            </div>
                            <Controller
                              name="value"
                              control={control}
                              render={({ field }) => (
                                <>
                                  <OkrInput
                                    {...field}
                                    inputSize="sm"
                                    placeholder="e.g. $2.5M, 95%, 68"
                                    error={!!errors.value}
                                  />
                                  {errors.value && <div className="text-[10px] text-[var(--danger)]">{errors.value.message}</div>}
                                </>
                              )}
                            />
                            <OkrButton type="submit" size="sm" className="w-full">
                              <Check className="w-3 h-3 mr-1" />
                              Save
                            </OkrButton>
                          </form>
                        ) : (
                          <>
                            <div className="text-[24px] font-[500] text-[var(--neutral-800)] tabular-nums leading-none">{kpi.value}</div>
                            <div className="text-[10px] font-[400] text-[var(--neutral-400)] mt-1">Target: {kpi.target}</div>
                          </>
                        )}
                      </div>

                      {!isEditing && (
                        <OkrButton
                          size="sm"
                          variant="outline"
                          onClick={() => handleStartEdit(kpi)}
                          className="w-full text-[10px] h-7"
                        >
                          {kpi.updatedAt ? 'Update Again' : 'Update Now'}
                        </OkrButton>
                      )}

                      {kpi.updatedAt && !isEditing && (
                        <div className="flex items-center gap-1">
                          <OkrBadge variant="success" size="sm">Updated</OkrBadge>
                        </div>
                      )}
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{kpi.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          );
        })}
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { Trophy, TrendingUp } from 'lucide-react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger, OkrSkeleton } from './design-system';
import { db } from './db';

function ScoreSkeleton() {
  return (
    <div className="bg-[#F3F3F3] rounded-xl p-6">
      <div className="flex items-start justify-between mb-4">
        <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
        <OkrSkeleton variant="rect" width={80} height={24} className="rounded-md" />
      </div>
      <div className="mb-2">
        <OkrSkeleton variant="text" height={10} width={100} />
        <OkrSkeleton variant="text" height={32} width={80} className="mt-1" />
      </div>
      <div className="space-y-2 mt-4">
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i} className="flex items-center justify-between">
            <OkrSkeleton variant="text" height={12} width={80} />
            <OkrSkeleton variant="text" height={12} width={30} />
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-[#E5E5E5]">
        <OkrSkeleton variant="text" height={10} width="80%" />
      </div>
    </div>
  );
}

export function LeadershipScoreBadge() {
  const [, setTick] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initial simulated load
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 800);
    return () => clearTimeout(timer);
  }, []);

  // Poll for changes — only after initial load
  useEffect(() => {
    if (!isLoaded) return;
    const interval = setInterval(() => setTick(t => t + 1), 2000);
    return () => clearInterval(interval);
  }, [isLoaded]);

  if (!isLoaded) return <ScoreSkeleton />;

  let rituals, krs, kpis, teams, risks;
  try {
    rituals = db.getRituals();
    krs = db.getKeyResults();
    kpis = db.getKPIs();
    teams = db.getTeams();
    risks = db.getRisks();
  } catch {
    return <ScoreSkeleton />;
  }

  // Dynamic score computation
  const ritualCompletion = rituals.filter(r => r.completed).length;
  const krUpdates = krs.filter(k => k.updatedAt).length;
  const kpiUpdates = kpis.filter(k => k.updatedAt).length;
  const teamVerifications = teams.filter(t => t.verified).length;
  const risksResolved = risks.filter(r => r.resolved).length;

  const scoreBreakdown = [
    { label: 'KR Updates', value: 20, current: Math.round((krUpdates / Math.max(1, krs.length)) * 20) },
    { label: 'KPI Updates', value: 20, current: Math.round((kpiUpdates / Math.max(1, kpis.length)) * 20) },
    { label: 'Risk Resolution', value: 20, current: Math.min(20, Math.round((risksResolved / Math.max(1, risks.length)) * 20) + 10) },
    { label: 'Team Verification', value: 20, current: Math.round((teamVerifications / Math.max(1, teams.length)) * 20) },
    { label: 'Ritual Completion', value: 20, current: Math.round((ritualCompletion / Math.max(1, rituals.length)) * 20) },
  ];

  const totalScore = scoreBreakdown.reduce((acc, item) => acc + item.current, 0);

  // Baseline score (before any updates) for "+X this week" calc
  const baselineScore = 10 + 0 + 10 + Math.round((teams.filter(t => t.redFlags === 0).length / Math.max(1, teams.length)) * 20) + 0;
  const weekDelta = Math.max(0, totalScore - baselineScore);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="bg-gradient-to-br from-[#6A3DE8] to-[#3E8BFF] rounded-xl p-6 text-white okr-card-shadow-hover transition-all duration-150 cursor-pointer">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Trophy className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              {weekDelta > 0 && (
                <div className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-md">
                  <TrendingUp className="w-3 h-3" strokeWidth={2} />
                  <span className="text-[10px] font-[500] uppercase tracking-[0.05em]">+{weekDelta} this week</span>
                </div>
              )}
            </div>

            <div className="mb-2">
              <div className="text-[10px] font-[500] text-white/80 mb-1 uppercase tracking-[0.05em]">Leadership Health</div>
              <div className="text-[32px] font-[600] leading-none tabular-nums">{totalScore}/100</div>
            </div>

            <div className="space-y-2 mt-4">
              {scoreBreakdown.map((item) => (
                <div key={item.label} className="flex items-center justify-between text-[12px] font-[400]">
                  <span className="text-white/80">{item.label}</span>
                  <span className="text-white font-[500] tabular-nums">{item.current}/{item.value}</span>
                </div>
              ))}
            </div>

            <div className="mt-4 pt-4 border-t border-white/20">
              <div className="text-[10px] font-[400] text-white/80 leading-relaxed">
                Score computed live from your weekly execution rituals
              </div>
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="left" className="max-w-xs">
          <p className="text-[14px] font-[400]">
            Your Leadership Health Score measures how consistently you maintain strategic oversight through weekly rituals.
            Complete all check-in steps to maximize your score.
          </p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
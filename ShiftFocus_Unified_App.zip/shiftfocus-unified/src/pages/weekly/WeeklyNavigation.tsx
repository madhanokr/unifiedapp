import { db } from './db';
import { Calendar, Lock, ChevronLeft, ChevronRight } from 'lucide-react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';

interface WeeklyNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const filterTabs = [
  { id: 'all', label: 'All Zones' },
  { id: 'team-checkins', label: 'Team Check-ins' },
  { id: 'my-checkin', label: 'My Check-in' },
  { id: 'ai-insights', label: 'AI Insights' },
];

export function WeeklyNavigation({ activeTab, onTabChange }: WeeklyNavigationProps) {
  const weeks = db.getAvailableWeeks();
  const isHistorical = db.isViewingHistory();
  const currentViewWeek = db.getViewWeek() || 'this-week';

  // Determine which week tab is selected and which filter is active
  const selectedWeek = weeks.find(w => w.id === activeTab) ? activeTab : currentViewWeek;
  const selectedFilter = filterTabs.find(f => f.id === activeTab) ? activeTab : 'all';
  const activeWeek = weeks.find(w => w.id === selectedWeek);

  const handleWeekSelect = (weekId: string) => {
    onTabChange(weekId);
  };

  const handleFilterSelect = (filterId: string) => {
    // When clicking a filter, keep the current week context
    if (filterId === 'all') {
      onTabChange(selectedWeek);
    } else {
      onTabChange(filterId);
    }
  };

  // Navigate to adjacent week
  const currentWeekIndex = weeks.findIndex(w => w.id === selectedWeek);
  const canGoNewer = currentWeekIndex > 0;
  const canGoOlder = currentWeekIndex < weeks.length - 1;

  return (
    <TooltipProvider>
      <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-[var(--neutral-200)]">
        <div className="max-w-[1320px] mx-auto px-8">
          <div className="flex items-center gap-0 h-[56px]">
            {/* Week selector section */}
            <div className="flex items-center gap-1 mr-2">
              {/* Newer week arrow */}
              <button
                onClick={() => canGoNewer && handleWeekSelect(weeks[currentWeekIndex - 1].id)}
                disabled={!canGoNewer}
                className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${
                  canGoNewer ? 'hover:bg-[var(--neutral-100)] text-[var(--neutral-600)]' : 'text-[var(--neutral-300)] cursor-not-allowed'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Week tabs */}
              {weeks.map((week) => (
                <Tooltip key={week.id}>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => handleWeekSelect(week.id)}
                      className={`
                        relative px-4 py-2 rounded-lg transition-all duration-120
                        flex items-center gap-2
                        ${selectedWeek === week.id
                          ? week.isHistorical
                            ? 'bg-[var(--warning-light)] border border-[var(--at-risk)]/30'
                            : 'bg-gradient-to-r from-[var(--brand-primary)]/8 to-[var(--info)]/8 border border-[var(--brand-primary)]/20'
                          : 'hover:bg-[var(--neutral-100)] border border-transparent'
                        }
                      `}
                    >
                      {week.isHistorical && selectedWeek === week.id && (
                        <Lock className="w-3 h-3 text-[var(--at-risk)]" />
                      )}
                      {!week.isHistorical && selectedWeek === week.id && (
                        <Calendar className="w-3 h-3 text-[var(--brand-primary)]" />
                      )}
                      <div className="flex flex-col items-start">
                        <span className={`text-[14px] font-[500] leading-tight ${
                          selectedWeek === week.id
                            ? week.isHistorical ? 'text-[var(--at-risk)]' : 'text-[var(--brand-primary)]'
                            : 'text-[var(--neutral-600)]'
                        }`}>
                          {week.label}
                        </span>
                        <span className="text-[10px] font-[400] text-[var(--neutral-400)] leading-tight">
                          {week.dateRange}
                        </span>
                      </div>
                      {week.isHistorical && week.grade && (
                        <span className={`text-[10px] font-[600] px-2 py-1 rounded ${
                          selectedWeek === week.id
                            ? 'bg-[var(--at-risk)]/15 text-[var(--at-risk)]'
                            : 'bg-[var(--neutral-100)] text-[var(--neutral-400)]'
                        }`}>
                          {week.grade}
                        </span>
                      )}
                      {week.status === 'in-progress' && selectedWeek === week.id && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[var(--brand-primary)] animate-pulse" />
                      )}
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="text-[12px]">
                    {week.isHistorical
                      ? <p>Historical snapshot — read-only view of {week.dateRange}</p>
                      : <p>Current week — live data, editable</p>
                    }
                  </TooltipContent>
                </Tooltip>
              ))}

              {/* Older week arrow */}
              <button
                onClick={() => canGoOlder && handleWeekSelect(weeks[currentWeekIndex + 1].id)}
                disabled={!canGoOlder}
                className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors ${
                  canGoOlder ? 'hover:bg-[var(--neutral-100)] text-[var(--neutral-600)]' : 'text-[var(--neutral-300)] cursor-not-allowed'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Divider */}
            <div className="w-px h-8 bg-[var(--neutral-200)] mx-3" />

            {/* Filter tabs */}
            <div className="flex items-center gap-1">
              {filterTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleFilterSelect(tab.id)}
                  className={`
                    px-4 py-2 rounded-lg text-[14px] font-[500] transition-all duration-120
                    ${selectedFilter === tab.id
                      ? 'bg-[var(--neutral-100)] text-[var(--neutral-800)]'
                      : 'text-[var(--neutral-400)] hover:text-[var(--neutral-600)] hover:bg-[var(--neutral-50)]'
                    }
                  `}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Historical view banner */}
        {isHistorical && activeWeek && (
          <div className="border-t border-[var(--at-risk)]/20 bg-[var(--warning-light)]">
            <div className="max-w-[1320px] mx-auto px-8">
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <Lock className="w-3.5 h-3.5 text-[var(--at-risk)]" />
                  <span className="text-[12px] font-[500] text-[var(--at-risk)]">
                    HISTORICAL SNAPSHOT
                  </span>
                  <span className="text-[12px] font-[400] text-[var(--neutral-400)]">
                    {activeWeek.dateRange} — This week is closed. All data is read-only.
                  </span>
                  {activeWeek.grade && (
                    <span className="text-[12px] font-[600] px-2 py-1 rounded bg-[var(--at-risk)]/15 text-[var(--at-risk)]">
                      Final Grade: {activeWeek.grade}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => handleWeekSelect('this-week')}
                  className="text-[12px] font-[500] text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] transition-colors px-3 py-1 rounded-md hover:bg-[var(--brand-primary)]/8"
                >
                  Return to This Week
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}
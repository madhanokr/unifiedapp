import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrBadgeVariants = cva(
  'inline-flex items-center justify-center rounded-md border-0 whitespace-nowrap shrink-0 [&>svg]:pointer-events-none gap-1 transition-colors duration-120 uppercase tracking-[0.05em]',
  {
    variants: {
      variant: {
        success: 'bg-[#E5F9F1] text-[#2E9865]',
        warning: 'bg-[#FFF2E6] text-[#F98B2B]',
        danger: 'bg-[#FFE5E5] text-[#D33A3A]',
        info: 'bg-[#E5ECFF] text-[#3452E1]',
        neutral: 'bg-[#F3F3F3] text-[#666666]',
        brand: 'bg-[#6A3DE8]/[0.08] text-[#6A3DE8]',
      },
      size: {
        sm: 'px-2 py-0.5 text-[10px] font-[500] [&>svg]:size-2.5',
        md: 'px-3 py-1 text-[12px] font-[500] [&>svg]:size-3',
      },
    },
    defaultVariants: {
      variant: 'neutral',
      size: 'sm',
    },
  }
);

export interface OkrBadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof okrBadgeVariants> {
  asChild?: boolean;
  className?: string;
}

const OkrBadge = React.forwardRef<HTMLSpanElement, OkrBadgeProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? 'span' : 'span';

    return (
      <Comp
        ref={ref}
        data-slot="okr-badge"
        className={cn(okrBadgeVariants({ variant, size, className }))}
        {...props}
      />
    );
  }
);

OkrBadge.displayName = 'OkrBadge';

export { OkrBadge, okrBadgeVariants };
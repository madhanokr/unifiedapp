import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrSkeletonVariants = cva(
  'bg-[#E5E5E5] animate-pulse',
  {
    variants: {
      variant: {
        text: 'rounded-md h-4 w-full',
        circle: 'rounded-full',
        rect: 'rounded-xl',
      },
    },
    defaultVariants: {
      variant: 'rect',
    },
  }
);

export interface OkrSkeletonProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof okrSkeletonVariants> {
  /** Width — only used for circle/rect. Text defaults to full width. */
  width?: string | number;
  /** Height — required for rect, used as diameter for circle. */
  height?: string | number;
  className?: string;
}

function OkrSkeleton({
  className,
  variant,
  width,
  height,
  style,
  ...props
}: OkrSkeletonProps) {
  const computedStyle: React.CSSProperties = { ...style };

  if (variant === 'circle') {
    const size = width || height || 40;
    computedStyle.width = size;
    computedStyle.height = size;
  } else {
    if (width) computedStyle.width = width;
    if (height) computedStyle.height = height;
  }

  return (
    <div
      data-slot="okr-skeleton"
      className={cn(okrSkeletonVariants({ variant, className }))}
      style={computedStyle}
      {...props}
    />
  );
}

export { OkrSkeleton, okrSkeletonVariants };
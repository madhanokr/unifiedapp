/* ═══════════════════════════════════════════════════════════════════
 * ShiftFocus Design System — Barrel Export
 * Every component + its TypeScript props type in one import.
 * Usage: import { OkrButton, OkrBadge, okrToast } from './components/design-system';
 * ═══════════════════════════════════════════════════════════════════ */

// Button
export { OkrButton, okrButtonVariants } from './button';
export type { OkrButtonProps } from './button';

// Badge
export { OkrBadge, okrBadgeVariants } from './badge';
export type { OkrBadgeProps } from './badge';

// Input
export { OkrInput, okrInputVariants } from './input';
export type { OkrInputProps } from './input';

// Select
export {
  OkrSelect,
  OkrSelectGroup,
  OkrSelectValue,
  OkrSelectTrigger,
  OkrSelectContent,
  OkrSelectItem,
  OkrSelectLabel,
  OkrSelectSeparator,
  OkrSelectField,
} from './select';
export type { OkrSelectTriggerProps, OkrSelectFieldProps } from './select';

// Dialog / Modal
export {
  OkrDialog,
  OkrDialogTrigger,
  OkrDialogClose,
  OkrDialogContent,
  OkrDialogHeader,
  OkrDialogFooter,
  OkrDialogTitle,
  OkrDialogDescription,
  dialogContentVariants,
} from './dialog';
export type { OkrDialogContentProps } from './dialog';

// Drawer / Sheet
export {
  OkrDrawer,
  OkrDrawerTrigger,
  OkrDrawerClose,
  OkrDrawerContent,
  OkrDrawerHeader,
  OkrDrawerFooter,
  OkrDrawerTitle,
  OkrDrawerDescription,
  drawerContentVariants,
} from './drawer';
export type { OkrDrawerContentProps } from './drawer';

// Dropdown Menu
export {
  OkrDropdownMenu,
  OkrDropdownMenuPortal,
  OkrDropdownMenuTrigger,
  OkrDropdownMenuContent,
  OkrDropdownMenuGroup,
  OkrDropdownMenuLabel,
  OkrDropdownMenuItem,
  OkrDropdownMenuCheckboxItem,
  OkrDropdownMenuRadioGroup,
  OkrDropdownMenuRadioItem,
  OkrDropdownMenuSeparator,
  OkrDropdownMenuShortcut,
  OkrDropdownMenuSub,
  OkrDropdownMenuSubTrigger,
  OkrDropdownMenuSubContent,
} from './dropdown-menu';

// Tabs
export {
  OkrTabs,
  OkrTabsList,
  OkrTabsTrigger,
  OkrTabsContent,
  tabsListVariants,
  tabsTriggerVariants,
} from './tabs';
export type { OkrTabsListProps, OkrTabsTriggerProps } from './tabs';

// Tooltip
export {
  OkrTooltip,
  OkrTooltipTrigger,
  OkrTooltipContent,
  OkrTooltipProvider,
} from './tooltip';

// Switch / Toggle
export { OkrSwitch, okrSwitchVariants } from './switch';
export type { OkrSwitchProps } from './switch';

// Checkbox
export { OkrCheckbox } from './checkbox';
export type { OkrCheckboxProps } from './checkbox';

// Card
export {
  OkrCard,
  OkrCardHeader,
  OkrCardTitle,
  OkrCardDescription,
  OkrCardContent,
  OkrCardFooter,
  okrCardVariants,
} from './card';
export type { OkrCardProps } from './card';

// Progress Bar
export { OkrProgressBar, progressTrackVariants, progressIndicatorVariants } from './progress-bar';
export type { OkrProgressBarProps } from './progress-bar';

// Skeleton
export { OkrSkeleton, okrSkeletonVariants } from './skeleton';
export type { OkrSkeletonProps } from './skeleton';

// Empty State
export { OkrEmptyState } from './empty-state';
export type { OkrEmptyStateProps } from './empty-state';

// Toast (Sonner helpers)
export { okrToast } from './toast';
export type { OkrToastOptions } from './toast';

// Confirm Dialog
export { OkrConfirmDialog } from './confirm-dialog';
export type { OkrConfirmDialogProps } from './confirm-dialog';

// Textarea
export { OkrTextarea, okrTextareaVariants } from './textarea';
export type { OkrTextareaProps } from './textarea';
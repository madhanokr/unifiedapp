import * as React from 'react';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ───────── Root / Trigger / Close / Portal ───────── */

function OkrDialog(props: React.ComponentProps<typeof DialogPrimitive.Root>) {
  return <DialogPrimitive.Root data-slot="okr-dialog" {...props} />;
}

function OkrDialogTrigger(props: React.ComponentProps<typeof DialogPrimitive.Trigger>) {
  return <DialogPrimitive.Trigger data-slot="okr-dialog-trigger" {...props} />;
}

function OkrDialogClose(props: React.ComponentProps<typeof DialogPrimitive.Close>) {
  return <DialogPrimitive.Close data-slot="okr-dialog-close" {...props} />;
}

/* ───────── Overlay ───────── */

function OkrDialogOverlay({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Overlay>) {
  return (
    <DialogPrimitive.Overlay
      data-slot="okr-dialog-overlay"
      className={cn(
        'fixed inset-0 z-50 bg-black/50 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0',
        className
      )}
      {...props}
    />
  );
}

/* ───────── Content (with size variants) ───────── */

const dialogContentVariants = cva(
  'bg-white text-[#2B2B2B] fixed top-[50%] left-[50%] z-50 translate-x-[-50%] translate-y-[-50%] rounded-xl border border-[#E5E5E5] okr-modal-shadow data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 w-full max-w-[calc(100%-2rem)]',
  {
    variants: {
      dialogSize: {
        sm: 'sm:max-w-[400px]',
        md: 'sm:max-w-[560px]',
        lg: 'sm:max-w-[720px]',
        xl: 'sm:max-w-[960px]',
      },
    },
    defaultVariants: {
      dialogSize: 'md',
    },
  }
);

export interface OkrDialogContentProps
  extends React.ComponentProps<typeof DialogPrimitive.Content>,
    VariantProps<typeof dialogContentVariants> {
  /** Hide the close X button (still closable via overlay / Escape) */
  hideCloseButton?: boolean;
  className?: string;
}

function OkrDialogContent({
  className,
  dialogSize,
  hideCloseButton = false,
  children,
  ...props
}: OkrDialogContentProps) {
  return (
    <DialogPrimitive.Portal>
      <OkrDialogOverlay />
      <DialogPrimitive.Content
        data-slot="okr-dialog-content"
        className={cn(dialogContentVariants({ dialogSize, className }))}
        {...props}
      >
        <div className="p-6">{children}</div>
        {!hideCloseButton && (
          <DialogPrimitive.Close className="absolute top-4 right-4 rounded-lg w-8 h-8 flex items-center justify-center text-[#A1A1A1] hover:text-[#666666] hover:bg-[#F3F3F3] transition-all duration-120 outline-none focus-visible:ring-2 focus-visible:ring-[#6A3DE8]/15">
            <X className="size-4" />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}

/* ───────── Header / Footer / Title / Description ───────── */

function OkrDialogHeader({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-dialog-header"
      className={cn('flex flex-col gap-2 mb-6', className)}
      {...props}
    />
  );
}

function OkrDialogFooter({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-dialog-footer"
      className={cn('flex justify-end gap-3 mt-6 pt-4 border-t border-[#E5E5E5]', className)}
      {...props}
    />
  );
}

function OkrDialogTitle({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Title>) {
  return (
    <DialogPrimitive.Title
      data-slot="okr-dialog-title"
      className={cn('text-[20px] font-[500] text-[#2B2B2B]', className)}
      {...props}
    />
  );
}

function OkrDialogDescription({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Description>) {
  return (
    <DialogPrimitive.Description
      data-slot="okr-dialog-description"
      className={cn('text-[14px] font-[400] text-[#666666]', className)}
      {...props}
    />
  );
}

export {
  OkrDialog,
  OkrDialogTrigger,
  OkrDialogClose,
  OkrDialogContent,
  OkrDialogHeader,
  OkrDialogFooter,
  OkrDialogTitle,
  OkrDialogDescription,
  dialogContentVariants,
};
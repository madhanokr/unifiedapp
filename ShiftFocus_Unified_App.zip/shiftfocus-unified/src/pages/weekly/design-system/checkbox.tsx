import * as React from 'react';
import * as CheckboxPrimitive from '@radix-ui/react-checkbox';
import { CheckIcon } from 'lucide-react';
import { cn } from '../lib/utils';

export interface OkrCheckboxProps
  extends React.ComponentProps<typeof CheckboxPrimitive.Root> {
  className?: string;
}

function OkrCheckbox({ className, ...props }: OkrCheckboxProps) {
  return (
    <CheckboxPrimitive.Root
      data-slot="okr-checkbox"
      className={cn(
        'peer size-4 shrink-0 rounded-[4px] border border-[#E5E5E5] bg-white transition-all duration-120 outline-none',
        'data-[state=checked]:bg-[#6A3DE8] data-[state=checked]:text-white data-[state=checked]:border-[#6A3DE8]',
        'focus-visible:ring-2 focus-visible:ring-[#6A3DE8]/15',
        'disabled:cursor-not-allowed disabled:opacity-50',
        className
      )}
      {...props}
    >
      <CheckboxPrimitive.Indicator
        data-slot="okr-checkbox-indicator"
        className="flex items-center justify-center text-current transition-none"
      >
        <CheckIcon className="size-3.5" />
      </CheckboxPrimitive.Indicator>
    </CheckboxPrimitive.Root>
  );
}

export { OkrCheckbox };
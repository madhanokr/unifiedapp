import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ───────── Track ───────── */

const progressTrackVariants = cva(
  'bg-[#E5E5E5] rounded-full overflow-hidden w-full',
  {
    variants: {
      progressSize: {
        sm: 'h-1.5',
        md: 'h-2',
      },
    },
    defaultVariants: {
      progressSize: 'md',
    },
  }
);

/* ───────── Indicator ───────── */

const progressIndicatorVariants = cva(
  'h-full rounded-full transition-all duration-300 transition-smooth',
  {
    variants: {
      variant: {
        success: 'bg-[#40C78C]',
        warning: 'bg-[#F98B2B]',
        danger: 'bg-[#E53935]',
        brand: 'bg-gradient-to-r from-[#6A3DE8] to-[#3E8BFF]',
        'brand-success': 'bg-gradient-to-r from-[#40C78C] to-[#3CCB7F]',
      },
    },
    defaultVariants: {
      variant: 'brand',
    },
  }
);

export interface OkrProgressBarProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof progressTrackVariants>,
    VariantProps<typeof progressIndicatorVariants> {
  /** Progress value 0–100 */
  value: number;
  /** Show percentage label to the right */
  showLabel?: boolean;
  className?: string;
}

const OkrProgressBar = React.forwardRef<HTMLDivElement, OkrProgressBarProps>(
  (
    {
      className,
      progressSize,
      variant,
      value,
      showLabel = false,
      ...props
    },
    ref
  ) => {
    const clampedValue = Math.min(100, Math.max(0, value));

    return (
      <div
        ref={ref}
        data-slot="okr-progress-bar"
        className={cn('flex items-center gap-2 w-full', className)}
        {...props}
      >
        <div className={cn(progressTrackVariants({ progressSize }), 'flex-1')}>
          <div
            className={cn(progressIndicatorVariants({ variant }))}
            style={{ width: `${clampedValue}%` }}
            role="progressbar"
            aria-valuenow={clampedValue}
            aria-valuemin={0}
            aria-valuemax={100}
          />
        </div>
        {showLabel && (
          <span className="text-[12px] font-[500] text-[#2B2B2B] tabular-nums shrink-0">
            {clampedValue}%
          </span>
        )}
      </div>
    );
  }
);

OkrProgressBar.displayName = 'OkrProgressBar';

export { OkrProgressBar, progressTrackVariants, progressIndicatorVariants };
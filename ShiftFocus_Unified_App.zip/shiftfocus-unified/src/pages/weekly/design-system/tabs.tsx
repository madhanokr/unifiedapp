import * as React from 'react';
import * as TabsPrimitive from '@radix-ui/react-tabs';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ───────── Root ───────── */

function OkrTabs({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Root>) {
  return (
    <TabsPrimitive.Root
      data-slot="okr-tabs"
      className={cn('flex flex-col gap-2', className)}
      {...props}
    />
  );
}

/* ───────── List (with variant) ───────── */

const tabsListVariants = cva(
  'inline-flex items-center gap-1',
  {
    variants: {
      variant: {
        underline: 'border-b border-[#E5E5E5] pb-0 gap-0',
        pills: 'bg-[#F3F3F3] p-1 rounded-lg',
      },
    },
    defaultVariants: {
      variant: 'pills',
    },
  }
);

export interface OkrTabsListProps
  extends React.ComponentProps<typeof TabsPrimitive.List>,
    VariantProps<typeof tabsListVariants> {
  className?: string;
}

function OkrTabsList({ className, variant, ...props }: OkrTabsListProps) {
  return (
    <TabsPrimitive.List
      data-slot="okr-tabs-list"
      data-variant={variant}
      className={cn(tabsListVariants({ variant, className }))}
      {...props}
    />
  );
}

/* ───────── Trigger (with variant) ───────── */

const tabsTriggerVariants = cva(
  'inline-flex items-center justify-center gap-1.5 text-[14px] font-[500] whitespace-nowrap transition-all duration-120 outline-none disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*="size-"])]:size-4',
  {
    variants: {
      variant: {
        underline:
          'px-4 py-2.5 -mb-px border-b-2 border-transparent text-[#A1A1A1] hover:text-[#666666] data-[state=active]:border-[#6A3DE8] data-[state=active]:text-[#6A3DE8] rounded-none',
        pills:
          'px-4 py-2 rounded-md text-[#666666] hover:text-[#2B2B2B] data-[state=active]:bg-white data-[state=active]:text-[#2B2B2B] data-[state=active]:okr-card-shadow',
      },
    },
    defaultVariants: {
      variant: 'pills',
    },
  }
);

export interface OkrTabsTriggerProps
  extends React.ComponentProps<typeof TabsPrimitive.Trigger>,
    VariantProps<typeof tabsTriggerVariants> {
  className?: string;
}

function OkrTabsTrigger({ className, variant, ...props }: OkrTabsTriggerProps) {
  return (
    <TabsPrimitive.Trigger
      data-slot="okr-tabs-trigger"
      className={cn(tabsTriggerVariants({ variant, className }))}
      {...props}
    />
  );
}

/* ───────── Content ───────── */

function OkrTabsContent({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Content>) {
  return (
    <TabsPrimitive.Content
      data-slot="okr-tabs-content"
      className={cn('flex-1 outline-none', className)}
      {...props}
    />
  );
}

export {
  OkrTabs,
  OkrTabsList,
  OkrTabsTrigger,
  OkrTabsContent,
  tabsListVariants,
  tabsTriggerVariants,
};
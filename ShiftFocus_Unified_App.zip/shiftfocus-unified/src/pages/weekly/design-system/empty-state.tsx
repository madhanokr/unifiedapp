import * as React from 'react';
import { cn } from '../lib/utils';

export interface OkrEmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Lucide icon component (e.g. CheckCircle) */
  icon?: React.ElementType;
  /** Icon color — defaults to #2E9865 (success green) */
  iconColor?: string;
  /** Icon background color — defaults to transparent */
  iconBg?: string;
  /** Primary message */
  message: string;
  /** Message text color — defaults to #2E9865 (success green) */
  messageColor?: string;
  /** Secondary description */
  description?: string;
  /** Optional action button (rendered as-is) */
  action?: React.ReactNode;
  className?: string;
}

function OkrEmptyState({
  icon: Icon,
  iconColor = '#2E9865',
  iconBg,
  message,
  messageColor,
  description,
  action,
  className,
  ...props
}: OkrEmptyStateProps) {
  const resolvedMessageColor = messageColor || iconColor || '#2E9865';

  return (
    <div
      data-slot="okr-empty-state"
      className={cn(
        'bg-[#E5F9F1] border border-[#40C78C]/30 rounded-xl p-8 text-center',
        className
      )}
      {...props}
    >
      {Icon && (
        <div className="flex justify-center mb-3">
          {iconBg ? (
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center okr-card-shadow"
              style={{ backgroundColor: iconBg }}
            >
              <Icon className="w-6 h-6" style={{ color: iconColor }} strokeWidth={2} />
            </div>
          ) : (
            <Icon className="w-8 h-8" style={{ color: iconColor }} strokeWidth={2} />
          )}
        </div>
      )}
      <div className="text-[14px] font-[500]" style={{ color: resolvedMessageColor }}>{message}</div>
      {description && (
        <div className="text-[12px] font-[400] text-[#666666] mt-1">{description}</div>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export { OkrEmptyState };
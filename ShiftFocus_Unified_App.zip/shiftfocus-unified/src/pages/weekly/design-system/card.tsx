import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrCardVariants = cva(
  'bg-white text-[#2B2B2B] rounded-xl border transition-all duration-150 transition-apple',
  {
    variants: {
      variant: {
        default: 'border-[#E5E5E5] okr-card-shadow',
        bordered: 'border-[#E5E5E5]',
        elevated: 'border-[#E5E5E5] okr-elevated-shadow',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
);

export interface OkrCardProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof okrCardVariants> {
  /** Enable hover shadow lift */
  hoverable?: boolean;
  className?: string;
}

const OkrCard = React.forwardRef<HTMLDivElement, OkrCardProps>(
  ({ className, variant, hoverable = false, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-slot="okr-card"
        className={cn(
          okrCardVariants({ variant }),
          hoverable && 'hover:okr-card-shadow-hover cursor-pointer',
          className
        )}
        {...props}
      />
    );
  }
);

OkrCard.displayName = 'OkrCard';

/* ───────── Sub-components ───────── */

function OkrCardHeader({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-card-header"
      className={cn('px-6 pt-6', className)}
      {...props}
    />
  );
}

function OkrCardTitle({ className, ...props }: React.ComponentProps<'h4'>) {
  return (
    <h4
      data-slot="okr-card-title"
      className={cn('text-[16px] font-[500] text-[#2B2B2B]', className)}
      {...props}
    />
  );
}

function OkrCardDescription({ className, ...props }: React.ComponentProps<'p'>) {
  return (
    <p
      data-slot="okr-card-description"
      className={cn('text-[14px] font-[400] text-[#666666] mt-1', className)}
      {...props}
    />
  );
}

function OkrCardContent({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-card-content"
      className={cn('px-6', className)}
      {...props}
    />
  );
}

function OkrCardFooter({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-card-footer"
      className={cn('flex items-center px-6 pb-6', className)}
      {...props}
    />
  );
}

export {
  OkrCard,
  OkrCardHeader,
  OkrCardTitle,
  OkrCardDescription,
  OkrCardContent,
  OkrCardFooter,
  okrCardVariants,
};
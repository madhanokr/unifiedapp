/**
 * ShiftFocus Standardized Toast Helpers
 *
 * Wraps Sonner toast with enforcement-language presets.
 * Every toast includes an icon, primary message, optional description,
 * and can be dismissed programmatically.
 */
import { toast, type ExternalToast } from 'sonner';

const DEFAULT_DURATION = 3000;
const LONG_DURATION = 5000;

export interface OkrToastOptions extends ExternalToast {
  /** Override default duration in ms */
  duration?: number;
}

/**
 * Standard ShiftFocus toast patterns.
 * Every call returns the toast ID for programmatic dismissal.
 */
export const okrToast = {
  /** Positive enforcement — action completed, verified, resolved */
  success(title: string, description?: string, opts?: OkrToastOptions): string | number {
    return toast.success(title, {
      description,
      duration: DEFAULT_DURATION,
      ...opts,
    });
  },

  /** Warning — approaching deadline, drift detected */
  warning(title: string, description?: string, opts?: OkrToastOptions): string | number {
    return toast.warning(title, {
      description,
      duration: LONG_DURATION,
      ...opts,
    });
  },

  /** Error — failed, overdue, escalation triggered */
  error(title: string, description?: string, opts?: OkrToastOptions): string | number {
    return toast.error(title, {
      description,
      duration: LONG_DURATION,
      ...opts,
    });
  },

  /** Neutral — informational, dismissed, navigated */
  info(title: string, description?: string, opts?: OkrToastOptions): string | number {
    return toast(title, {
      description,
      duration: DEFAULT_DURATION,
      ...opts,
    });
  },

  /** Action toast with undo capability */
  withUndo(
    title: string,
    description: string,
    onUndo: () => void,
    opts?: OkrToastOptions
  ): string | number {
    return toast(title, {
      description,
      duration: LONG_DURATION,
      action: {
        label: 'Undo',
        onClick: onUndo,
      },
      ...opts,
    });
  },

  /** Loading toast — returns ID to dismiss later */
  loading(title: string, description?: string): string | number {
    return toast.loading(title, { description });
  },

  /** Dismiss a specific or all toasts */
  dismiss(id?: string | number): void {
    toast.dismiss(id);
  },
};
import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrTextareaVariants = cva(
  'flex w-full min-w-0 rounded-lg border bg-white text-[#2B2B2B] font-[400] transition-all duration-120 outline-none placeholder:text-[#A1A1A1] resize-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50',
  {
    variants: {
      textareaSize: {
        sm: 'px-3 py-2 text-[12px] min-h-[64px]',
        md: 'px-3 py-2 text-[14px] min-h-[120px]',
        lg: 'px-4 py-3 text-[14px] min-h-[240px]',
      },
      error: {
        true: 'border-[#E53935] focus:ring-2 focus:ring-[#E53935]/15 focus:border-[#E53935]',
        false:
          'border-[#E5E5E5] focus:ring-2 focus:ring-[#6A3DE8]/15 focus:border-[#6A3DE8]',
      },
    },
    defaultVariants: {
      textareaSize: 'md',
      error: false,
    },
  }
);

export interface OkrTextareaProps
  extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'size'>,
    VariantProps<typeof okrTextareaVariants> {
  /** Error message shown below the textarea */
  errorMessage?: string;
  className?: string;
}

const OkrTextarea = React.forwardRef<HTMLTextAreaElement, OkrTextareaProps>(
  ({ className, textareaSize, error, errorMessage, ...props }, ref) => {
    const hasError = error ?? !!errorMessage;

    return (
      <div className="w-full">
        <textarea
          ref={ref}
          data-slot="okr-textarea"
          className={cn(
            okrTextareaVariants({ textareaSize, error: hasError, className })
          )}
          aria-invalid={hasError || undefined}
          {...props}
        />
        {hasError && errorMessage && (
          <p className="mt-1 text-[12px] font-[400] text-[#E53935]">
            {errorMessage}
          </p>
        )}
      </div>
    );
  }
);

OkrTextarea.displayName = 'OkrTextarea';

export { OkrTextarea, okrTextareaVariants };
/**
 * OkrTooltip — Re-exports Radix Tooltip with ShiftFocus theming.
 * The ui/tooltip.tsx is already well-built with ShiftFocus tokens.
 */
export {
  Tooltip as OkrTooltip,
  TooltipTrigger as OkrTooltipTrigger,
  TooltipContent as OkrTooltipContent,
  TooltipProvider as OkrTooltipProvider,
} from '../ui/tooltip';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { Slot } from '@radix-ui/react-slot';
import { Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';

const okrButtonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap text-[14px] font-[500] transition-all duration-120 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*="size-"])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-[#6A3DE8]/15 active:scale-[0.98] active:translate-y-[1px]',
  {
    variants: {
      variant: {
        primary:
          'bg-[#6A3DE8] text-white hover:bg-[#7448EE] active:bg-[#5C2FD8] rounded-lg okr-brand-shadow hover:okr-brand-shadow-hover',
        secondary:
          'bg-[#F3F3F3] text-[#2B2B2B] hover:bg-[#E5E5E5] active:bg-[#D5D5D5] rounded-lg',
        ghost:
          'hover:bg-[#FAFAFA] text-[#666666] hover:text-[#2B2B2B] active:bg-[#F3F3F3] rounded-lg',
        destructive:
          'bg-[#E53935] text-white hover:bg-[#D33A3A] active:bg-[#D33A3A] rounded-lg focus-visible:ring-[#E53935]/15',
        outline:
          'border border-[#E5E5E5] bg-white text-[#2B2B2B] hover:bg-[#FAFAFA] active:bg-[#F3F3F3] rounded-lg',
        brand:
          'bg-gradient-to-r from-[#6A3DE8] to-[#3E8BFF] text-white hover:from-[#7448EE] hover:to-[#4F97FF] rounded-lg okr-brand-shadow hover:okr-brand-shadow-hover',
        link: 'text-[#6A3DE8] underline-offset-4 hover:underline',
      },
      size: {
        sm: 'h-[32px] px-3 py-1.5 gap-1.5',
        md: 'h-[40px] px-4 py-2',
        lg: 'h-[48px] px-6 py-3',
        icon: 'size-[40px] rounded-lg',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

export interface OkrButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof okrButtonVariants> {
  /** Renders a loading spinner and disables interactions */
  loading?: boolean;
  /** Renders children via Radix Slot for composability */
  asChild?: boolean;
  /** Additional className for overrides */
  className?: string;
}

const OkrButton = React.forwardRef<HTMLButtonElement, OkrButtonProps>(
  (
    {
      className,
      variant,
      size,
      loading = false,
      asChild = false,
      disabled,
      children,
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : 'button';
    const isDisabled = disabled || loading;

    return (
      <Comp
        ref={ref}
        data-slot="okr-button"
        disabled={isDisabled}
        className={cn(okrButtonVariants({ variant, size, className }))}
        {...props}
      >
        {loading && (
          <Loader2
            className="size-4 animate-spin"
            aria-hidden="true"
          />
        )}
        {children}
      </Comp>
    );
  }
);

OkrButton.displayName = 'OkrButton';

export { OkrButton, okrButtonVariants };
import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrInputVariants = cva(
  'flex w-full min-w-0 rounded-lg border bg-white text-[#2B2B2B] font-[400] transition-all duration-120 outline-none placeholder:text-[#A1A1A1] disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50',
  {
    variants: {
      inputSize: {
        sm: 'h-[32px] px-3 py-1.5 text-[12px]',
        md: 'h-[40px] px-3 py-2 text-[14px]',
      },
      error: {
        true: 'border-[#E53935] focus:ring-2 focus:ring-[#E53935]/15 focus:border-[#E53935]',
        false:
          'border-[#E5E5E5] focus:ring-2 focus:ring-[#6A3DE8]/15 focus:border-[#6A3DE8]',
      },
    },
    defaultVariants: {
      inputSize: 'md',
      error: false,
    },
  }
);

export interface OkrInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof okrInputVariants> {
  /** Error message shown below the input */
  errorMessage?: string;
  className?: string;
}

const OkrInput = React.forwardRef<HTMLInputElement, OkrInputProps>(
  ({ className, inputSize, error, errorMessage, ...props }, ref) => {
    const hasError = error ?? !!errorMessage;

    return (
      <div className="w-full">
        <input
          ref={ref}
          data-slot="okr-input"
          className={cn(
            okrInputVariants({ inputSize, error: hasError, className })
          )}
          aria-invalid={hasError || undefined}
          {...props}
        />
        {hasError && errorMessage && (
          <p className="mt-1 text-[12px] font-[400] text-[#E53935]">
            {errorMessage}
          </p>
        )}
      </div>
    );
  }
);

OkrInput.displayName = 'OkrInput';

export { OkrInput, okrInputVariants };
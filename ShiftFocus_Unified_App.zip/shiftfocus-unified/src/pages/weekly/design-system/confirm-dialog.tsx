/**
 * OkrConfirmDialog — Phase 3: Reusable confirmation dialog for destructive actions
 * 
 * Usage:
 *   <OkrConfirmDialog
 *     open={showConfirm}
 *     onOpenChange={setShowConfirm}
 *     title="Resolve this risk?"
 *     description="This action cannot be undone. The risk will be marked as mitigated."
 *     confirmLabel="Resolve"
 *     variant="destructive"
 *     onConfirm={() => { ... }}
 *   />
 */
import * as React from 'react';
import {
  OkrDialog,
  OkrDialogContent,
  OkrDialogHeader,
  OkrDialogFooter,
  OkrDialogTitle,
  OkrDialogDescription,
} from './dialog';
import { OkrButton } from './button';
import { AlertTriangle, ShieldAlert, Info } from 'lucide-react';

export interface OkrConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'destructive' | 'warning' | 'info';
  onConfirm: () => void;
  onCancel?: () => void;
}

const variantConfig = {
  destructive: {
    icon: AlertTriangle,
    iconBg: '#FFE5E5',
    iconColor: '#E53935',
    buttonVariant: 'destructive' as const,
  },
  warning: {
    icon: ShieldAlert,
    iconBg: '#FFF2E6',
    iconColor: '#F98B2B',
    buttonVariant: 'primary' as const,
  },
  info: {
    icon: Info,
    iconBg: '#E5ECFF',
    iconColor: '#3E8BFF',
    buttonVariant: 'primary' as const,
  },
};

function OkrConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'destructive',
  onConfirm,
  onCancel,
}: OkrConfirmDialogProps) {
  const config = variantConfig[variant];
  const Icon = config.icon;

  const handleConfirm = () => {
    onConfirm();
    onOpenChange(false);
  };

  const handleCancel = () => {
    onCancel?.();
    onOpenChange(false);
  };

  return (
    <OkrDialog open={open} onOpenChange={onOpenChange}>
      <OkrDialogContent dialogSize="sm" hideCloseButton>
        <OkrDialogHeader>
          <div className="flex items-start gap-4">
            <div
              className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ backgroundColor: config.iconBg }}
            >
              <Icon className="w-6 h-6" style={{ color: config.iconColor }} strokeWidth={2} />
            </div>
            <div>
              <OkrDialogTitle>{title}</OkrDialogTitle>
              <OkrDialogDescription className="mt-2">{description}</OkrDialogDescription>
            </div>
          </div>
        </OkrDialogHeader>
        <OkrDialogFooter>
          <OkrButton variant="secondary" size="sm" onClick={handleCancel}>
            {cancelLabel}
          </OkrButton>
          <OkrButton variant={config.buttonVariant} size="sm" onClick={handleConfirm}>
            {confirmLabel}
          </OkrButton>
        </OkrDialogFooter>
      </OkrDialogContent>
    </OkrDialog>
  );
}

export { OkrConfirmDialog };

import * as React from 'react';
import * as SelectPrimitive from '@radix-ui/react-select';
import { CheckIcon, ChevronDownIcon, ChevronUpIcon } from 'lucide-react';
import { cn } from '../lib/utils';

/* ───────── Root / Group / Value ───────── */

function OkrSelect(props: React.ComponentProps<typeof SelectPrimitive.Root>) {
  return <SelectPrimitive.Root data-slot="okr-select" {...props} />;
}

function OkrSelectGroup(props: React.ComponentProps<typeof SelectPrimitive.Group>) {
  return <SelectPrimitive.Group data-slot="okr-select-group" {...props} />;
}

function OkrSelectValue(props: React.ComponentProps<typeof SelectPrimitive.Value>) {
  return <SelectPrimitive.Value data-slot="okr-select-value" {...props} />;
}

/* ───────── Trigger ───────── */

export interface OkrSelectTriggerProps
  extends React.ComponentProps<typeof SelectPrimitive.Trigger> {
  selectSize?: 'sm' | 'md';
  error?: boolean;
  className?: string;
}

function OkrSelectTrigger({
  className,
  selectSize = 'md',
  error = false,
  children,
  ...props
}: OkrSelectTriggerProps) {
  return (
    <SelectPrimitive.Trigger
      data-slot="okr-select-trigger"
      className={cn(
        'flex w-full items-center justify-between gap-2 rounded-lg border bg-white px-3 text-[#2B2B2B] font-[400] transition-all duration-120 outline-none disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*="size-"])]:size-4',
        selectSize === 'sm' ? 'h-[32px] text-[12px]' : 'h-[40px] text-[14px]',
        error
          ? 'border-[#E53935] focus:ring-2 focus:ring-[#E53935]/15 focus:border-[#E53935]'
          : 'border-[#E5E5E5] focus:ring-2 focus:ring-[#6A3DE8]/15 focus:border-[#6A3DE8]',
        className
      )}
      {...props}
    >
      {children}
      <SelectPrimitive.Icon asChild>
        <ChevronDownIcon className="size-4 text-[#A1A1A1]" />
      </SelectPrimitive.Icon>
    </SelectPrimitive.Trigger>
  );
}

/* ───────── Content ───────── */

function OkrSelectContent({
  className,
  children,
  position = 'popper',
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Content>) {
  return (
    <SelectPrimitive.Portal>
      <SelectPrimitive.Content
        data-slot="okr-select-content"
        className={cn(
          'bg-white text-[#2B2B2B] z-50 max-h-[var(--radix-select-content-available-height)] min-w-[8rem] overflow-y-auto rounded-lg border border-[#E5E5E5] p-1 okr-dropdown-shadow',
          'data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95',
          position === 'popper' && 'data-[side=bottom]:translate-y-1 data-[side=top]:-translate-y-1',
          className
        )}
        position={position}
        {...props}
      >
        <OkrSelectScrollUpButton />
        <SelectPrimitive.Viewport
          className={cn(
            'p-1',
            position === 'popper' &&
              'h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)] scroll-my-1'
          )}
        >
          {children}
        </SelectPrimitive.Viewport>
        <OkrSelectScrollDownButton />
      </SelectPrimitive.Content>
    </SelectPrimitive.Portal>
  );
}

/* ───────── Item ───────── */

function OkrSelectItem({
  className,
  children,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Item>) {
  return (
    <SelectPrimitive.Item
      data-slot="okr-select-item"
      className={cn(
        'relative flex w-full cursor-default items-center gap-2 rounded-md py-2 pr-8 pl-3 text-[14px] font-[400] outline-hidden select-none transition-colors hover:bg-[#FAFAFA] focus:bg-[#F3F3F3] data-[disabled]:pointer-events-none data-[disabled]:opacity-50',
        className
      )}
      {...props}
    >
      <span className="absolute right-2 flex size-3.5 items-center justify-center">
        <SelectPrimitive.ItemIndicator>
          <CheckIcon className="size-4 text-[#6A3DE8]" />
        </SelectPrimitive.ItemIndicator>
      </span>
      <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
    </SelectPrimitive.Item>
  );
}

/* ───────── Label / Separator ───────── */

function OkrSelectLabel({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Label>) {
  return (
    <SelectPrimitive.Label
      data-slot="okr-select-label"
      className={cn('px-3 py-1.5 text-[10px] font-[500] text-[#A1A1A1] uppercase tracking-[0.05em]', className)}
      {...props}
    />
  );
}

function OkrSelectSeparator({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Separator>) {
  return (
    <SelectPrimitive.Separator
      data-slot="okr-select-separator"
      className={cn('bg-[#E5E5E5] -mx-1 my-1 h-px', className)}
      {...props}
    />
  );
}

/* ───────── Scroll Buttons ───────── */

function OkrSelectScrollUpButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollUpButton>) {
  return (
    <SelectPrimitive.ScrollUpButton
      className={cn('flex cursor-default items-center justify-center py-1', className)}
      {...props}
    >
      <ChevronUpIcon className="size-4 text-[#A1A1A1]" />
    </SelectPrimitive.ScrollUpButton>
  );
}

function OkrSelectScrollDownButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollDownButton>) {
  return (
    <SelectPrimitive.ScrollDownButton
      className={cn('flex cursor-default items-center justify-center py-1', className)}
      {...props}
    >
      <ChevronDownIcon className="size-4 text-[#A1A1A1]" />
    </SelectPrimitive.ScrollDownButton>
  );
}

/* ───────── Error Wrapper ───────── */

export interface OkrSelectFieldProps {
  error?: boolean;
  errorMessage?: string;
  children: React.ReactNode;
  className?: string;
}

function OkrSelectField({ error, errorMessage, children, className }: OkrSelectFieldProps) {
  return (
    <div className={cn('w-full', className)}>
      {children}
      {(error || errorMessage) && errorMessage && (
        <p className="mt-1 text-[12px] font-[400] text-[#E53935]">{errorMessage}</p>
      )}
    </div>
  );
}

export {
  OkrSelect,
  OkrSelectGroup,
  OkrSelectValue,
  OkrSelectTrigger,
  OkrSelectContent,
  OkrSelectItem,
  OkrSelectLabel,
  OkrSelectSeparator,
  OkrSelectField,
};
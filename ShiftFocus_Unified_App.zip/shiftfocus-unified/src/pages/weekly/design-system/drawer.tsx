import * as React from 'react';
import { Drawer as DrawerPrimitive } from 'vaul';
import { X } from 'lucide-react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

/* ───────── Root / Trigger / Close ───────── */

function OkrDrawer(props: React.ComponentProps<typeof DrawerPrimitive.Root>) {
  return <DrawerPrimitive.Root data-slot="okr-drawer" {...props} />;
}

function OkrDrawerTrigger(props: React.ComponentProps<typeof DrawerPrimitive.Trigger>) {
  return <DrawerPrimitive.Trigger data-slot="okr-drawer-trigger" {...props} />;
}

function OkrDrawerClose(props: React.ComponentProps<typeof DrawerPrimitive.Close>) {
  return <DrawerPrimitive.Close data-slot="okr-drawer-close" {...props} />;
}

/* ───────── Overlay ───────── */

function OkrDrawerOverlay({
  className,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Overlay>) {
  return (
    <DrawerPrimitive.Overlay
      data-slot="okr-drawer-overlay"
      className={cn(
        'fixed inset-0 z-50 bg-black/50 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0',
        className
      )}
      {...props}
    />
  );
}

/* ───────── Content ───────── */

const drawerContentVariants = cva(
  'bg-white fixed z-50 flex flex-col overflow-y-auto okr-drawer-shadow transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500',
  {
    variants: {
      side: {
        right:
          'inset-y-0 right-0 h-full border-l border-[#E5E5E5] data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right w-full md:w-auto',
        left:
          'inset-y-0 left-0 h-full border-r border-[#E5E5E5] data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left w-full md:w-auto',
      },
      drawerSize: {
        sm: 'md:max-w-[400px]',
        md: 'md:max-w-[560px]',
        lg: 'md:max-w-[720px]',
      },
    },
    defaultVariants: {
      side: 'right',
      drawerSize: 'lg',
    },
  }
);

export interface OkrDrawerContentProps
  extends React.ComponentProps<typeof DrawerPrimitive.Content>,
    VariantProps<typeof drawerContentVariants> {
  /** Hide the close X button */
  hideCloseButton?: boolean;
  className?: string;
}

function OkrDrawerContent({
  className,
  side,
  drawerSize,
  hideCloseButton = false,
  children,
  ...props
}: OkrDrawerContentProps) {
  return (
    <DrawerPrimitive.Portal>
      <OkrDrawerOverlay />
      <DrawerPrimitive.Content
        data-slot="okr-drawer-content"
        className={cn(drawerContentVariants({ side, drawerSize, className }))}
        {...props}
      >
        {children}
        {!hideCloseButton && (
          <DrawerPrimitive.Close className="absolute top-4 right-4 z-10 rounded-lg w-10 h-10 flex items-center justify-center text-[#A1A1A1] hover:text-[#666666] hover:bg-[#F3F3F3] transition-all duration-120 outline-none focus-visible:ring-2 focus-visible:ring-[#6A3DE8]/15">
            <X className="size-5" />
            <span className="sr-only">Close</span>
          </DrawerPrimitive.Close>
        )}
      </DrawerPrimitive.Content>
    </DrawerPrimitive.Portal>
  );
}

/* ───────── Header / Footer / Title / Description ───────── */

function OkrDrawerHeader({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-drawer-header"
      className={cn('flex flex-col gap-1.5 p-6', className)}
      {...props}
    />
  );
}

function OkrDrawerFooter({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="okr-drawer-footer"
      className={cn('mt-auto flex flex-col gap-2 p-6 border-t border-[#E5E5E5]', className)}
      {...props}
    />
  );
}

function OkrDrawerTitle({
  className,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Title>) {
  return (
    <DrawerPrimitive.Title
      data-slot="okr-drawer-title"
      className={cn('text-[20px] font-[500] text-[#2B2B2B]', className)}
      {...props}
    />
  );
}

function OkrDrawerDescription({
  className,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Description>) {
  return (
    <DrawerPrimitive.Description
      data-slot="okr-drawer-description"
      className={cn('text-[14px] font-[400] text-[#666666]', className)}
      {...props}
    />
  );
}

export {
  OkrDrawer,
  OkrDrawerTrigger,
  OkrDrawerClose,
  OkrDrawerContent,
  OkrDrawerHeader,
  OkrDrawerFooter,
  OkrDrawerTitle,
  OkrDrawerDescription,
  drawerContentVariants,
};
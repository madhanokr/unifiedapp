import * as React from 'react';
import * as SwitchPrimitive from '@radix-ui/react-switch';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const okrSwitchVariants = cva(
  'peer inline-flex shrink-0 items-center rounded-full border border-transparent transition-all duration-120 outline-none focus-visible:ring-2 focus-visible:ring-[#6A3DE8]/15 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-[#6A3DE8] data-[state=unchecked]:bg-[#E5E5E5]',
  {
    variants: {
      switchSize: {
        sm: 'h-[18px] w-[32px]',
        md: 'h-[24px] w-[44px]',
      },
    },
    defaultVariants: {
      switchSize: 'sm',
    },
  }
);

const thumbVariants = cva(
  'pointer-events-none block rounded-full bg-white ring-0 transition-transform data-[state=unchecked]:translate-x-0',
  {
    variants: {
      switchSize: {
        sm: 'size-[14px] data-[state=checked]:translate-x-[14px]',
        md: 'size-[20px] data-[state=checked]:translate-x-[20px]',
      },
    },
    defaultVariants: {
      switchSize: 'sm',
    },
  }
);

export interface OkrSwitchProps
  extends React.ComponentProps<typeof SwitchPrimitive.Root>,
    VariantProps<typeof okrSwitchVariants> {
  className?: string;
}

function OkrSwitch({ className, switchSize, ...props }: OkrSwitchProps) {
  return (
    <SwitchPrimitive.Root
      data-slot="okr-switch"
      className={cn(okrSwitchVariants({ switchSize, className }))}
      {...props}
    >
      <SwitchPrimitive.Thumb
        data-slot="okr-switch-thumb"
        className={cn(thumbVariants({ switchSize }))}
      />
    </SwitchPrimitive.Root>
  );
}

export { OkrSwitch, okrSwitchVariants };
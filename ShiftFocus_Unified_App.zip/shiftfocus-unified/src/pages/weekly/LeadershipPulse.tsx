import { useState, useCallback } from 'react';
import { AlertCircle, Clock, Users, Zap, CheckCircle } from 'lucide-react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger, OkrSkeleton, OkrEmptyState, OkrButton, OkrConfirmDialog, okrToast } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { LeadershipPulseItem } from './db';

const iconMap: Record<number, typeof Clock> = {
  1: Clock,
  2: AlertCircle,
  3: Users,
  4: Zap,
};

function PulseSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="rounded-xl border border-[#E5E5E5] p-6">
          <div className="flex items-start gap-4 mb-4">
            <OkrSkeleton variant="rect" width={40} height={40} className="rounded-lg" />
            <div className="flex-1 space-y-1">
              <OkrSkeleton variant="text" height={32} width={40} />
              <OkrSkeleton variant="text" height={12} width="80%" />
            </div>
          </div>
          <OkrSkeleton variant="text" height={12} width="90%" />
          <OkrSkeleton variant="text" height={12} width="60%" className="mt-1" />
          <OkrSkeleton variant="text" height={10} width={100} className="mt-3" />
        </div>
      ))}
    </div>
  );
}

export function LeadershipPulse() {
  const loader = useCallback(() => db.getPulseItems(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<LeadershipPulseItem[]>(loader);
  const [confirmItem, setConfirmItem] = useState<LeadershipPulseItem | null>(null);

  if (state === 'loading') {
    return (
      <TooltipProvider>
        <section>
          <div className="mb-6">
            <OkrSkeleton variant="text" height={20} width={220} />
            <OkrSkeleton variant="text" height={14} width={280} className="mt-2" />
          </div>
          <PulseSkeleton />
        </section>
      </TooltipProvider>
    );
  }

  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="#E53935"
          message="Failed to load leadership pulse"
          description={error || 'localStorage read failed'}
          className="bg-[#FFE5E5] border-[#E53935]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const items = loadedData || [];

  if (items.length === 0) {
    return (
      <section>
        <OkrEmptyState
          icon={Zap}
          iconColor="#3E8BFF"
          iconBg="#3E8BFF"
          message="No pulse items this week"
          description="All leadership action items have been addressed."
        />
      </section>
    );
  }

  const activeItems = items.filter(i => !i.resolved);

  const handleResolve = (item: LeadershipPulseItem) => {
    const updated = db.resolvePulseItem(item.id);
    setData(updated);
    okrToast.success(`Resolved: ${item.count} ${item.label}`, 'Item addressed. Audit trail recorded.');
  };

  return (
    <TooltipProvider>
      <section>
        {/* Confirmation dialog for resolving pulse items */}
        <OkrConfirmDialog
          open={confirmItem !== null}
          onOpenChange={(open) => !open && setConfirmItem(null)}
          title={`Resolve: ${confirmItem?.count || 0} ${confirmItem?.label || ''}?`}
          description="This will mark the item as addressed and update the leadership pulse. This action cannot be undone."
          confirmLabel="Resolve"
          variant="warning"
          onConfirm={() => {
            if (confirmItem) handleResolve(confirmItem);
          }}
        />

        <div className="mb-6">
          <Tooltip>
            <TooltipTrigger className="inline-flex items-center gap-2 cursor-help">
              <h2 className="text-[20px] font-[500] text-[#2B2B2B] mb-1">Weekly Leadership Pulse</h2>
              {activeItems.length > 0 && (
                <div className="w-2 h-2 rounded-full bg-[#E53935] animate-pulse" />
              )}
            </TooltipTrigger>
            <TooltipContent>
              <p>Urgent items requiring your immediate attention this week</p>
            </TooltipContent>
          </Tooltip>
          <p className="text-[14px] font-[400] text-[#666666]">
            {activeItems.length > 0 
              ? 'Items requiring your immediate attention' 
              : 'All pulse items addressed'
            }
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {items.map((item) => {
            const Icon = iconMap[item.id] || AlertCircle;
            const isResolved = item.resolved;

            return (
              <Tooltip key={item.id}>
                <TooltipTrigger asChild>
                  <div 
                    className={`rounded-xl p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple cursor-pointer border ${
                      isResolved ? 'opacity-60' : ''
                    }`}
                    style={{ 
                      backgroundColor: isResolved ? '#E5F9F1' : item.bgColor,
                      borderColor: isResolved ? '#40C78C' : item.borderColor
                    }}
                    onClick={() => !isResolved && setConfirmItem(item)}
                  >
                    <div className="flex items-start gap-4 mb-4">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 okr-card-shadow"
                        style={{ backgroundColor: isResolved ? '#40C78C' : item.iconBg }}
                      >
                        {isResolved ? (
                          <CheckCircle className="w-5 h-5 text-white" strokeWidth={2} />
                        ) : (
                          <Icon className="w-5 h-5 text-white" strokeWidth={2} />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="text-[32px] font-[600] text-[#2B2B2B] mb-1 leading-none tabular-nums">
                          {isResolved ? '0' : item.count}
                        </div>
                        <div className="text-[12px] font-[400] text-[#666666]">{item.label}</div>
                      </div>
                    </div>
                    <div className="text-[12px] font-[400] text-[#666666] leading-relaxed">
                      {isResolved ? 'Addressed — no further action required' : item.description}
                    </div>
                    {!isResolved && (
                      <div className="mt-3 text-[10px] font-[500] text-[#6A3DE8] uppercase tracking-[0.05em]">
                        Click to resolve →
                      </div>
                    )}
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{item.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>
      </section>
    </TooltipProvider>
  );
}
import { useState, useEffect, useCallback } from 'react';
import { CheckCircle, Circle, Flame, AlertCircle } from 'lucide-react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger, OkrProgressBar, OkrSkeleton, OkrEmptyState, OkrButton, okrToast } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { Ritual } from './db';

function HabitLoopRowSkeleton() {
  return (
    <div className="bg-gradient-to-r from-[var(--brand-primary)]/[0.04] via-[var(--info)]/[0.04] to-[var(--brand-primary)]/[0.04] border-b border-[var(--neutral-200)]">
      <div className="max-w-[1320px] mx-auto px-8 py-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-8 flex-wrap">
            <div className="flex items-center gap-2">
              <OkrSkeleton variant="text" height={14} width={140} />
              <OkrSkeleton variant="rect" height={24} width={40} className="rounded-md" />
            </div>
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center gap-2">
                <OkrSkeleton variant="circle" width={16} height={16} />
                <OkrSkeleton variant="text" height={12} width={80} />
              </div>
            ))}
          </div>
          <OkrSkeleton variant="rect" height={40} width={120} className="rounded-lg" />
        </div>
        <div className="mt-4">
          <OkrSkeleton variant="rect" height={8} />
        </div>
      </div>
    </div>
  );
}

export function HabitLoopRow() {
  const ritualsLoader = useCallback(() => db.getRituals(), []);
  const streakLoader = useCallback(() => db.getStreak(), []);
  const { data: ritualsData, state: ritualsState, error: ritualsError, retry: retryRituals, setData: setRituals } = useSimulatedLoad<Ritual[]>(ritualsLoader);
  const { data: streakData, state: streakState, setData: setStreak } = useSimulatedLoad(streakLoader);

  const isLoading = ritualsState === 'loading' || streakState === 'loading';

  const rituals = ritualsData || [];
  const streak = streakData || { count: 0, lastCompletedWeek: null };

  const completedCount = rituals.filter(r => r.completed).length;
  const totalCount = rituals.length;
  const allComplete = completedCount === totalCount && totalCount > 0;

  // Check if all rituals just completed
  useEffect(() => {
    if (allComplete && !streak.lastCompletedWeek) {
      const updated = db.incrementStreak();
      setStreak(updated);
      okrToast.success('All rituals completed! Streak extended.', `${updated.count} consecutive weeks of execution discipline.`);
    }
  }, [allComplete, streak.lastCompletedWeek]);

  const handleToggle = (id: number) => {
    const updated = db.toggleRitual(id);
    setRituals(updated);
    const ritual = updated.find(r => r.id === id);
    if (ritual?.completed) {
      okrToast.success(`"${ritual.label}" — completed`, undefined, { duration: 2000 });
    }
  };

  if (isLoading) return <HabitLoopRowSkeleton />;

  if (ritualsState === 'error') {
    return (
      <div className="border-b border-[var(--neutral-200)] p-4">
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="var(--danger)"
          message="Failed to load rituals"
          description={ritualsError || 'localStorage read failed'}
          className="bg-[var(--danger-light)] border-[var(--danger)]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retryRituals}>Retry</OkrButton>}
        />
      </div>
    );
  }

  if (rituals.length === 0) {
    return (
      <div className="border-b border-[var(--neutral-200)] p-4">
        <OkrEmptyState
          icon={CheckCircle}
          message="No rituals configured"
          description="Configure weekly rituals to enforce execution discipline."
        />
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-[var(--brand-primary)]/[0.04] via-[var(--info)]/[0.04] to-[var(--brand-primary)]/[0.04] border-b border-[var(--neutral-200)]">
      <div className="max-w-[1320px] mx-auto px-8 py-4">
        <TooltipProvider>
          <div className="flex items-center justify-between flex-wrap gap-4">
            {/* Left: Rituals */}
            <div className="flex items-center gap-8 flex-wrap">
              <Tooltip>
                <TooltipTrigger className="flex items-center gap-2 cursor-help">
                  <div className="text-[14px] font-[500] text-[var(--neutral-800)]">This Week's Rituals:</div>
                  <div className={`text-[12px] font-[500] px-3 py-1 rounded-md ${
                    allComplete 
                      ? 'bg-[var(--success-light)] text-[var(--success-active)]' 
                      : 'bg-[var(--brand-primary)]/[0.08] text-[var(--brand-primary)]'
                  }`}>
                    {completedCount}/{totalCount}
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Complete all 5 rituals to keep your leadership streak alive</p>
                </TooltipContent>
              </Tooltip>

              {rituals.map((ritual) => (
                <Tooltip key={ritual.id}>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => handleToggle(ritual.id)}
                      className="flex items-center gap-2 group"
                    >
                      {ritual.completed ? (
                        <CheckCircle className="w-4 h-4 text-[var(--success)]" strokeWidth={2} />
                      ) : (
                        <Circle className="w-4 h-4 text-[var(--neutral-200)] group-hover:text-[var(--neutral-400)] transition-colors duration-120" strokeWidth={2} />
                      )}
                      <span className={`text-[12px] font-[400] ${
                        ritual.completed ? 'text-[var(--neutral-800)] line-through' : 'text-[var(--neutral-600)]'
                      }`}>
                        {ritual.label}
                      </span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{ritual.tooltip}</p>
                  </TooltipContent>
                </Tooltip>
              ))}
            </div>

            {/* Right: Streak */}
            <Tooltip>
              <TooltipTrigger className="flex items-center gap-3 bg-white px-4 py-2 rounded-lg border border-[var(--neutral-200)] cursor-help okr-card-shadow hover:okr-card-shadow-hover transition-shadow duration-150">
                <Flame className="w-5 h-5 text-[var(--warning)]" fill="var(--warning)" />
                <div>
                  <div className="text-[10px] font-[500] tracking-[0.05em] text-[var(--warning)] uppercase">Streak</div>
                  <div className="text-[14px] font-[500] text-[var(--neutral-800)] tabular-nums">{streak.count} weeks</div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>You've completed all rituals for {streak.count} consecutive weeks. Don't break the chain!</p>
              </TooltipContent>
            </Tooltip>
          </div>

          {/* Progress bar */}
          <div className="mt-4">
            <OkrProgressBar
              value={(completedCount / totalCount) * 100}
              variant={allComplete ? 'brand-success' : 'brand'}
              progressSize="md"
            />
          </div>
        </TooltipProvider>
      </div>
    </div>
  );
}
import { useState, useCallback } from 'react';
import { TrendingUp, Sparkles, X, Check, Target, AlertCircle } from 'lucide-react';
import { OkrButton, OkrBadge, OkrProgressBar, OkrSkeleton, OkrEmptyState, okrToast } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { KeyResult } from './db';
import { z } from 'zod';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip as RechartsTooltip } from 'recharts';

const krUpdateSchema = z.object({
  progress: z.number().min(0).max(100),
  note: z.string().min(1, 'Update note is required').max(500, 'Note must be under 500 characters'),
  confidence: z.enum(['High', 'Medium', 'Low'], { required_error: 'Confidence is required' }),
});

type KRUpdateForm = z.infer<typeof krUpdateSchema>;

function KRCheckInLaneSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-5 space-y-4">
              <OkrSkeleton variant="text" height={16} width="80%" />
              <OkrSkeleton variant="text" height={12} width="60%" />
              <div className="flex items-center gap-3">
                <OkrSkeleton variant="circle" width={32} height={32} />
                <div className="space-y-1">
                  <OkrSkeleton variant="text" height={12} width={80} />
                  <OkrSkeleton variant="text" height={10} width={40} />
                </div>
              </div>
              <OkrSkeleton variant="rect" height={40} />
            </div>
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center justify-between">
                <OkrSkeleton variant="text" height={12} width={60} />
                <OkrSkeleton variant="text" height={14} width={50} />
              </div>
              <OkrSkeleton variant="rect" height={8} />
              <OkrSkeleton variant="text" height={12} width={100} />
              <OkrSkeleton variant="rect" height={24} />
            </div>
            <div className="lg:col-span-3 space-y-2">
              <OkrSkeleton variant="rect" height={32} />
              <OkrSkeleton variant="rect" height={32} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function KRCheckInLane() {
  const loader = useCallback(() => db.getKeyResults(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<KeyResult[]>(loader);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [predictingId, setPredictingId] = useState<number | null>(null);

  const { control, handleSubmit, formState: { errors }, reset, watch } = useForm<KRUpdateForm>({
    resolver: zodResolver(krUpdateSchema),
    defaultValues: {
      progress: 0,
      note: '',
      confidence: 'High',
    },
  });

  // Loading state
  if (state === 'loading') return <KRCheckInLaneSkeleton />;

  // Error state
  if (state === 'error') {
    return (
      <OkrEmptyState
        icon={AlertCircle}
        iconColor="var(--danger)"
        message="Failed to load key results"
        description={error || 'localStorage read failed'}
        className="bg-[var(--danger-light)] border-[var(--danger)]/30"
        action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
      />
    );
  }

  const keyResults = loadedData || [];

  // Empty state
  if (keyResults.length === 0) {
    return (
      <OkrEmptyState
        icon={Target}
        iconColor="var(--brand-primary)"
        iconBg="var(--brand-primary)"
        message="No key results found"
        description="Configure key results to begin tracking commitments."
      />
    );
  }

  const handleStartEdit = (kr: KeyResult) => {
    setEditingId(kr.id);
    reset({
      progress: kr.progress,
      note: '',
      confidence: kr.confidence,
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    reset();
  };

  const onSubmit = (data: KRUpdateForm) => {
    const kr = keyResults.find(k => k.id === editingId);
    if (!kr) return;

    const change = data.progress - kr.progress;
    const changeStr = change >= 0 ? `+${change}` : `${change}`;
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const confidenceColor = data.confidence === 'High' ? 'var(--success-on-track)' : data.confidence === 'Medium' ? 'var(--at-risk)' : 'var(--danger)';
    const status = data.confidence === 'Low' ? 'blocked' as const : data.progress < 50 ? 'at-risk' as const : 'on-track' as const;

    const updated = db.updateKeyResult(kr.id, {
      progress: data.progress,
      change: changeStr,
      confidence: data.confidence,
      confidenceColor,
      status,
      lastUpdate: `Today ${timeStr}: ${data.note}`,
      progressHistory: [...kr.progressHistory.slice(-5), data.progress],
    });
    setData(updated);
    setEditingId(null);
    reset();
    okrToast.success(`KR updated: ${kr.name.slice(0, 40)}...`, `Progress: ${kr.progress}% → ${data.progress}% (${changeStr})`);
  };

  const handleAIPredict = (kr: KeyResult) => {
    setPredictingId(kr.id);
    setTimeout(() => {
      const predicted = Math.min(100, kr.progress + Math.floor(Math.random() * 15) + 3);
      const weeksToComplete = Math.ceil((100 - kr.progress) / ((predicted - kr.progress) || 5));
      okrToast.success(
        `AI Prediction: ${kr.name.slice(0, 30)}...`,
        `Forecasted at ${predicted}% next week. ~${weeksToComplete} weeks to 100% at current velocity.`,
        { duration: 5000 }
      );
      setPredictingId(null);
    }, 1200);
  };

  return (
    <div>
      <div className="space-y-4">
        {keyResults.map((kr) => {
          const isEditing = editingId === kr.id;
          const isPredicting = predictingId === kr.id;

          // Prepare chart data
          const chartData = kr.progressHistory.map((val, i) => ({
            index: i,
            value: val,
          }));

          return (
            <div
              key={kr.id}
              className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple"
            >
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* Left: KR Info */}
                <div className="md:col-span-5 space-y-4">
                  <div>
                    <div className="text-[14px] font-[500] text-[var(--neutral-800)] mb-1">{kr.name}</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{kr.objective}</div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[var(--brand-primary)] to-[var(--info)] flex items-center justify-center text-white text-[12px] font-[500]">
                      {kr.ownerAvatar}
                    </div>
                    <div>
                      <div className="text-[12px] font-[500] text-[var(--neutral-800)]">{kr.owner}</div>
                      <div className="text-[10px] font-[400] text-[var(--neutral-400)] uppercase tracking-[0.05em]">Owner</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {kr.updatedAt ? (
                      <OkrBadge variant="success" size="sm">Updated</OkrBadge>
                    ) : (
                      <OkrBadge variant="warning" size="sm">Update Due</OkrBadge>
                    )}
                  </div>

                  <div className="text-[12px] font-[400] text-[var(--neutral-600)] bg-white rounded-lg p-3 border border-[var(--neutral-200)]">
                    {kr.lastUpdate}
                  </div>
                </div>

                {/* Center: Progress */}
                <div className="md:col-span-4 flex flex-col justify-center space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-[500] text-[var(--neutral-600)]">Progress</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[14px] font-[500] text-[var(--neutral-800)] tabular-nums">{kr.progress}%</span>
                      {kr.change && (
                        <span className={`text-[12px] font-[500] tabular-nums ${
                          kr.change.startsWith('+') ? 'text-[var(--success-on-track)]' : kr.change.startsWith('-') ? 'text-[var(--danger)]' : 'text-[var(--neutral-600)]'
                        }`}>
                          {kr.change}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <OkrProgressBar
                    value={kr.progress}
                    variant={
                      kr.status === 'on-track'
                        ? 'success'
                        : kr.status === 'blocked'
                          ? 'danger'
                          : 'warning'
                    }
                    progressSize="md"
                  />

                  <div className="flex items-center gap-2">
                    <span className="text-[12px] font-[400] text-[var(--neutral-600)]">Confidence:</span>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: kr.confidenceColor }}
                      />
                      <span className="text-[12px] font-[500] text-[var(--neutral-800)]">{kr.confidence}</span>
                    </div>
                  </div>

                  {/* Recharts sparkline */}
                  <div className="h-8 w-full">
                    <ResponsiveContainer width="100%" height={32}>
                      <BarChart data={chartData} margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
                        <Bar dataKey="value" fill="var(--brand-primary)" radius={[2, 2, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="md:col-span-3 flex flex-col gap-2 justify-center">
                  {isEditing ? (
                    <form onSubmit={handleSubmit(onSubmit)} className="space-y-3 bg-white rounded-lg p-4 border border-[var(--brand-primary)]/20">
                      <div className="flex items-center justify-between">
                        <span className="text-[12px] font-[500] text-[var(--neutral-800)]">Update Progress</span>
                        <button type="button" onClick={handleCancelEdit}>
                          <X className="w-4 h-4 text-[var(--neutral-400)] hover:text-[var(--neutral-600)]" />
                        </button>
                      </div>
                      <div>
                        <Controller
                          name="progress"
                          control={control}
                          render={({ field }) => (
                            <>
                              <input
                                type="range"
                                min={0}
                                max={100}
                                value={field.value}
                                onChange={(e) => field.onChange(Number(e.target.value))}
                                className="w-full accent-[var(--brand-primary)]"
                              />
                              <div className="flex justify-between text-[10px] text-[var(--neutral-400)] tabular-nums mt-1">
                                <span>0%</span>
                                <span className="text-[14px] font-[500] text-[var(--brand-primary)]">{watch('progress')}%</span>
                                <span>100%</span>
                              </div>
                            </>
                          )}
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-[500] text-[var(--neutral-600)] uppercase tracking-[0.05em] mb-1 block">Confidence</label>
                        <Controller
                          name="confidence"
                          control={control}
                          render={({ field }) => (
                            <div className="flex gap-1">
                              {(['High', 'Medium', 'Low'] as const).map(c => (
                                <button
                                  type="button"
                                  key={c}
                                  onClick={() => field.onChange(c)}
                                  className={`flex-1 py-1 text-[10px] font-[500] rounded-md border transition-all ${
                                    field.value === c 
                                      ? c === 'High' ? 'bg-[var(--success-light)] border-[var(--success-on-track)] text-[var(--success-active)]' 
                                        : c === 'Medium' ? 'bg-[var(--warning-light)] border-[var(--at-risk)] text-[var(--at-risk)]' 
                                        : 'bg-[var(--danger-light)] border-[var(--danger)] text-[var(--danger)]'
                                      : 'border-[var(--neutral-200)] text-[var(--neutral-400)]'
                                  }`}
                                >
                                  {c}
                                </button>
                              ))}
                            </div>
                          )}
                        />
                        {errors.confidence && <div className="text-[10px] text-[var(--danger)] mt-1">{errors.confidence.message}</div>}
                      </div>
                      <Controller
                        name="note"
                        control={control}
                        render={({ field }) => (
                          <>
                            <textarea
                              {...field}
                              placeholder="What changed? (required)"
                              className="w-full text-[12px] p-2 rounded-md border border-[var(--neutral-200)] resize-none h-16 focus:border-[var(--brand-primary)] outline-none"
                            />
                            {errors.note && <div className="text-[10px] text-[var(--danger)]">{errors.note.message}</div>}
                          </>
                        )}
                      />
                      <OkrButton
                        type="submit"
                        size="sm"
                        className="w-full"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        Submit Update
                      </OkrButton>
                    </form>
                  ) : (
                    <>
                      <OkrButton
                        size="sm"
                        onClick={() => handleStartEdit(kr)}
                        className="w-full justify-start gap-2"
                      >
                        <TrendingUp className="w-4 h-4" />
                        {kr.updatedAt ? 'Update Again' : 'Update Now'}
                      </OkrButton>
                      <OkrButton
                        size="sm"
                        variant="outline"
                        loading={isPredicting}
                        onClick={() => handleAIPredict(kr)}
                        className="w-full justify-start gap-2 text-[var(--brand-primary)] border-[var(--brand-primary)]/20 hover:bg-[var(--brand-primary)]/[0.04]"
                      >
                        <Sparkles className="w-4 h-4" />
                        {isPredicting ? 'Predicting...' : 'AI Predict'}
                      </OkrButton>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
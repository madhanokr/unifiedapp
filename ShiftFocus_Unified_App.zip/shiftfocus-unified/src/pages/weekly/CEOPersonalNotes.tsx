import { useState, useCallback } from 'react';
import { Edit3, Save, History, X, Clock, AlertCircle } from 'lucide-react';
import { OkrButton, OkrSkeleton, OkrEmptyState, OkrTextarea, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { CEONotes } from './db';
import { z } from 'zod';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

const ceoNotesSchema = z.object({
  content: z.string().min(1, 'Notes cannot be empty').max(5000, 'Notes must be under 5000 characters'),
});

type CEONotesForm = z.infer<typeof ceoNotesSchema>;

function NotesSkeleton() {
  return (
    <div className="bg-white rounded-xl border border-[#E5E5E5] p-8 okr-card-shadow">
      <div className="space-y-4">
        <OkrSkeleton variant="text" height={14} width="90%" />
        <OkrSkeleton variant="text" height={14} width="80%" />
        <OkrSkeleton variant="text" height={14} width="70%" />
        <OkrSkeleton variant="text" height={14} width="85%" />
        <OkrSkeleton variant="text" height={14} width="60%" />
        <OkrSkeleton variant="text" height={14} width="75%" />
        <OkrSkeleton variant="text" height={14} width="50%" />
      </div>
    </div>
  );
}

export function CEOPersonalNotes() {
  const loader = useCallback(() => db.getCEONotes(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<CEONotes>(loader);
  const [isEditing, setIsEditing] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  const { control, handleSubmit, formState: { errors }, reset } = useForm<CEONotesForm>({
    resolver: zodResolver(ceoNotesSchema),
    defaultValues: {
      content: '',
    },
  });

  if (state === 'loading') {
    return (
      <TooltipProvider>
        <section>
          <div className="mb-8">
            <OkrSkeleton variant="text" height={20} width={240} />
            <OkrSkeleton variant="text" height={14} width={280} className="mt-2" />
          </div>
          <NotesSkeleton />
        </section>
      </TooltipProvider>
    );
  }

  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="#E53935"
          message="Failed to load CEO notes"
          description={error || 'localStorage read failed'}
          className="bg-[#FFE5E5] border-[#E53935]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const ceoNotes = loadedData || { content: '', savedAt: null, history: [] };

  const onSubmit = (data: CEONotesForm) => {
    const updated = db.saveCEONotes(data.content);
    setData(updated);
    setIsEditing(false);
    okrToast.success('Notes saved', 'Your leadership notes have been persisted.');
  };

  const handleCancel = () => {
    setIsEditing(false);
    reset({ content: ceoNotes.content });
  };

  const handleStartEdit = () => {
    reset({ content: ceoNotes.content });
    setIsEditing(true);
  };

  const handleRestoreVersion = (content: string) => {
    reset({ content });
    setIsEditing(true);
    setShowHistory(false);
    okrToast.info('Version restored to editor', 'Review and save to apply.');
  };

  return (
    <TooltipProvider>
      <section>
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <Tooltip>
              <TooltipTrigger className="inline-flex items-center gap-2 cursor-help">
                <h2 className="text-[20px] font-[500] text-[#2B2B2B]">CEO Notes for This Week</h2>
                <Edit3 className="w-4 h-4 text-[#6A3DE8]" strokeWidth={2} />
              </TooltipTrigger>
              <TooltipContent>
                <p>Your private notes and reflections on this week's execution. Saved to localStorage with version history.</p>
              </TooltipContent>
            </Tooltip>
            <div className="flex gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <OkrButton
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => setShowHistory(!showHistory)}
                    disabled={ceoNotes.history.length === 0}
                  >
                    <History className="w-4 h-4" strokeWidth={2} />
                    History ({ceoNotes.history.length})
                  </OkrButton>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{ceoNotes.history.length === 0 ? 'No previous versions yet' : 'View previous versions of your weekly notes'}</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </div>
          <p className="text-[14px] font-[400] text-[#666666]">Your private reflections and leadership notes</p>
        </div>

        {/* History Panel */}
        {showHistory && ceoNotes.history.length > 0 && (
          <div className="mb-6 bg-[#FAFAFA] rounded-xl border border-[#E5E5E5] p-6 okr-card-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="text-[14px] font-[500] text-[#2B2B2B]">Version History</div>
              <button onClick={() => setShowHistory(false)}>
                <X className="w-4 h-4 text-[#A1A1A1] hover:text-[#666666]" />
              </button>
            </div>
            <div className="space-y-3 max-h-[300px] overflow-y-auto">
              {ceoNotes.history.slice().reverse().map((entry, idx) => (
                <div key={idx} className="bg-white rounded-lg border border-[#E5E5E5] p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-[10px] font-[500] text-[#A1A1A1] uppercase tracking-[0.05em]">
                      <Clock className="w-3 h-3" />
                      {new Date(entry.savedAt).toLocaleString()}
                    </div>
                    <OkrButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleRestoreVersion(entry.content)}
                      className="h-6 text-[10px] px-2 text-[#6A3DE8] border-[#6A3DE8]/20"
                    >
                      Restore
                    </OkrButton>
                  </div>
                  <div className="text-[12px] font-[400] text-[#666666] whitespace-pre-wrap line-clamp-3">
                    {entry.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {showHistory && ceoNotes.history.length === 0 && (
          <div className="mb-6 bg-[#FAFAFA] rounded-xl border border-[#E5E5E5] p-6 text-center">
            <div className="text-[14px] font-[400] text-[#666666]">No previous versions yet. Save your first edit to start history.</div>
          </div>
        )}

        <div className="bg-white rounded-xl border border-[#E5E5E5] p-8 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple">
          {isEditing ? (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <Controller
                name="content"
                control={control}
                render={({ field }) => (
                  <OkrTextarea
                    {...field}
                    textareaSize="lg"
                    error={!!errors.content}
                    errorMessage={errors.content?.message}
                    className="bg-[#FAFAFA]"
                    placeholder="Write your thoughts, decisions, and reflections for this week..."
                  />
                )}
              />
              <div className="flex justify-between items-center pt-2">
                <div className="text-[12px] font-[400] text-[#666666] flex items-center gap-2">
                  {ceoNotes.savedAt && (
                    <>
                      <span className="w-2 h-2 rounded-full bg-[#40C78C]" />
                      Last saved: {new Date(ceoNotes.savedAt).toLocaleString()}
                    </>
                  )}
                </div>
                <div className="flex gap-2">
                  <OkrButton
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleCancel}
                  >
                    Cancel
                  </OkrButton>
                  <OkrButton
                    type="submit"
                    size="sm"
                    variant="brand"
                    className="gap-2"
                  >
                    <Save className="w-4 h-4" strokeWidth={2} />
                    Save Notes
                  </OkrButton>
                </div>
              </div>
            </form>
          ) : (
            <div
              onClick={handleStartEdit}
              className="min-h-[240px] text-[14px] font-[400] text-[#2B2B2B] leading-relaxed whitespace-pre-wrap cursor-text hover:bg-[#FAFAFA] rounded-lg p-6 transition-all duration-120 border border-transparent hover:border-[#E5E5E5]"
            >
              {ceoNotes.content || (
                <span className="text-[#A1A1A1] italic">
                  Click to add your thoughts and reflections for this week...
                </span>
              )}
            </div>
          )}
        </div>
      </section>
    </TooltipProvider>
  );
}
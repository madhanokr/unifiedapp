import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const badgeVariants = cva(
  "inline-flex items-center justify-center rounded-md border-0 px-3 py-1.5 text-[12px] font-[500] uppercase tracking-[0.01em] w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none transition-colors duration-120",
  {
    variants: {
      variant: {
        default:
          "bg-[#6A3DE8]/[0.08] text-[#6A3DE8]",
        success:
          "bg-[#E5F9F1] text-[#2E9865]",
        warning:
          "bg-[#FFF2E6] text-[#F98B2B]",
        danger:
          "bg-[#FFE5E5] text-[#D33A3A]",
        info:
          "bg-[#E5ECFF] text-[#3452E1]",
        secondary:
          "bg-[#F3F3F3] text-[#666666]",
        outline:
          "border border-[#E5E5E5] bg-white text-[#2B2B2B]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

function Badge({
  className,
  variant,
  asChild = false,
  ...props
}: React.ComponentProps<"span"> &
  VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "span";

  return (
    <Comp
      data-slot="badge"
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    />
  );
}

export { Badge, badgeVariants };

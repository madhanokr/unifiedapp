import { useState, useCallback } from 'react';
import { TrendingUp, TrendingDown, Minus, Sparkles, Check, AlertCircle } from 'lucide-react';
import { OkrButton, OkrSkeleton, OkrEmptyState, OkrConfirmDialog, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { Prediction } from './db';

type PredVal = 'up' | 'down' | 'stable' | null;

function PredictionSkeleton() {
  return (
    <div className="bg-gradient-to-br from-[#6A3DE8]/[0.06] via-[#3E8BFF]/[0.06] to-[#6A3DE8]/[0.06] rounded-2xl border border-[#6A3DE8]/20 p-6">
      <OkrSkeleton variant="text" height={14} width="60%" className="mb-2" />
      <OkrSkeleton variant="text" height={12} width="40%" className="mb-6" />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-xl border border-[#E5E5E5] p-4">
            <OkrSkeleton variant="text" height={14} width={80} className="mb-4" />
            <div className="flex gap-2">
              <OkrSkeleton variant="rect" height={36} className="flex-1 rounded-lg" />
              <OkrSkeleton variant="rect" height={36} className="flex-1 rounded-lg" />
              <OkrSkeleton variant="rect" height={36} className="flex-1 rounded-lg" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function WeeklyPredictionBox() {
  const loader = useCallback(() => db.getPrediction(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<Prediction>(loader);
  const [saved, setSaved] = useState(false);
  const [showLockConfirm, setShowLockConfirm] = useState(false);

  if (state === 'loading') {
    return (
      <TooltipProvider>
        <section>
          <div className="mb-6">
            <OkrSkeleton variant="text" height={20} width={360} />
            <OkrSkeleton variant="text" height={14} width={320} className="mt-2" />
          </div>
          <PredictionSkeleton />
        </section>
      </TooltipProvider>
    );
  }

  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="#E53935"
          message="Failed to load predictions"
          description={error || 'localStorage read failed'}
          className="bg-[#FFE5E5] border-[#E53935]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const predictions = loadedData || { momentum: null, confidence: null, risk: null, savedAt: null };
  const isSaved = saved || !!predictions.savedAt;

  const updatePrediction = (metric: 'momentum' | 'confidence' | 'risk', value: PredVal) => {
    if (isSaved) return;
    const updated = db.updatePrediction({ [metric]: value });
    setData(updated);
  };

  const allPredicted = predictions.momentum && predictions.confidence && predictions.risk;

  const handleSave = () => {
    const updated = db.savePrediction();
    setData(updated);
    setSaved(true);
    okrToast.success('Consequence forecast locked', 'Your prediction is recorded. We\'ll compare vs. reality next Monday.', { duration: 4000 });
  };

  return (
    <TooltipProvider>
      <section>
        {/* Confirmation dialog for locking prediction */}
        <OkrConfirmDialog
          open={showLockConfirm}
          onOpenChange={setShowLockConfirm}
          title="Lock your consequence forecast?"
          description="Once locked, your prediction cannot be changed. It will be compared against actual results next Monday. This action cannot be undone."
          confirmLabel="Lock Prediction"
          variant="info"
          onConfirm={handleSave}
        />

        <div className="mb-6">
          <Tooltip>
            <TooltipTrigger className="inline-flex items-center gap-2 cursor-help">
              <h2 className="text-[20px] font-[500] text-[#2B2B2B] mb-1">If Nothing Changes — Consequence Forecast</h2>
              <Sparkles className="w-5 h-5 text-[#6A3DE8]" strokeWidth={2} />
            </TooltipTrigger>
            <TooltipContent>
              <p>Your intuitive prediction helps calibrate AI and builds strategic pattern recognition</p>
            </TooltipContent>
          </Tooltip>
          <p className="text-[14px] font-[400] text-[#666666]">Forecast assumes no further updates or verification</p>
        </div>

        <div className="bg-gradient-to-br from-[#6A3DE8]/[0.06] via-[#3E8BFF]/[0.06] to-[#6A3DE8]/[0.06] rounded-2xl border border-[#6A3DE8]/20 p-6 okr-card-shadow">
          <div className="mb-6">
            <div className="text-[14px] font-[500] text-[#2B2B2B] mb-2">
              Based on current trajectory — what happens <span className="text-[#6A3DE8]">next week</span>?
            </div>
            <div className="text-[12px] font-[400] text-[#666666]">
              Your prediction builds strategic intuition and helps identify execution gaps
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* Momentum */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={`bg-white rounded-xl border p-4 okr-card-shadow transition-all ${isSaved ? 'opacity-80' : ''} ${predictions.momentum ? 'border-[#6A3DE8]/20' : 'border-[#E5E5E5]'}`}>
                  <div className="text-[14px] font-[500] text-[#2B2B2B] mb-4">Momentum</div>
                  <div className="flex gap-2">
                    {([['up', TrendingUp], ['stable', Minus], ['down', TrendingDown]] as const).map(([val, Icon]) => (
                      <button
                        key={val}
                        onClick={() => updatePrediction('momentum', val)}
                        disabled={isSaved}
                        className={`flex-1 py-2 px-4 rounded-lg border transition-all duration-120 disabled:cursor-not-allowed ${
                          predictions.momentum === val
                            ? val === 'up' ? 'bg-[#E5F9F1] border-[#40C78C] text-[#2E9865]'
                              : val === 'stable' ? 'bg-[#E5ECFF] border-[#3E8BFF] text-[#3452E1]'
                              : 'bg-[#FFE5E5] border-[#E53935] text-[#D33A3A]'
                            : 'border-[#E5E5E5] text-[#666666] hover:border-[#A1A1A1]'
                        }`}
                      >
                        <Icon className="w-4 h-4 mx-auto" strokeWidth={2} />
                      </button>
                    ))}
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Will the company move faster or slower next week?</p>
              </TooltipContent>
            </Tooltip>

            {/* Confidence */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={`bg-white rounded-xl border p-4 okr-card-shadow transition-all ${isSaved ? 'opacity-80' : ''} ${predictions.confidence ? 'border-[#6A3DE8]/20' : 'border-[#E5E5E5]'}`}>
                  <div className="text-[14px] font-[500] text-[#2B2B2B] mb-4">Confidence</div>
                  <div className="flex gap-2">
                    {([['up', TrendingUp], ['stable', Minus], ['down', TrendingDown]] as const).map(([val, Icon]) => (
                      <button
                        key={val}
                        onClick={() => updatePrediction('confidence', val)}
                        disabled={isSaved}
                        className={`flex-1 py-2 px-4 rounded-lg border transition-all duration-120 disabled:cursor-not-allowed ${
                          predictions.confidence === val
                            ? val === 'up' ? 'bg-[#E5F9F1] border-[#40C78C] text-[#2E9865]'
                              : val === 'stable' ? 'bg-[#E5ECFF] border-[#3E8BFF] text-[#3452E1]'
                              : 'bg-[#FFE5E5] border-[#E53935] text-[#D33A3A]'
                            : 'border-[#E5E5E5] text-[#666666] hover:border-[#A1A1A1]'
                        }`}
                      >
                        <Icon className="w-4 h-4 mx-auto" strokeWidth={2} />
                      </button>
                    ))}
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Will team confidence in achieving outcomes increase or decrease?</p>
              </TooltipContent>
            </Tooltip>

            {/* Risk */}
            <Tooltip>
              <TooltipTrigger asChild>
                <div className={`bg-white rounded-xl border p-4 okr-card-shadow transition-all ${isSaved ? 'opacity-80' : ''} ${predictions.risk ? 'border-[#6A3DE8]/20' : 'border-[#E5E5E5]'}`}>
                  <div className="text-[14px] font-[500] text-[#2B2B2B] mb-4">Risk</div>
                  <div className="flex gap-2">
                    {([['up', TrendingUp], ['stable', Minus], ['down', TrendingDown]] as const).map(([val, Icon]) => (
                      <button
                        key={val}
                        onClick={() => updatePrediction('risk', val)}
                        disabled={isSaved}
                        className={`flex-1 py-2 px-4 rounded-lg border transition-all duration-120 disabled:cursor-not-allowed ${
                          predictions.risk === val
                            ? val === 'up' ? 'bg-[#FFE5E5] border-[#E53935] text-[#D33A3A]'
                              : val === 'stable' ? 'bg-[#E5ECFF] border-[#3E8BFF] text-[#3452E1]'
                              : 'bg-[#E5F9F1] border-[#40C78C] text-[#2E9865]'
                            : 'border-[#E5E5E5] text-[#666666] hover:border-[#A1A1A1]'
                        }`}
                      >
                        <Icon className="w-4 h-4 mx-auto" strokeWidth={2} />
                      </button>
                    ))}
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Will risks increase or decrease next week?</p>
              </TooltipContent>
            </Tooltip>
          </div>

          {allPredicted && !isSaved && (
            <div className="bg-[#6A3DE8]/[0.08] rounded-lg p-4 flex items-center justify-between border border-[#6A3DE8]/20">
              <div className="flex items-center gap-4">
                <Sparkles className="w-5 h-5 text-[#6A3DE8]" strokeWidth={2} />
                <div className="text-[14px] font-[500] text-[#2B2B2B]">
                  Prediction ready. Lock it in?
                </div>
              </div>
              <OkrButton size="sm" onClick={() => setShowLockConfirm(true)}>
                Lock Prediction
              </OkrButton>
            </div>
          )}

          {isSaved && (
            <div className="bg-[#E5F9F1] rounded-lg p-4 flex items-center gap-4 border border-[#40C78C]/30">
              <Check className="w-5 h-5 text-[#2E9865]" strokeWidth={2} />
              <div>
                <div className="text-[14px] font-[500] text-[#2E9865]">
                  Consequence forecast locked
                </div>
                <div className="text-[12px] font-[400] text-[#666666]">
                  Saved {predictions.savedAt ? new Date(predictions.savedAt).toLocaleString() : 'now'}. Comparison available next Monday.
                </div>
              </div>
            </div>
          )}
        </div>
      </section>
    </TooltipProvider>
  );
}
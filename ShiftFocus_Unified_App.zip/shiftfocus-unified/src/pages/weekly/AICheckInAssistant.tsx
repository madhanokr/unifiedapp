import { useState, useEffect } from 'react';
import { Sparkles, Zap, FileText, AlertCircle, Calendar, Target, TrendingUp, CheckCircle } from 'lucide-react';
import { OkrButton, OkrSkeleton, okrToast } from './design-system';

interface AICheckInAssistantProps {
  onFixMyWeek: () => void;
}

const aiResponses: Record<string, { title: string; desc: string }> = {
  'Summarize my week': {
    title: 'Weekly Summary Generated',
    desc: '4 KRs updated (+12% avg progress), 5 KPIs tracked, 3 risks flagged, 2 escalations pending. Overall momentum: positive. Key risk: Enterprise PMF timeline.',
  },
  'What changed the most?': {
    title: 'Biggest Change Detected',
    desc: 'Engineering velocity surged +15% this week — highest in 6 months. Conversely, Sales conversion dipped -3%, requiring attention before Q1 close.',
  },
  'Identify blockers': {
    title: '3 Active Blockers Identified',
    desc: '1) Resource constraints on PMF (High) 2) Customer NPS drift (Medium) 3) Q1 revenue target at risk (High). Use "Fix My Week" for AI solutions.',
  },
  'Generate meeting agenda': {
    title: 'Leadership Meeting Agenda Ready',
    desc: '1) Review Q1 revenue gap ($100K) 2) PMF resource reallocation 3) Engineering knowledge transfer plan 4) Sales enablement decision. Duration: 45min.',
  },
  'Recommend top 3 actions': {
    title: 'Top 3 Required Actions',
    desc: '1) Reassign 2 engineers to PMF initiative 2) Launch sales conversion recovery program 3) Schedule knowledge transfer for departing engineer.',
  },
  'Predict future risks': {
    title: 'Risk Prediction Complete',
    desc: 'If current trajectory holds: 78% chance Q1 revenue misses by $100K+, 65% chance NPS drops below 65, 40% chance feature delivery slips 2+ weeks.',
  },
};

const aiActionClusters = [
  {
    title: 'Identify Problems',
    actions: [
      { icon: FileText, label: 'Summarize my week', iconBg: 'var(--info)' },
      { icon: TrendingUp, label: 'What changed the most?', iconBg: 'var(--brand-primary)' },
      { icon: AlertCircle, label: 'Identify blockers', iconBg: 'var(--at-risk)' },
    ]
  },
  {
    title: 'Execute Decisions',
    actions: [
      { icon: Calendar, label: 'Generate meeting agenda', iconBg: 'var(--success-on-track)' },
      { icon: Zap, label: 'Fix my week', iconBg: 'var(--brand-primary)' },
    ]
  },
  {
    title: 'Prevent Failures',
    actions: [
      { icon: CheckCircle, label: 'Recommend top 3 actions', iconBg: 'var(--info)' },
      { icon: Target, label: 'Predict future risks', iconBg: 'var(--danger)' },
    ]
  }
];

function AISkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 rounded-xl bg-[var(--neutral-100)] p-10">
        <OkrSkeleton variant="rect" width={64} height={64} className="rounded-lg mb-6" />
        <OkrSkeleton variant="text" height={24} width="60%" className="mb-3" />
        <OkrSkeleton variant="text" height={14} width="80%" className="mb-2" />
        <OkrSkeleton variant="text" height={14} width="60%" className="mb-8" />
        <OkrSkeleton variant="rect" width={180} height={48} className="rounded-lg" />
      </div>
      <div className="bg-white rounded-xl border border-[var(--neutral-200)] p-6">
        <OkrSkeleton variant="text" height={14} width={120} className="mb-6" />
        {[1, 2, 3, 4, 5, 6, 7].map((i) => (
          <div key={i} className="flex items-center gap-3 p-3 mb-2">
            <OkrSkeleton variant="rect" width={36} height={36} className="rounded-lg" />
            <OkrSkeleton variant="text" height={14} width="60%" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function AICheckInAssistant({ onFixMyWeek }: AICheckInAssistantProps) {
  const [processingAction, setProcessingAction] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate 800ms loading
  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const handleAction = (label: string) => {
    if (label === 'Fix my week') {
      onFixMyWeek();
      return;
    }

    setProcessingAction(label);

    setTimeout(() => {
      const response = aiResponses[label];
      if (response) {
        okrToast.success(response.title, response.desc, { duration: 6000 });
      }
      setProcessingAction(null);
    }, 800);
  };

  if (isLoading) {
    return (
      <section>
        <div className="mb-6">
          <OkrSkeleton variant="text" height={20} width={200} />
          <OkrSkeleton variant="text" height={14} width={400} className="mt-2" />
        </div>
        <AISkeleton />
      </section>
    );
  }

  return (
    <section>
      <div className="mb-6">
        <h2 className="text-[20px] font-[500] text-[var(--neutral-800)] mb-2">AI Check-In Assistant</h2>
        <p className="text-[14px] font-[400] text-[var(--neutral-600)]">Your weekly AI co-pilot. See everything. Fix everything. In 30 seconds.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main CTA Card - AI Component (gradients allowed) */}
        <div className="lg:col-span-2 relative overflow-hidden rounded-xl bg-gradient-to-br from-[var(--brand-primary)] to-[var(--gradient-end)] p-10 text-white okr-card-shadow-hover transition-all duration-200">
          <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative z-10">
            <div className="w-16 h-16 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center mb-6 transition-transform duration-150">
              <Sparkles className="w-8 h-8 text-white" strokeWidth={2} />
            </div>
            
            <h3 className="text-[24px] font-[600] text-white mb-3 leading-tight">Fix My Week with AI</h3>
            <p className="text-white/90 mb-8 leading-relaxed max-w-lg text-[14px] font-[400]">
              Get instant analysis of blockers, AI-powered solutions, and a personalized weekly focus plan. Turn chaos into clarity in seconds.
            </p>

            <OkrButton 
              size="lg" 
              onClick={onFixMyWeek}
              className="bg-white text-[var(--brand-primary)] hover:bg-white/95 okr-card-shadow-hover transition-all duration-150 h-[48px] px-6 text-[14px] font-[500]"
            >
              <Zap className="w-5 h-5 mr-2" strokeWidth={2} />
              Fix My Week →
            </OkrButton>
          </div>
        </div>

        {/* Quick Actions - Clustered */}
        <div className="bg-white rounded-xl border border-[var(--neutral-200)] p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150">
          <div className="text-[14px] font-[500] text-[var(--neutral-800)] mb-6">Quick AI Actions</div>
          <div className="space-y-5">
            {aiActionClusters.map((cluster) => (
              <div key={cluster.title}>
                <div className="text-[10px] font-[500] uppercase tracking-[0.05em] text-[var(--neutral-400)] mb-3 px-3">
                  {cluster.title}
                </div>
                <div className="space-y-2">
                  {cluster.actions.map((action) => {
                    const Icon = action.icon;
                    const isProcessing = processingAction === action.label;
                    return (
                      <button
                        key={action.label}
                        onClick={() => handleAction(action.label)}
                        disabled={isProcessing}
                        className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-[var(--neutral-50)] transition-all duration-120 transition-apple text-left group disabled:opacity-60"
                      >
                        <div 
                          className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform duration-150 okr-card-shadow ${isProcessing ? 'animate-pulse' : ''}`}
                          style={{ backgroundColor: action.iconBg }}
                        >
                          <Icon className="w-4 h-4 text-white" strokeWidth={2} />
                        </div>
                        <span className="text-[14px] font-[400] text-[var(--neutral-800)] group-hover:text-[var(--brand-primary)] transition-colors">
                          {isProcessing ? 'Processing...' : action.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
import { useState, useCallback } from 'react';
import { Target, AlertCircle, TrendingUp, Link2, CheckCircle } from 'lucide-react';
import { OkrEmptyState, OkrSkeleton, OkrConfirmDialog, OkrButton, okrToast } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { AlignmentIssue } from './db';

const iconMap: Record<string, typeof AlertCircle> = {
  'Teams Out-of-Sync': AlertCircle,
  'KRs Without Updates': Target,
  'KPIs Contradicting OKRs': TrendingUp,
  'Dependencies Blocked': Link2,
  'cross-team': AlertCircle,
  'internal': Target,
};

function AlignmentSkeleton() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="bg-white rounded-xl border border-[var(--neutral-200)] p-8">
        <div className="flex items-center justify-between mb-6">
          <OkrSkeleton variant="text" height={14} width={120} />
          <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
        </div>
        <OkrSkeleton variant="text" height={32} width={80} className="mb-4" />
        <OkrSkeleton variant="text" height={12} width="60%" className="mb-6" />
        <OkrSkeleton variant="rect" height={8} className="mb-6" />
        <div className="space-y-2">
          <div className="flex justify-between">
            <OkrSkeleton variant="text" height={12} width={80} />
            <OkrSkeleton variant="text" height={12} width={20} />
          </div>
          <div className="flex justify-between">
            <OkrSkeleton variant="text" height={12} width={60} />
            <OkrSkeleton variant="text" height={12} width={20} />
          </div>
        </div>
      </div>
      <div className="lg:col-span-2 space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-xl border border-[var(--neutral-200)] p-6">
            <div className="flex items-start gap-4">
              <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
              <div className="flex-1 space-y-2">
                <OkrSkeleton variant="text" height={14} width="40%" />
                <OkrSkeleton variant="text" height={12} width="70%" />
              </div>
              <OkrSkeleton variant="text" height={12} width={80} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AlignmentHealth() {
  const loader = useCallback(() => db.getAlignmentIssues(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<AlignmentIssue[]>(loader);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [confirmIssue, setConfirmIssue] = useState<AlignmentIssue | null>(null);

  if (state === 'loading') {
    return (
      <section>
        <div className="mb-8">
          <OkrSkeleton variant="text" height={20} width={180} />
          <OkrSkeleton variant="text" height={14} width={300} className="mt-2" />
        </div>
        <AlignmentSkeleton />
      </section>
    );
  }

  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="var(--danger)"
          message="Failed to load alignment health"
          description={error || 'localStorage read failed'}
          className="bg-[var(--danger-light)] border-[var(--danger)]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const issues = loadedData || [];
  const activeIssues = issues.filter(i => !i.resolved);
  const resolvedCount = issues.filter(i => i.resolved).length;
  const overallScore = resolvedCount > 0
    ? Math.min(100, 87 + (resolvedCount * 3))
    : 87;

  const handleResolve = (issue: AlignmentIssue) => {
    const updated = db.resolveAlignmentIssue(issue.id);
    setData(updated);
    okrToast.success(`Resolved: ${issue.type}`, `${issue.count} issue${issue.count > 1 ? 's' : ''} addressed. Alignment score updated.`);
  };

  return (
    <section>
      {/* Confirmation dialog for resolving alignment issues */}
      <OkrConfirmDialog
        open={confirmIssue !== null}
        onOpenChange={(open) => !open && setConfirmIssue(null)}
        title={`Resolve: ${confirmIssue?.type || ''}?`}
        description={`This will mark ${confirmIssue?.count || 0} issue${(confirmIssue?.count || 0) > 1 ? 's' : ''} as addressed and update the alignment score. This action cannot be undone.`}
        confirmLabel="Mark as Resolved"
        variant="warning"
        onConfirm={() => {
          if (confirmIssue) handleResolve(confirmIssue);
        }}
      />

      <div className="mb-8">
        <h2 className="text-[20px] font-[500] text-[var(--neutral-800)] mb-2">Alignment Health</h2>
        <p className="text-[14px] font-[400] text-[var(--neutral-600)]">Cross-team coherence and strategic synchronization</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Overall Alignment Score */}
        <div className="bg-white rounded-xl border border-[var(--neutral-200)] p-8 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple">
          <div className="flex items-center justify-between mb-6">
            <div className="text-[14px] font-[500] text-[var(--neutral-600)]">Overall Alignment</div>
            <div className="w-12 h-12 rounded-lg bg-[var(--success-light)] flex items-center justify-center okr-card-shadow">
              <Target className="w-5 h-5 text-[var(--success)]" strokeWidth={2} />
            </div>
          </div>

          <div className="mb-6">
            <div className="text-[32px] font-[600] text-[var(--neutral-800)] mb-4 tabular-nums leading-none">{overallScore}%</div>
            <div className="text-[12px] font-[400] text-[var(--neutral-600)]">Company-wide alignment score</div>
          </div>

          <div className="relative h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden mb-6">
            <div
              className="absolute top-0 left-0 h-full bg-gradient-to-r from-[var(--success)] to-[#3CCB7F] rounded-full transition-all duration-300 transition-smooth"
              style={{ width: `${overallScore}%` }}
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-[12px] font-[400] text-[var(--neutral-600)]">
              <span>Active issues</span>
              <span className="tabular-nums font-[500] text-[var(--neutral-800)]">{activeIssues.length}</span>
            </div>
            <div className="flex items-center justify-between text-[12px] font-[400] text-[var(--neutral-600)]">
              <span>Resolved</span>
              <span className="tabular-nums font-[500] text-[var(--success-active)]">{resolvedCount}</span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-[var(--neutral-200)]">
            <div className="flex items-center gap-2 text-[12px] font-[400] text-[var(--neutral-600)] flex-wrap">
              <span className="flex items-center gap-1">
                Marketing <span className="text-[var(--danger)]">↘</span>
              </span>
              <span className="text-[var(--neutral-200)]">|</span>
              <span className="flex items-center gap-1">
                Sales <span className="text-[var(--success)]">↗</span>
              </span>
              <span className="text-[var(--neutral-200)]">|</span>
              <span className="flex items-center gap-1">
                Engineering <span className="text-[var(--success)]">↗</span>
              </span>
            </div>
          </div>
        </div>

        {/* Alignment Issues */}
        <div className="lg:col-span-2 space-y-4">
          {activeIssues.map((issue) => {
            const Icon = iconMap[issue.type] || AlertCircle;
            const isExpanded = expandedId === issue.id;
            return (
              <div
                key={issue.id}
                className="border rounded-xl overflow-hidden okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple"
                style={{
                  backgroundColor: issue.bgColor,
                  borderColor: issue.borderColor
                }}
              >
                <div className="p-6">
                  <div className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 okr-card-shadow"
                      style={{ backgroundColor: issue.iconBg }}
                    >
                      <Icon className="w-5 h-5 text-white" strokeWidth={2} />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[14px] font-[500] text-[var(--neutral-800)]">{issue.type}</span>
                        <span
                          className="text-[10px] font-[500] px-3 py-1 rounded-md uppercase tracking-[0.05em]"
                          style={{
                            backgroundColor: issue.badgeColor.bg,
                            color: issue.badgeColor.text
                          }}
                        >
                          {issue.count} issue{issue.count > 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="text-[12px] font-[400] text-[var(--neutral-600)] leading-relaxed">
                        {issue.description}
                      </div>
                    </div>

                    <button
                      onClick={() => setExpandedId(isExpanded ? null : issue.id)}
                      className="text-[12px] font-[500] text-[var(--brand-primary)] hover:text-[var(--brand-primary-active)] flex-shrink-0 transition-colors duration-120"
                    >
                      {isExpanded ? 'Hide Details' : 'View Details →'}
                    </button>
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div className="border-t px-6 py-4 bg-white/60" style={{ borderColor: issue.borderColor + '40' }}>
                    <div className="space-y-2 mb-4">
                      {issue.details.map((detail, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-[12px] font-[400] text-[var(--neutral-800)]">
                          <span className="text-[var(--danger)] mt-0.5 flex-shrink-0">•</span>
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                    <OkrButton
                      size="sm"
                      onClick={() => setConfirmIssue(issue)}
                      style={{ backgroundColor: issue.iconBg }}
                      className="text-white"
                    >
                      Mark as Resolved
                    </OkrButton>
                  </div>
                )}
              </div>
            );
          })}

          {resolvedCount > 0 && (
            <div className="bg-[var(--success-light)] border border-[var(--success)]/30 rounded-xl p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[var(--success-active)]" />
                <span className="text-[12px] font-[500] text-[var(--success-active)]">
                  {resolvedCount} alignment issue{resolvedCount > 1 ? 's' : ''} resolved
                </span>
              </div>
            </div>
          )}

          {activeIssues.length === 0 && (
            <OkrEmptyState
              icon={CheckCircle}
              message="Full alignment achieved"
              description="All teams synchronized."
            />
          )}
        </div>
      </div>
    </section>
  );
}
import { useState, useEffect } from 'react';
import { TrendingUp, Shield, Activity, AlertTriangle } from 'lucide-react';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger, OkrSkeleton } from './design-system';
import { db } from './db';

function SnapshotSkeleton() {
  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <div>
          <OkrSkeleton variant="text" height={20} width={180} />
          <OkrSkeleton variant="text" height={14} width={240} className="mt-2" />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="rounded-xl border border-[var(--neutral-200)] p-6">
            <div className="flex items-start justify-between mb-4">
              <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
              <OkrSkeleton variant="rect" width={40} height={20} className="rounded-md" />
            </div>
            <div className="space-y-2">
              <OkrSkeleton variant="text" height={12} width="60%" />
              <OkrSkeleton variant="text" height={32} width="40%" />
              <OkrSkeleton variant="text" height={12} width="80%" />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ThisWeekSnapshot() {
  const [, setTick] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  // Initial simulated load
  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 800);
    return () => clearTimeout(timer);
  }, []);

  // Poll for changes — only after initial load
  useEffect(() => {
    if (!isLoaded) return;
    const interval = setInterval(() => setTick(t => t + 1), 2000);
    return () => clearInterval(interval);
  }, [isLoaded]);

  if (!isLoaded) return <SnapshotSkeleton />;

  let krs, teams, risks;
  try {
    krs = db.getKeyResults();
    teams = db.getTeams();
    risks = db.getRisks();
  } catch {
    return <SnapshotSkeleton />;
  }

  const avgProgress = krs.length > 0 ? Math.round(krs.reduce((s, k) => s + k.progress, 0) / krs.length) : 0;
  const avgConfidence = teams.length > 0 ? Math.round(teams.reduce((s, t) => s + t.confidence, 0) / teams.length) : 0;
  const onTrackPct = krs.length > 0 ? Math.round((krs.filter(k => k.status === 'on-track').length / krs.length) * 100) : 0;
  const criticalRisks = risks.filter(r => !r.resolved && r.severity === 'critical').length;

  const snapshots = [
    {
      title: 'Weekly Momentum',
      value: `+${Math.max(0, avgProgress - 60)}%`,
      trend: 'up',
      description: 'How fast the company moved this week.',
      icon: TrendingUp,
      iconBg: 'var(--brand-primary)',
      bgColor: 'var(--neutral-50)'
    },
    {
      title: 'Weekly Confidence',
      value: `${avgConfidence}%`,
      status: avgConfidence >= 85 ? 'High' : avgConfidence >= 70 ? 'Medium' : 'Low',
      description: 'Team belief in achieving outcomes.',
      icon: Shield,
      iconBg: 'var(--info)',
      bgColor: 'var(--neutral-50)'
    },
    {
      title: 'Weekly Predictability',
      value: `${onTrackPct}%`,
      description: 'Likelihood of hitting quarterly targets.',
      icon: Activity,
      iconBg: 'var(--success-on-track)',
      bgColor: 'var(--neutral-50)'
    },
    {
      title: 'Weekly Risk Index',
      value: `${criticalRisks}`,
      status: criticalRisks > 0 ? 'Critical risks' : 'No critical risks',
      description: 'What can derail the week.',
      icon: AlertTriangle,
      iconBg: 'var(--at-risk)',
      bgColor: criticalRisks > 0 ? 'var(--warning-light)' : 'var(--success-light)'
    }
  ];

  return (
    <section>
      <div className="flex items-center justify-between mb-6">
        <div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <h2 className="text-[20px] font-[500] text-[var(--neutral-800)] mb-1 cursor-help">This Week Snapshot</h2>
              </TooltipTrigger>
              <TooltipContent>
                <p>Four critical metrics that define your company's heartbeat this week</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <p className="text-[14px] font-[400] text-[var(--neutral-600)]">Your company's heartbeat at a glance</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {snapshots.map((snapshot) => {
          const Icon = snapshot.icon;
          return (
            <TooltipProvider key={snapshot.title}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div
                    className="relative overflow-hidden rounded-xl border border-[var(--neutral-200)] p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple"
                    style={{ backgroundColor: snapshot.bgColor }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center okr-card-shadow"
                        style={{ backgroundColor: snapshot.iconBg }}
                      >
                        <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                      </div>
                      {snapshot.trend === 'up' && (
                        <div className="flex items-center gap-1 text-[var(--success-on-track)] bg-[var(--success-light)] px-2 py-1 rounded-md text-[10px] font-[500] uppercase tracking-[0.05em]">
                          <span>↑</span>
                          <span>Up</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-[12px] font-[500] text-[var(--neutral-600)] uppercase tracking-[0.05em]">{snapshot.title}</div>
                      <div className="text-[32px] font-[600] text-[var(--neutral-800)] leading-none tabular-nums">{snapshot.value}</div>
                      {snapshot.status && (
                        <div className="text-[14px] font-[500] text-[var(--neutral-800)]">{snapshot.status}</div>
                      )}
                      <div className="text-[12px] font-[400] text-[var(--neutral-600)] leading-relaxed">
                        {snapshot.description}
                      </div>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{snapshot.description}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          );
        })}
      </div>
    </section>
  );
}
import { useState, useCallback } from 'react';
import { AlertCircle, Sparkles, Target, CheckCircle, Download, Share2, TrendingUp } from 'lucide-react';
import { OkrButton, OkrDrawer, OkrDrawerContent, OkrSkeleton, OkrEmptyState, OkrConfirmDialog, okrToast } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { Blocker } from './db';

interface FixMyWeekDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

const weeklyFocus = {
  topPriority: 'Unblock Enterprise PMF initiative',
  quickWins: [
    'Complete 5th AI prediction feature',
    'Ship performance scaling updates',
    'Close 3 enterprise deals in pipeline'
  ],
  risksToMonitor: [
    'Team velocity sustainability',
    'Customer NPS recovery'
  ],
  kpiToWatch: 'Revenue Growth ($2.4M → $2.5M)',
  tasksToComplete: 8
};

function BlockersSkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-4 space-y-3">
          <div className="flex items-start justify-between">
            <div className="space-y-2 flex-1">
              <div className="flex gap-2">
                <OkrSkeleton variant="rect" width={30} height={18} />
                <OkrSkeleton variant="rect" width={40} height={18} />
              </div>
              <OkrSkeleton variant="text" height={14} width="70%" />
              <OkrSkeleton variant="text" height={12} width="50%" />
            </div>
          </div>
          <OkrSkeleton variant="rect" height={60} />
          <div className="flex gap-2">
            <OkrSkeleton variant="rect" width={100} height={32} className="rounded-lg" />
            <OkrSkeleton variant="rect" width={80} height={32} className="rounded-lg" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function FixMyWeekDrawer({ isOpen, onClose }: FixMyWeekDrawerProps) {
  const loader = useCallback(() => db.getBlockers(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<Blocker[]>(loader);
  const [focusAccepted, setFocusAccepted] = useState(false);
  const [confirmDismiss, setConfirmDismiss] = useState<Blocker | null>(null);

  if (!isOpen) return null;

  const blockers = loadedData || [];
  const activeBlockers = blockers.filter(b => !b.applied && !b.dismissed);

  const handleApply = (blocker: Blocker) => {
    const updated = db.applyBlockerSolution(blocker.id);
    setData(updated);
    okrToast.success(`Solution applied: ${blocker.title.slice(0, 40)}...`, blocker.aiSolution, { duration: 4000 });
  };

  const handleDismiss = (blocker: Blocker) => {
    const updated = db.dismissBlocker(blocker.id);
    setData(updated);
    okrToast.info('Blocker dismissed', `"${blocker.title.slice(0, 40)}..." will not be actioned this week.`);
  };

  const handleAcceptFocus = () => {
    setFocusAccepted(true);
    okrToast.success('Weekly focus plan accepted', 'Your priorities are locked. Stay disciplined.', { duration: 3000 });
  };

  const handleExport = (format: string) => {
    // Generate export content
    const exportContent = `ShiftFocus Weekly Focus Plan
${'='.repeat(50)}
Generated: ${new Date().toLocaleString()}

TOP PRIORITY
${weeklyFocus.topPriority}

QUICK WINS
${weeklyFocus.quickWins.map((win, i) => `${i + 1}. ${win}`).join('\n')}

RISKS TO MONITOR
${weeklyFocus.risksToMonitor.map((risk, i) => `${i + 1}. ${risk}`).join('\n')}

KPI TO WATCH
${weeklyFocus.kpiToWatch}

TASKS
${weeklyFocus.tasksToComplete} high-priority tasks to complete

BLOCKERS
${activeBlockers.map((b, i) => `${i + 1}. [${b.severity.toUpperCase()}] ${b.title}\n   Solution: ${b.aiSolution}`).join('\n\n')}
`;

    const blob = new Blob([exportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shiftfocus-weekly-plan-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    okrToast.success(`Exported as ${format}`, `Weekly plan downloaded successfully.`);
  };

  return (
    <OkrDrawer open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <OkrDrawerContent side="right" drawerSize="lg" hideCloseButton>
        {/* Confirmation dialog for dismissing blockers */}
        <OkrConfirmDialog
          open={confirmDismiss !== null}
          onOpenChange={(open) => !open && setConfirmDismiss(null)}
          title="Dismiss this blocker?"
          description={`"${confirmDismiss?.title.slice(0, 60) || ''}" will not be actioned this week. The AI solution will be discarded. This cannot be undone.`}
          confirmLabel="Dismiss Blocker"
          variant="destructive"
          onConfirm={() => {
            if (confirmDismiss) handleDismiss(confirmDismiss);
          }}
        />

        <div className="sticky top-0 bg-gradient-to-r from-[var(--brand-primary)] to-[var(--info)] p-6 border-b border-white/20 z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-[20px] font-[500] text-white">Fix My Week</h2>
                <p className="text-[12px] font-[400] text-white/80">AI-powered weekly execution plan</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
            >
              <span className="text-white text-[18px]">×</span>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Blockers Section */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-5 h-5 text-[var(--warning)]" />
              <h3 className="text-[16px] font-[500] text-[var(--neutral-800)]">Blockers Detected</h3>
              <span className="text-[10px] font-[500] px-2 py-1 rounded-md bg-[var(--warning-light)] text-[var(--warning)] uppercase tracking-[0.05em]">
                {activeBlockers.length} active
              </span>
            </div>

            {state === 'loading' && <BlockersSkeleton />}

            {state === 'error' && (
              <OkrEmptyState
                icon={AlertCircle}
                iconColor="var(--danger)"
                message="Failed to load blockers"
                description={error || 'localStorage read failed'}
                className="bg-[var(--danger-light)] border-[var(--danger)]/30"
                action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
              />
            )}

            {state === 'ready' && blockers.length === 0 && (
              <OkrEmptyState
                icon={CheckCircle}
                message="No blockers detected"
                description="All clear — no obstacles found this week."
              />
            )}

            {state === 'ready' && (
              <div className="space-y-3">
                {blockers.map((blocker) => {
                  if (blocker.applied || blocker.dismissed) {
                    return (
                      <div key={blocker.id} className="bg-[var(--success-light)] rounded-xl border border-[var(--success)]/30 p-4 opacity-60">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-[var(--success-active)]" />
                          <span className="text-[12px] font-[500] text-[var(--success-active)]">
                            {blocker.applied ? 'Solution applied' : 'Dismissed'}
                          </span>
                          <span className="text-[12px] font-[400] text-[var(--neutral-600)]">— {blocker.title.slice(0, 50)}</span>
                        </div>
                      </div>
                    );
                  }
                  return (
                    <div
                      key={blocker.id}
                      className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-4 space-y-3 okr-card-shadow"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-[500] px-2 py-0.5 rounded-md bg-[var(--neutral-100)] text-[var(--neutral-600)] uppercase tracking-[0.05em]">
                              {blocker.type}
                            </span>
                            <span className={`text-[10px] font-[500] px-2 py-0.5 rounded-md uppercase tracking-[0.05em] ${
                              blocker.severity === 'high' 
                                ? 'bg-[var(--danger-light)] text-[var(--danger)]'
                                : 'bg-[var(--warning-light)] text-[var(--warning)]'
                            }`}>
                              {blocker.severity}
                            </span>
                          </div>
                          <div className="text-[14px] font-[500] text-[var(--neutral-800)]">{blocker.title}</div>
                          <div className="text-[12px] font-[400] text-[var(--neutral-600)] mt-1">{blocker.source}</div>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 p-3 bg-[var(--brand-primary)]/[0.06] rounded-lg border border-[var(--brand-primary)]/20">
                        <Sparkles className="w-4 h-4 text-[var(--brand-primary)] mt-0.5 flex-shrink-0" />
                        <div>
                          <div className="text-[10px] font-[500] text-[var(--brand-primary)] mb-1 uppercase tracking-[0.05em]">AI Solution</div>
                          <div className="text-[14px] font-[400] text-[var(--neutral-800)]">{blocker.aiSolution}</div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <OkrButton
                          size="sm"
                          onClick={() => handleApply(blocker)}
                        >
                          Apply Solution
                        </OkrButton>
                        <OkrButton
                          size="sm"
                          variant="outline"
                          onClick={() => setConfirmDismiss(blocker)}
                        >
                          Dismiss
                        </OkrButton>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Weekly Focus Plan */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-[var(--info)]" />
              <h3 className="text-[16px] font-[500] text-[var(--neutral-800)]">Weekly Focus Plan</h3>
            </div>
            <div className="bg-gradient-to-br from-[var(--brand-primary)]/[0.06] to-[var(--info)]/[0.06] rounded-xl border border-[var(--brand-primary)]/20 p-6 space-y-6">
              {/* Top Priority */}
              <div>
                <div className="text-[10px] font-[500] text-[var(--brand-primary)] mb-2 uppercase tracking-[0.05em]">Top Priority</div>
                <div className="text-[14px] font-[500] text-[var(--neutral-800)]">{weeklyFocus.topPriority}</div>
              </div>

              {/* Quick Wins */}
              <div>
                <div className="text-[10px] font-[500] text-[var(--success)] mb-2 uppercase tracking-[0.05em]">Quick Wins</div>
                <ul className="space-y-1">
                  {weeklyFocus.quickWins.map((win, idx) => (
                    <li key={idx} className="text-[14px] font-[400] text-[var(--neutral-800)] flex items-center gap-2">
                      <CheckCircle className="w-3 h-3 text-[var(--success)]" />
                      {win}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Risks to Monitor */}
              <div>
                <div className="text-[10px] font-[500] text-[var(--warning)] mb-2 uppercase tracking-[0.05em]">Risks to Monitor</div>
                <ul className="space-y-1">
                  {weeklyFocus.risksToMonitor.map((risk, idx) => (
                    <li key={idx} className="text-[14px] font-[400] text-[var(--neutral-800)] flex items-center gap-2">
                      <AlertCircle className="w-3 h-3 text-[var(--warning)]" />
                      {risk}
                    </li>
                  ))}
                </ul>
              </div>

              {/* KPI to Watch */}
              <div>
                <div className="text-[10px] font-[500] text-[var(--brand-primary)] mb-2 uppercase tracking-[0.05em]">KPI to Watch</div>
                <div className="text-[14px] font-[400] text-[var(--neutral-800)]">{weeklyFocus.kpiToWatch}</div>
              </div>

              {/* Tasks */}
              <div>
                <div className="text-[10px] font-[500] text-[var(--neutral-600)] mb-2 uppercase tracking-[0.05em]">Tasks to Complete</div>
                <div className="text-[14px] font-[500] text-[var(--neutral-800)]">{weeklyFocus.tasksToComplete} high-priority tasks</div>
              </div>

              {!focusAccepted ? (
                <OkrButton
                  onClick={handleAcceptFocus}
                  className="w-full"
                >
                  Accept Focus Plan
                </OkrButton>
              ) : (
                <div className="flex items-center gap-2 p-3 bg-[var(--success-light)] rounded-lg border border-[var(--success)]/30">
                  <CheckCircle className="w-4 h-4 text-[var(--success-active)]" />
                  <span className="text-[12px] font-[500] text-[var(--success-active)]">Focus plan accepted — stay disciplined</span>
                </div>
              )}
            </div>
          </section>

          {/* Export Options */}
          <section>
            <div className="text-[14px] font-[500] text-[var(--neutral-800)] mb-3">Export & Share</div>
            <div className="grid grid-cols-3 gap-3">
              <OkrButton
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => handleExport('PDF')}
              >
                <Download className="w-4 h-4" />
                PDF
              </OkrButton>
              <OkrButton
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => handleExport('Slack')}
              >
                <Share2 className="w-4 h-4" />
                Slack
              </OkrButton>
              <OkrButton
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => handleExport('Email')}
              >
                <TrendingUp className="w-4 h-4" />
                Email
              </OkrButton>
            </div>
          </section>
        </div>
      </OkrDrawerContent>
    </OkrDrawer>
  );
}
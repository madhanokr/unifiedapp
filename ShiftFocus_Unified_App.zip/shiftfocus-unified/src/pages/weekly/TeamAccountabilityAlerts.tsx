import { useState, useCallback } from 'react';
import { AlertCircle, Clock, Activity, CheckCircle } from 'lucide-react';
import { OkrButton, OkrEmptyState, OkrSkeleton, OkrConfirmDialog, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { AccountabilityAlert } from './db';

const iconMap: Record<string, typeof Clock> = {
  'missing-checkin': Clock,
  'zero-movement': Activity,
  'blocked-dependencies': AlertCircle,
};

function AlertsSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="rounded-xl border border-[#E5E5E5] p-6">
          <div className="flex items-start gap-4">
            <OkrSkeleton variant="rect" width={40} height={40} className="rounded-lg" />
            <div className="flex-1 space-y-2">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <OkrSkeleton variant="text" height={14} width="60%" />
                  <OkrSkeleton variant="text" height={12} width="80%" />
                  <div className="flex gap-2">
                    <OkrSkeleton variant="rect" width={60} height={24} className="rounded-full" />
                    <OkrSkeleton variant="rect" width={70} height={24} className="rounded-full" />
                  </div>
                </div>
                <OkrSkeleton variant="rect" width={100} height={32} className="rounded-lg" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function TeamAccountabilityAlerts() {
  const loader = useCallback(() => db.getAlerts(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<AccountabilityAlert[]>(loader);
  const [confirmAlert, setConfirmAlert] = useState<AccountabilityAlert | null>(null);

  // Loading state
  if (state === 'loading') {
    return (
      <TooltipProvider>
        <section>
          <div className="mb-6">
            <OkrSkeleton variant="text" height={20} width={200} />
            <OkrSkeleton variant="text" height={14} width={300} className="mt-2" />
          </div>
          <AlertsSkeleton />
        </section>
      </TooltipProvider>
    );
  }

  // Error state
  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="#E53935"
          message="Failed to load accountability alerts"
          description={error || 'localStorage read failed'}
          className="bg-[#FFE5E5] border-[#E53935]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const alerts = loadedData || [];
  const activeAlerts = alerts.filter(a => !a.resolved);
  const resolvedAlerts = alerts.filter(a => a.resolved);

  const handleAction = (alert: AccountabilityAlert) => {
    const updated = db.resolveAlert(alert.id);
    setData(updated);

    const actionMessages: Record<string, { title: string; desc: string }> = {
      'Escalate Now': { 
        title: `Escalation sent for ${alert.teams.join(', ')}`, 
        desc: 'Leadership has been notified. Auto-follow-up scheduled in 24h.' 
      },
      'Fix Now': { 
        title: `Fix initiated for ${alert.teams.join(', ')}`, 
        desc: 'Silence breach flagged. Team leads required to respond within 4h.' 
      },
      'Verify Now': { 
        title: `Verification requested for ${alert.teams.join(', ')}`, 
        desc: 'Dependency review escalated. Resolution due by end of day.' 
      },
    };

    const msg = actionMessages[alert.action] || { title: 'Alert resolved', desc: '' };
    okrToast.success(msg.title, msg.desc, { duration: 4000 });
  };

  return (
    <TooltipProvider>
      <section>
        {/* Confirmation dialog for alert actions */}
        <OkrConfirmDialog
          open={confirmAlert !== null}
          onOpenChange={(open) => !open && setConfirmAlert(null)}
          title={`${confirmAlert?.action || 'Action'} — ${confirmAlert?.teams.join(', ') || ''}`}
          description={`This will ${confirmAlert?.action === 'Escalate Now' ? 'notify leadership and trigger auto-follow-up' : confirmAlert?.action === 'Fix Now' ? 'flag a silence breach requiring team response within 4h' : 'escalate the dependency review for resolution'}. This action cannot be undone.`}
          confirmLabel={confirmAlert?.action || 'Confirm'}
          variant="warning"
          onConfirm={() => {
            if (confirmAlert) handleAction(confirmAlert);
          }}
        />

        <div className="mb-6">
          <Tooltip>
            <TooltipTrigger className="inline-flex items-center gap-2 cursor-help">
              <h2 className="text-[20px] font-[500] text-[#2B2B2B] mb-1">Accountability Alerts</h2>
              {activeAlerts.length > 0 && (
                <div className="w-2 h-2 rounded-full bg-[#E53935] animate-pulse" />
              )}
            </TooltipTrigger>
            <TooltipContent>
              <p>Teams that need leadership intervention to maintain accountability</p>
            </TooltipContent>
          </Tooltip>
          <p className="text-[14px] font-[400] text-[#666666]">
            {activeAlerts.length > 0 
              ? `${activeAlerts.length} item${activeAlerts.length > 1 ? 's' : ''} requiring leadership intervention`
              : 'All accountability items resolved'
            }
          </p>
        </div>

        <div className="space-y-4">
          {activeAlerts.map((alert) => {
            const Icon = iconMap[alert.type] || AlertCircle;

            return (
              <Tooltip key={alert.id}>
                <TooltipTrigger asChild>
                  <div 
                    className="border rounded-xl p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple"
                    style={{
                      backgroundColor: alert.bgColor,
                      borderColor: alert.borderColor
                    }}
                  >
                    <div className="flex items-start gap-4">
                      <div 
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 okr-card-shadow"
                        style={{ backgroundColor: alert.iconBg }}
                      >
                        <Icon className="w-5 h-5 text-white" strokeWidth={2} />
                      </div>

                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-[14px] font-[500] text-[#2B2B2B]">{alert.message}</span>
                              <span 
                                className="text-[10px] font-[500] px-2 py-1 rounded-md uppercase tracking-[0.05em]"
                                style={{
                                  backgroundColor: alert.badgeColor.bg,
                                  color: alert.badgeColor.text
                                }}
                              >
                                {alert.severity}
                              </span>
                            </div>
                            <div className="text-[12px] font-[400] text-[#666666] mb-2">
                              {alert.description}
                            </div>
                            <div className="flex gap-2">
                              {alert.teams.map((team) => (
                                <span
                                  key={team}
                                  className="text-[12px] font-[500] px-3 py-1 bg-white rounded-full border border-[#E5E5E5]"
                                >
                                  {team}
                                </span>
                              ))}
                            </div>
                          </div>
                          <OkrButton
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmAlert(alert);
                            }}
                            className="flex-shrink-0"
                            style={{
                              backgroundColor: alert.iconBg,
                              color: 'white',
                            }}
                          >
                            {alert.action}
                          </OkrButton>
                        </div>
                      </div>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{alert.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            );
          })}

          {/* Resolved alerts (collapsed) */}
          {resolvedAlerts.length > 0 && (
            <div className="bg-[#E5F9F1] border border-[#40C78C]/30 rounded-xl p-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-[#2E9865]" />
                <span className="text-[12px] font-[500] text-[#2E9865]">
                  {resolvedAlerts.length} alert{resolvedAlerts.length > 1 ? 's' : ''} resolved this session
                </span>
              </div>
            </div>
          )}

          {activeAlerts.length === 0 && resolvedAlerts.length === 0 && (
            <OkrEmptyState
              icon={CheckCircle}
              message="All clear — no accountability issues"
            />
          )}
        </div>
      </section>
    </TooltipProvider>
  );
}
import { useState, useCallback } from 'react';
import { Award, TrendingUp, Share2, Download, CheckCircle, AlertCircle } from 'lucide-react';
import { OkrButton, OkrSkeleton, OkrEmptyState, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { ComputedGrade, GradeState } from './db';

const getGradeColor = (grade: string) => {
  if (grade.startsWith('A')) return {
    bg: 'from-[#40C78C] to-[#3CCB7F]',
    textColor: '#40C78C',
    borderColor: '#40C78C',
    bgLight: '#E5F9F1'
  };
  if (grade.startsWith('B')) return {
    bg: 'from-[#3E8BFF] to-[#6A3DE8]',
    textColor: '#3E8BFF',
    borderColor: '#3E8BFF',
    bgLight: '#E5ECFF'
  };
  if (grade.startsWith('C')) return {
    bg: 'from-[#F98B2B] to-[#F5A623]',
    textColor: '#F98B2B',
    borderColor: '#F98B2B',
    bgLight: '#FFF2E6'
  };
  return {
    bg: 'from-[#E53935] to-[#D33A3A]',
    textColor: '#E53935',
    borderColor: '#E53935',
    bgLight: '#FFE5E5'
  };
};

function GradeSkeleton() {
  return (
    <div className="rounded-xl border-2 border-[#E5E5E5] overflow-hidden">
      <div className="bg-[#F3F3F3] p-8">
        <div className="flex items-end gap-6">
          <div>
            <OkrSkeleton variant="text" height={14} width={120} />
            <OkrSkeleton variant="text" height={64} width={80} className="mt-2" />
          </div>
          <div className="pb-4">
            <OkrSkeleton variant="text" height={32} width={80} />
            <OkrSkeleton variant="text" height={14} width={100} className="mt-2" />
          </div>
        </div>
      </div>
      <div className="p-6 space-y-6">
        <OkrSkeleton variant="text" height={16} width={140} />
        {[1, 2, 3, 4, 5].map((i) => (
          <div key={i}>
            <div className="flex items-center justify-between mb-2">
              <OkrSkeleton variant="text" height={12} width={120} />
              <OkrSkeleton variant="text" height={14} width={40} />
            </div>
            <OkrSkeleton variant="rect" height={8} />
          </div>
        ))}
      </div>
    </div>
  );
}

export function WeeklyBusinessGrade() {
  const gradeLoader = useCallback(() => db.getComputedGrade(), []);
  const stateLoader = useCallback(() => db.getGradeState(), []);
  const { data: gradeData, state: gradeState, error: gradeError, retry: retryGrade } = useSimulatedLoad<ComputedGrade>(gradeLoader);
  const { data: gradeUiState, state: uiState, setData: setGradeUiState } = useSimulatedLoad<GradeState>(stateLoader);

  const isLoading = gradeState === 'loading' || uiState === 'loading';

  if (isLoading) {
    return (
      <TooltipProvider>
        <section>
          <div className="mb-6">
            <OkrSkeleton variant="text" height={20} width={200} />
            <OkrSkeleton variant="text" height={14} width={320} className="mt-2" />
          </div>
          <GradeSkeleton />
        </section>
      </TooltipProvider>
    );
  }

  if (gradeState === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="#E53935"
          message="Failed to load business grade"
          description={gradeError || 'localStorage read failed'}
          className="bg-[#FFE5E5] border-[#E53935]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retryGrade}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const data = gradeData || { grade: 'B+', score: 85, previousGrade: 'B', trend: 'up' as const, breakdown: [], insights: [] };
  const uiData = gradeUiState || { sentToLeadership: false, sentAt: null, exported: false, exportedAt: null };
  const colors = getGradeColor(data.grade);

  const handleSendToLeadership = () => {
    const updated = db.updateGradeState({ sentToLeadership: true, sentAt: new Date().toISOString() });
    setGradeUiState(updated);
    okrToast.success('Weekly brief sent to leadership', 'Grade report + executive summary delivered. Recipients notified.', { duration: 4000 });
  };

  const handleExport = () => {
    const updated = db.updateGradeState({ exported: true, exportedAt: new Date().toISOString() });
    setGradeUiState(updated);

    const reportText = `ShiftFocus Weekly Business Grade Report\n${'='.repeat(40)}\nGrade: ${data.grade} (${data.score}/100)\nPrevious: ${data.previousGrade}\n\nBreakdown:\n${data.breakdown.map(b => `  ${b.metric}: ${b.score} (${b.weight}% weight)`).join('\n')}\n\nInsights:\n${data.insights.map(i => `  - ${i}`).join('\n')}`;

    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shiftfocus-weekly-grade-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    okrToast.success('Report exported', 'Weekly grade report downloaded as text file.');
  };

  return (
    <TooltipProvider>
      <section>
        <div className="mb-6">
          <Tooltip>
            <TooltipTrigger className="inline-flex items-center gap-2 cursor-help">
              <h2 className="text-[20px] font-[500] text-[#2B2B2B] mb-1">Weekly Business Grade</h2>
              <Award className="w-5 h-5 text-[#6A3DE8]" strokeWidth={2} />
            </TooltipTrigger>
            <TooltipContent>
              <p>AI-generated grade based on all execution metrics, momentum, and strategic alignment</p>
            </TooltipContent>
          </Tooltip>
          <p className="text-[14px] font-[400] text-[#666666]">AI-powered assessment of your company's weekly performance</p>
        </div>

        <div
          className="rounded-xl border-2 overflow-hidden okr-card-shadow-hover"
          style={{
            backgroundColor: colors.bgLight,
            borderColor: colors.borderColor
          }}
        >
          {/* Grade Header */}
          <div className={`bg-gradient-to-r ${colors.bg} p-8 text-white relative overflow-hidden`}>
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-end gap-6">
                <div>
                  <div className="text-[14px] font-[500] text-white/80 mb-2">This Week's Grade</div>
                  <div className="text-[64px] font-[600] leading-none">{data.grade}</div>
                </div>
                <div className="pb-4">
                  <div className="text-[32px] font-[600] text-white/90 mb-1 tabular-nums leading-none">{data.score}/100</div>
                  <div className="flex items-center gap-2 text-[14px] font-[500]">
                    <TrendingUp className="w-4 h-4" strokeWidth={2} />
                    <span>Up from {data.previousGrade}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <OkrButton
                      variant="secondary"
                      size="sm"
                      className="gap-2"
                      onClick={handleSendToLeadership}
                      disabled={uiData.sentToLeadership}
                    >
                      {uiData.sentToLeadership ? <CheckCircle className="w-4 h-4" /> : <Share2 className="w-4 h-4" strokeWidth={2} />}
                      {uiData.sentToLeadership ? 'Sent' : 'Share'}
                    </OkrButton>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Share your weekly grade with your team or investors</p>
                  </TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <OkrButton
                      variant="secondary"
                      size="sm"
                      className="gap-2"
                      onClick={handleExport}
                    >
                      <Download className="w-4 h-4" strokeWidth={2} />
                      Export
                    </OkrButton>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Download weekly grade report</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
          </div>

          {/* Grade Breakdown */}
          <div className="p-6 space-y-6">
            <div>
              <div className="text-[16px] font-[500] text-[#2B2B2B] mb-4">Grade Breakdown</div>
              <div className="space-y-4">
                {data.breakdown.map((item) => (
                  <Tooltip key={item.metric}>
                    <TooltipTrigger asChild>
                      <div className="cursor-help">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[12px] font-[400] text-[#666666]">{item.metric}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-[500] text-[#A1A1A1] uppercase tracking-[0.05em]">{item.weight}% weight</span>
                            <span
                              className="text-[14px] font-[500] tabular-nums"
                              style={{ color: colors.textColor }}
                            >
                              {item.score}
                            </span>
                          </div>
                        </div>
                        <div className="relative h-2 bg-[#E5E5E5] rounded-full overflow-hidden">
                          <div
                            className={`absolute top-0 left-0 h-full bg-gradient-to-r ${colors.bg} rounded-full transition-all duration-300 transition-smooth`}
                            style={{ width: `${item.score}%` }}
                          />
                        </div>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>This metric contributes {item.weight}% to your overall grade</p>
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            </div>

            {/* AI Insights */}
            <div>
              <div className="text-[16px] font-[500] text-[#2B2B2B] mb-4">AI Insights</div>
              <div className="space-y-2">
                {data.insights.map((insight, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2 text-[14px] font-[400] text-[#2B2B2B] bg-white rounded-lg p-4 border border-[#E5E5E5]"
                  >
                    <span style={{ color: colors.textColor }} className="mt-0.5">•</span>
                    <span className="leading-relaxed">{insight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Call to Action */}
            <div className="pt-6 border-t border-[#E5E5E5] space-y-4">
              <div className="flex gap-3">
                <OkrButton
                  className="flex-1"
                  onClick={handleSendToLeadership}
                  disabled={uiData.sentToLeadership}
                >
                  {uiData.sentToLeadership ? (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Sent to Leadership
                    </>
                  ) : (
                    <>
                      <Share2 className="w-4 h-4 mr-2" />
                      Send to Leadership
                    </>
                  )}
                </OkrButton>
                <OkrButton
                  variant="outline"
                  className="flex-1"
                  onClick={handleExport}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
                </OkrButton>
              </div>
              <div className="text-[12px] font-[400] text-[#666666] text-center">
                Grade calculated by AI based on 47 execution signals across strategy, operations, and team health
              </div>
            </div>
          </div>
        </div>
      </section>
    </TooltipProvider>
  );
}

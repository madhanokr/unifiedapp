import { useState, useCallback } from 'react';
import { Users, CheckCircle, AlertCircle } from 'lucide-react';
import { OkrButton, OkrBadge, OkrProgressBar, OkrSkeleton, OkrEmptyState, OkrConfirmDialog, okrToast } from './design-system';
import { OkrTooltip as Tooltip, OkrTooltipContent as TooltipContent, OkrTooltipProvider as TooltipProvider, OkrTooltipTrigger as TooltipTrigger } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { Team } from './db';

const teamColors: Record<string, string> = {
  'Engineering': 'from-[var(--info)] to-[var(--info)]',
  'Product': 'from-[var(--brand-primary)] to-[var(--brand-primary)]',
  'Sales': 'from-[var(--success)] to-[#3CCB7F]',
  'Marketing': 'from-[var(--warning)] to-[#F5A623]',
  'Customer Success': 'from-[var(--danger)] to-[var(--danger)]',
  'Operations': 'from-[var(--info)] to-[var(--brand-primary)]',
};

function TeamCheckInBoardSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="bg-[var(--neutral-50)] rounded-xl border border-[var(--neutral-200)] p-6">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <OkrSkeleton variant="rect" width={40} height={40} className="rounded-lg" />
                <div className="space-y-1">
                  <OkrSkeleton variant="text" height={14} width={80} />
                  <OkrSkeleton variant="text" height={10} width={40} />
                </div>
              </div>
              <OkrSkeleton variant="rect" width={80} height={20} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <OkrSkeleton variant="rect" height={56} />
              <OkrSkeleton variant="rect" height={56} />
            </div>
            <OkrSkeleton variant="rect" height={48} />
            <OkrSkeleton variant="rect" height={40} />
            <OkrSkeleton variant="rect" height={32} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function TeamCheckInBoard() {
  const loader = useCallback(() => db.getTeams(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<Team[]>(loader);
  const [confirmTeamId, setConfirmTeamId] = useState<number | null>(null);

  // Loading state
  if (state === 'loading') return <TeamCheckInBoardSkeleton />;

  // Error state
  if (state === 'error') {
    return (
      <OkrEmptyState
        icon={AlertCircle}
        iconColor="var(--danger)"
        message="Failed to load teams"
        description={error || 'localStorage read failed'}
        className="bg-[var(--danger-light)] border-[var(--danger)]/30"
        action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
      />
    );
  }

  const teams = loadedData || [];

  // Empty state
  if (teams.length === 0) {
    return (
      <OkrEmptyState
        icon={Users}
        iconColor="var(--success)"
        iconBg="var(--success)"
        message="No teams found"
        description="Configure teams to begin tracking verification status."
      />
    );
  }

  const confirmTeam = teams.find(t => t.id === confirmTeamId);

  const handleVerify = (teamId: number) => {
    const team = teams.find(t => t.id === teamId);
    if (!team) return;

    const updated = db.verifyTeam(teamId);
    setData(updated);
    okrToast.success(`${team.name} — verified`, 'Team check-in verification recorded.');
  };

  return (
    <div>
      {/* Confirm dialog for verification */}
      <OkrConfirmDialog
        open={confirmTeamId !== null}
        onOpenChange={(open) => !open && setConfirmTeamId(null)}
        title={`Verify ${confirmTeam?.name || ''} check-in?`}
        description="This will mark the team as verified for this week. Red flags will be cleared. This action cannot be undone."
        confirmLabel="Verify Now"
        variant="warning"
        onConfirm={() => {
          if (confirmTeamId !== null) handleVerify(confirmTeamId);
        }}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {teams.map((team) => {
          const velocityColor = team.velocityTrend === 'up' ? 'var(--success)' : 'var(--danger)';
          const statusBg = team.verified ? 'var(--success-light)' : team.redFlags === 0 ? 'var(--success-light)' : team.redFlags === 1 ? 'var(--warning-light)' : 'var(--danger-light)';
          const statusColor = team.verified ? 'var(--success-active)' : team.redFlags === 0 ? 'var(--success-active)' : team.redFlags === 1 ? 'var(--warning)' : 'var(--danger)';
          const statusText = team.verified ? 'Verified' : team.redFlags === 0 ? 'Pending Verification' : team.redFlags === 1 ? 'Pending Verification' : 'Verification Failed';
          const gradientClass = teamColors[team.name] || 'from-[var(--brand-primary)] to-[var(--info)]';

          return (
            <TooltipProvider key={team.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className={`bg-[var(--neutral-50)] rounded-xl border p-6 okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple cursor-pointer ${
                    team.verified ? 'border-[var(--success)]/30' : 'border-[var(--neutral-200)]'
                  }`}>
                    <div className="space-y-4">
                      {/* Team Header */}
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${gradientClass} flex items-center justify-center okr-card-shadow`}>
                            <Users className="w-5 h-5 text-white" strokeWidth={2} />
                          </div>
                          <div>
                            <div className="text-[14px] font-[500] text-[var(--neutral-800)]">{team.name}</div>
                            <div className="text-[10px] font-[400] text-[var(--neutral-600)] uppercase tracking-[0.05em]">Team</div>
                          </div>
                        </div>
                        <div
                          className="text-[10px] font-[500] px-2 py-1 rounded-md uppercase tracking-[0.05em]"
                          style={{ backgroundColor: statusBg, color: statusColor }}
                        >
                          {statusText}
                        </div>
                      </div>

                      {/* Metrics */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-white rounded-lg p-3 border border-[var(--neutral-200)]">
                          <div className="text-[10px] font-[500] text-[var(--neutral-400)] mb-1 uppercase tracking-[0.05em]">Confidence</div>
                          <div className="text-[20px] font-[500] text-[var(--neutral-800)] tabular-nums leading-none">{team.confidence}%</div>
                        </div>
                        <div className="bg-white rounded-lg p-3 border border-[var(--neutral-200)]">
                          <div className="text-[10px] font-[500] text-[var(--neutral-400)] mb-1 uppercase tracking-[0.05em]">Velocity</div>
                          <div className="text-[20px] font-[500] tabular-nums leading-none" style={{ color: velocityColor }}>
                            {team.velocity}
                          </div>
                        </div>
                      </div>

                      {/* Items progress */}
                      <div className="bg-white rounded-lg p-3 border border-[var(--neutral-200)]">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-[10px] font-[500] text-[var(--neutral-400)] uppercase tracking-[0.05em]">Completed / Planned</span>
                          <span className="text-[12px] font-[500] text-[var(--neutral-800)] tabular-nums">{team.completedItems}/{team.plannedItems}</span>
                        </div>
                        <OkrProgressBar
                          value={Math.min(100, (team.completedItems / team.plannedItems) * 100)}
                          variant="brand"
                          progressSize="sm"
                        />
                      </div>

                      {/* Latest Update */}
                      <div className="text-[12px] font-[400] text-[var(--neutral-600)] bg-white rounded-lg p-3 border border-[var(--neutral-200)]">
                        {team.updates}
                      </div>

                      {/* Red flags */}
                      {!team.verified && team.redFlags > 0 && (
                        <OkrBadge variant="danger" size="md" className="w-full justify-start px-3 py-2">
                          {team.redFlags} red flag{team.redFlags > 1 ? 's' : ''} require{team.redFlags === 1 ? 's' : ''} verification
                        </OkrBadge>
                      )}

                      {/* Action */}
                      <OkrButton
                        size="sm"
                        disabled={team.verified}
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfirmTeamId(team.id);
                        }}
                        className={`
                          ${team.verified 
                            ? 'bg-[var(--success-light)] text-[var(--success-active)] hover:bg-[var(--success-light)] cursor-default' 
                            : 'bg-[var(--success)] hover:bg-[var(--success-active)]'
                          }`}
                      >
                        {team.verified ? (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Verified
                          </>
                        ) : 'Verify Now'}
                      </OkrButton>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{team.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          );
        })}
      </div>
    </div>
  );
}
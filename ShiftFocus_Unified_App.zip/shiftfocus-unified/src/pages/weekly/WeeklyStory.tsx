import { TrendingUp, TrendingDown, Zap, AlertCircle, Sparkles, ChevronDown } from 'lucide-react';
import { useCallback } from 'react';
import { OkrSkeleton, OkrEmptyState, OkrButton } from './design-system';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { ComputedStory } from './db';
import { useState } from 'react';

function StorySkeleton() {
  return (
    <div className="bg-white rounded-xl border border-[var(--neutral-200)] p-8">
      <div className="flex items-center gap-4">
        <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
        <div className="flex-1 space-y-2">
          <OkrSkeleton variant="text" height={16} width="70%" />
          <OkrSkeleton variant="text" height={12} width="30%" />
        </div>
        <OkrSkeleton variant="rect" width={20} height={20} />
      </div>
    </div>
  );
}

export function WeeklyStory() {
  const loader = useCallback(() => db.getComputedStory(), []);
  const { data: storyData, state, error, retry } = useSimulatedLoad<ComputedStory>(loader);
  const [isExpanded, setIsExpanded] = useState(false);

  if (state === 'loading') {
    return (
      <section>
        <div className="mb-6">
          <OkrSkeleton variant="text" height={20} width={200} />
          <OkrSkeleton variant="text" height={14} width={240} className="mt-2" />
        </div>
        <StorySkeleton />
      </section>
    );
  }

  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="var(--danger)"
          message="Failed to load weekly brief"
          description={error || 'localStorage read failed'}
          className="bg-[var(--danger-light)] border-[var(--danger)]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const data = storyData || { improved: [], slowedDown: [], changed: [], newBlockers: [], aiRecommendations: [] };

  const totalMovements =
    data.improved.length +
    data.slowedDown.length +
    data.changed.length +
    data.newBlockers.length;

  return (
    <section>
      <div className="mb-6">
        <h2 className="text-[20px] font-[500] text-[var(--neutral-800)] mb-2">Weekly Brief Preview</h2>
        <p className="text-[14px] font-[400] text-[var(--neutral-600)]">Auto-generated executive summary</p>
      </div>

      <div className="bg-white rounded-xl border border-[var(--neutral-200)] okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple overflow-hidden">
        {/* Collapsible Header */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-between p-8 hover:bg-[var(--neutral-50)] transition-all duration-120 transition-apple group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--brand-primary)]/[0.08] to-[var(--info)]/[0.08] flex items-center justify-center group-hover:scale-105 transition-transform duration-120 border border-[var(--brand-primary)]/20">
              <Sparkles className="w-6 h-6 text-[var(--brand-primary)]" strokeWidth={2} />
            </div>
            <div className="text-left">
              <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">AI Summary: {totalMovements} Key Movements This Week</div>
              <div className="text-[12px] font-[400] text-[var(--neutral-600)]">Click to {isExpanded ? 'collapse' : 'expand'} details</div>
            </div>
          </div>
          <div className={`transition-transform duration-120 ${isExpanded ? 'rotate-0' : '-rotate-90'}`}>
            <ChevronDown className="w-5 h-5 text-[var(--neutral-400)] group-hover:text-[var(--neutral-600)] transition-colors" strokeWidth={2} />
          </div>
        </button>

        {/* Expanded Content */}
        {isExpanded && (
          <div className="border-t border-[var(--neutral-200)]">
            {/* What Improved */}
            {data.improved.length > 0 && (
              <div className="p-8 border-b border-[var(--neutral-200)]">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--success)] to-[#3CCB7F] flex items-center justify-center okr-card-shadow">
                    <TrendingUp className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">What Improved</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{data.improved.length} positive movements</div>
                  </div>
                </div>
                <ul className="space-y-4">
                  {data.improved.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-[14px] font-[400] text-[var(--neutral-800)] leading-relaxed group/item">
                      <span className="text-[var(--success)] mt-1 group-hover/item:scale-110 transition-transform">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* What Moved Down */}
            {data.slowedDown.length > 0 && (
              <div className="p-8 border-b border-[var(--neutral-200)] bg-[var(--warning-light)]/20">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--warning)] to-[#F5A623] flex items-center justify-center okr-card-shadow">
                    <TrendingDown className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">What Moved Down</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{data.slowedDown.length} areas needing attention</div>
                  </div>
                </div>
                <ul className="space-y-4">
                  {data.slowedDown.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-[14px] font-[400] text-[var(--neutral-800)] leading-relaxed group/item">
                      <span className="text-[var(--warning)] mt-1 group-hover/item:scale-110 transition-transform">⚠</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* What Changed */}
            {data.changed.length > 0 && (
              <div className="p-8 border-b border-[var(--neutral-200)]">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--info)] to-[var(--brand-primary)] flex items-center justify-center okr-card-shadow">
                    <Zap className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">What Changed</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{data.changed.length} strategic adjustments</div>
                  </div>
                </div>
                <ul className="space-y-4">
                  {data.changed.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-[14px] font-[400] text-[var(--neutral-800)] leading-relaxed group/item">
                      <span className="text-[var(--info)] mt-1 group-hover/item:scale-110 transition-transform">→</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Top Risks */}
            {data.newBlockers.length > 0 && (
              <div className="p-8 border-b border-[var(--neutral-200)] bg-[var(--danger-light)]/20">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--danger)] to-[var(--danger-active)] flex items-center justify-center okr-card-shadow">
                    <AlertCircle className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">Top Risks</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{data.newBlockers.length} critical blockers</div>
                  </div>
                </div>
                <ul className="space-y-4">
                  {data.newBlockers.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-[14px] font-[400] text-[var(--neutral-800)] leading-relaxed group/item">
                      <span className="text-[var(--danger)] mt-1 group-hover/item:scale-110 transition-transform">✕</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* AI Recommendations */}
            {data.aiRecommendations.length > 0 && (
              <div className="p-8 bg-gradient-to-br from-[var(--brand-primary)]/[0.06] to-[var(--info)]/[0.06]">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[var(--brand-primary)] to-[var(--info)] flex items-center justify-center okr-card-shadow">
                    <Sparkles className="w-5 h-5 text-white" strokeWidth={2} />
                  </div>
                  <div>
                    <div className="text-[16px] font-[500] text-[var(--neutral-800)] mb-1">AI Recommendations</div>
                    <div className="text-[12px] font-[400] text-[var(--neutral-600)]">{data.aiRecommendations.length} intelligent next actions</div>
                  </div>
                </div>
                <ul className="space-y-4">
                  {data.aiRecommendations.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-4 text-[14px] font-[400] text-[var(--neutral-800)] leading-relaxed group/item">
                      <span className="text-[var(--brand-primary)] mt-1 group-hover/item:scale-110 transition-transform">★</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

import { AlertTriangle, AlertCircle, Info, Sparkles, ChevronDown, CheckCircle } from 'lucide-react';
import { OkrButton, OkrEmptyState, OkrSkeleton, OkrConfirmDialog, okrToast } from './design-system';
import { useState, useCallback } from 'react';
import { useSimulatedLoad } from './hooks/useSimulatedLoad';
import { db } from './db';
import type { Risk } from './db';

const getImpactValue = (impact: string): number => {
  const map: { [key: string]: number } = { 'High': 10, 'Medium': 6, 'Low': 3 };
  return map[impact] || 5;
};

const getProbabilityValue = (probability: string): number => {
  return parseInt(probability) / 10;
};

function RiskRadarSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2].map((i) => (
        <div key={i} className="bg-white rounded-xl border border-[var(--neutral-200)] overflow-hidden">
          <div className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <OkrSkeleton variant="rect" width={20} height={20} />
              <OkrSkeleton variant="text" height={16} width={120} />
              <OkrSkeleton variant="rect" width={24} height={24} className="rounded-md" />
            </div>
          </div>
          <div className="border-t border-[var(--neutral-200)] p-6 space-y-4">
            {[1, 2].map((j) => (
              <div key={j} className="bg-[var(--neutral-50)] rounded-xl p-6 border border-[var(--neutral-200)]">
                <div className="flex items-start gap-4">
                  <OkrSkeleton variant="rect" width={48} height={48} className="rounded-lg" />
                  <div className="flex-1 space-y-3">
                    <div className="flex gap-2">
                      <OkrSkeleton variant="rect" width={60} height={20} />
                      <OkrSkeleton variant="rect" width={50} height={20} />
                    </div>
                    <OkrSkeleton variant="text" height={14} width="70%" />
                    <OkrSkeleton variant="text" height={12} width="90%" />
                    <OkrSkeleton variant="rect" height={8} />
                    <OkrSkeleton variant="rect" height={8} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export function WeeklyRiskRadar() {
  const loader = useCallback(() => db.getRisks(), []);
  const { data: loadedData, state, error, retry, setData } = useSimulatedLoad<Risk[]>(loader);
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['critical']);
  const [confirmRisk, setConfirmRisk] = useState<Risk | null>(null);

  // Loading state
  if (state === 'loading') {
    return (
      <section>
        <div className="flex items-center justify-between mb-8">
          <div>
            <OkrSkeleton variant="text" height={20} width={180} />
            <OkrSkeleton variant="text" height={14} width={300} className="mt-2" />
          </div>
          <div className="flex items-center gap-4">
            <OkrSkeleton variant="rect" width={80} height={16} />
            <OkrSkeleton variant="rect" width={80} height={16} />
            <OkrSkeleton variant="rect" width={60} height={16} />
          </div>
        </div>
        <RiskRadarSkeleton />
      </section>
    );
  }

  // Error state
  if (state === 'error') {
    return (
      <section>
        <OkrEmptyState
          icon={AlertCircle}
          iconColor="var(--danger)"
          message="Failed to load risk radar"
          description={error || 'localStorage read failed'}
          className="bg-[var(--danger-light)] border-[var(--danger)]/30"
          action={<OkrButton size="sm" variant="destructive" onClick={retry}>Retry</OkrButton>}
        />
      </section>
    );
  }

  const risks = loadedData || [];
  const activeRisks = risks.filter(r => !r.resolved);
  const resolvedCount = risks.filter(r => r.resolved).length;

  const riskCategories = [
    { id: 'critical', label: 'Critical Risks', risks: activeRisks.filter(r => r.riskType === 'critical') },
    { id: 'business', label: 'Business Risks', risks: activeRisks.filter(r => r.riskType === 'business') },
    { id: 'technical', label: 'Technical Risks', risks: activeRisks.filter(r => r.riskType === 'technical') },
    { id: 'operational', label: 'Operational Risks', risks: activeRisks.filter(r => r.riskType === 'operational') },
    { id: 'people', label: 'People Risks', risks: activeRisks.filter(r => r.riskType === 'people') },
  ].filter(cat => cat.risks.length > 0);

  const riskCounts = {
    critical: activeRisks.filter(r => r.severity === 'critical').length,
    moderate: activeRisks.filter(r => r.severity === 'moderate').length,
    low: activeRisks.filter(r => r.severity === 'low').length,
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleResolve = (risk: Risk) => {
    const updated = db.resolveRisk(risk.id);
    setData(updated);
    okrToast.success(`Risk resolved: ${risk.title}`, `${risk.severity} risk marked as mitigated. Audit trail recorded.`, { duration: 4000 });
  };

  return (
    <section>
      {/* Confirmation dialog for resolving risks */}
      <OkrConfirmDialog
        open={confirmRisk !== null}
        onOpenChange={(open) => !open && setConfirmRisk(null)}
        title={`Resolve risk: ${confirmRisk?.title.slice(0, 50) || ''}?`}
        description={`This will mark the ${confirmRisk?.severity || ''} risk as mitigated and record an audit trail. This action cannot be undone.`}
        confirmLabel="Resolve Risk"
        variant="warning"
        onConfirm={() => {
          if (confirmRisk) handleResolve(confirmRisk);
        }}
      />

      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-[20px] font-[500] text-[var(--neutral-800)] mb-2">Weekly Risk Radar</h2>
          <p className="text-[14px] font-[400] text-[var(--neutral-600)]">Proactive threat detection across the company</p>
        </div>
        <div className="flex items-center gap-4">
          {resolvedCount > 0 && (
            <div className="flex items-center gap-2">
              <CheckCircle className="w-3 h-3 text-[var(--success-active)]" />
              <span className="text-[12px] font-[500] text-[var(--success-active)]">{resolvedCount} Resolved</span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[var(--danger)]" />
            <span className="text-[12px] font-[400] text-[var(--neutral-600)]">{riskCounts.critical} Critical</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[var(--warning)]" />
            <span className="text-[12px] font-[400] text-[var(--neutral-600)]">{riskCounts.moderate} Moderate</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[var(--info)]" />
            <span className="text-[12px] font-[400] text-[var(--neutral-600)]">{riskCounts.low} Low</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {riskCategories.length === 0 && (
          <OkrEmptyState
            icon={CheckCircle}
            message="All risks resolved"
            description="No active risks this week. Keep monitoring."
          />
        )}

        {riskCategories.map((category) => {
          const isExpanded = expandedCategories.includes(category.id);
          
          return (
            <div key={category.id} className="bg-white rounded-xl border border-[var(--neutral-200)] okr-card-shadow hover:okr-card-shadow-hover transition-all duration-150 transition-apple overflow-hidden">
              {/* Category Header */}
              <button
                onClick={() => toggleCategory(category.id)}
                className="w-full flex items-center justify-between p-6 hover:bg-[var(--neutral-50)] transition-all duration-120 transition-apple group"
              >
                <div className="flex items-center gap-4">
                  <div className={`transition-transform duration-120 ${isExpanded ? 'rotate-0' : '-rotate-90'}`}>
                    <ChevronDown className="w-5 h-5 text-[var(--neutral-400)] group-hover:text-[var(--neutral-600)] transition-colors" strokeWidth={2} />
                  </div>
                  <span className="text-[16px] font-[500] text-[var(--neutral-800)]">{category.label}</span>
                  <span className="text-[12px] font-[500] px-3 py-1 rounded-md bg-[var(--neutral-100)] text-[var(--neutral-600)]">
                    {category.risks.length}
                  </span>
                </div>
              </button>

              {/* Category Risks */}
              {isExpanded && (
                <div className="border-t border-[var(--neutral-200)] p-6 space-y-4">
                  {category.risks.map((risk) => {
                    const severityConfig = {
                      critical: {
                        icon: AlertTriangle,
                        iconColor: 'var(--danger)',
                        badgeColor: { bg: 'var(--danger-light)', text: 'var(--danger)' }
                      },
                      moderate: {
                        icon: AlertCircle,
                        iconColor: 'var(--warning)',
                        badgeColor: { bg: 'var(--warning-light)', text: 'var(--warning)' }
                      },
                      low: {
                        icon: Info,
                        iconColor: 'var(--info)',
                        badgeColor: { bg: 'var(--info-light)', text: 'var(--info)' }
                      }
                    };

                    const config = severityConfig[risk.severity as keyof typeof severityConfig];
                    const Icon = config.icon;
                    const impactValue = getImpactValue(risk.impact);
                    const probabilityValue = getProbabilityValue(risk.probability);

                    return (
                      <div
                        key={risk.id}
                        className="bg-[var(--neutral-50)] rounded-xl p-6 hover:bg-[var(--neutral-100)] transition-all duration-120 transition-apple border border-[var(--neutral-200)]"
                      >
                        <div className="flex items-start gap-4">
                          {/* Icon */}
                          <div 
                            className="w-12 h-12 rounded-lg bg-white flex items-center justify-center flex-shrink-0 okr-card-shadow"
                            style={{ color: config.iconColor }}
                          >
                            <Icon className="w-5 h-5" strokeWidth={2} />
                          </div>

                          {/* Content */}
                          <div className="flex-1 space-y-4">
                            <div className="flex items-start justify-between gap-4">
                              <div>
                                <div className="flex items-center gap-2 mb-2">
                                  <span 
                                    className="text-[10px] font-[500] px-3 py-1 rounded-md uppercase tracking-[0.05em]"
                                    style={{
                                      backgroundColor: config.badgeColor.bg,
                                      color: config.badgeColor.text
                                    }}
                                  >
                                    {risk.severity.charAt(0).toUpperCase() + risk.severity.slice(1)}
                                  </span>
                                  <span className="text-[10px] font-[500] px-3 py-1 rounded-md bg-[var(--neutral-100)] text-[var(--neutral-600)] uppercase tracking-[0.05em]">
                                    {risk.category}
                                  </span>
                                </div>
                                <div className="text-[14px] font-[500] text-[var(--neutral-800)] mb-2">{risk.title}</div>
                                <div className="text-[12px] font-[400] text-[var(--neutral-600)] leading-relaxed">
                                  {risk.description}
                                </div>
                              </div>
                            </div>

                            {/* Probability vs Impact Bars */}
                            <div className="space-y-4">
                              <div>
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-[12px] font-[400] text-[var(--neutral-600)]">Probability</span>
                                  <span className="text-[12px] font-[500] text-[var(--neutral-800)] tabular-nums">{risk.probability}</span>
                                </div>
                                <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-gradient-to-r from-[var(--info)] to-[var(--brand-primary)] rounded-full transition-all duration-300 transition-smooth"
                                    style={{ width: `${probabilityValue * 10}%` }}
                                  />
                                </div>
                              </div>
                              <div>
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-[12px] font-[400] text-[var(--neutral-600)]">Impact</span>
                                  <span className="text-[12px] font-[500] text-[var(--neutral-800)] tabular-nums">{risk.impact}</span>
                                </div>
                                <div className="h-2 bg-[var(--neutral-200)] rounded-full overflow-hidden">
                                  <div 
                                    className="h-full bg-gradient-to-r from-[var(--brand-primary)] to-[var(--brand-primary)] rounded-full transition-all duration-300 transition-smooth"
                                    style={{ width: `${impactValue * 10}%` }}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Action */}
                          <OkrButton
                            size="sm"
                            variant="outline"
                            onClick={() => setConfirmRisk(risk)}
                            className="flex-shrink-0 gap-2 text-[var(--brand-primary)] border-[var(--brand-primary)]/20 hover:bg-[var(--brand-primary)]/[0.04] transition-all duration-120"
                          >
                            <Sparkles className="w-4 h-4" strokeWidth={2} />
                            Resolve
                          </OkrButton>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
import { Play, Calendar, AlertCircle, CheckCircle2, Clock, TrendingUp, BarChart3, Filter, Download } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { loadRules } from './store';
import type { Rule } from './store';

// Deterministic hash for simulation numbers based on rule properties
function simHash(str: string, max: number): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % max;
}

// Derive simulation forecast from a single rule
function simulateRule(rule: Rule, multiplier: number) {
  const baseTriggers = (rule.triggers7d || 0) * multiplier;
  const triggers = Math.max(1, baseTriggers + simHash(rule.id + 'trig', 8));
  const critical = Math.max(0, Math.round(triggers * (rule.severity === 'High' || rule.severity === 'Critical' ? 0.35 : 0.1)));
  const resolved = Math.max(0, triggers - critical - simHash(rule.id + 'unres', 3));
  const avgH = (1.0 + simHash(rule.id + 'time', 40) / 10).toFixed(1);
  return { triggers, critical, resolved, avgTime: `${avgH}h` };
}

export function Simulation() {
  const [timeWindow, setTimeWindow] = useState('7d');
  const [selectedRule, setSelectedRule] = useState<string | null>(null);

  const computeRules = useCallback(() => loadRules(), []);
  const [rules, setRules] = useState<Rule[]>(computeRules);

  // Listen for cross-tab rule changes
  useEffect(() => {
    const reload = () => setRules(loadRules());
    window.addEventListener('rules-updated', reload);
    return () => window.removeEventListener('rules-updated', reload);
  }, []);

  const multiplier = timeWindow === '7d' ? 1 : timeWindow === '14d' ? 2 : 4;

  // Build forecast data from real rules
  const forecasts = rules.map(rule => {
    const sim = simulateRule(rule, multiplier);
    return {
      id: rule.id,
      name: rule.name,
      status: rule.status === 'live' ? 'Live' : rule.status === 'paused' ? 'Paused' : 'Draft',
      description: `${rule.signal} → ${rule.action} (${rule.scope})`,
      ...sim,
    };
  });

  // Aggregate summary
  const totalTriggers = forecasts.reduce((s, f) => s + f.triggers, 0);
  const totalCritical = forecasts.reduce((s, f) => s + f.critical, 0);
  const totalResolved = forecasts.reduce((s, f) => s + f.resolved, 0);
  const avgResponse = forecasts.length > 0
    ? (forecasts.reduce((s, f) => s + parseFloat(f.avgTime), 0) / forecasts.length).toFixed(1)
    : '0';

  // Deterministic heatmap data (seeded by day+hour) to avoid re-render flicker
  const heatmapData: Record<string, number[]> = {
    Monday:    [0.1,0.1,0.0,0.0,0.1,0.2,0.3,0.5,0.8,0.9,0.7,0.6,0.4,0.5,0.6,0.7,0.5,0.3,0.2,0.1,0.1,0.0,0.0,0.0],
    Tuesday:   [0.0,0.0,0.0,0.1,0.1,0.2,0.4,0.6,0.7,0.8,0.9,0.7,0.5,0.6,0.8,0.6,0.4,0.3,0.2,0.1,0.0,0.0,0.0,0.0],
    Wednesday: [0.0,0.1,0.0,0.0,0.1,0.2,0.3,0.5,0.6,0.7,0.6,0.5,0.4,0.5,0.7,0.8,0.6,0.4,0.2,0.1,0.1,0.0,0.0,0.0],
    Thursday:  [0.0,0.0,0.1,0.0,0.1,0.3,0.4,0.7,0.9,0.8,0.7,0.6,0.5,0.6,0.7,0.5,0.4,0.3,0.2,0.1,0.0,0.0,0.0,0.1],
    Friday:    [0.0,0.0,0.0,0.0,0.1,0.2,0.3,0.4,0.6,0.7,0.8,0.6,0.5,0.4,0.5,0.6,0.4,0.2,0.1,0.0,0.0,0.0,0.0,0.0],
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-ink text-xl font-semibold mb-1">Enforcement Simulation</h2>
          <p className="text-ink-secondary text-sm">Forecast based on your {rules.length} rules — see what would happen against historical data</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-surface-0 border border-edge rounded-lg p-1">
            {['7d', '14d', '30d'].map((period) => (
              <button
                key={period}
                onClick={() => setTimeWindow(period)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  timeWindow === period
                    ? 'bg-brand text-[var(--white)]'
                    : 'text-ink-secondary hover:text-ink'
                }`}
              >
                {period === '7d' ? 'Last 7 days' : period === '14d' ? 'Last 14 days' : 'Last 30 days'}
              </button>
            ))}
          </div>
          <button onClick={() => toast('TODO: Not implemented — would export simulation report')} className="px-4 py-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all text-sm font-medium flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </div>

      {/* Summary Cards — derived from real rules */}
      <div className="grid grid-cols-4 gap-5">
        <div className="bg-surface-0 rounded-xl border border-edge p-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-ink-secondary text-sm font-medium">Total Triggers</span>
            <Play className="w-5 h-5 text-brand" />
          </div>
          <div className="text-3xl font-bold text-ink mb-2">{totalTriggers}</div>
          <p className="text-ink-secondary text-sm">Would have fired</p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge p-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-ink-secondary text-sm font-medium">Critical</span>
            <AlertCircle className="w-5 h-5 text-danger-text" />
          </div>
          <div className="text-3xl font-bold text-danger-text mb-2">{totalCritical}</div>
          <p className="text-ink-secondary text-sm">High-priority alerts</p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge p-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-ink-secondary text-sm font-medium">Auto-Resolved</span>
            <CheckCircle2 className="w-5 h-5 text-success-text" />
          </div>
          <div className="text-3xl font-bold text-success-text mb-2">{totalResolved}</div>
          <p className="text-ink-secondary text-sm">Prevented escalation</p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge p-6">
          <div className="flex items-center justify-between mb-3">
            <span className="text-ink-secondary text-sm font-medium">Avg Response</span>
            <Clock className="w-5 h-5 text-info" />
          </div>
          <div className="text-3xl font-bold text-info mb-2">{avgResponse}h</div>
          <p className="text-ink-secondary text-sm">Time to resolution</p>
        </div>
      </div>

      {/* Rule-by-Rule Breakdown — from real rules */}
      <div className="bg-surface-0 rounded-xl border border-edge p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-ink font-semibold text-lg">Rule Performance Forecast ({forecasts.length} rules)</h3>
          <button onClick={() => toast('TODO: Not implemented — would filter simulation rules')} className="text-ink-secondary hover:text-ink text-sm font-medium flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filter Rules
          </button>
        </div>

        {forecasts.length === 0 && (
          <div className="text-center py-12 text-ink-muted">
            <Play className="w-10 h-10 mx-auto mb-3 text-ink-faint" />
            <p className="font-semibold mb-1">No rules to simulate</p>
            <p className="text-sm">Create rules in the Operating Policies tab to see forecast data here.</p>
          </div>
        )}

        <div className="space-y-3">
          {forecasts.map((rule) => (
            <div
              key={rule.id}
              onClick={() => setSelectedRule(selectedRule === rule.id ? null : rule.id)}
              className={`p-5 rounded-xl border-2 transition-all cursor-pointer ${
                selectedRule === rule.id
                  ? 'bg-brand-light border-brand'
                  : 'bg-surface-1 border-edge hover:border-ink-faint'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h4 className="text-ink font-semibold">{rule.name}</h4>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                      rule.status === 'Live'
                        ? 'bg-success-light text-success-text'
                        : rule.status === 'Paused'
                        ? 'bg-warning-light text-warning'
                        : 'bg-surface-2 text-ink-secondary'
                    }`}>
                      {rule.status}
                    </span>
                  </div>
                  <p className="text-ink-secondary text-sm">{rule.description}</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-ink">{rule.triggers}</div>
                  <div className="text-xs text-ink-muted">would fire</div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4 pt-3 border-t border-edge">
                <div>
                  <div className="text-xs text-ink-secondary mb-1">Total Triggers</div>
                  <div className="text-lg font-bold text-ink">{rule.triggers}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-secondary mb-1">Critical</div>
                  <div className="text-lg font-bold text-danger-text">{rule.critical}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-secondary mb-1">Auto-Resolved</div>
                  <div className="text-lg font-bold text-success-text">{rule.resolved}</div>
                </div>
                <div>
                  <div className="text-xs text-ink-secondary mb-1">Avg Response</div>
                  <div className="text-lg font-bold text-info">{rule.avgTime}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Time-based Heatmap */}
      <div className="bg-surface-0 rounded-xl border border-edge p-6">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-ink font-semibold text-lg mb-1">Trigger Frequency Heatmap</h3>
            <p className="text-ink-secondary text-sm">When would rules fire most often?</p>
          </div>
        </div>

        <div className="space-y-4">
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => (
            <div key={day} className="flex items-center gap-4">
              <div className="w-24 text-sm font-medium text-ink-secondary">{day}</div>
              <div className="flex-1 flex gap-1">
                {Array.from({ length: 24 }, (_, hour) => {
                  const intensity = heatmapData[day][hour];
                  return (
                    <div
                      key={hour}
                      className={`h-8 flex-1 rounded ${
                        intensity > 0.7 ? 'bg-brand' :
                        intensity > 0.5 ? 'bg-brand/60' :
                        intensity > 0.3 ? 'bg-brand/30' :
                        'bg-surface-2'
                      }`}
                      title={`${hour}:00 - ${intensity > 0.5 ? 'High' : 'Low'} activity`}
                    />
                  );
                })}
              </div>
            </div>
          ))}
          <div className="flex items-center justify-between pt-4 border-t border-edge">
            <div className="flex items-center gap-4">
              <span className="text-xs text-ink-muted">Less activity</span>
              <div className="flex gap-1">
                <div className="w-4 h-4 bg-surface-2 rounded" />
                <div className="w-4 h-4 bg-brand/30 rounded" />
                <div className="w-4 h-4 bg-brand/60 rounded" />
                <div className="w-4 h-4 bg-brand rounded" />
              </div>
              <span className="text-xs text-ink-muted">More activity</span>
            </div>
            <div className="text-xs text-ink-muted">
              Based on {rules.length} rules with {totalTriggers} projected triggers
            </div>
          </div>
        </div>
      </div>

      {/* Impact Projection — derived from real data */}
      <div className="bg-gradient-to-r from-brand-light to-info-light border border-brand rounded-xl p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-brand" />
              <h3 className="text-brand-active font-bold text-lg">Projected Impact</h3>
            </div>
            <p className="text-ink-secondary mb-4">
              If all {rules.length} rules had been active, here's what would have happened:
            </p>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-surface-0 rounded-lg p-4 border border-brand">
                <div className="text-2xl font-bold text-success-text mb-1">~{Math.round(totalTriggers * 0.2)}h</div>
                <div className="text-sm text-ink-secondary">Executive time saved</div>
              </div>
              <div className="bg-surface-0 rounded-lg p-4 border border-brand">
                <div className="text-2xl font-bold text-info mb-1">{totalResolved}</div>
                <div className="text-sm text-ink-secondary">Issues prevented</div>
              </div>
              <div className="bg-surface-0 rounded-lg p-4 border border-brand">
                <div className="text-2xl font-bold text-brand mb-1">{totalTriggers > 0 ? Math.round((totalResolved / totalTriggers) * 100) : 0}%</div>
                <div className="text-sm text-ink-secondary">Auto-resolution rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
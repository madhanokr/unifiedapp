import { X, AlertTriangle, Clock, CheckCircle2, User, Bell, Calendar, FileText, Download } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { saveEvidenceResolution, loadEvidenceResolutions } from './store';

interface TimelineEvent {
  id: string;
  timestamp: string;
  type: 'signal' | 'policy' | 'action' | 'acknowledgement' | 'update' | 'resolution';
  title: string;
  description?: string;
  actor?: string;
  metadata?: Record<string, unknown>; // TODO: type properly during merge
}

interface EvidenceTimelineProps {
  isOpen: boolean;
  onClose: () => void;
  incident: {
    id: string;
    title: string;
    status: 'open' | 'resolved';
    slaStatus: 'met' | 'breached';
    slaDetails?: string;
    policy: string;
    owner: string;
    escalationLevel: string;
    signal: string;
    conditions: Record<string, unknown>[]; // TODO: type properly during merge
    exceptions: Record<string, unknown>[]; // TODO: type properly during merge
  };
}

export function EvidenceTimeline({ isOpen, onClose, incident }: EvidenceTimelineProps) {
  const [showResolutionForm, setShowResolutionForm] = useState(false);
  const [resolutionType, setResolutionType] = useState('');
  const [resolutionNote, setResolutionNote] = useState('');
  const [resolutionProof, setResolutionProof] = useState('');
  // Check if this incident already has a persisted resolution
  const [isResolved, setIsResolved] = useState(() => {
    if (incident.status === 'resolved') return true;
    const resolutions = loadEvidenceResolutions();
    return resolutions.some(r => r.incidentId === incident.id);
  });

  if (!isOpen) return null;

  // Mock timeline events
  const timelineEvents: TimelineEvent[] = [
    {
      id: '1',
      timestamp: 'Dec 12, 2024 10:04 AM',
      type: 'signal',
      title: 'Signal detected: "Blocked status entered"',
      description: 'Task "Mobile App v2 Launch" changed to Blocked status',
      metadata: { previousStatus: 'In Progress', newStatus: 'Blocked' }
    },
    {
      id: '2',
      timestamp: 'Dec 14, 2024 10:04 AM',
      type: 'signal',
      title: 'SLA exceeded (48h)',
      description: 'Blocked duration threshold reached: 48 hours'
    },
    {
      id: '3',
      timestamp: 'Dec 14, 2024 10:05 AM',
      type: 'policy',
      title: 'Policy fired: Blocked SLA (Critical)',
      description: 'Conditions matched. Escalation initiated.',
      metadata: {
        matchedConditions: [
          'Severity = High',
          'Team = Engineering',
          'Dependency = cross-team'
        ],
        ignoredExceptions: [
          'Already notified <24h: NOT triggered'
        ]
      }
    },
    {
      id: '4',
      timestamp: 'Dec 14, 2024 10:05 AM',
      type: 'action',
      title: 'Action: Slack sent to Marcus (owner)',
      description: 'Notification delivered via Slack #engineering',
      actor: 'System',
      metadata: { channel: 'slack', requireAck: true }
    },
    {
      id: '5',
      timestamp: 'Dec 14, 2024 10:05 AM',
      type: 'action',
      title: 'Action: Task created "Unblock: API dependency"',
      description: 'Follow-up task assigned to Marcus Kim',
      actor: 'System',
      metadata: { taskId: 'TASK-4821', assignee: 'Marcus Kim' }
    },
    {
      id: '6',
      timestamp: 'Dec 15, 2024 10:05 AM',
      type: 'action',
      title: 'No acknowledgement → escalated to Manager (Sarah)',
      description: 'Escalation triggered after 24h with no owner acknowledgement',
      actor: 'System',
      metadata: { escalationLevel: 'Manager' }
    },
    {
      id: '7',
      timestamp: 'Dec 15, 2024 10:06 AM',
      type: 'action',
      title: 'Huddle scheduled (15m)',
      description: 'Unblock huddle scheduled for Dec 15, 2PM',
      actor: 'System',
      metadata: { attendees: ['Marcus Kim', 'Sarah Chen', 'Design Lead'] }
    },
    {
      id: '8',
      timestamp: 'Dec 16, 2024 12:14 PM',
      type: 'update',
      title: 'Update received: "Waiting on Design"',
      description: 'Owner provided status update',
      actor: 'Marcus Kim',
      metadata: { updateText: 'Blocked by Design team - waiting on API spec finalization' }
    },
    {
      id: '9',
      timestamp: 'Dec 16, 2024 4:30 PM',
      type: 'resolution',
      title: 'Resolved: blocker removed (proof attached)',
      description: 'Dependency cleared - API spec delivered by Design team',
      actor: 'Marcus Kim',
      metadata: {
        resolutionType: 'dependency-cleared',
        proof: 'https://figma.com/file/api-spec-v2',
        note: 'Design team delivered API spec. Unblocked and ready to proceed.'
      }
    }
  ];

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'signal': return <AlertTriangle className="w-5 h-5" />;
      case 'policy': return <FileText className="w-5 h-5" />;
      case 'action': return <Bell className="w-5 h-5" />;
      case 'acknowledgement': return <CheckCircle2 className="w-5 h-5" />;
      case 'update': return <User className="w-5 h-5" />;
      case 'resolution': return <CheckCircle2 className="w-5 h-5" />;
      default: return <Clock className="w-5 h-5" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'signal': return 'bg-warning-light text-warning border-warning';
      case 'policy': return 'bg-brand-light text-brand border-brand';
      case 'action': return 'bg-info-light text-info border-info';
      case 'acknowledgement': return 'bg-success-light text-success-text border-success';
      case 'update': return 'bg-info-light text-info border-info';
      case 'resolution': return 'bg-success-light text-success-text border-success';
      default: return 'bg-surface-2 text-ink-secondary border-edge';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-end">
      <div className="bg-surface-0 h-full w-full max-w-3xl shadow-[var(--shadow-elevated)] flex flex-col animate-slide-in-right">
        {/* Header */}
        <div className="p-6 border-b border-edge bg-gradient-to-r from-brand-light to-info-light">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <FileText className="w-6 h-6 text-brand" />
                <h2 className="text-ink text-xl font-semibold">Evidence Timeline</h2>
              </div>
              <h3 className="text-ink font-bold mb-2">{incident.title}</h3>
              <p className="text-ink-secondary text-sm">Complete audit trail and proof of governance</p>
            </div>
            <button onClick={onClose} className="text-ink-muted hover:text-ink-secondary text-2xl leading-none">
              ×
            </button>
          </div>

          {/* Summary Strip */}
          <div className="grid grid-cols-4 gap-3">
            <div className="p-3 bg-surface-0 rounded-lg border border-edge">
              <p className="text-ink-secondary text-xs mb-1">Status</p>
              <div className="flex items-center gap-1">
                {incident.status === 'resolved' ? (
                  <CheckCircle2 className="w-4 h-4 text-success-text" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-danger-text" />
                )}
                <p className="text-ink font-semibold text-sm capitalize">{incident.status}</p>
              </div>
            </div>

            <div className="p-3 bg-surface-0 rounded-lg border border-edge">
              <p className="text-ink-secondary text-xs mb-1">SLA</p>
              <p className={`font-semibold text-sm ${
                incident.slaStatus === 'breached' ? 'text-danger-text' : 'text-success-text'
              }`}>
                {incident.slaStatus === 'breached' ? 'Breached by 12h' : 'Met'}
              </p>
            </div>

            <div className="p-3 bg-surface-0 rounded-lg border border-edge">
              <p className="text-ink-secondary text-xs mb-1">Policy</p>
              <p className="text-ink font-semibold text-sm">{incident.policy}</p>
            </div>

            <div className="p-3 bg-surface-0 rounded-lg border border-edge">
              <p className="text-ink-secondary text-xs mb-1">Owner</p>
              <p className="text-ink font-semibold text-sm">{incident.owner}</p>
            </div>
          </div>
        </div>

        {/* Body - Scrollable */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Why This Fired */}
          <div className="p-3 bg-brand-light border-2 border-brand rounded-lg">
            <h4 className="text-brand-active font-semibold mb-2 flex items-center gap-2 text-sm">
              <AlertTriangle className="w-4 h-4" />
              Why This Fired
            </h4>
            
            <div className="space-y-2 text-sm">
              <div>
                <p className="text-brand font-medium mb-1 text-xs">Signal:</p>
                <p className="text-brand-active bg-surface-0 px-2 py-1.5 rounded border border-brand text-xs">
                  {incident.signal}
                </p>
              </div>

              <div>
                <p className="text-brand font-medium mb-1 text-xs">Conditions Matched:</p>
                <ul className="space-y-1">
                  {['Severity = High', 'Team = Engineering', 'Dependency = cross-team'].map((cond, i) => (
                    <li key={i} className="flex items-center gap-2 text-brand-active bg-surface-0 px-2 py-1.5 rounded border border-brand text-xs">
                      <CheckCircle2 className="w-3 h-3 text-success-text" />
                      {cond}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <p className="text-brand font-medium mb-1 text-xs">Exceptions Checked:</p>
                <ul className="space-y-1">
                  <li className="flex items-center gap-2 text-brand-active bg-surface-0 px-2 py-1.5 rounded border border-brand text-xs">
                    <X className="w-3 h-3 text-danger-text" />
                    Already notified &lt;24h: <strong>NOT triggered</strong>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div>
            <h4 className="text-ink font-semibold mb-3 flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4 text-ink-secondary" />
              Complete Timeline
            </h4>

            {/* Vertical Timeline */}
            <div className="relative">
              {/* Vertical Line */}
              <div className="absolute left-4 top-3 bottom-3 w-0.5 bg-edge"></div>

              <div className="space-y-3">
                {timelineEvents.map((event, index) => (
                  <div key={event.id} className="relative pl-11">
                    {/* Timeline Dot */}
                    <div className={`absolute left-0 top-1.5 w-8 h-8 rounded-full border-2 flex items-center justify-center ${getEventColor(event.type)}`}>
                      {getEventIcon(event.type)}
                    </div>

                    {/* Event Card */}
                    <div className="bg-surface-0 border border-edge rounded-lg p-3 hover:border-ink-faint transition-colors">
                      <div className="flex items-start justify-between mb-1.5">
                        <div className="flex-1">
                          <p className="text-ink font-semibold text-xs mb-1">{event.title}</p>
                          <div className="flex items-center gap-2 text-xs text-ink-muted">
                            <Clock className="w-3 h-3" />
                            {event.timestamp}
                            {event.actor && (
                              <>
                                <span>•</span>
                                <User className="w-3 h-3" />
                                {event.actor}
                              </>
                            )}
                          </div>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold uppercase ${getEventColor(event.type)}`}>
                          {event.type}
                        </span>
                      </div>

                      {event.description && (
                        <p className="text-ink-secondary text-xs mb-2">{event.description}</p>
                      )}

                      {/* Event Metadata */}
                      {event.metadata && (
                        <div className="mt-2 p-2 bg-surface-1 border border-edge rounded-lg">
                          {event.type === 'policy' && event.metadata.matchedConditions && (
                            <div className="space-y-1">
                              <p className="text-ink-secondary font-medium text-xs">Matched Conditions:</p>
                              <ul className="space-y-0.5">
                                {event.metadata.matchedConditions.map((cond: string, i: number) => (
                                  <li key={i} className="text-ink-secondary text-xs flex items-center gap-1">
                                    <CheckCircle2 className="w-3 h-3 text-success-text" />
                                    {cond}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {event.type === 'resolution' && event.metadata.proof && (
                            <div className="space-y-1">
                              <p className="text-ink-secondary font-medium text-xs">Proof of Resolution:</p>
                              <div className="space-y-0.5 text-xs">
                                <p className="text-ink-secondary">
                                  <strong>Type:</strong> {event.metadata.resolutionType?.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                                </p>
                                <p className="text-ink-secondary">
                                  <strong>Note:</strong> {event.metadata.note}
                                </p>
                                <p className="text-ink-secondary">
                                  <strong>Reference:</strong>{' '}
                                  <a href={event.metadata.proof} className="text-brand hover:underline" target="_blank" rel="noopener noreferrer">
                                    {event.metadata.proof}
                                  </a>
                                </p>
                              </div>
                            </div>
                          )}

                          {event.type === 'action' && event.metadata.channel && (
                            <p className="text-ink-secondary text-xs">
                              <strong>Channel:</strong> {event.metadata.channel} • <strong>Require Ack:</strong> {event.metadata.requireAck ? 'Yes' : 'No'}
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Acknowledgements / Ignored */}
          <div className="p-3 bg-warning-light border border-warning rounded-lg">
            <h4 className="text-warning font-semibold mb-2 text-sm">Acknowledgement History</h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-warning">First notification sent:</span>
                <span className="text-warning font-semibold">Dec 14, 10:05 AM</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-warning">Owner acknowledgement:</span>
                <span className="text-danger-text font-semibold">None (ignored for 24h)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-warning">Escalation triggered:</span>
                <span className="text-warning font-semibold">Dec 15, 10:05 AM (to Manager)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-warning">Repeat offender count (30d):</span>
                <span className="text-danger-text font-semibold">3 incidents ignored</span>
              </div>
            </div>
          </div>

          {/* Resolution Form (if incident is open) */}
          {!isResolved && !showResolutionForm && (
            <button
              onClick={() => setShowResolutionForm(true)}
              className="w-full py-2.5 bg-success text-[var(--white)] rounded-lg hover:bg-success/90 transition-colors font-semibold text-sm"
            >
              Mark as Resolved (Proof Required)
            </button>
          )}

          {isResolved && !showResolutionForm && (
            <div className="p-3 bg-success-light border-2 border-success rounded-lg flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-success-text" />
              <span className="text-success-text font-semibold text-sm">This incident has been resolved</span>
            </div>
          )}

          {showResolutionForm && (
            <div className="p-4 bg-success-light border-2 border-success rounded-lg space-y-3">
              <h4 className="text-success-text font-semibold text-sm">Proof Required: Mark as Resolved</h4>
              
              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">
                  Resolution Type <span className="text-danger-text">*</span>
                </label>
                <select
                  value={resolutionType}
                  onChange={(e) => setResolutionType(e.target.value)}
                  className="w-full px-3 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-success text-sm"
                >
                  <option value="">Select type...</option>
                  <option value="update-received">Update received from owner</option>
                  <option value="dependency-cleared">Dependency cleared</option>
                  <option value="owner-changed">Owner changed</option>
                  <option value="scope-adjusted">Scope adjusted</option>
                  <option value="eta-committed">ETA committed</option>
                </select>
              </div>

              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">
                  Proof Note (required) <span className="text-danger-text">*</span>
                </label>
                <textarea
                  value={resolutionNote}
                  onChange={(e) => setResolutionNote(e.target.value)}
                  placeholder="Provide a 1-sentence explanation of how this was resolved..."
                  className="w-full px-3 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-success resize-none text-sm"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">
                  Proof Link/File (optional)
                </label>
                <input
                  type="text"
                  value={resolutionProof}
                  onChange={(e) => setResolutionProof(e.target.value)}
                  placeholder="https://... or file path"
                  className="w-full px-3 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-success text-sm"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowResolutionForm(false)}
                  className="flex-1 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium text-sm"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    if (!resolutionType || !resolutionNote) {
                      toast.error('Please provide resolution type and note');
                      return;
                    }
                    saveEvidenceResolution({
                      incidentId: incident.id,
                      type: resolutionType,
                      note: resolutionNote,
                      proof: resolutionProof,
                      resolvedAt: new Date().toISOString(),
                    });
                    toast.success(`Incident resolved (${resolutionType})`);
                    setShowResolutionForm(false);
                    setIsResolved(true);
                    // Notify EvidenceAuditPage to reload resolutions
                    window.dispatchEvent(new CustomEvent('evidence-resolutions-updated'));
                  }}
                  disabled={!resolutionType || !resolutionNote}
                  className={`flex-1 py-2 rounded-lg transition-colors font-semibold text-sm ${
                    resolutionType && resolutionNote
                      ? 'bg-success text-[var(--white)] hover:bg-success/90'
                      : 'bg-edge text-ink-muted cursor-not-allowed'
                  }`}
                >
                  Confirm Resolution
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 pb-6 pt-4 border-t border-edge flex items-center justify-between bg-surface-1">
          <div className="text-sm text-ink-secondary">
            <p>Incident ID: <span className="font-mono text-ink">{incident.id}</span></p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => toast('TODO: Not implemented — would export incident timeline as PDF')} className="flex items-center gap-2 px-4 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium text-sm">
              <Download className="w-4 h-4" />
              Export (PDF)
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium text-sm"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
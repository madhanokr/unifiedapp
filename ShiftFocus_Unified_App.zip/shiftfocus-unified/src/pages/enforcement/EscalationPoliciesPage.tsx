import { useState, useEffect, useCallback } from 'react';
import { TrendingUp, Clock, Bell, AlertTriangle, CheckCircle2, Settings, ChevronRight, Edit } from 'lucide-react';
import { EscalationPolicyEditor } from './EscalationPolicyEditor';
import { loadEscalationPolicies } from './store';
import type { EscalationPolicyState } from './store';

// Action label map (shared with editor)
const ACTION_LABELS: Record<string, string> = {
  'notify-owner': 'Notify Owner',
  'notify-manager': 'Notify Manager',
  'escalate-manager': 'Escalate to Manager',
  'escalate-exec': 'Escalate to Exec',
  'create-task': 'Create Task',
  'require-update': 'Require Update',
  'schedule-huddle': 'Schedule Huddle',
  'weekly-brief-top5': 'Weekly Brief Top 5',
  'mark-exec-attention': 'Exec Attention',
};

interface PolicyDisplay {
  id: string;
  name: string;
  description: string;
  severity: string[];
  steps: number;
  avgResolutionTime: string;
  activeIncidents: number;
  color: string;
  // Saved step data for timeline preview
  savedSteps: { delay: string; actions: string[] }[] | null;
}

const BASE_POLICIES: PolicyDisplay[] = [
  {
    id: 'Critical',
    name: 'Critical',
    description: 'For business-critical issues requiring immediate attention',
    severity: ['Critical'],
    steps: 4,
    avgResolutionTime: '4.2h',
    activeIncidents: 3,
    color: 'red',
    savedSteps: null,
  },
  {
    id: 'High Priority',
    name: 'High Priority',
    description: 'For high-impact issues that need fast resolution',
    severity: ['High'],
    steps: 3,
    avgResolutionTime: '12h',
    activeIncidents: 8,
    color: 'amber',
    savedSteps: null,
  },
  {
    id: 'Standard',
    name: 'Standard',
    description: 'Default escalation path for medium priority issues',
    severity: ['Medium'],
    steps: 2,
    avgResolutionTime: '24h',
    activeIncidents: 15,
    color: 'yellow',
    savedSteps: null,
  },
  {
    id: 'Low Priority',
    name: 'Low Priority',
    description: 'For minor issues with flexible timelines',
    severity: ['Low'],
    steps: 2,
    avgResolutionTime: '72h',
    activeIncidents: 4,
    color: 'gray',
    savedSteps: null,
  },
];

function mergePolicies(saved: EscalationPolicyState[] | null): PolicyDisplay[] {
  return BASE_POLICIES.map(base => {
    const match = saved?.find(s => s.id === base.id || s.name === base.name);
    if (!match) return base;
    return {
      ...base,
      steps: match.steps.length,
      savedSteps: match.steps.map(s => ({ delay: s.delay, actions: s.actions })),
    };
  });
}

function getFirstAction(actions: string[]): string {
  if (actions.length === 0) return 'No action';
  return ACTION_LABELS[actions[0]] || actions[0];
}

export function EscalationPoliciesPage() {
  const [editingPolicy, setEditingPolicy] = useState<string | null>(null);
  const [policies, setPolicies] = useState<PolicyDisplay[]>(() =>
    mergePolicies(loadEscalationPolicies())
  );

  // Reload when editor saves (cross-component coherence)
  const reload = useCallback(() => {
    setPolicies(mergePolicies(loadEscalationPolicies()));
  }, []);

  useEffect(() => {
    window.addEventListener('escalation-policies-updated', reload);
    return () => window.removeEventListener('escalation-policies-updated', reload);
  }, [reload]);

  // Derive stats from policies
  const totalIncidents = policies.reduce((sum, p) => sum + p.activeIncidents, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-ink mb-2">Escalation Policies</h2>
        <p className="text-ink-secondary text-sm">
          Define how incidents escalate over time — from owner notification to executive attention
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-brand-light rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-brand" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">{totalIncidents}</div>
              <p className="text-ink-secondary text-xs">Active Incidents</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-danger-light rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-danger-text" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">3</div>
              <p className="text-ink-secondary text-xs">Breached SLA</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-success-light rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-success-text" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">94%</div>
              <p className="text-ink-secondary text-xs">Resolved On Time</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-info-light rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-info" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">8.4h</div>
              <p className="text-ink-secondary text-xs">Avg Resolution</p>
            </div>
          </div>
        </div>
      </div>

      {/* Policies List */}
      <div className="space-y-4">
        {policies.map(policy => (
          <div key={policy.id} className="p-6 bg-surface-0 rounded-xl border-2 border-edge hover:border-brand transition-colors">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-ink font-semibold text-lg">{policy.name}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    policy.color === 'red' ? 'bg-danger-light text-danger-text' :
                    policy.color === 'amber' ? 'bg-warning-light text-warning' :
                    policy.color === 'yellow' ? 'bg-warning-light text-warning' :
                    'bg-surface-2 text-ink-secondary'
                  }`}>
                    {policy.severity.join(', ')} Severity
                  </span>
                  {policy.savedSteps && (
                    <span className="px-2 py-0.5 bg-success-light text-success-text text-xs font-semibold rounded-full">
                      Customized
                    </span>
                  )}
                </div>
                <p className="text-ink-secondary text-sm mb-4">{policy.description}</p>

                {/* Policy Stats */}
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-ink-muted" />
                    <span className="text-ink-secondary text-sm font-medium">{policy.steps} escalation steps</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-ink-muted" />
                    <span className="text-ink-secondary text-sm">Avg resolution: {policy.avgResolutionTime}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-ink-muted" />
                    <span className="text-ink-secondary text-sm">{policy.activeIncidents} active incidents</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setEditingPolicy(policy.id)}
                className="flex items-center gap-2 px-4 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium"
              >
                <Edit className="w-4 h-4" />
                Edit Timeline
              </button>
            </div>

            {/* Quick Preview of Steps — dynamic from localStorage */}
            <div className="pt-4 border-t border-edge">
              <p className="text-ink-secondary text-xs font-semibold mb-3">Escalation Timeline:</p>
              <div className="flex items-center gap-2 flex-wrap">
                {policy.savedSteps ? (
                  // Render from persisted data
                  policy.savedSteps.map((step, i) => {
                    const colorClass =
                      policy.color === 'red' ? (i === 0 ? 'bg-danger-light border-danger text-danger-text' : i < 2 ? 'bg-warning-light border-warning text-warning' : 'bg-brand-light border-brand text-brand') :
                      policy.color === 'amber' ? 'bg-warning-light border-warning text-warning' :
                      policy.color === 'yellow' ? 'bg-warning-light border-warning text-warning' :
                      'bg-surface-1 border-edge text-ink-secondary';
                    return (
                      <span key={i} className="contents">
                        <div className={`px-3 py-1.5 border rounded-lg text-xs ${colorClass}`}>
                          <span className="font-semibold">{step.delay}h:</span>{' '}
                          <span>{getFirstAction(step.actions)}</span>
                        </div>
                        {i < policy.savedSteps!.length - 1 && (
                          <ChevronRight className="w-3 h-3 text-ink-muted" />
                        )}
                      </span>
                    );
                  })
                ) : (
                  // Fallback defaults for policies never edited
                  <>
                    {policy.id === 'Critical' && (
                      <>
                        <div className="px-3 py-1.5 bg-danger-light border border-danger rounded-lg text-xs">
                          <span className="text-danger-text font-semibold">0h:</span> <span className="text-danger-text">Notify Owner</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">4h:</span> <span className="text-warning">Escalate to Manager</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">12h:</span> <span className="text-warning">Escalate to Director</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-brand-light border border-brand rounded-lg text-xs">
                          <span className="text-brand-active font-semibold">24h:</span> <span className="text-brand">Executive Brief</span>
                        </div>
                      </>
                    )}
                    {policy.id === 'High Priority' && (
                      <>
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">0h:</span> <span className="text-warning">Notify Owner</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">12h:</span> <span className="text-warning">Escalate to Manager</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-brand-light border border-brand rounded-lg text-xs">
                          <span className="text-brand-active font-semibold">48h:</span> <span className="text-brand">Weekly Brief</span>
                        </div>
                      </>
                    )}
                    {policy.id === 'Standard' && (
                      <>
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">0h:</span> <span className="text-warning">Notify Owner</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-warning-light border border-warning rounded-lg text-xs">
                          <span className="text-warning font-semibold">24h:</span> <span className="text-warning">Escalate to Manager</span>
                        </div>
                      </>
                    )}
                    {policy.id === 'Low Priority' && (
                      <>
                        <div className="px-3 py-1.5 bg-surface-1 border border-edge rounded-lg text-xs">
                          <span className="text-ink font-semibold">0h:</span> <span className="text-ink-secondary">Notify Owner</span>
                        </div>
                        <ChevronRight className="w-3 h-3 text-ink-muted" />
                        <div className="px-3 py-1.5 bg-info-light border border-info rounded-lg text-xs">
                          <span className="text-info font-semibold">72h:</span> <span className="text-info">Reminder</span>
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Editor Modal */}
      {editingPolicy && (
        <EscalationPolicyEditor
          isOpen={true}
          onClose={() => setEditingPolicy(null)}
          policyName={policies.find(p => p.id === editingPolicy)?.name || 'Critical'}
        />
      )}
    </div>
  );
}
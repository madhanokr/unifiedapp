import { useState } from 'react';
import { ChevronRight, X, Check, TriangleAlert, Activity, RotateCcw, FileText, Plug, ExternalLink, Info } from 'lucide-react';
import { AuditLogModal } from './AuditLogModal';
import { toast } from 'sonner';
import { loadSettings, saveSettings, type SettingsState, loadIntegrationStates, saveIntegrationStates, loadSettingsExtended, saveSettingsExtended } from './store';

interface Policy {
  id: string;
  name: string;
  description: string;
  chain: string;
}

interface Integration {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  logo: string;
  workspace?: string;
  lastSync?: string;
  apiKey?: string;
}

export function Settings() {
  const [policies] = useState([
    {
      id: '1',
      name: 'Standard',
      description: 'Owner → Manager (48h) → Exec (96h)',
      chain: 'Owner → Manager (48h) → Exec (96h)',
    },
    {
      id: '2',
      name: 'Critical',
      description: 'Owner → Manager (24h) → COO (48h)',
      chain: 'Owner → Manager (24h) → COO (48h)',
    },
    {
      id: '3',
      name: 'Silent',
      description: 'Owner only (no escalation)',
      chain: 'Owner only (no escalation)',
    },
  ]);

  const [selectedPolicy, setSelectedPolicy] = useState<Policy | null>(null);
  const [channels] = useState({
    slack: { connected: true, workspace: 'ShiftFocus Team' },
    teams: { connected: true, workspace: 'Company Workspace' },
    email: { connected: true, workspace: 'company@example.com' },
  });

  // Load persisted settings from localStorage on mount
  const [settingsState, setSettingsState] = useState<SettingsState>(() => loadSettings());

  const quietHoursEnabled = settingsState.quietHoursEnabled;
  const failSafeEnabled = settingsState.failSafeEnabled;
  const digestEnabled = settingsState.digestEnabled;
  const maxPerDay = settingsState.maxPerDay;
  const failSafeThreshold = settingsState.failSafeThreshold;

  const updateSettings = (patch: Partial<SettingsState>) => {
    setSettingsState(prev => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  };

  const setQuietHoursEnabled = (v: boolean) => updateSettings({ quietHoursEnabled: v });
  const setFailSafeEnabled = (v: boolean) => updateSettings({ failSafeEnabled: v });
  const setDigestEnabled = (v: boolean) => updateSettings({ digestEnabled: v });
  const setMaxPerDay = (v: string) => updateSettings({ maxPerDay: v });
  const setFailSafeThreshold = (v: string) => updateSettings({ failSafeThreshold: v });

  // Extended settings: notification routing, escalation chain, etc.
  const [extSettings, setExtSettings] = useState(() => loadSettingsExtended());
  const updateExtSettings = (patch: Partial<typeof extSettings>) => {
    setExtSettings(prev => {
      const next = { ...prev, ...patch };
      saveSettingsExtended(next);
      return next;
    });
  };

  // Notification routing state (controlled)
  const [notificationRoutes, setNotificationRoutes] = useState(extSettings.notificationRoutes);
  const updateRoute = (index: number, field: keyof typeof notificationRoutes[0], value: string) => {
    const updated = notificationRoutes.map((r, i) => i === index ? { ...r, [field]: value } : r);
    setNotificationRoutes(updated);
    updateExtSettings({ notificationRoutes: updated });
  };

  // Email distribution (controlled)
  const [emailCritical, setEmailCritical] = useState(extSettings.notificationRoutes.length > 0 ? 'exec-team@company.com, coo@company.com' : '');
  const [emailStandard, setEmailStandard] = useState('managers@company.com, team-leads@company.com');
  const [emailDigest, setEmailDigest] = useState('all-staff@company.com');

  // Approval toggle (controlled)
  const [requireApproval, setRequireApproval] = useState(true);

  // Escalation chain editor state (per-policy, controlled)
  const [chainStep1, setChainStep1] = useState('Owner');
  const [chainStep2, setChainStep2] = useState('Manager');
  const [chainStep3, setChainStep3] = useState('Exec');
  const [slaWarning, setSlaWarning] = useState(extSettings.escalationSlaWarning);
  const [slaEscalate, setSlaEscalate] = useState(extSettings.escalationSlaEscalate);

  // Integration config state (controlled)
  const [integrationBoard, setIntegrationBoard] = useState(extSettings.integrationDefaultBoard);
  const [integrationTemplate, setIntegrationTemplate] = useState(extSettings.integrationNotificationTemplate);
  const [integrationAutoAssign, setIntegrationAutoAssign] = useState(extSettings.integrationTemplateEnabled);

  const DEFAULT_INTEGRATIONS: Integration[] = [
    {
      id: 'jira',
      name: 'Jira',
      description: 'Create and manage issues in Jira workspaces',
      connected: true,
      logo: '🔷',
      workspace: 'ShiftFocus Engineering',
      lastSync: '2 min ago',
    },
    {
      id: 'asana',
      name: 'Asana',
      description: 'Create tasks and projects in Asana',
      connected: true,
      logo: '🔸',
      workspace: 'Product Team Workspace',
      lastSync: '5 min ago',
    },
    {
      id: 'linear',
      name: 'Linear',
      description: 'Create and track issues in Linear',
      connected: false,
      logo: '⚡',
    },
    {
      id: 'trello',
      name: 'Trello',
      description: 'Create cards on Trello boards',
      connected: false,
      logo: '📋',
    },
    {
      id: 'notion',
      name: 'Notion',
      description: 'Create pages and tasks in Notion',
      connected: false,
      logo: '📝',
    },
    {
      id: 'github',
      name: 'GitHub',
      description: 'Create issues in GitHub repositories',
      connected: false,
      logo: '🐙',
    },
  ];

  // Merge persisted integration states with defaults
  const savedIntegrations = loadIntegrationStates();
  const initialIntegrations = DEFAULT_INTEGRATIONS.map(d => {
    const saved = savedIntegrations?.find(s => s.id === d.id);
    if (saved) {
      return { ...d, connected: saved.connected, workspace: saved.connected ? (d.workspace || 'Default Workspace') : undefined, lastSync: saved.connected ? (d.lastSync || 'Previously') : undefined };
    }
    return d;
  });

  const [integrations, setIntegrations] = useState<Integration[]>(initialIntegrations);
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null);
  const [showAuditLog, setShowAuditLog] = useState(false);
  const [auditTarget, setAuditTarget] = useState<{ id?: string, type?: 'rule' | 'policy' | 'playbook' | 'setting' | 'integration' | 'all', name?: string }>({});

  const handleConnect = (integrationId: string) => {
    const updated = integrations.map(int => 
      int.id === integrationId 
        ? { ...int, connected: true, workspace: 'Default Workspace', lastSync: 'Just now' }
        : int
    );
    setIntegrations(updated);
    saveIntegrationStates(updated.map(i => ({ id: i.id, connected: i.connected })));
    const integration = integrations.find(i => i.id === integrationId);
    toast.success(`${integration?.name} connected`);
  };

  const handleDisconnect = (integrationId: string) => {
    const integration = integrations.find(i => i.id === integrationId);
    const updated = integrations.map(int => 
      int.id === integrationId 
        ? { ...int, connected: false, workspace: undefined, lastSync: undefined }
        : int
    );
    setIntegrations(updated);
    saveIntegrationStates(updated.map(i => ({ id: i.id, connected: i.connected })));
    toast.success(`${integration?.name} disconnected`);
  };

  /* Toggle switch class — reused across all toggles */
  const toggleCls = "w-11 h-6 bg-edge peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-surface-0 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand";

  return (
    <div className="space-y-8">
      {/* Escalation Policies */}
      <div>
        <div className="mb-5">
          <h2 className="text-ink text-xl mb-1">Escalation Policies</h2>
          <p className="text-ink-muted text-sm">
            Define notification chains and escalation timelines
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {policies.map((policy) => (
            <div
              key={policy.id}
              className="bg-surface-0 rounded-xl border border-edge p-6 shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)] transition-all cursor-pointer group"
              onClick={() => setSelectedPolicy(policy)}
            >
              <div className="flex items-start justify-between mb-3">
                <h4 className="text-ink font-medium">{policy.name}</h4>
                <ChevronRight className="w-5 h-5 text-ink-muted group-hover:text-brand transition-colors" />
              </div>
              <p className="text-ink-secondary text-sm">{policy.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Safety Controls */}
      <div>
        <div className="mb-5">
          <h2 className="text-ink text-xl mb-1">Safety Controls</h2>
          <p className="text-ink-muted text-sm">
            Protect your team from notification overload
          </p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge shadow-[var(--shadow-card)]">
          <div className="p-6 space-y-6">
            {/* Connected Channels */}
            <div>
              <h4 className="text-ink font-medium mb-4">Connected Channels</h4>
              <div className="space-y-3">
                {Object.entries(channels).map(([channel, info]) => (
                  <div
                    key={channel}
                    className="flex items-center justify-between p-4 bg-surface-1 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-surface-0 rounded-lg border border-edge flex items-center justify-center">
                        {info.connected && <Check className="w-5 h-5 text-success-text" />}
                      </div>
                      <div>
                        <p className="text-ink capitalize text-sm font-medium">{channel}</p>
                        <p className="text-ink-secondary text-xs">{info.workspace}</p>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 bg-success-light text-success-text rounded-full text-xs font-medium">
                      Connected
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quiet Hours */}
            <div className="pt-6 border-t border-edge">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="text-ink font-medium mb-1">Quiet Hours</h4>
                  <p className="text-ink-secondary text-sm">Suppress notifications during off hours</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={quietHoursEnabled}
                    onChange={(e) => setQuietHoursEnabled(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className={toggleCls}></div>
                </label>
              </div>

              {quietHoursEnabled && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-ink-secondary text-sm mb-2">Start Time</label>
                    <input
                      type="time"
                      value={settingsState.quietHoursStart}
                      onChange={(e) => updateSettings({ quietHoursStart: e.target.value })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-ink-secondary text-sm mb-2">End Time</label>
                    <input
                      type="time"
                      value={settingsState.quietHoursEnd}
                      onChange={(e) => updateSettings({ quietHoursEnd: e.target.value })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Throttling & Digest */}
            <div className="pt-6 border-t border-edge">
              <h4 className="text-ink font-medium mb-4">Notification Limits</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-ink-secondary text-sm mb-2">
                    Maximum notifications per day (per person)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      value={maxPerDay}
                      onChange={(e) => setMaxPerDay(e.target.value)}
                      className="w-32 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                    />
                    <span className="text-ink-secondary text-sm">notifications/day</span>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-info-light border border-info rounded-lg">
                  <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-info" />
                    <div>
                      <p className="text-ink text-sm font-medium">Batch into daily digest</p>
                      <p className="text-ink-secondary text-xs">
                        Switch to digest mode after {maxPerDay} notifications
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={digestEnabled}
                      onChange={(e) => setDigestEnabled(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className={toggleCls}></div>
                  </label>
                </div>
              </div>
            </div>

            {/* Fail-Safe Mode */}
            <div className="pt-6 border-t border-edge">
              <div className="flex items-start gap-4 p-4 bg-warning-light border border-warning rounded-lg">
                <TriangleAlert className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-ink font-medium">Fail-Safe Spike Protection</h4>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={failSafeEnabled}
                        onChange={(e) => setFailSafeEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className={toggleCls}></div>
                    </label>
                  </div>
                  <p className="text-ink-secondary text-sm mb-3">
                    Automatically switch to digest mode if high trigger volume detected
                  </p>
                  {failSafeEnabled && (
                    <div className="flex items-center gap-3">
                      <span className="text-ink-secondary text-sm">If more than</span>
                      <input
                        type="number"
                        value={failSafeThreshold}
                        onChange={(e) => setFailSafeThreshold(e.target.value)}
                        className="w-24 px-3 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      />
                      <span className="text-ink-secondary text-sm">interventions per hour &rarr; digest mode</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* STEP 6: Notification Routing */}
            <div className="pt-6 border-t border-edge">
              <h4 className="text-ink font-medium mb-4">Notification Routing</h4>
              
              {/* Slack Channel Mapping */}
              <div className="mb-5">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-ink-secondary font-medium text-sm">Slack Channel Mapping</label>
                  <button
                    onClick={() => toast('Add Mapping — TODO: Not implemented')}
                    className="text-sm text-brand hover:text-brand-hover font-medium"
                  >
                    + Add Mapping
                  </button>
                </div>
                <div className="space-y-2">
                  {notificationRoutes.map((route, i) => (
                    <div key={i} className="p-4 bg-surface-1 rounded-lg flex items-center justify-between border border-edge hover:border-brand transition-colors">
                      <div className="flex items-center gap-4 flex-1">
                        <span className="font-medium text-ink min-w-[100px]">{route.team}</span>
                        <span className="text-ink-muted">&rarr;</span>
                        <input 
                          type="text"
                          value={route.channel}
                          className="px-3 py-1.5 bg-surface-0 border border-edge rounded-lg text-sm flex-1 max-w-[200px]"
                          onChange={(e) => updateRoute(i, 'channel', e.target.value)}
                        />
                        <select className="px-3 py-1.5 bg-surface-0 border border-edge rounded-lg text-sm"
                          value={route.severity}
                          onChange={(e) => updateRoute(i, 'severity', e.target.value)}
                        >
                          <option>All</option>
                          <option>High only</option>
                          <option>Medium+</option>
                          <option>Critical only</option>
                        </select>
                      </div>
                      <button
                        onClick={() => toast('Remove mapping — TODO: Not implemented')}
                        className="text-ink-muted hover:text-danger-text ml-3"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Email Distribution Groups */}
              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-3">Email Distribution Groups</label>
                <div className="space-y-3">
                  <div className="p-4 bg-surface-1 rounded-lg border border-edge">
                    <label className="block font-medium text-ink mb-2 text-sm">Critical Escalations</label>
                    <input 
                      type="text" 
                      value={emailCritical}
                      className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg text-sm"
                      onChange={(e) => setEmailCritical(e.target.value)}
                    />
                    <p className="text-xs text-ink-muted mt-1">Comma-separated email addresses</p>
                  </div>
                  <div className="p-4 bg-surface-1 rounded-lg border border-edge">
                    <label className="block font-medium text-ink mb-2 text-sm">Standard Alerts</label>
                    <input 
                      type="text" 
                      value={emailStandard}
                      className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg text-sm"
                      onChange={(e) => setEmailStandard(e.target.value)}
                    />
                  </div>
                  <div className="p-4 bg-surface-1 rounded-lg border border-edge">
                    <label className="block font-medium text-ink mb-2 text-sm">Digest Recipients</label>
                    <input 
                      type="text" 
                      value={emailDigest}
                      className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg text-sm"
                      onChange={(e) => setEmailDigest(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* MS Teams Integration */}
              <div className="mt-5 p-4 bg-info-light border border-info rounded-lg">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm text-info font-medium mb-1">Microsoft Teams Integration</p>
                    <p className="text-xs text-info mb-2">
                      Configure Teams webhooks in Integrations section below
                    </p>
                    <button
                      onClick={() => {
                        const el = document.getElementById('integrations-section');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                        else toast('Scroll down to the Integrations section below');
                      }}
                      className="text-xs text-info hover:text-info font-medium"
                    >
                      Go to Integrations &rarr;
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Audit & Rollback */}
      <div>
        <div className="mb-5">
          <h2 className="text-ink text-xl mb-1">Audit &amp; Rollback</h2>
          <p className="text-ink-muted text-sm">
            Track changes and restore previous configurations
          </p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge shadow-[var(--shadow-card)]">
          <div className="p-6">
            {/* Recent Changes */}
            <div className="mb-6">
              <h4 className="text-ink font-medium mb-4">Recent Changes</h4>
              <div className="space-y-3">
                <div className="flex items-start gap-4 p-4 bg-surface-1 rounded-lg hover:bg-surface-2 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 bg-brand-light rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-brand" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h5 className="text-ink font-medium text-sm">Updated escalation policy &ldquo;Critical&rdquo;</h5>
                      <span className="text-ink-muted text-xs">2h ago</span>
                    </div>
                    <p className="text-ink-secondary text-xs mb-2">
                      Changed SLA timer from 24h to 48h (Level 1 &rarr; 2)
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-ink-muted">By: Sarah Chen</span>
                      <button
                        onClick={() => toast('TODO: Not implemented — would roll back escalation policy Critical SLA timer to 24h')}
                        className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-brand hover:text-brand-hover text-xs font-medium"
                      >
                        <RotateCcw className="w-3 h-3" />
                        Rollback
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-surface-1 rounded-lg hover:bg-surface-2 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 bg-info-light rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-info" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h5 className="text-ink font-medium text-sm">Enabled playbook &ldquo;Dependency Heat&rdquo;</h5>
                      <span className="text-ink-muted text-xs">1d ago</span>
                    </div>
                    <p className="text-ink-secondary text-xs mb-2">
                      Switched from Disabled to Monitor-only mode
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-ink-muted">By: Marcus Kim</span>
                      <button
                        onClick={() => toast('TODO: Not implemented — would roll back and disable playbook Dependency Heat')}
                        className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-brand hover:text-brand-hover text-xs font-medium"
                      >
                        <RotateCcw className="w-3 h-3" />
                        Rollback
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-surface-1 rounded-lg hover:bg-surface-2 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 bg-warning-light rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-warning" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h5 className="text-ink font-medium text-sm">Updated notification limits</h5>
                      <span className="text-ink-muted text-xs">2d ago</span>
                    </div>
                    <p className="text-ink-secondary text-xs mb-2">
                      Changed max per day from 20 to 15 notifications
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-ink-muted">By: Sarah Chen</span>
                      <button
                        onClick={() => {
                          setMaxPerDay('20');
                          toast.success('Rolled back: Max notifications restored to 20/day');
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 text-brand hover:text-brand-hover text-xs font-medium"
                      >
                        <RotateCcw className="w-3 h-3" />
                        Rollback
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Approval Settings */}
            <div className="pt-6 border-t border-edge">
              <div className="flex items-start gap-4 p-4 bg-info-light border border-info rounded-lg">
                <Check className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-ink font-medium">Require Approval for Org-Wide Rules</h4>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={requireApproval}
                        onChange={(e) => setRequireApproval(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className={toggleCls}></div>
                    </label>
                  </div>
                  <p className="text-ink-secondary text-sm mb-3">
                    Rules affecting &ldquo;All teams&rdquo; require COO approval before going live
                  </p>
                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-ink-secondary">Approvers:</span>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 bg-surface-0 border border-edge rounded-full text-xs">Sarah Chen (COO)</span>
                      <button
                        onClick={() => toast('Add approver — TODO: Not implemented')}
                        className="text-brand hover:text-brand-hover text-xs font-medium"
                      >+ Add</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Export & Backup */}
            <div className="pt-6 border-t border-edge mt-6">
              <h4 className="text-ink font-medium mb-4">Export &amp; Backup</h4>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    const data = JSON.stringify({
                      rules: localStorage.getItem('shiftfocus_rules'),
                      settings: localStorage.getItem('shiftfocus_settings'),
                    }, null, 2);
                    const blob = new Blob([data], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'shiftfocus-config.json';
                    a.click();
                    URL.revokeObjectURL(url);
                    toast.success('Configuration exported successfully');
                  }}
                  className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-medium"
                >
                  Export Configuration
                </button>
                <button
                  onClick={() => {
                    setAuditTarget({ type: 'all' });
                    setShowAuditLog(true);
                  }}
                  className="px-5 py-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all text-sm font-medium"
                >
                  View Full Audit Log
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Policy Editor Drawer */}
      {selectedPolicy && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div
            className="absolute inset-0 bg-black bg-opacity-25"
            onClick={() => setSelectedPolicy(null)}
          />

          <div className="absolute inset-y-0 right-0 max-w-2xl w-full bg-surface-0 shadow-[var(--shadow-elevated)] flex flex-col">
            {/* Header */}
            <div className="px-8 py-6 border-b border-edge flex items-center justify-between">
              <div>
                <h2 className="text-ink mb-1">Edit Escalation Policy</h2>
                <p className="text-ink-secondary text-sm">{selectedPolicy.name}</p>
              </div>
              <button
                onClick={() => setSelectedPolicy(null)}
                className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-ink-secondary" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto px-8 py-6 space-y-8">
              {/* Chain Editor */}
              <div>
                <label className="block text-ink font-medium mb-3">Escalation Chain</label>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-brand-light text-brand rounded-full flex items-center justify-center text-sm font-medium">
                      1
                    </div>
                    <select className="flex-1 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      value={chainStep1}
                      onChange={(e) => setChainStep1(e.target.value)}
                    >
                      <option>Owner</option>
                      <option>Manager</option>
                      <option>Exec</option>
                      <option>COO</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-brand-light text-brand rounded-full flex items-center justify-center text-sm font-medium">
                      2
                    </div>
                    <select className="flex-1 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      value={chainStep2}
                      onChange={(e) => setChainStep2(e.target.value)}
                    >
                      <option>Manager</option>
                      <option>Owner</option>
                      <option>Exec</option>
                      <option>COO</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-brand-light text-brand rounded-full flex items-center justify-center text-sm font-medium">
                      3
                    </div>
                    <select className="flex-1 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      value={chainStep3}
                      onChange={(e) => setChainStep3(e.target.value)}
                    >
                      <option>Exec</option>
                      <option>Owner</option>
                      <option>Manager</option>
                      <option>COO</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* SLA Timers */}
              <div>
                <label className="block text-ink font-medium mb-3">SLA Timers</label>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="text-ink-secondary w-32 text-sm">Level 1 &rarr; 2:</span>
                    <input
                      type="number"
                      className="w-24 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      value={slaWarning}
                      onChange={(e) => setSlaWarning(e.target.value)}
                    />
                    <span className="text-ink-secondary text-sm">hours</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-ink-secondary w-32 text-sm">Level 2 &rarr; 3:</span>
                    <input
                      type="number"
                      className="w-24 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                      value={slaEscalate}
                      onChange={(e) => setSlaEscalate(e.target.value)}
                    />
                    <span className="text-ink-secondary text-sm">hours</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-6 border-t border-edge flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedPolicy(null)}
                className="px-6 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  toast(`TODO: Not implemented — would save escalation policy "${selectedPolicy.name}"`);
                  setSelectedPolicy(null);
                }}
                className="px-6 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Integrations */}
      <div id="integrations-section">
        <div className="mb-5">
          <h2 className="text-ink text-xl mb-1">Integrations</h2>
          <p className="text-ink-muted text-sm">
            Connect external tools to create tasks and sync data
          </p>
        </div>

        <div className="bg-surface-0 rounded-xl border border-edge shadow-[var(--shadow-card)] p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {integrations.map((integration) => (
              <div
                key={integration.id}
                className="p-5 bg-surface-1 rounded-xl border border-edge hover:border-brand transition-all group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-surface-0 rounded-lg border border-edge flex items-center justify-center text-2xl">
                      {integration.logo}
                    </div>
                    <div>
                      <h4 className="text-ink font-semibold">{integration.name}</h4>
                      <p className="text-ink-secondary text-xs mt-0.5">{integration.description}</p>
                    </div>
                  </div>
                </div>

                {integration.connected ? (
                  <div className="space-y-3 mt-4">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 bg-success-light text-success-text rounded-full text-xs font-medium flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        Connected
                      </span>
                      <button
                        onClick={() => setSelectedIntegration(integration)}
                        className="text-brand hover:text-brand-hover text-xs font-medium"
                      >
                        Configure &rarr;
                      </button>
                    </div>
                    <div className="text-xs text-ink-muted">
                      <div>Workspace: {integration.workspace}</div>
                      <div>Last sync: {integration.lastSync}</div>
                    </div>
                    <button
                      onClick={() => handleDisconnect(integration.id)}
                      className="w-full px-4 py-2 border border-danger text-danger-text rounded-lg hover:bg-danger-light transition-all text-sm font-medium"
                    >
                      Disconnect
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => handleConnect(integration.id)}
                    className="w-full px-4 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-medium mt-4"
                  >
                    Connect {integration.name}
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="mt-6 pt-6 border-t border-edge">
            <div className="flex items-start gap-3 p-4 bg-info-light border border-info rounded-lg">
              <Plug className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-info font-medium mb-1">How integrations work</p>
                <p className="text-xs text-info">
                  Connected integrations allow you to create tasks in external tools directly from enforcement rules. 
                  When a rule triggers with &ldquo;Create task&rdquo; action, you can choose which tool to send it to.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Integration Config Modal */}
      {selectedIntegration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black bg-opacity-25" onClick={() => setSelectedIntegration(null)} />
          
          <div className="relative bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-2xl w-full mx-4">
            <div className="px-8 py-6 border-b border-edge flex items-center justify-between">
              <div>
                <h2 className="text-ink">Configure {selectedIntegration.name}</h2>
                <p className="text-sm text-ink-muted mt-1">Manage connection settings and preferences</p>
              </div>
              <button
                onClick={() => setSelectedIntegration(null)}
                className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-ink-secondary" />
              </button>
            </div>

            <div className="px-8 py-6 space-y-6">
              <div>
                <label className="block text-ink font-medium mb-2">Workspace/Organization</label>
                <input
                  type="text"
                  value={selectedIntegration.workspace || ''}
                  disabled
                  className="w-full px-4 py-2.5 bg-surface-1 border border-edge rounded-lg text-ink-secondary"
                />
              </div>

              <div>
                <label className="block text-ink font-medium mb-2">Default Project/Board</label>
                <select className="w-full px-4 py-2.5 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  value={integrationBoard}
                  onChange={(e) => setIntegrationBoard(e.target.value)}
                >
                  <option>Engineering - Sprint Board</option>
                  <option>Product - Roadmap</option>
                  <option>Operations - Tasks</option>
                </select>
                <p className="text-xs text-ink-muted mt-1">Tasks will be created here by default</p>
              </div>

              <div>
                <label className="block text-ink font-medium mb-2">Task Template</label>
                <textarea
                  className="w-full px-4 py-2.5 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  rows={4}
                  placeholder="[Rule Name] - Action Required&#10;&#10;Description: {{description}}&#10;Owner: {{owner}}&#10;Due: {{due_date}}"
                  value={integrationTemplate}
                  onChange={(e) => setIntegrationTemplate(e.target.value)}
                />
                <p className="text-xs text-ink-muted mt-1">Use {`{{placeholders}}`} for dynamic values</p>
              </div>

              <div className="flex items-center justify-between p-4 bg-surface-1 rounded-lg">
                <div>
                  <p className="text-sm text-ink font-medium">Auto-assign to owner</p>
                  <p className="text-xs text-ink-secondary">Automatically assign tasks to the KR/Initiative owner</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={integrationAutoAssign}
                    onChange={(e) => setIntegrationAutoAssign(e.target.checked)}
                  />
                  <div className={toggleCls}></div>
                </label>
              </div>

              <div className="pt-4 border-t border-edge">
                <div className="flex items-center gap-2 text-sm text-ink-secondary">
                  <Check className="w-4 h-4 text-success-text" />
                  <span>Connected {selectedIntegration.lastSync}</span>
                </div>
                <button
                  onClick={() => toast(`TODO: Not implemented — would test ${selectedIntegration.name} connection`)}
                  className="mt-3 text-sm text-brand hover:text-brand-hover font-medium flex items-center gap-1"
                >
                  <ExternalLink className="w-4 h-4" />
                  Test Connection
                </button>
              </div>
            </div>

            <div className="px-8 py-6 border-t border-edge flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedIntegration(null)}
                className="px-6 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  toast(`TODO: Not implemented — would save ${selectedIntegration.name} settings`);
                  setSelectedIntegration(null);
                }}
                className="px-6 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Audit Log Modal */}
      <AuditLogModal
        isOpen={showAuditLog}
        onClose={() => setShowAuditLog(false)}
        targetId={auditTarget.id}
        targetType={auditTarget.type}
        targetName={auditTarget.name}
      />
    </div>
  );
}

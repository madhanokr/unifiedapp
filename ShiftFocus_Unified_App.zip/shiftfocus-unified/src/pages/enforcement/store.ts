// ShiftFocus Enforcement Center — localStorage persistence store
// All state mutations are traceable through this single module.

export interface Rule {
  id: string;
  name: string;
  signal: string;
  action: string;
  scope: string;
  enabled: boolean;
  status: 'draft' | 'live' | 'paused';
  mode: 'monitor' | 'enforce';
  team?: string;
  severity?: string;
  lastTriggered?: string;
  triggers7d?: number;
}

export interface SettingsState {
  quietHoursEnabled: boolean;
  quietHoursStart: string;
  quietHoursEnd: string;
  maxPerDay: string;
  digestEnabled: boolean;
  failSafeEnabled: boolean;
  failSafeThreshold: string;
  briefSendTo: string;
  briefSchedule: string;
  briefIncludeDeepLinks: boolean;
  briefIncludeMetrics: boolean;
  briefHighlightRepeatOffenders: boolean;
}

const RULES_KEY = 'shiftfocus_rules';
const SETTINGS_KEY = 'shiftfocus_settings';

const DEFAULT_RULES: Rule[] = [
  {
    id: '1',
    name: 'Missed Weekly Check-in',
    signal: 'Missed check-in',
    action: 'Notify owner',
    scope: 'All teams',
    enabled: true,
    status: 'live',
    mode: 'enforce',
    team: 'Company-wide',
    severity: 'Medium',
    lastTriggered: '2h ago',
    triggers7d: 23,
  },
  {
    id: '2',
    name: 'Critical Blocker Aging',
    signal: 'Blocked SLA',
    action: 'Escalate to manager',
    scope: 'Engineering',
    enabled: true,
    status: 'live',
    mode: 'enforce',
    team: 'Engineering',
    severity: 'High',
    lastTriggered: '45m ago',
    triggers7d: 8,
  },
  {
    id: '3',
    name: 'OKR Drift Alert',
    signal: 'KR drift',
    action: 'Require update',
    scope: 'All teams',
    enabled: true,
    status: 'live',
    mode: 'monitor',
    team: 'Company-wide',
    severity: 'Medium',
    lastTriggered: '1d ago',
    triggers7d: 15,
  },
  {
    id: '4',
    name: 'New Initiative Coverage',
    signal: 'Coverage gap',
    action: 'Notify admin',
    scope: 'All teams',
    enabled: false,
    status: 'draft',
    mode: 'monitor',
    team: 'Company-wide',
    severity: 'Low',
    lastTriggered: 'Never',
    triggers7d: 0,
  },
  {
    id: '5',
    name: 'Dependency Risk Escalation',
    signal: 'Dependency heat',
    action: 'Escalate to COO',
    scope: 'Engineering',
    enabled: true,
    status: 'paused',
    mode: 'enforce',
    team: 'Engineering',
    severity: 'High',
    lastTriggered: '3d ago',
    triggers7d: 2,
  },
];

const DEFAULT_SETTINGS: SettingsState = {
  quietHoursEnabled: true,
  quietHoursStart: '20:00',
  quietHoursEnd: '08:00',
  maxPerDay: '15',
  digestEnabled: true,
  failSafeEnabled: true,
  failSafeThreshold: '20',
  briefSendTo: 'coo@company.com, ceo@company.com',
  briefSchedule: 'Every Monday at 8:00 AM',
  briefIncludeDeepLinks: true,
  briefIncludeMetrics: true,
  briefHighlightRepeatOffenders: true,
};

// --- Rules CRUD ---

export function loadRules(): Rule[] {
  try {
    const stored = localStorage.getItem(RULES_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as Rule[];
      // Migrate legacy team: 'All' → 'Company-wide' (BUG 3 fix)
      let migrated = false;
      const rules = parsed.map(r => {
        if (r.team === 'All') {
          migrated = true;
          return { ...r, team: 'Company-wide' };
        }
        return r;
      });
      if (migrated) saveRules(rules);
      return rules;
    }
  } catch {
    // corrupt data — reset
  }
  // Seed defaults on first run
  localStorage.setItem(RULES_KEY, JSON.stringify(DEFAULT_RULES));
  return DEFAULT_RULES;
}

export function saveRules(rules: Rule[]): void {
  localStorage.setItem(RULES_KEY, JSON.stringify(rules));
}

export function addRule(rules: Rule[], newRule: Omit<Rule, 'id'>): Rule[] {
  const rule: Rule = { ...newRule, id: Date.now().toString() };
  const updated = [...rules, rule];
  saveRules(updated);
  return updated;
}

export function updateRule(rules: Rule[], ruleId: string, patch: Partial<Rule>): Rule[] {
  const updated = rules.map(r => r.id === ruleId ? { ...r, ...patch } : r);
  saveRules(updated);
  return updated;
}

export function deleteRule(rules: Rule[], ruleId: string): Rule[] {
  const updated = rules.filter(r => r.id !== ruleId);
  saveRules(updated);
  return updated;
}

export function duplicateRule(rules: Rule[], ruleId: string): Rule[] {
  const original = rules.find(r => r.id === ruleId);
  if (!original) return rules;
  const copy: Rule = {
    ...original,
    id: Date.now().toString(),
    name: `${original.name} (Copy)`,
    status: 'draft',
    lastTriggered: 'Never',
    triggers7d: 0,
  };
  const updated = [...rules, copy];
  saveRules(updated);
  return updated;
}

// --- Settings CRUD ---

export function loadSettings(): SettingsState {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    }
  } catch {
    // corrupt data — reset
  }
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS));
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: SettingsState): void {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

// --- Playbooks Persistence ---

export interface PlaybookState {
  id: string;
  enabled: boolean;
  mode: 'monitor' | 'enforce';
  scope: string;
  channels: { slack: boolean; teams: boolean; email: boolean };
  threshold: string;
  primaryOwner: string;
  backupOwner: string;
  escalationPolicy: string;
  quietHoursStart: string;
  quietHoursEnd: string;
  maxNotifications: string;
  exceptions: { excludeExec: boolean; excludeLaunchWeek: boolean; excludeWeekends: boolean };
}

const PLAYBOOKS_KEY = 'shiftfocus_playbooks';

export function loadPlaybookStates(): PlaybookState[] | null {
  try {
    const stored = localStorage.getItem(PLAYBOOKS_KEY);
    if (stored) return JSON.parse(stored) as PlaybookState[];
  } catch { /* corrupt data */ }
  return null;
}

export function savePlaybookStates(states: PlaybookState[]): void {
  localStorage.setItem(PLAYBOOKS_KEY, JSON.stringify(states));
}

// --- Integration Persistence ---

export interface IntegrationState {
  id: string;
  connected: boolean;
}

const INTEGRATIONS_KEY = 'shiftfocus_integrations';

export function loadIntegrationStates(): IntegrationState[] | null {
  try {
    const stored = localStorage.getItem(INTEGRATIONS_KEY);
    if (stored) return JSON.parse(stored) as IntegrationState[];
  } catch { /* corrupt data */ }
  return null;
}

export function saveIntegrationStates(states: IntegrationState[]): void {
  localStorage.setItem(INTEGRATIONS_KEY, JSON.stringify(states));
}

// --- Escalation Policy Persistence ---

export interface EscalationPolicyState {
  id: string;
  name: string;
  steps: Array<{
    id: string;
    delay: string;
    delayUnit: string;
    actions: string[];
    channels: string[];
    requireAck: boolean;
    ackTimeout: number;
  }>;
  quietHours: string;
  autoResolve: boolean;
}

const ESCALATION_POLICIES_KEY = 'shiftfocus_escalation_policies';

export function loadEscalationPolicies(): EscalationPolicyState[] | null {
  try {
    const stored = localStorage.getItem(ESCALATION_POLICIES_KEY);
    if (stored) return JSON.parse(stored) as EscalationPolicyState[];
  } catch { /* corrupt data */ }
  return null;
}

export function saveEscalationPolicies(policies: EscalationPolicyState[]): void {
  localStorage.setItem(ESCALATION_POLICIES_KEY, JSON.stringify(policies));
}

// --- Evidence Resolution Persistence ---

export interface EvidenceResolution {
  incidentId: string;
  type: string;
  note: string;
  proof: string;
  resolvedAt: string;
}

const EVIDENCE_RESOLUTIONS_KEY = 'shiftfocus_evidence_resolutions';

export function loadEvidenceResolutions(): EvidenceResolution[] {
  try {
    const stored = localStorage.getItem(EVIDENCE_RESOLUTIONS_KEY);
    if (stored) return JSON.parse(stored) as EvidenceResolution[];
  } catch { /* corrupt data */ }
  return [];
}

export function saveEvidenceResolution(resolution: EvidenceResolution): EvidenceResolution[] {
  const existing = loadEvidenceResolutions();
  const updated = [...existing.filter(r => r.incidentId !== resolution.incidentId), resolution];
  localStorage.setItem(EVIDENCE_RESOLUTIONS_KEY, JSON.stringify(updated));
  return updated;
}

// --- Settings: Notification Routing Persistence ---

export interface NotificationRoute {
  signal: string;
  channel: string;
  severity: string;
}

export interface EscalationChainStep {
  level: number;
  target: string;
  slaHours: string;
}

export interface SettingsExtended extends SettingsState {
  notificationRoutes: NotificationRoute[];
  escalationChain: EscalationChainStep[];
  escalationSlaWarning: string;
  escalationSlaEscalate: string;
  autoDigestEnabled: boolean;
  integrationTemplateEnabled: boolean;
  integrationDefaultBoard: string;
  integrationNotificationTemplate: string;
}

const SETTINGS_EXT_KEY = 'shiftfocus_settings_extended';

const DEFAULT_NOTIFICATION_ROUTES: NotificationRoute[] = [
  { signal: 'Missed check-in', channel: '#ops-enforcement', severity: 'Medium' },
  { signal: 'Blocked SLA', channel: '#eng-alerts', severity: 'High' },
  { signal: 'KR drift', channel: '#leadership', severity: 'Medium' },
];

const DEFAULT_SETTINGS_EXT: SettingsExtended = {
  ...({} as SettingsState), // will be merged with base settings at load
  notificationRoutes: DEFAULT_NOTIFICATION_ROUTES,
  escalationChain: [
    { level: 1, target: 'Owner', slaHours: '48' },
    { level: 2, target: 'Manager', slaHours: '96' },
    { level: 3, target: 'Exec', slaHours: '' },
  ],
  escalationSlaWarning: '48',
  escalationSlaEscalate: '96',
  autoDigestEnabled: true,
  integrationTemplateEnabled: true,
  integrationDefaultBoard: 'Engineering - Sprint Board',
  integrationNotificationTemplate: '[Rule Name] - Action Required\n\nDescription: {{description}}\nOwner: {{owner}}\nDue: {{due_date}}',
  // base settings fields (will be overridden by loadSettings merge)
  quietHoursEnabled: true,
  quietHoursStart: '20:00',
  quietHoursEnd: '08:00',
  maxPerDay: '15',
  digestEnabled: true,
  failSafeEnabled: true,
  failSafeThreshold: '20',
  briefSendTo: 'coo@company.com, ceo@company.com',
  briefSchedule: 'Every Monday at 8:00 AM',
  briefIncludeDeepLinks: true,
  briefIncludeMetrics: true,
  briefHighlightRepeatOffenders: true,
};

export function loadSettingsExtended(): SettingsExtended {
  try {
    const stored = localStorage.getItem(SETTINGS_EXT_KEY);
    if (stored) {
      return { ...DEFAULT_SETTINGS_EXT, ...JSON.parse(stored) };
    }
  } catch { /* corrupt data */ }
  return DEFAULT_SETTINGS_EXT;
}

export function saveSettingsExtended(settings: SettingsExtended): void {
  localStorage.setItem(SETTINGS_EXT_KEY, JSON.stringify(settings));
}
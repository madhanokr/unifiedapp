import { ArrowRight, TrendingUp, AlertTriangle, CheckCircle2, Clock, Users, Info } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { TrustScoreChip } from './TrustScoreChip';
import { EvidenceTimeline } from './EvidenceTimeline';
import { loadSettings, saveSettings, loadRules } from './store';
import type { Rule } from './store';

interface Risk {
  id: string;
  title: string;
  owner: string;
  status: string;
  risk: string;
  why: string;
  action: string;
  deepLink?: string;
  trustScore?: number;
  trustTrend?: number;
}

export function ExecutiveWeeklyBrief() {
  const navigate = useNavigate();
  const [selectedRisk, setSelectedRisk] = useState<Risk | null>(null);
  const [showCalculation, setShowCalculation] = useState<string | null>(null);
  const [showProofDialog, setShowProofDialog] = useState(false);
  const [proofType, setProofType] = useState('');
  const [proofNote, setProofNote] = useState('');
  const [proofLink, setProofLink] = useState('');
  const [showEvidenceTimeline, setShowEvidenceTimeline] = useState(false);
  const [evidenceRisk, setEvidenceRisk] = useState<Risk | null>(null);

  // Brief config — loaded from store.ts
  const [settings] = useState(() => loadSettings());
  const [briefSendTo, setBriefSendTo] = useState(settings.briefSendTo);
  const [briefSchedule, setBriefSchedule] = useState(settings.briefSchedule);
  const [briefIncludeDeepLinks, setBriefIncludeDeepLinks] = useState(settings.briefIncludeDeepLinks);
  const [briefIncludeMetrics, setBriefIncludeMetrics] = useState(settings.briefIncludeMetrics);
  const [briefHighlightRepeatOffenders, setBriefHighlightRepeatOffenders] = useState(settings.briefHighlightRepeatOffenders);

  // Load rules from store for dynamic summary
  const [rules, setRules] = useState<Rule[]>(() => loadRules());
  useEffect(() => {
    const reload = () => setRules(loadRules());
    window.addEventListener('rules-updated', reload);
    return () => window.removeEventListener('rules-updated', reload);
  }, []);

  const risks: Risk[] = [
    { id: 'r1', title: 'Q1 Pipeline KR blocked for 6 days', owner: 'Marcus Kim (Sales)', status: 'Escalated', risk: 'High', why: 'Critical dependency on Marketing delayed. Revenue impact: $2.3M at risk.', action: 'Fix Now', deepLink: 'rules-blocked-sla', trustScore: 85, trustTrend: -5 },
    { id: 'r2', title: '3 Engineering KRs missed weekly update', owner: 'Engineering Team', status: 'Notified', risk: 'Medium', why: 'Stale progress data prevents accurate forecasting. Confidence dropped 15%.', action: 'View Details', deepLink: 'rules-weekly-reality' },
    { id: 'r3', title: 'Cross-team dependency slip (Design → Product)', owner: 'Alex Rivera (Design)', status: 'In Progress', risk: 'Medium', why: 'Upstream delay affects 2 downstream initiatives. 12-day cascading risk.', action: 'View Details', deepLink: 'rules-dependency-heat' },
    { id: 'r4', title: 'Capacity overload: Engineering at 92%', owner: 'Engineering Team', status: 'Warning Sent', risk: 'Low', why: 'WIP limits breached. Burnout risk flagged by Capacity Guardrail policy.', action: 'View Details', deepLink: 'rules-capacity-guardrail' },
    { id: 'r5', title: '2 orphaned tasks (no owner, no KR link)', owner: 'Multiple teams', status: 'Fixed', risk: 'Low', why: 'Work items not linked to outcomes. "No Orphans" policy caught and fixed.', action: 'Resolved ✓', deepLink: 'rules-no-orphans' },
  ];

  const handleRiskAction = (risk: Risk) => {
    if (risk.status === 'Escalated') {
      setSelectedRisk(risk);
    } else if (risk.status !== 'Fixed') {
      const deepLinkRoutes: Record<string, string> = {
        'rules-blocked-sla': '/evidence/INC-2401',
        'rules-weekly-reality': '/operating-policies',
        'rules-dependency-heat': '/evidence/INC-2395',
        'rules-capacity-guardrail': '/escalation-policies',
        'rules-no-orphans': '/evidence/INC-2392',
      };
      const route = risk.deepLink ? deepLinkRoutes[risk.deepLink] : null;
      if (route) { navigate(route); toast.success(`Navigating to ${risk.deepLink}`); }
      else { toast(`Deep link not configured: ${risk.deepLink}`); }
    }
  };

  const interventionsBreakdown = [
    { policy: 'Blocked SLA', count: 8, description: 'blocked tasks unblocked', timeSaved: 1.8 },
    { policy: 'Weekly Reality', count: 6, description: 'stale KRs updated', timeSaved: 1.2 },
    { policy: 'No Orphans', count: 5, description: 'missing owners assigned', timeSaved: 0.3 },
    { policy: 'Capacity Guardrail', count: 4, description: 'capacity warnings resolved', timeSaved: 0.5 },
  ];

  const totalInterventions = interventionsBreakdown.reduce((sum, item) => sum + item.count, 0);
  const totalTimeSaved = interventionsBreakdown.reduce((sum, item) => sum + (item.count * item.timeSaved), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-ink">Executive Weekly Brief</h2>
          <span className="px-3 py-1 bg-brand-light text-brand rounded-full text-sm font-medium">
            Next: Monday 8:00 AM
          </span>
        </div>
        <p className="text-ink-secondary text-sm">
          Automated weekly execution summary sent to COO/CEO every Monday morning
        </p>
      </div>

      {/* Preview Card */}
      <div className="bg-gradient-to-br from-brand-light via-surface-0 to-info-light rounded-xl border-2 border-brand p-8 shadow-[var(--shadow-card-hover)]">
        {/* Email Header Simulation */}
        <div className="mb-6 pb-6 border-b border-edge">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-xs text-ink-muted uppercase tracking-wide mb-1">From: ShiftFocus Enforcement Center</p>
              <h3 className="text-ink text-xl font-semibold">Weekly Execution Brief — Week of Dec 16</h3>
            </div>
            <img src="data:image/svg+xml,%3Csvg width='48' height='48' viewBox='0 0 48 48' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Crect width='48' height='48' rx='12' fill='%237C3AED'/%3E%3Cpath d='M24 14L30 20L24 26M18 26L24 20L18 14' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E" alt="ShiftFocus" className="w-12 h-12" />
          </div>
          <p className="text-ink-secondary text-sm">Good morning Sarah — {rules.length} rules monitored {rules.reduce((s, r) => s + (r.triggers7d || 0), 0)} signals this week. Here's what enforcement caught.</p>
        </div>

        {/* Section 1: Top 5 Risks */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-warning" />
            <h4 className="text-ink font-semibold">Top 5 Risks This Week</h4>
          </div>
          <div className="space-y-3">
            {risks.map((risk, i) => (
              <div key={i} className={`p-4 bg-surface-0 rounded-lg border-2 ${
                risk.status === 'Escalated' ? 'border-danger' : 
                risk.status === 'Fixed' ? 'border-success' : 'border-edge'
              }`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h5 className="text-ink font-semibold text-sm">{i + 1}. {risk.title}</h5>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                        risk.risk === 'High' ? 'bg-danger-light text-danger-text' :
                        risk.risk === 'Medium' ? 'bg-warning-light text-warning' :
                        'bg-surface-2 text-ink-secondary'
                      }`}>
                        {risk.risk}
                      </span>
                    </div>
                    <p className="text-ink-secondary text-xs mb-1">{risk.owner}</p>
                    <p className="text-ink-secondary text-xs leading-relaxed">{risk.why}</p>
                    {risk.trustScore !== undefined && (
                      <div className="mt-2">
                        <TrustScoreChip score={risk.trustScore} trend={risk.trustTrend} />
                      </div>
                    )}
                  </div>
                  <div className="ml-4 flex flex-col gap-2">
                    <button className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                      risk.status === 'Escalated' ? 'bg-danger text-[var(--white)] hover:bg-danger-text' :
                      risk.status === 'Fixed' ? 'bg-success text-[var(--white)]' :
                      'bg-brand text-[var(--white)] hover:bg-brand-hover'
                    }`} onClick={() => handleRiskAction(risk)}>
                      {risk.action}
                    </button>
                    <button 
                      onClick={() => { setEvidenceRisk(risk); setShowEvidenceTimeline(true); }}
                      className="px-3 py-1.5 bg-surface-2 text-ink-secondary hover:bg-edge rounded-lg text-xs font-medium whitespace-nowrap border border-edge"
                    >
                      View Evidence
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section 2: What Was Fixed */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-5 h-5 text-success-text" />
            <h4 className="text-ink font-semibold">What Was Fixed Last Week</h4>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {/* Interventions Resolved */}
            <div className="p-4 bg-success-light rounded-lg border border-success relative cursor-help"
              onMouseEnter={() => setShowCalculation('interventions')} onMouseLeave={() => setShowCalculation(null)}>
              <div className="flex items-center justify-between mb-1">
                <div className="text-3xl font-bold text-success-text">{totalInterventions}</div>
                <Info className="w-4 h-4 text-success-text" />
              </div>
              <p className="text-success-text text-sm font-medium">Interventions Resolved</p>
              <p className="text-success-text text-xs mt-1">↑ 12% vs. last week</p>
              {showCalculation === 'interventions' && (
                <div className="absolute top-full left-0 mt-2 z-10 bg-ink text-[var(--white)] p-3 rounded-lg shadow-[var(--shadow-elevated)] w-72">
                  <p className="text-xs font-semibold mb-2">Breakdown by Policy:</p>
                  {interventionsBreakdown.map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-xs mb-1"><span>• {item.policy}:</span><span className="font-semibold">{item.count} {item.description}</span></div>
                  ))}
                  <div className="border-t border-[rgba(255,255,255,0.2)] mt-2 pt-2">
                    <div className="flex items-center justify-between text-xs font-bold"><span>Total:</span><span>{totalInterventions} interventions</span></div>
                  </div>
                </div>
              )}
            </div>

            {/* Time Saved */}
            <div className="p-4 bg-info-light rounded-lg border border-info relative cursor-help"
              onMouseEnter={() => setShowCalculation('time')} onMouseLeave={() => setShowCalculation(null)}>
              <div className="flex items-center justify-between mb-1">
                <div className="text-3xl font-bold text-info">{totalTimeSaved.toFixed(1)}h</div>
                <Info className="w-4 h-4 text-info" />
              </div>
              <p className="text-info text-sm font-medium">Fire Drills Prevented</p>
              <p className="text-info text-xs mt-1">Time saved across teams</p>
              {showCalculation === 'time' && (
                <div className="absolute top-full left-0 mt-2 z-10 bg-ink text-[var(--white)] p-3 rounded-lg shadow-[var(--shadow-elevated)] w-80">
                  <p className="text-xs font-semibold mb-2">Time Saved Calculation:</p>
                  {interventionsBreakdown.map((item, i) => (
                    <div key={i} className="text-xs mb-1.5">
                      <div className="flex items-center justify-between"><span className="font-medium">{item.policy}:</span><span>{item.count} × {item.timeSaved}h = {(item.count * item.timeSaved).toFixed(1)}h</span></div>
                      <div className="text-[rgba(255,255,255,0.6)] text-xs ml-2">({item.count} {item.description})</div>
                    </div>
                  ))}
                  <div className="border-t border-[rgba(255,255,255,0.2)] mt-2 pt-2">
                    <div className="flex items-center justify-between text-xs font-bold"><span>Total Time Saved:</span><span>{totalTimeSaved.toFixed(1)} hours</span></div>
                  </div>
                  <p className="text-[rgba(255,255,255,0.6)] text-xs mt-2 italic">Average time per intervention type based on historical resolution data</p>
                </div>
              )}
            </div>

            <div className="p-4 bg-brand-light rounded-lg border border-brand">
              <div className="text-3xl font-bold text-brand mb-1">94%</div>
              <p className="text-brand-active text-sm font-medium">Owner Response Rate</p>
              <p className="text-brand text-xs mt-1">Within 24h of notification</p>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-surface-1 rounded-lg">
            <p className="text-ink-secondary text-sm">
              <strong>Notable fixes:</strong> "Blocked SLA" policy unblocked 8 critical tasks. 
              "Weekly Reality" policy caught 6 stale KRs before they became risks.
            </p>
          </div>
        </div>

        {/* Section 3: Who's Repeatedly Ignoring */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-warning" />
            <h4 className="text-ink font-semibold">Who's Repeatedly Ignoring</h4>
          </div>
          <div className="space-y-2">
            {[
              { name: 'Jordan Lee (Product)', ignored: 3, policy: 'Weekly Reality', since: '2 weeks' },
              { name: 'Sam Chen (Engineering)', ignored: 2, policy: 'Blocked SLA', since: '1 week' },
            ].map((person, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-warning-light border border-warning rounded-lg">
                <div>
                  <p className="text-ink font-medium text-sm">{person.name}</p>
                  <p className="text-ink-secondary text-xs">
                    Ignored <strong>{person.ignored} notifications</strong> from "{person.policy}" policy ({person.since})
                  </p>
                </div>
                <button onClick={() => toast(`TODO: Not implemented — would escalate ${person.name} and notify their manager`)} className="px-3 py-1.5 bg-warning text-[var(--white)] rounded-lg hover:bg-warning text-xs font-medium">
                  Escalate
                </button>
              </div>
            ))}
          </div>
          <p className="text-ink-secondary text-xs mt-2">
            <strong>Recommendation:</strong> Consider 1:1 check-in with Jordan Lee to understand blockers.
          </p>
        </div>

        {/* What You Didn't See (Addiction Engine) */}
        <div className="mb-6 p-6 bg-gradient-to-br from-success-light via-success-light to-on-track-light border-2 border-success rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-6 h-6 text-success-text" />
            <h4 className="text-ink font-semibold text-lg">What You Didn't See This Week</h4>
          </div>
          <p className="text-success-text text-sm mb-4 leading-relaxed">
            These fires were prevented <strong>before</strong> they reached your attention. 
            ShiftFocus caught and resolved them silently.
          </p>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-success">
              <div className="text-4xl font-bold text-success-text mb-1">14</div>
              <p className="text-success-text text-sm font-medium">Fires Prevented</p>
              <p className="text-success-text text-xs">Before escalation needed</p>
            </div>
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-info">
              <div className="text-4xl font-bold text-info mb-1">19</div>
              <p className="text-info text-sm font-medium">Risks Auto-Resolved</p>
              <p className="text-info text-xs">Owner responded quickly</p>
            </div>
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-brand">
              <div className="text-4xl font-bold text-brand mb-1">6.3h</div>
              <p className="text-brand-active text-sm font-medium">Exec Time Saved</p>
              <p className="text-brand text-xs">Decisions you didn't make</p>
            </div>
          </div>
          <div className="space-y-2">
            <p className="text-ink-secondary font-semibold text-sm mb-2">Top 3 Silent Saves:</p>
            {[
              { title: 'Sales KR drift caught early', desc: 'Prevented 12-day slip • Owner: Marcus Kim' },
              { title: 'Dependency heat escalated before sprint', desc: 'Avoided 2-week cascading delay • Team: Engineering' },
              { title: 'Orphan tasks auto-fixed', desc: 'Prevented scope leak • 8 tasks assigned owners' },
            ].map((save, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-surface-0 rounded-lg border border-success">
                <div className="w-6 h-6 bg-success-light rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-success-text text-xs font-bold">{idx + 1}</span>
                </div>
                <div>
                  <p className="text-ink font-medium text-sm">{save.title}</p>
                  <p className="text-ink-secondary text-xs">{save.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-gradient-to-r from-success-light to-success-light border border-success rounded-lg">
            <p className="text-success-text text-xs font-semibold">
              💡 Why this matters: You weren't surprised this week. That's not luck — that's governance.
            </p>
          </div>
        </div>

        {/* Section 4: Policy Performance */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-success-text" />
            <h4 className="text-ink font-semibold">What Policies Are Working</h4>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { name: 'Blocked SLA', success: 87, fires: 12, avg: '2.1 days faster' },
              { name: 'Weekly Reality', success: 92, fires: 9, avg: '15% better update rate' },
              { name: 'No Orphans', success: 78, fires: 18, avg: '100% ownership coverage' },
              { name: 'Capacity Guardrail', success: 95, fires: 3, avg: 'Prevented 2 burnout risks' },
            ].map((policy, i) => (
              <div key={i} className="p-3 bg-surface-0 rounded-lg border border-edge">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-ink font-medium text-sm">{policy.name}</p>
                  <span className="px-2 py-0.5 bg-success-light text-success-text rounded-full text-xs font-semibold">
                    {policy.success}%
                  </span>
                </div>
                <div className="text-xs text-ink-secondary space-y-0.5">
                  <p>• Fired {policy.fires}x this week</p>
                  <p>• Impact: {policy.avg}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer CTA */}
        <div className="mt-8 pt-6 border-t border-edge">
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-brand to-info rounded-lg text-[var(--white)]">
            <div>
              <p className="font-semibold mb-1">Review Full Dashboard</p>
              <p className="text-[rgba(255,255,255,0.8)] text-sm">Deep dive into enforcement metrics and trends</p>
            </div>
            <button onClick={() => navigate('/overview')} className="flex items-center gap-2 px-5 py-2.5 bg-surface-0 text-brand rounded-lg hover:bg-brand-light transition-colors font-semibold">
              Open ShiftFocus
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Configuration */}
      <div className="bg-surface-0 rounded-xl border border-edge p-6">
        <h4 className="text-ink font-semibold mb-4">Brief Configuration</h4>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-ink-secondary font-medium text-sm mb-2">Send To</label>
              <input type="text" value={briefSendTo} onChange={(e) => setBriefSendTo(e.target.value)}
                className="w-full px-4 py-2.5 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand" />
            </div>
            <div>
              <label className="block text-ink-secondary font-medium text-sm mb-2">Schedule</label>
              <select value={briefSchedule} onChange={(e) => setBriefSchedule(e.target.value)}
                className="w-full px-4 py-2.5 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand">
                <option>Every Monday at 8:00 AM</option>
                <option>Every Monday at 9:00 AM</option>
                <option>Every Friday at 5:00 PM</option>
              </select>
            </div>
          </div>
          {[
            { state: briefIncludeDeepLinks, setter: setBriefIncludeDeepLinks, label: 'Include deep links to Fix Now actions' },
            { state: briefIncludeMetrics, setter: setBriefIncludeMetrics, label: 'Include policy performance metrics' },
            { state: briefHighlightRepeatOffenders, setter: setBriefHighlightRepeatOffenders, label: 'Highlight repeat offenders for escalation' },
          ].map(opt => (
            <div key={opt.label}>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={opt.state} onChange={(e) => opt.setter(e.target.checked)} className="w-5 h-5 text-brand border-edge rounded" />
                <span className="text-ink-secondary text-sm">{opt.label}</span>
              </label>
            </div>
          ))}
        </div>
        <div className="mt-6 flex items-center justify-between">
          <button onClick={() => toast('TODO: Not implemented — would send test email to recipients')} className="text-brand hover:text-brand-hover font-medium text-sm">
            Send Test Email
          </button>
          <button onClick={() => {
            const currentSettings = loadSettings();
            saveSettings({ ...currentSettings, briefSendTo, briefSchedule, briefIncludeDeepLinks, briefIncludeMetrics, briefHighlightRepeatOffenders });
            toast.success('Brief settings saved');
          }} className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium">
            Save Settings
          </button>
        </div>
      </div>

      {/* Impact Statement */}
      <div className="p-5 bg-gradient-to-r from-success-light to-info-light border-2 border-success rounded-xl">
        <div className="flex items-start gap-3">
          <Clock className="w-6 h-6 text-success-text flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-success-text font-semibold mb-2">Why this creates obsession:</p>
            <p className="text-success-text text-sm leading-relaxed">
              Every Monday at 8 AM, your exec team gets a <strong>reality-based brief</strong> — not opinions, not manual reports. 
              They see exactly what broke, what got fixed, and who needs help. Deep links let them act in seconds.
              <br /><br />
              <strong>Result:</strong> ShiftFocus becomes the <span className="underline">weekly operating cadence</span>. 
              They won't churn because this brief is now how they run the company.
            </p>
          </div>
        </div>
      </div>

      {/* Board Summary Generator (Counterfactual Narrative) */}
      <div className="bg-surface-0 rounded-xl border-2 border-brand p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-ink font-semibold mb-1">Board Summary Generator</h4>
            <p className="text-ink-secondary text-sm">Counterfactual narrative for leadership and investors</p>
          </div>
          <button onClick={() => toast('TODO: Not implemented — would generate board summary with counterfactual analysis')} className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium shadow-[var(--shadow-card)] flex items-center gap-2">
            <ArrowRight className="w-4 h-4" />
            Generate Board Summary
          </button>
        </div>

        {/* Generated Summary Preview */}
        <div className="p-6 bg-gradient-to-br from-surface-1 to-surface-1 border-2 border-edge rounded-xl">
          <div className="mb-4 pb-4 border-b border-edge">
            <p className="text-ink-muted text-xs uppercase tracking-wide mb-1">Counterfactual Analysis</p>
            <h5 className="text-ink font-bold text-lg">If ShiftFocus Policies Were Active Last 30 Days</h5>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-3 gap-4 mb-5">
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-brand">
              <div className="text-3xl font-bold text-brand mb-1">37</div>
              <p className="text-ink text-sm font-medium">Risks Surfaced Earlier</p>
              <p className="text-ink-secondary text-xs mt-1">Avg 8.3 days sooner</p>
            </div>
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-success">
              <div className="text-3xl font-bold text-success-text mb-1">11</div>
              <p className="text-ink text-sm font-medium">Exec Escalations Avoided</p>
              <p className="text-ink-secondary text-xs mt-1">Auto-resolved at team level</p>
            </div>
            <div className="p-4 bg-surface-0 rounded-lg border-2 border-info">
              <div className="text-3xl font-bold text-info mb-1">+18%</div>
              <p className="text-ink text-sm font-medium">Delivery Probability Uplift</p>
              <p className="text-ink-secondary text-xs mt-1">Based on risk reduction</p>
            </div>
          </div>

          {/* Biggest Root Causes */}
          <div className="mb-5">
            <p className="text-ink font-semibold text-sm mb-3">Biggest Root Causes Prevented:</p>
            <div className="space-y-2">
              {[
                { num: '1', bg: 'bg-danger-light', text: 'text-danger-text', title: 'Stale progress updates', desc: '14 occurrences → would trigger "Weekly Reality" policy', badge: 'High Impact', badgeBg: 'bg-danger-light text-danger-text' },
                { num: '2', bg: 'bg-warning-light', text: 'text-warning', title: 'Blocked work aging silently', desc: '9 occurrences → would trigger "Blocked SLA" policy', badge: 'Medium Impact', badgeBg: 'bg-warning-light text-warning' },
                { num: '3', bg: 'bg-warning-light', text: 'text-warning', title: 'Missing ownership clarity', desc: '7 occurrences → would trigger "No Orphans" policy', badge: 'Medium Impact', badgeBg: 'bg-warning-light text-warning' },
              ].map(cause => (
                <div key={cause.num} className="flex items-center justify-between p-3 bg-surface-0 rounded-lg border border-edge">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 ${cause.bg} rounded-full flex items-center justify-center`}>
                      <span className={`${cause.text} text-xs font-bold`}>{cause.num}</span>
                    </div>
                    <div>
                      <p className="text-ink font-medium text-sm">{cause.title}</p>
                      <p className="text-ink-secondary text-xs">{cause.desc}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 ${cause.badgeBg} rounded text-xs font-semibold`}>{cause.badge}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Top Policy ROI */}
          <div className="mb-4">
            <p className="text-ink font-semibold text-sm mb-3">Top Policy ROI (Last 30 Days):</p>
            <div className="grid grid-cols-2 gap-3">
              {[
                { name: 'Blocked SLA', roi: '8.2h', desc: 'Would have unblocked 34 tasks, avg 2.1 days faster' },
                { name: 'Weekly Reality', roi: '5.1h', desc: 'Would have prevented 14 stale updates, avg 3.7 days lag' },
                { name: 'No Orphans', roi: '2.8h', desc: 'Would have assigned 22 orphaned tasks immediately' },
                { name: 'Capacity Guardrail', roi: '4.2h', desc: 'Would have prevented 3 overload situations, 5 burnout risks' },
              ].map(p => (
                <div key={p.name} className="p-3 bg-surface-0 rounded-lg border border-edge">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-ink font-medium text-sm">{p.name}</p>
                    <span className="px-2 py-0.5 bg-success-light text-success-text rounded-full text-xs font-semibold">ROI: {p.roi}</span>
                  </div>
                  <p className="text-ink-secondary text-xs">{p.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Estimated Impact */}
          <div className="p-4 bg-gradient-to-r from-brand-light to-info-light border-2 border-brand rounded-lg">
            <p className="text-brand-active font-semibold text-sm mb-2">📊 Estimated 30-Day Impact</p>
            <div className="grid grid-cols-2 gap-3 text-xs text-brand-active">
              <div>
                <p>• <strong>$4.2M</strong> revenue risk surfaced earlier</p>
                <p>• <strong>20.3 hours</strong> executive time saved</p>
                <p>• <strong>37 issues</strong> prevented from escalating</p>
              </div>
              <div>
                <p>• <strong>18% higher</strong> delivery probability</p>
                <p>• <strong>11 fewer</strong> reactive fire drills</p>
                <p>• <strong>100%</strong> ownership coverage maintained</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <p className="text-ink-secondary text-xs">
            <strong>Note:</strong> Counterfactual analysis based on historical execution data and policy simulation.
          </p>
          <button onClick={() => toast('TODO: Not implemented — would export board summary to PDF')} className="text-brand hover:text-brand-hover font-medium text-sm flex items-center gap-1">
            Export to PDF
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Fix Now Modal */}
      {selectedRisk && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-edge bg-danger-light">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-6 h-6 text-danger-text" />
                    <h3 className="text-ink font-semibold text-lg">Fix Now: Critical Risk</h3>
                  </div>
                  <h4 className="text-ink font-bold mb-1">{selectedRisk.title}</h4>
                  <p className="text-ink-secondary text-sm">{selectedRisk.owner}</p>
                </div>
                <button onClick={() => setSelectedRisk(null)} className="text-ink-muted hover:text-ink-secondary text-2xl leading-none">×</button>
              </div>
            </div>
            <div className="p-6 space-y-5">
              <div className="p-3 bg-surface-1 border border-edge rounded-lg">
                <p className="text-ink-secondary font-medium text-xs mb-1">Accountable Chain:</p>
                <p className="text-ink text-sm">Marcus Kim <span className="text-ink-muted">→</span> Sarah Chen (Manager) <span className="text-ink-muted">→</span> COO</p>
              </div>
              {selectedRisk.trustScore !== undefined && (
                <div className="p-4 bg-gradient-to-br from-info-light to-brand-light border-2 border-info rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-ink font-semibold text-sm">Owner Reliability</p>
                    <TrustScoreChip score={selectedRisk.trustScore} trend={selectedRisk.trustTrend} size="medium" />
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between"><span className="text-ink-secondary">Response rate (24h / 48h):</span><span className="text-ink font-semibold">87% / 94%</span></div>
                    <div className="flex items-center justify-between"><span className="text-ink-secondary">SLA breaches (30d):</span><span className="text-warning font-semibold">3</span></div>
                    <div className="flex items-center justify-between"><span className="text-ink-secondary">Escalations caused (30d):</span><span className="text-warning font-semibold">2</span></div>
                    <div className="flex items-center justify-between"><span className="text-ink-secondary">Resolved after escalation:</span><span className="text-success-text font-semibold">92%</span></div>
                  </div>
                  <p className="text-ink-secondary text-xs mt-3 italic">Trust Score trend: {selectedRisk.trustTrend && selectedRisk.trustTrend > 0 ? 'Improving' : 'Declining'} over last 30 days</p>
                </div>
              )}
              <div>
                <p className="text-ink-secondary font-medium text-sm mb-2">Problem:</p>
                <p className="text-ink-secondary text-sm leading-relaxed">{selectedRisk.why}</p>
              </div>
              <div className="p-4 bg-warning-light border border-warning rounded-lg">
                <p className="text-warning font-medium text-sm mb-2">⚠️ Current Status</p>
                <div className="space-y-1 text-sm text-warning">
                  <p>• Blocked for: <strong>6 days</strong></p>
                  <p>• Revenue at risk: <strong>$2.3M</strong></p>
                  <p>• Dependency: <strong>Marketing team (delayed)</strong></p>
                  <p>• Last update: <strong>2 days ago</strong></p>
                </div>
              </div>
              <div>
                <p className="text-ink font-semibold mb-3">Available Actions:</p>
                <div className="space-y-2">
                  {[
                    { emoji: '🎯', title: 'Schedule Unblock Huddle', desc: 'Get Marcus Kim + Marketing lead in 15-min call to unblock', bg: 'bg-brand-light', border: 'border-brand', icon: 'text-brand', handler: () => { toast('TODO: Not implemented — would schedule unblock huddle with Marcus Kim + Marketing lead'); setSelectedRisk(null); } },
                    { emoji: '👤', title: 'Reassign Dependency Owner', desc: 'Assign specific Marketing owner to unblock this KR', bg: 'bg-info-light', border: 'border-info', icon: 'text-info', handler: () => { toast('TODO: Not implemented — would reassign dependency owner to Marketing lead'); setSelectedRisk(null); } },
                    { emoji: '🚨', title: 'Escalate to COO', desc: 'Notify COO of $2.3M revenue risk with context', bg: 'bg-success-light', border: 'border-success', icon: 'text-success-text', handler: () => { toast('TODO: Not implemented — would notify COO of $2.3M revenue risk'); setSelectedRisk(null); } },
                    { emoji: '📝', title: 'Mark as Resolved', desc: 'Dependency was unblocked outside of system', bg: 'bg-surface-1', border: 'border-edge', icon: 'text-ink-secondary', handler: () => setShowProofDialog(true) },
                  ].map(action => (
                    <button key={action.title} onClick={action.handler} className={`w-full p-4 ${action.bg} border-2 ${action.border} rounded-lg hover:opacity-90 transition-colors text-left group`}>
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-ink font-medium text-sm mb-1">{action.emoji} {action.title}</p>
                          <p className="text-ink-secondary text-xs">{action.desc}</p>
                        </div>
                        <ArrowRight className={`w-4 h-4 ${action.icon} group-hover:translate-x-1 transition-transform`} />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="p-4 bg-gradient-to-r from-brand-light to-info-light border-2 border-brand rounded-lg">
                <p className="text-brand-active font-semibold text-sm mb-2">💡 AI Recommendation</p>
                <p className="text-brand-active text-sm leading-relaxed mb-3">
                  Based on similar blockers, <strong>scheduling an Unblock Huddle</strong> resolves 87% of cases within 24 hours. 
                  Average resolution time: <strong>2.1 days faster</strong> than reassignment.
                </p>
                <p className="text-brand text-xs italic">Historical data shows Marketing responds best to direct sync vs. async assignment.</p>
              </div>
            </div>
            <div className="px-6 pb-6 flex items-center justify-between">
              <button onClick={() => setSelectedRisk(null)} className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium">Close</button>
              <button onClick={() => { navigate('/evidence'); setSelectedRisk(null); }} className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium shadow-[var(--shadow-card)]">
                View Full Details in Evidence →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Proof Dialog */}
      {showProofDialog && (
        <div className="fixed inset-0 z-[60] bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-xl w-full">
            <div className="p-6 border-b border-edge">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-ink font-semibold text-lg mb-1">Proof Required: Mark as Resolved</h3>
                  <p className="text-ink-secondary text-sm">{selectedRisk?.title}</p>
                </div>
                <button onClick={() => { setShowProofDialog(false); setProofType(''); setProofNote(''); setProofLink(''); }} className="text-ink-muted hover:text-ink-secondary text-2xl leading-none">×</button>
              </div>
            </div>
            <div className="p-6 space-y-5">
              <div className="p-4 bg-warning-light border border-warning rounded-lg">
                <p className="text-warning font-semibold text-sm mb-1">⚠️ Accountability Required</p>
                <p className="text-warning text-xs">You must provide proof of resolution. This creates an audit trail and prevents "fake closes".</p>
              </div>
              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-2">How was this resolved? <span className="text-danger-text">*</span></label>
                <select value={proofType} onChange={(e) => setProofType(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent">
                  <option value="">Select proof type...</option>
                  <option value="update-received">Update received from owner</option>
                  <option value="dependency-cleared">Dependency cleared</option>
                  <option value="owner-changed">Owner changed</option>
                  <option value="scope-adjusted">Scope adjusted</option>
                  <option value="eta-committed">ETA committed</option>
                </select>
              </div>
              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-2">Provide 1-sentence explanation <span className="text-danger-text">*</span></label>
                <textarea value={proofNote} onChange={(e) => setProofNote(e.target.value)} placeholder="Example: Marketing team unblocked dependency and provided revised timeline"
                  className="w-full px-4 py-3 border-2 border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent resize-none" rows={3} />
                <p className="text-ink-muted text-xs mt-1">{proofNote.length}/200 characters</p>
              </div>
              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-2">Attach link or file (optional)</label>
                <input type="text" value={proofLink} onChange={(e) => setProofLink(e.target.value)} placeholder="https://... or file path"
                  className="w-full px-4 py-3 border-2 border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent" />
              </div>
              {proofType && proofNote && (
                <div className="p-4 bg-success-light border border-success rounded-lg">
                  <p className="text-success-text font-semibold text-sm mb-2">✓ Audit Trail Preview</p>
                  <div className="space-y-1 text-xs text-success-text">
                    <p><strong>Resolved by:</strong> Sarah Chen (COO)</p>
                    <p><strong>Timestamp:</strong> {new Date().toLocaleString()}</p>
                    <p><strong>Method:</strong> {proofType.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}</p>
                    <p><strong>Note:</strong> {proofNote}</p>
                    {proofLink && <p><strong>Reference:</strong> {proofLink}</p>}
                  </div>
                </div>
              )}
            </div>
            <div className="px-6 pb-6 flex items-center justify-between">
              <button onClick={() => { setShowProofDialog(false); setProofType(''); setProofNote(''); setProofLink(''); }}
                className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium">Cancel</button>
              <button disabled={!proofType || !proofNote}
                onClick={() => { toast('TODO: Not implemented — would mark risk as resolved and create audit trail'); setShowProofDialog(false); setSelectedRisk(null); setProofType(''); setProofNote(''); setProofLink(''); }}
                className={`px-5 py-2.5 rounded-lg transition-colors font-medium shadow-[var(--shadow-card)] ${
                  !proofType || !proofNote ? 'bg-edge text-ink-muted cursor-not-allowed' : 'bg-success text-[var(--white)] hover:bg-success-text'
                }`}>Confirm Resolution</button>
            </div>
          </div>
        </div>
      )}

      {/* Evidence Timeline Dialog */}
      {showEvidenceTimeline && evidenceRisk && (
        <EvidenceTimeline
          isOpen={showEvidenceTimeline}
          onClose={() => { setShowEvidenceTimeline(false); setEvidenceRisk(null); }}
          incident={{
            id: evidenceRisk.id,
            title: evidenceRisk.title,
            status: evidenceRisk.status === 'Fixed' ? 'resolved' : 'open',
            slaStatus: 'breached',
            slaDetails: 'Breached by 12h',
            policy: 'Blocked SLA (Critical)',
            owner: evidenceRisk.owner,
            escalationLevel: 'Manager',
            signal: 'Blocked > 48h',
            conditions: [
              { field: 'severity', operator: '=', value: 'High' },
              { field: 'team', operator: '=', value: 'Engineering' },
              { field: 'dependency', operator: '=', value: 'cross-team' }
            ],
            exceptions: []
          }}
        />
      )}
    </div>
  );
}

import { Plus, X } from 'lucide-react';
import { useState } from 'react';

export interface Condition {
  id: string;
  field: string;
  operator: string;
  value: string;
}

interface ConditionBuilderProps {
  conditions: Condition[];
  onChange: (conditions: Condition[]) => void;
  title?: string;
  helper?: string;
  placeholder?: string;
  isException?: boolean;
}

export function ConditionBuilder({ 
  conditions, 
  onChange, 
  title = "IF (only trigger when...)",
  helper = "Reduce noise. Define exactly which cases should fire.",
  placeholder = "No conditions set — policy will fire for all cases",
  isException = false
}: ConditionBuilderProps) {
  const addCondition = () => {
    onChange([
      ...conditions,
      { id: Date.now().toString(), field: '', operator: '', value: '' }
    ]);
  };

  const removeCondition = (id: string) => {
    onChange(conditions.filter(c => c.id !== id));
  };

  const updateCondition = (id: string, key: keyof Condition, value: string) => {
    onChange(conditions.map(c => c.id === id ? { ...c, [key]: value } : c));
  };

  const fieldOptions = [
    { value: '', label: 'Select field...', disabled: true },
    { value: 'scope.team', label: 'Team' },
    { value: 'scope.org', label: 'Org Unit' },
    { value: 'scope.role', label: 'Role' },
    { value: 'object.type', label: 'Object Type' },
    { value: 'object.priority', label: 'Priority/Severity' },
    { value: 'object.status', label: 'Stage/Status' },
    { value: 'time.aging', label: 'Aging (hours/days)' },
    { value: 'time.overdue', label: 'Overdue by (days)' },
    { value: 'dependency.cross_team', label: 'Has cross-team dependency' },
    { value: 'dependency.blocker_count', label: '# of blockers' },
    { value: 'evidence.has_owner', label: 'Has owner' },
    { value: 'evidence.has_due_date', label: 'Has due date' },
    { value: 'evidence.has_kr_link', label: 'Has KR link' },
    { value: 'evidence.last_update', label: 'Last update older than (days)' },
  ];

  const getOperators = (field: string) => {
    if (field.includes('count') || field.includes('aging') || field.includes('overdue') || field.includes('last_update')) {
      return [
        { value: '', label: 'Select operator...', disabled: true },
        { value: '>', label: '>' },
        { value: '>=', label: '>=' },
        { value: '=', label: '=' },
        { value: '<', label: '<' },
        { value: '<=', label: '<=' },
      ];
    }
    return [
      { value: '', label: 'Select operator...', disabled: true },
      { value: '=', label: '=' },
      { value: '!=', label: '!=' },
    ];
  };

  const getValuePlaceholder = (field: string) => {
    if (field.includes('team')) return 'Engineering, Sales, Product...';
    if (field.includes('org')) return 'North America, EMEA...';
    if (field.includes('role')) return 'Owner, Manager, Exec';
    if (field.includes('type')) return 'KR, Initiative, Task, Dependency';
    if (field.includes('priority')) return 'Low, Medium, High, Critical';
    if (field.includes('status')) return 'On Track, At Risk, Blocked, Overdue';
    if (field.includes('aging') || field.includes('overdue') || field.includes('last_update')) return 'Number (days)';
    if (field.includes('cross_team') || field.includes('has_')) return 'Yes or No';
    if (field.includes('count')) return 'Number';
    return 'Enter value...';
  };

  return (
    <div className="space-y-3">
      <div>
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-[var(--neutral-800)] font-semibold text-sm">{title}</h4>
          <button
            onClick={addCondition}
            className="flex items-center gap-1 px-3 py-1.5 text-brand hover:bg-brand-light rounded-lg transition-colors text-sm font-medium"
          >
            <Plus className="w-4 h-4" />
            Add Condition
          </button>
        </div>
        <p className="text-[var(--neutral-600)] text-xs mb-3">{helper}</p>
      </div>

      {conditions.length === 0 ? (
        <div className={`p-4 border-2 border-dashed rounded-lg text-center ${
          isException ? 'bg-success-light border-[var(--success)]' : 'bg-surface-1 border-[var(--neutral-200)]'
        }`}>
          <p className="text-[var(--neutral-400)] text-sm">{placeholder}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {conditions.map((condition, index) => (
            <div key={condition.id}>
              {index > 0 && (
                <div className="flex items-center justify-center -my-1">
                  <span className="px-2 py-0.5 bg-[var(--neutral-200)] text-[var(--neutral-600)] rounded text-xs font-semibold">
                    AND
                  </span>
                </div>
              )}
              <div className="flex items-center gap-2 p-3 bg-surface-0 border border-[var(--neutral-200)] rounded-lg">
                <select
                  value={condition.field}
                  onChange={(e) => updateCondition(condition.id, 'field', e.target.value)}
                  className="flex-1 px-3 py-2 border border-[var(--neutral-200)] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand"
                >
                  {fieldOptions.map(opt => (
                    <option key={opt.value} value={opt.value} disabled={opt.disabled}>
                      {opt.label}
                    </option>
                  ))}
                </select>

                <select
                  value={condition.operator}
                  onChange={(e) => updateCondition(condition.id, 'operator', e.target.value)}
                  disabled={!condition.field}
                  className="w-24 px-3 py-2 border border-[var(--neutral-200)] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand disabled:bg-surface-2 disabled:text-[var(--neutral-400)]"
                >
                  {getOperators(condition.field).map(opt => (
                    <option key={opt.value} value={opt.value} disabled={opt.disabled}>
                      {opt.label}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  value={condition.value}
                  onChange={(e) => updateCondition(condition.id, 'value', e.target.value)}
                  disabled={!condition.operator}
                  placeholder={getValuePlaceholder(condition.field)}
                  className="flex-1 px-3 py-2 border border-[var(--neutral-200)] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand disabled:bg-surface-2"
                />

                <button
                  onClick={() => removeCondition(condition.id)}
                  className="p-2 text-[var(--neutral-400)] hover:text-danger hover:bg-danger-light rounded-lg transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

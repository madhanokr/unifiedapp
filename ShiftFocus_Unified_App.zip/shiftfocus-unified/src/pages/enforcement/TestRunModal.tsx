import { useState } from 'react';
import { X, Play, Check } from 'lucide-react';

interface TestRunModalProps {
  onClose: () => void;
}

export function TestRunModal({ onClose }: TestRunModalProps) {
  const [running, setRunning] = useState(false);
  const [complete, setComplete] = useState(false);
  const [timeRange, setTimeRange] = useState('Last 7 days');
  const [scope, setScope] = useState('All teams');
  const [includeEnabledPlaybooks, setIncludeEnabledPlaybooks] = useState(true);
  const [includeActiveRules, setIncludeActiveRules] = useState(true);
  const [includeMonitorOnly, setIncludeMonitorOnly] = useState(false);

  const handleRunTest = () => {
    setRunning(true);
    setTimeout(() => {
      setRunning(false);
      setComplete(true);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black bg-opacity-25" onClick={onClose} />
      
      <div className="relative bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-2xl w-full mx-4">
        {/* Header */}
        <div className="px-8 py-6 border-b border-edge flex items-center justify-between">
          <h2 className="text-ink">Run Simulation</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-ink-secondary" />
          </button>
        </div>

        {/* Content */}
        <div className="px-8 py-6">
          {!complete ? (
            <>
              <p className="text-ink-secondary mb-6">
                Test your enforcement setup by running a simulation on historical data. 
                See which rules would have triggered and who would have been notified — without actually sending notifications.
              </p>

              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-ink-secondary mb-2">Time Range</label>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  >
                    <option>Last 7 days</option>
                    <option>Last 14 days</option>
                    <option>Last 30 days</option>
                    <option>Custom range</option>
                  </select>
                </div>

                <div>
                  <label className="block text-ink-secondary mb-2">Scope</label>
                  <select
                    value={scope}
                    onChange={(e) => setScope(e.target.value)}
                    className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  >
                    <option>All teams</option>
                    <option>Engineering</option>
                    <option>Product</option>
                    <option>Marketing</option>
                    <option>Design</option>
                  </select>
                </div>

                <div>
                  <label className="block text-ink-secondary mb-2">Include</label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeEnabledPlaybooks}
                        onChange={(e) => setIncludeEnabledPlaybooks(e.target.checked)}
                        className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                      />
                      <span className="text-ink-secondary">Enabled playbooks only</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeActiveRules}
                        onChange={(e) => setIncludeActiveRules(e.target.checked)}
                        className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                      />
                      <span className="text-ink-secondary">Active rules only</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeMonitorOnly}
                        onChange={(e) => setIncludeMonitorOnly(e.target.checked)}
                        className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                      />
                      <span className="text-ink-secondary">Include monitor-only mode</span>
                    </label>
                  </div>
                </div>
              </div>

              {running && (
                <div className="p-4 bg-brand-light border border-brand rounded-lg mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 border-2 border-brand border-t-transparent rounded-full animate-spin" />
                    <span className="text-brand">Running simulation...</span>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-success-light rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-success-text" />
              </div>
              <h3 className="text-ink mb-2">Simulation Complete</h3>
              <p className="text-ink-secondary mb-6">
                Scroll down to the "If this ran last week..." section for detailed results
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-8 py-6 border-t border-edge flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors"
          >
            {complete ? 'Close' : 'Cancel'}
          </button>
          {!complete && (
            <button
              onClick={handleRunTest}
              disabled={running}
              className="flex items-center gap-2 px-6 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
              Run Simulation
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
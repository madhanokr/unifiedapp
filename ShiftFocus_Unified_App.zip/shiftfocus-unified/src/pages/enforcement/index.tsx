/**
 * Enforcement Center — Internal sub-routing with tabs
 * Uses relative routes within the /enforcement/* path
 * store.ts provides localStorage persistence for rules
 */
import { useState } from 'react';
import { Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { PlaybooksGallery } from './PlaybooksGallery';
import { RulesBuilder } from './RulesBuilder';
import { Settings } from './Settings';
import { Overview } from './Overview';
import { ExecutiveWeeklyBrief } from './ExecutiveWeeklyBrief';
import { EscalationPoliciesPage } from './EscalationPoliciesPage';
import { EvidenceAuditPage } from './EvidenceAuditPage';
import { TestRunModal } from './TestRunModal';
import { CreateRuleModal } from './CreateRuleModal';
import { loadRules, saveRules } from './store';
import type { Rule } from './store';
import {
  BarChart3, Zap, Settings as SettingsIcon, Layout,
  TrendingUp, FileText, Mail, Play,
} from 'lucide-react';
import { toast } from 'sonner';

const tabs = [
  { id: 'overview', path: 'overview', label: 'Overview', icon: BarChart3 },
  { id: 'playbooks', path: 'policy-templates', label: 'Policy Templates', icon: Zap },
  { id: 'rules', path: 'operating-policies', label: 'Operating Policies', icon: Layout },
  { id: 'escalation', path: 'escalation-policies', label: 'Escalation Policies', icon: TrendingUp },
  { id: 'evidence', path: 'evidence', label: 'Evidence & Audit', icon: FileText },
  { id: 'brief', path: 'weekly-brief', label: 'Weekly Brief', icon: Mail },
  { id: 'settings', path: 'settings', label: 'Settings', icon: SettingsIcon },
];

export default function EnforcementPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [showTestRunModal, setShowTestRunModal] = useState(false);
  const [showCreateRuleModal, setShowCreateRuleModal] = useState(false);

  const handleCreateRule = (rule: Rule) => {
    const current = loadRules();
    const updated = [...current, rule];
    saveRules(updated);
    toast.success('Rule created successfully');
    navigate('operating-policies');
  };

  const currentTab = tabs.find((t) =>
    location.pathname.includes(t.path)
  ) || tabs[0];

  return (
    <div>
      {/* Tab navigation */}
      <div
        className="flex items-center gap-1 mb-6 pb-3"
        style={{ borderBottom: '1px solid var(--neutral-200)' }}
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab.id === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => navigate(tab.path)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all"
              style={{
                fontSize: '13px',
                fontWeight: isActive ? 600 : 500,
                color: isActive ? 'var(--brand-primary)' : 'var(--neutral-600)',
                backgroundColor: isActive ? 'var(--brand-primary-light)' : 'transparent',
              }}
            >
              <Icon style={{ width: '14px', height: '14px' }} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Sub-routes */}
      <Routes>
        <Route index element={<Navigate to="overview" replace />} />
        <Route path="overview" element={<Overview />} />
        <Route path="policy-templates" element={<PlaybooksGallery />} />
        <Route path="operating-policies" element={<RulesBuilder />} />
        <Route path="escalation-policies" element={<EscalationPoliciesPage />} />
        <Route path="evidence" element={<EvidenceAuditPage />} />
        <Route path="evidence/:incidentId" element={<EvidenceAuditPage />} />
        <Route path="weekly-brief" element={<ExecutiveWeeklyBrief />} />
        <Route path="settings" element={<Settings />} />
      </Routes>

      {/* Modals */}
      {showTestRunModal && <TestRunModal onClose={() => setShowTestRunModal(false)} />}
      {showCreateRuleModal && (
        <CreateRuleModal
          onClose={() => setShowCreateRuleModal(false)}
          onSave={handleCreateRule}
        />
      )}
    </div>
  );
}

import { useState } from 'react';
import { X, Plus, Info, HelpCircle, AlertCircle, ChevronDown } from 'lucide-react';
import { toast } from 'sonner';
import type { Rule } from './store';

interface CreateRuleModalProps {
  show: boolean;
  onClose: () => void;
  editingRule?: Rule | null;
  onSave?: (rule: Rule) => void;
}

// Signal definitions with auto-determined objects
const signalConfig: Record<string, {
  description: string;
  object: string;
  availableConditions: string[];
}> = {
  'missed-checkin': {
    description: 'Triggered when a KR or Initiative misses its scheduled update for > 7 days.',
    object: 'KR / Initiative',
    availableConditions: ['Owner\'s Team', 'Owner', 'Owner\'s Manager', 'Days Since Last Update', 'Confidence Level', 'Impact Level'],
  },
  'blocked-sla': {
    description: 'Triggered when a blocker or dependency remains unresolved beyond SLA threshold.',
    object: 'Task / Blocker',
    availableConditions: ['Assignee\'s Team', 'Assignee', 'Days Blocked', 'Impact Level', 'Blocker Type'],
  },
  'kr-drift': {
    description: 'Triggered when KR progress diverges > 20% from target trajectory.',
    object: 'KR',
    availableConditions: ['Owner\'s Team', 'Owner', 'Drift %', 'Confidence Level', 'Impact Level'],
  },
  'dependency-risk': {
    description: 'Triggered when cross-team dependency shows risk signals (delays, conflicts).',
    object: 'Dependency',
    availableConditions: ['Upstream Team', 'Downstream Team', 'Days At Risk', 'Impact Level'],
  },
  'capacity-overload': {
    description: 'Triggered when team capacity utilization exceeds 85% for > 3 days.',
    object: 'Team',
    availableConditions: ['Team Name', 'Capacity %', 'Days Overloaded', 'Active Initiatives'],
  },
  'scope-creep': {
    description: 'Triggered when KR or initiative grew > 25% in tasks or budget.',
    object: 'KR / Initiative',
    availableConditions: ['Owner\'s Team', 'Owner', 'Scope Increase %', 'Budget Variance %', 'Impact Level'],
  },
  'confidence-drop': {
    description: 'Triggered when owner confidence < 60% for > 48 hours.',
    object: 'KR / Initiative',
    availableConditions: ['Owner\'s Team', 'Owner', 'Confidence Level', 'Days Low Confidence', 'Impact Level'],
  },
};

// Escalation policy previews
const escalationPreviews: Record<string, string> = {
  'Standard': 'Owner → Manager (48h) → Exec (96h)',
  'Critical': 'Owner → Manager (24h) → Exec (48h)',
  'Silent': 'Log only, no escalation',
};

// Action tooltips for clarity
const actionTooltips: Record<string, string> = {
  'notify': 'Sends alert via Slack / Email to the item owner',
  'create-task': 'Adds follow-up task in Task OS',
  'require-update': 'Blocks item close until update submitted',
  'schedule-huddle': 'Auto-creates 15 min sync meeting',
  'escalate': 'Escalates to owner\'s manager per policy',
};

// Dynamic value options based on field type
const getValueInput = (field: string, value: string, onChange: (val: string) => void) => {
  switch (field) {
    case 'Owner\'s Team':
    case 'Assignee\'s Team':
    case 'Upstream Team':
    case 'Downstream Team':
    case 'Team Name':
      return (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
        >
          <option value="">Select team...</option>
          <option value="Engineering">Engineering</option>
          <option value="Product">Product</option>
          <option value="Sales">Sales</option>
          <option value="Marketing">Marketing</option>
          <option value="Design">Design</option>
          <option value="Operations">Operations</option>
        </select>
      );
    
    case 'Impact Level':
      return (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
        >
          <option value="">Select impact...</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      );
    
    case 'Owner':
    case 'Assignee':
    case 'Owner\'s Manager':
      return (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
        >
          <option value="">Select person...</option>
          <option value="Sarah Chen">Sarah Chen</option>
          <option value="Mike Johnson">Mike Johnson</option>
          <option value="Alex Kim">Alex Kim</option>
          <option value="Jordan Lee">Jordan Lee</option>
          <option value="Taylor Brown">Taylor Brown</option>
          <option value="Casey Martinez">Casey Martinez</option>
        </select>
      );
    
    case 'Blocker Type':
      return (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
        >
          <option value="">Select type...</option>
          <option value="Technical">Technical</option>
          <option value="Resource">Resource</option>
          <option value="Dependency">Dependency</option>
          <option value="Decision">Decision</option>
        </select>
      );
    
    case 'Days Since Last Update':
    case 'Days Blocked':
    case 'Days At Risk':
    case 'Days Overloaded':
    case 'Days Low Confidence':
    case 'Active Initiatives':
      return (
        <div className="flex-1 flex items-center gap-2">
          <input
            type="number"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="0"
            min="0"
            className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
          />
          <span className="text-sm text-[var(--neutral-600)]">days</span>
        </div>
      );
    
    case 'Confidence Level':
    case 'Capacity %':
    case 'Drift %':
    case 'Scope Increase %':
    case 'Budget Variance %':
      return (
        <div className="flex-1 flex items-center gap-2">
          <input
            type="number"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="0"
            min="0"
            max="100"
            className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
          />
          <span className="text-sm text-[var(--neutral-600)]">%</span>
        </div>
      );
    
    default:
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Value"
          className="flex-1 px-3 py-2 bg-surface-0 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
        />
      );
  }
};

export function CreateRuleModal({ show, onClose, editingRule, onSave }: CreateRuleModalProps) {
  const [ruleName, setRuleName] = useState(editingRule?.name || '');
  const [signal, setSignal] = useState(editingRule?.signal || '');
  const [conditions, setConditions] = useState([
    { field: 'Owner\'s Team', operator: '=', value: '' },
  ]);
  const [actions, setActions] = useState(['notify']);
  const [scope, setScope] = useState('All teams');
  const [mode, setMode] = useState<'monitor' | 'enforce'>('monitor');
  const [impact, setImpact] = useState('medium');
  const [escalationPolicy, setEscalationPolicy] = useState('Standard');
  const [slaTimer, setSlaTimer] = useState(48);
  const [showTestModal, setShowTestModal] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [customThrottle, setCustomThrottle] = useState(false);
  const [throttleLimit, setThrottleLimit] = useState('10');
  const [customQuietHours, setCustomQuietHours] = useState(false);
  const [quietStart, setQuietStart] = useState('18:00');
  const [quietEnd, setQuietEnd] = useState('09:00');
  const [scopeMode, setScopeMode] = useState<'simple' | 'advanced'>('simple');
  const [selectedTeams, setSelectedTeams] = useState<string[]>([]);
  const [selectedOKRTypes, setSelectedOKRTypes] = useState<string[]>([]);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [selectedPriority, setSelectedPriority] = useState<string[]>([]);
  const [taskDestination, setTaskDestination] = useState('tasos');
  const [matchingLogic, setMatchingLogic] = useState('Match ALL criteria (AND)');

  if (!show) return null;

  const currentSignal = signal ? signalConfig[signal] : null;
  const availableConditions = currentSignal?.availableConditions || [];

  const addCondition = () => {
    const defaultField = availableConditions[0] || 'Owner\'s Team';
    setConditions([...conditions, { field: defaultField, operator: '=', value: '' }]);
  };

  const removeCondition = (index: number) => {
    setConditions(conditions.filter((_, i) => i !== index));
  };

  const updateCondition = (index: number, field: 'field' | 'operator' | 'value', value: string) => {
    const newConditions = [...conditions];
    newConditions[index][field] = value;
    setConditions(newConditions);
  };

  const toggleAction = (action: string) => {
    setActions((prev) =>
      prev.includes(action) ? prev.filter((a) => a !== action) : [...prev, action]
    );
  };

  // Auto-update SLA timer when escalation policy changes
  const handleEscalationChange = (policy: string) => {
    setEscalationPolicy(policy);
    if (policy === 'Standard') setSlaTimer(48);
    if (policy === 'Critical') setSlaTimer(24);
    if (policy === 'Silent') setSlaTimer(0);
  };

  // Reset conditions when signal changes
  const handleSignalChange = (newSignal: string) => {
    setSignal(newSignal);
    if (newSignal && signalConfig[newSignal]) {
      const defaultField = signalConfig[newSignal].availableConditions[0];
      setConditions([{ field: defaultField, operator: '=', value: '' }]);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black bg-opacity-25" onClick={onClose} />
        
        <div className="relative bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-3xl w-full mx-4 max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-surface-0 px-8 py-6 border-b border-edge flex items-center justify-between z-10">
            <div>
              <h2 className="text-ink">{editingRule ? 'Edit Rule' : 'Create New Rule'}</h2>
              <p className="text-sm text-ink-muted mt-1">Define automated enforcement logic: WHEN → IF → THEN</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-ink-secondary" />
            </button>
          </div>

          {/* Content */}
          <div className="px-8 py-6 space-y-6">
            {/* Rule Name */}
            <div>
              <label className="block text-ink mb-2 font-medium">Rule Name</label>
              <input
                type="text"
                value={ruleName}
                onChange={(e) => setRuleName(e.target.value)}
                placeholder="e.g., Engineering Weekly Check-in Enforcement"
                className="w-full px-4 py-2.5 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
              />
            </div>

            {/* WHEN: Signal (Trigger) - Auto-determines object */}
            <div className="bg-gradient-to-br from-brand-light to-surface-0 border border-brand rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-brand text-[var(--white)] rounded-lg flex items-center justify-center font-bold text-sm">
                  1
                </div>
                <label className="block text-ink font-semibold">WHEN this happens...</label>
              </div>
              
              <select
                value={signal}
                onChange={(e) => handleSignalChange(e.target.value)}
                className="w-full px-4 py-2.5 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent mb-2"
              >
                <option value="">Select a signal to start</option>
                <option value="missed-checkin">Missed check-in</option>
                <option value="blocked-sla">Blocked SLA exceeded</option>
                <option value="kr-drift">KR drift detected</option>
                <option value="dependency-risk">Dependency risk</option>
                <option value="capacity-overload">Capacity overload</option>
                <option value="scope-creep">Scope creep detected</option>
                <option value="confidence-drop">Confidence drop detected</option>
              </select>

              {/* Signal Description + Object */}
              {currentSignal && (
                <div className="space-y-2 mt-3">
                  <div className="flex items-start gap-2 p-3 bg-surface-0 rounded-lg border border-brand-light">
                    <Info className="w-4 h-4 text-brand mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-ink-secondary">{currentSignal.description}</p>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-brand-light rounded-lg border border-brand">
                    <span className="text-sm font-semibold text-brand-active">Applies to:</span>
                    <span className="px-3 py-1 bg-brand text-[var(--white)] rounded-full text-sm font-medium">
                      {currentSignal.object}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* IF: Conditions (Optional) */}
            {currentSignal && (
              <div className="bg-gradient-to-br from-info-light to-surface-0 border border-info rounded-xl p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-info text-[var(--white)] rounded-lg flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <label className="block text-ink font-semibold">IF these conditions match...</label>
                  <span className="text-xs text-ink-muted">(Optional filters)</span>
                </div>

                <div className="bg-info-light border border-info rounded-lg p-3 mb-4">
                  <p className="text-sm text-info font-medium mb-1">💡 Only for items where:</p>
                  <p className="text-xs text-info">
                    Conditions narrow down when this rule fires. Leave empty to apply to all {currentSignal.object} items.
                  </p>
                </div>
                
                <div className="space-y-3">
                  {conditions.map((condition, index) => (
                    <div key={index}>
                      {index > 0 && (
                        <div className="flex items-center gap-2 my-2">
                          <div className="flex-1 h-px bg-edge"></div>
                          <span className="px-3 py-1 bg-info-light text-info rounded-full text-xs font-semibold">
                            AND
                          </span>
                          <div className="flex-1 h-px bg-edge"></div>
                        </div>
                      )}
                      <div className="flex items-center gap-2 bg-surface-0 p-3 rounded-lg border border-info-light">
                        <select
                          value={condition.field}
                          onChange={(e) => updateCondition(index, 'field', e.target.value)}
                          className="px-3 py-2 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-info focus:border-transparent"
                        >
                          {availableConditions.map((field) => (
                            <option key={field} value={field}>{field}</option>
                          ))}
                        </select>
                        <select
                          value={condition.operator}
                          onChange={(e) => updateCondition(index, 'operator', e.target.value)}
                          className="px-3 py-2 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-info focus:border-transparent"
                        >
                          <option value="=">=</option>
                          <option value=">=">&gt;</option>
                          <option value="<=">&lt;</option>
                          <option value="!=">&ne;</option>
                        </select>
                        {getValueInput(condition.field, condition.value, (val) => updateCondition(index, 'value', val))}
                        {conditions.length > 1 && (
                          <button
                            onClick={() => removeCondition(index)}
                            className="p-2 hover:bg-danger-light rounded-lg transition-colors flex-shrink-0"
                          >
                            <X className="w-4 h-4 text-danger-text" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={addCondition}
                  className="flex items-center gap-2 px-4 py-2 text-info hover:bg-info-light rounded-lg transition-colors mt-3 w-full justify-center border border-info"
                >
                  <Plus className="w-4 h-4" />
                  Add Condition
                </button>
              </div>
            )}

            {/* THEN: Actions */}
            <div className="bg-gradient-to-br from-success-light to-surface-0 border border-success rounded-xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-success text-[var(--white)] rounded-lg flex items-center justify-center font-bold text-sm">
                  3
                </div>
                <label className="block text-ink font-semibold">THEN take these actions...</label>
              </div>
              
              <div className="space-y-2">
                {[
                  { id: 'notify', label: 'Notify owner' },
                  { id: 'create-task', label: 'Create follow-up task' },
                  { id: 'require-update', label: 'Require update' },
                  { id: 'schedule-huddle', label: 'Schedule huddle' },
                  { id: 'escalate', label: 'Escalate to manager' },
                ].map((action) => (
                  <div key={action.id}>
                    <label 
                      className="flex items-center gap-3 cursor-pointer p-3 bg-surface-0 rounded-lg border border-success-light hover:border-success transition-all group"
                    >
                      <input
                        type="checkbox"
                        checked={actions.includes(action.id)}
                        onChange={() => toggleAction(action.id)}
                        className="w-5 h-5 text-success-text border-edge rounded focus:ring-success"
                      />
                      <div className="flex-1">
                        <span className="text-ink font-medium">{action.label}</span>
                        <div className="flex items-center gap-1 mt-0.5">
                          <HelpCircle className="w-3 h-3 text-ink-muted" />
                          <span className="text-xs text-ink-muted">{actionTooltips[action.id]}</span>
                        </div>
                      </div>
                    </label>
                    
                    {/* Show channel selector for create-task action */}
                    {action.id === 'create-task' && actions.includes('create-task') && (
                      <div className="ml-11 mt-2 p-3 bg-success-light rounded-lg border border-success">
                        <label className="block text-sm text-ink-secondary font-medium mb-2">
                          Create task in:
                        </label>
                        <select
                          value={taskDestination}
                          onChange={(e) => setTaskDestination(e.target.value)}
                          className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-success focus:border-transparent text-sm"
                        >
                          <option value="tasos">TaskOS (Internal)</option>
                          <option value="jira">🔷 Jira - ShiftFocus Engineering</option>
                          <option value="asana">🔸 Asana - Product Team Workspace</option>
                          <option value="linear" disabled>⚡ Linear (Not connected)</option>
                          <option value="trello" disabled>📋 Trello (Not connected)</option>
                        </select>
                        <p className="text-xs text-ink-secondary mt-1">
                          Configure integrations in Settings →
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Escalation Policy */}
            <div className="bg-surface-1 rounded-lg p-4 border border-edge">
              <label className="block text-ink font-medium mb-3">Escalation Policy</label>
              <select
                value={escalationPolicy}
                onChange={(e) => handleEscalationChange(e.target.value)}
                className="w-full px-4 py-2.5 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent mb-3"
              >
                <option>Standard</option>
                <option>Critical</option>
                <option>Silent</option>
              </select>

              {/* Policy Preview */}
              <div className="flex items-start gap-2 p-3 bg-surface-0 rounded-lg border border-edge">
                <AlertCircle className="w-4 h-4 text-ink-muted mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm text-ink-secondary font-medium">{escalationPreviews[escalationPolicy]}</p>
                  <button onClick={() => toast('TODO: Not implemented — would show escalation policy details')} className="text-xs text-brand hover:text-brand-hover mt-1">
                    View Policy Details →
                  </button>
                </div>
              </div>

              {escalationPolicy !== 'Silent' && (
                <div className="flex items-center gap-3 mt-3">
                  <span className="text-sm text-ink-secondary">SLA Timer:</span>
                  <input
                    type="number"
                    value={slaTimer}
                    onChange={(e) => setSlaTimer(Number(e.target.value))}
                    className="w-24 px-3 py-2 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  />
                  <span className="text-sm text-ink-secondary">hours</span>
                </div>
              )}
            </div>

            {/* STEP 8: Upgraded Scope Selector */}
            <div className="bg-surface-1 rounded-lg p-5 border border-edge">
              <div className="flex items-center justify-between mb-4">
                <label className="text-ink font-medium">Advanced Scope Selector</label>
                <button
                  onClick={() => setScopeMode(scopeMode === 'simple' ? 'advanced' : 'simple')}
                  className="text-sm text-brand hover:text-brand-hover font-medium"
                >
                  {scopeMode === 'simple' ? '→ Advanced' : '← Simple'}
                </button>
              </div>

              {scopeMode === 'simple' ? (
                <div>
                  <select
                    value={scope}
                    onChange={(e) => setScope(e.target.value)}
                    className="w-full px-4 py-2.5 bg-surface-0 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
                  >
                    <option>All teams</option>
                    <option>Engineering</option>
                    <option>Product</option>
                    <option>Marketing</option>
                    <option>Design</option>
                    <option>Sales</option>
                  </select>
                  <p className="text-xs text-ink-muted mt-2">Simple mode: Select one team or all teams</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Teams Multi-select */}
                  <div>
                    <label className="block text-sm font-medium text-ink-secondary mb-2">Teams (multi-select)</label>
                    <div className="flex flex-wrap gap-2">
                      {['Engineering', 'Product', 'Sales', 'Marketing', 'Design', 'Operations'].map(team => (
                        <label key={team} className={`flex items-center gap-2 px-3 py-2 bg-surface-0 border rounded-lg cursor-pointer transition-all ${
                          selectedTeams.includes(team) ? 'border-brand bg-brand-light' : 'border-edge hover:border-brand'
                        }`}>
                          <input 
                            type="checkbox"
                            checked={selectedTeams.includes(team)}
                            onChange={() => {
                              setSelectedTeams(prev => 
                                prev.includes(team) ? prev.filter(t => t !== team) : [...prev, team]
                              )
                            }}
                            className="w-4 h-4 text-brand border-edge rounded"
                          />
                          <span className="text-sm">{team}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* OKR Types */}
                  <div>
                    <label className="block text-sm font-medium text-ink-secondary mb-2">OKR Types</label>
                    <div className="flex flex-wrap gap-2">
                      {['Company', 'Team', 'Individual', 'Cross-functional'].map(type => (
                        <label key={type} className={`flex items-center gap-2 px-3 py-2 bg-surface-0 border rounded-lg cursor-pointer transition-all ${
                          selectedOKRTypes.includes(type) ? 'border-brand bg-brand-light' : 'border-edge hover:border-brand'
                        }`}>
                          <input 
                            type="checkbox"
                            checked={selectedOKRTypes.includes(type)}
                            onChange={() => {
                              setSelectedOKRTypes(prev => 
                                prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
                              )
                            }}
                            className="w-4 h-4 text-brand border-edge rounded"
                          />
                          <span className="text-sm">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Roles */}
                  <div>
                    <label className="block text-sm font-medium text-ink-secondary mb-2">Roles</label>
                    <div className="flex flex-wrap gap-2">
                      {['Owner', 'Contributor', 'Stakeholder', 'Reviewer'].map(role => (
                        <label key={role} className={`flex items-center gap-2 px-3 py-2 bg-surface-0 border rounded-lg cursor-pointer transition-all ${
                          selectedRoles.includes(role) ? 'border-brand bg-brand-light' : 'border-edge hover:border-brand'
                        }`}>
                          <input 
                            type="checkbox"
                            checked={selectedRoles.includes(role)}
                            onChange={() => {
                              setSelectedRoles(prev => 
                                prev.includes(role) ? prev.filter(r => r !== role) : [...prev, role]
                              )
                            }}
                            className="w-4 h-4 text-brand border-edge rounded"
                          />
                          <span className="text-sm">{role}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Priority */}
                  <div>
                    <label className="block text-sm font-medium text-ink-secondary mb-2">Priority Levels</label>
                    <div className="flex flex-wrap gap-2">
                      {['P0 (Critical)', 'P1 (High)', 'P2 (Medium)', 'P3 (Low)'].map(priority => (
                        <label key={priority} className={`flex items-center gap-2 px-3 py-2 bg-surface-0 border rounded-lg cursor-pointer transition-all ${
                          selectedPriority.includes(priority) ? 'border-brand bg-brand-light' : 'border-edge hover:border-brand'
                        }`}>
                          <input 
                            type="checkbox"
                            checked={selectedPriority.includes(priority)}
                            onChange={() => {
                              setSelectedPriority(prev => 
                                prev.includes(priority) ? prev.filter(p => p !== priority) : [...prev, priority]
                              )
                            }}
                            className="w-4 h-4 text-brand border-edge rounded"
                          />
                          <span className="text-sm">{priority}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Logic Selector */}
                  <div className="p-4 bg-brand-light border border-brand rounded-lg">
                    <label className="block text-sm font-medium text-ink-secondary mb-2">Matching Logic</label>
                    <select
                      value={matchingLogic}
                      onChange={(e) => setMatchingLogic(e.target.value)}
                      className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg text-sm"
                    >
                      <option>Match ALL criteria (AND)</option>
                      <option>Match ANY criteria (OR)</option>
                    </select>
                    <p className="text-xs text-ink-secondary mt-1">How should multiple selections be combined?</p>
                  </div>
                </div>
              )}
            </div>

            {/* STEP 5: Advanced Settings Accordion */}
            <div className="border border-edge rounded-lg overflow-hidden">
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="w-full px-5 py-3 bg-surface-1 hover:bg-surface-2 flex items-center justify-between transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium text-ink">⚙️ Advanced Settings</span>
                  <span className="text-xs text-ink-muted">(Per-rule overrides)</span>
                </div>
                <ChevronDown className={`w-5 h-5 text-ink-secondary transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
              </button>

              {showAdvanced && (
                <div className="p-5 space-y-5 bg-surface-0 border-t border-edge">
                  {/* Custom Throttle */}
                  <div>
                    <label className="flex items-center gap-2 mb-3">
                      <input 
                        type="checkbox" 
                        checked={customThrottle}
                        onChange={(e) => setCustomThrottle(e.target.checked)}
                        className="w-5 h-5 text-brand border-edge rounded"
                      />
                      <span className="font-medium text-ink">Override organization throttle</span>
                    </label>
                    {customThrottle && (
                      <div className="ml-7 p-4 bg-surface-1 rounded-lg border border-edge">
                        <label className="block text-sm text-ink-secondary font-medium mb-2">
                          Max notifications per day for this rule
                        </label>
                        <div className="flex items-center gap-3">
                          <input 
                            type="number" 
                            value={throttleLimit}
                            onChange={(e) => setThrottleLimit(e.target.value)}
                            className="w-24 px-3 py-2 bg-surface-0 border border-edge rounded-lg" 
                          />
                          <span className="text-sm text-ink-secondary">notifications/day</span>
                        </div>
                        <p className="text-xs text-ink-muted mt-2">
                          Org default is 15/day. This rule will be limited to {throttleLimit}/day.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Custom Quiet Hours */}
                  <div>
                    <label className="flex items-center gap-2 mb-3">
                      <input 
                        type="checkbox"
                        checked={customQuietHours}
                        onChange={(e) => setCustomQuietHours(e.target.checked)}
                        className="w-5 h-5 text-brand border-edge rounded"
                      />
                      <span className="font-medium text-ink">Custom quiet hours for this rule</span>
                    </label>
                    {customQuietHours && (
                      <div className="ml-7 p-4 bg-surface-1 rounded-lg border border-edge">
                        <div className="grid grid-cols-2 gap-3 mb-2">
                          <div>
                            <label className="block text-sm text-ink-secondary font-medium mb-1">Start</label>
                            <input 
                              type="time" 
                              value={quietStart}
                              onChange={(e) => setQuietStart(e.target.value)}
                              className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg" 
                            />
                          </div>
                          <div>
                            <label className="block text-sm text-ink-secondary font-medium mb-1">End</label>
                            <input 
                              type="time" 
                              value={quietEnd}
                              onChange={(e) => setQuietEnd(e.target.value)}
                              className="w-full px-3 py-2 bg-surface-0 border border-edge rounded-lg" 
                            />
                          </div>
                        </div>
                        <p className="text-xs text-ink-muted">
                          Org default is 8PM-8AM. This rule will use {quietStart}-{quietEnd}.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Info Banner */}
                  <div className="p-3 bg-info-light border border-info rounded-lg">
                    <p className="text-xs text-info">
                      💡 <strong>Power user tip:</strong> Use these overrides for high-priority rules that need different noise controls.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Rule Preview */}
            {signal && (
              <div className="bg-gradient-to-r from-brand-light to-info-light border border-brand rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-4 h-4 text-brand" />
                  <span className="text-sm font-semibold text-ink">Rule Preview</span>
                </div>
                <p className="text-sm text-ink-secondary">
                  <span className="font-semibold">When</span> {signalConfig[signal]?.description.toLowerCase().replace('triggered when ', '')}
                  {conditions[0].value && (
                    <>
                      {' '}<span className="font-semibold">and</span> {conditions[0].field.toLowerCase()} = {conditions[0].value}
                    </>
                  )}
                  {' → '}
                  <span className="font-semibold">then</span>{' '}
                  {actions.length > 0 ? actions.map((a) => actionTooltips[a].split(' ')[0]).join(', ').toLowerCase() : 'no actions'}
                  {escalationPolicy !== 'Silent' && actions.includes('escalate') && ` (escalate after ${slaTimer}h)`}.
                </p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-surface-0 px-8 py-6 border-t border-edge flex items-center justify-between z-10">
            <button 
              onClick={() => setShowTestModal(true)}
              disabled={!signal}
              className="px-6 py-2.5 border-2 border-brand text-brand rounded-lg hover:bg-brand-light transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Test Rule
            </button>
            <div className="flex items-center gap-3">
              <button
                onClick={onClose}
                className="px-6 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (!signal || !ruleName) return;
                  const signalLabel = {
                    'missed-checkin': 'Missed check-in',
                    'blocked-sla': 'Blocked SLA',
                    'kr-drift': 'KR drift',
                    'dependency-risk': 'Dependency risk',
                    'capacity-overload': 'Capacity overload',
                    'scope-creep': 'Scope creep',
                    'confidence-drop': 'Confidence drop',
                  }[signal] || signal;
                  const actionLabel = actions.map(a => ({
                    'notify': 'Notify owner',
                    'create-task': 'Create task',
                    'require-update': 'Require update',
                    'schedule-huddle': 'Schedule huddle',
                    'escalate': 'Escalate to manager',
                  }[a] || a)).join(', ');
                  const severityMap: Record<string, string> = { low: 'Low', medium: 'Medium', high: 'High' };
                  const rule: Rule = {
                    id: editingRule?.id || Date.now().toString(),
                    name: ruleName,
                    signal: signalLabel,
                    action: actionLabel,
                    scope,
                    enabled: editingRule?.enabled ?? true,
                    status: editingRule?.status ?? 'draft',
                    mode,
                    team: scope === 'All teams' ? 'Company-wide' : scope,
                    severity: severityMap[impact] || 'Medium',
                    lastTriggered: editingRule?.lastTriggered ?? 'Never',
                    triggers7d: editingRule?.triggers7d ?? 0,
                  };
                  if (onSave) {
                    onSave(rule);
                  } else {
                    onClose();
                  }
                }}
                disabled={!signal || !ruleName}
                className="px-6 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium shadow-[var(--shadow-card)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {editingRule ? 'Save Changes' : 'Create Rule'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Test Rule Modal */}
      {showTestModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black bg-opacity-40" onClick={() => setShowTestModal(false)} />
          
          <div className="relative bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-lg w-full mx-4">
            <div className="px-6 py-5 border-b border-edge">
              <h3 className="text-ink font-semibold">Test Rule on Past 7 Days</h3>
              <p className="text-sm text-ink-secondary mt-1">See how this rule would have performed</p>
            </div>
            
            <div className="px-6 py-6">
              <div className="bg-brand-light border border-brand rounded-lg p-4 mb-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 bg-brand text-[var(--white)] rounded-lg flex items-center justify-center font-bold">
                    12
                  </div>
                  <div>
                    <div className="text-ink font-semibold">Would have triggered 12 times</div>
                    <div className="text-sm text-ink-secondary">Across 3 teams, 8 unique {currentSignal?.object || 'items'}</div>
                  </div>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-secondary">Engineering</span>
                  <span className="font-semibold text-ink">7 triggers</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-secondary">Product</span>
                  <span className="font-semibold text-ink">3 triggers</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-secondary">Sales</span>
                  <span className="font-semibold text-ink">2 triggers</span>
                </div>
              </div>

              <button onClick={() => toast('TODO: Not implemented — would show example rule instances')} className="text-sm text-brand hover:text-brand-hover font-medium">
                Show example instances →
              </button>
            </div>

            <div className="px-6 py-4 border-t border-edge flex items-center justify-end gap-3">
              <button
                onClick={() => setShowTestModal(false)}
                className="px-5 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setShowTestModal(false);
                  onClose();
                }}
                className="px-5 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium"
              >
                Looks Good, Create Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
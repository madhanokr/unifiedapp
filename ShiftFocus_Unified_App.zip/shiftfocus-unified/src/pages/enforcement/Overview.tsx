import { TrendingUp, TrendingDown, CheckCircle2, AlertCircle, Clock, Zap, Users, Target, ArrowRight, ChevronRight, AlertTriangle, ExternalLink, Activity, Shield, Brain, X, MoreVertical, Bell, CheckSquare, Calendar, UserPlus, ArrowUp, EyeOff, FileText, BarChart3, Download, Share2, Info, HelpCircle } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { loadRules, loadEvidenceResolutions } from './store';

// Derive live metrics from store data
function useLiveMetrics() {
  const compute = useCallback(() => {
    const rules = loadRules();
    const resolutions = loadEvidenceResolutions();
    const enabledRules = rules.filter(r => r.enabled);
    const liveRules = rules.filter(r => r.status === 'live');
    const totalTriggers = rules.reduce((sum, r) => sum + (r.triggers7d || 0), 0);
    const teamsMap = new Map<string, { triggers: number; count: number }>();
    rules.forEach(r => {
      const team = r.team || 'Unknown';
      const entry = teamsMap.get(team) || { triggers: 0, count: 0 };
      entry.triggers += r.triggers7d || 0;
      entry.count++;
      teamsMap.set(team, entry);
    });
    return {
      totalRules: rules.length,
      enabledRules: enabledRules.length,
      liveRules: liveRules.length,
      totalTriggers,
      resolutionCount: resolutions.length,
      teams: teamsMap,
    };
  }, []);

  const [metrics, setMetrics] = useState(compute);

  useEffect(() => {
    const reload = () => setMetrics(compute());
    window.addEventListener('rules-updated', reload);
    window.addEventListener('evidence-resolutions-updated', reload);
    return () => {
      window.removeEventListener('rules-updated', reload);
      window.removeEventListener('evidence-resolutions-updated', reload);
    };
  }, [compute]);

  return metrics;
}

export function Overview() {
  const navigate = useNavigate();
  const metrics = useLiveMetrics();
  const [showTeamModal, setShowTeamModal] = useState<'engineering' | 'sales' | null>(null);
  const [showFixIssuesModal, setShowFixIssuesModal] = useState(false);
  const [showTimeSavedModal, setShowTimeSavedModal] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [showTimelineModal, setShowTimelineModal] = useState(false);
  const [showMetricModal, setShowMetricModal] = useState<'velocity' | 'firedrills' | 'ontime' | 'response' | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportFormat, setExportFormat] = useState<'pdf' | 'excel'>('pdf');
  const [exportSections, setExportSections] = useState<Record<string, boolean>>({
    'Executive summary': true,
    'Health score trends': true,
    'Critical issues feed': true,
    'Team performance': true,
    'Auto-resolved items': false,
  });

  /* helper: common card wrapper */
  const T = (c: string) => c;
  /* helper: tooltip bg */
  const tooltipCls = "bg-ink text-[var(--white)] text-xs px-3 py-2 rounded-lg whitespace-nowrap shadow-[var(--shadow-card-hover)]";
  /* helper: secondary action btn */
  const secBtnCls = "px-4 py-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all text-sm font-medium flex items-center gap-2";
  /* helper: primary CTA */
  const priBtnCls = "px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-semibold shadow-[var(--shadow-card)] flex items-center gap-2";
  /* helper: dropdown menu */
  const dropdownCls = "absolute right-0 top-12 w-56 bg-surface-0 rounded-lg shadow-[var(--shadow-elevated)] border border-edge py-2 z-10";
  const dropItemCls = "w-full px-4 py-2 text-left text-sm text-ink-secondary hover:bg-surface-1 flex items-center gap-2";

  return (
    <div className="space-y-8">
      {/* What You Didn't See (Addiction Engine) */}
      <div className="p-6 bg-gradient-to-br from-success-light via-success-light to-on-track-light border-2 border-success rounded-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <EyeOff className="w-5 h-5 text-success-text" />
            <h3 className="text-ink font-semibold">What You Didn't See This Week</h3>
          </div>
          <span className="px-3 py-1 bg-success text-[var(--white)] rounded-full text-xs font-semibold">
            Silent Prevention
          </span>
        </div>
        <p className="text-success-text text-sm mb-4 leading-relaxed">
          These fires were prevented <strong>before</strong> they reached your attention. ShiftFocus caught and resolved them silently.
        </p>
        <div className="grid grid-cols-4 gap-3">
          <div className="p-3 bg-surface-0 rounded-lg border-2 border-success">
            <div className="text-3xl font-bold text-success-text mb-1">{metrics.totalTriggers}</div>
            <p className="text-success-text text-xs font-medium">Triggers Caught (7d)</p>
          </div>
          <div className="p-3 bg-surface-0 rounded-lg border-2 border-info">
            <div className="text-3xl font-bold text-info mb-1">{metrics.resolutionCount}</div>
            <p className="text-info text-xs font-medium">Incidents Resolved</p>
          </div>
          <div className="p-3 bg-surface-0 rounded-lg border-2 border-brand">
            <div className="text-3xl font-bold text-brand mb-1">{metrics.liveRules}</div>
            <p className="text-brand-active text-xs font-medium">Live Rules</p>
          </div>
          <div className="p-3 bg-surface-0 rounded-lg border-2 border-warning">
            <div className="text-3xl font-bold text-warning mb-1">{metrics.enabledRules}</div>
            <p className="text-warning text-xs font-medium">Enabled Rules</p>
          </div>
        </div>
        <div className="mt-4 p-3 bg-gradient-to-r from-success-light to-success-light border border-success rounded-lg flex items-center justify-between">
          <p className="text-success-text text-xs font-semibold">You weren't surprised this week. That's not luck — that's governance.</p>
          <button onClick={() => navigate('/weekly-brief')} className="text-success-text hover:text-success-text text-xs font-medium flex items-center gap-1">
            View Details<ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Executive Control Panel */}
      <div className="grid grid-cols-3 gap-6">
        {/* Health Score */}
        <div className="bg-surface-0 rounded-2xl border border-edge p-6 shadow-[var(--shadow-card)]">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
            <span className="text-ink-secondary text-xs font-medium uppercase tracking-wide">Execution Health</span>
          </div>
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-6xl font-bold text-ink">{Math.min(100, 60 + metrics.liveRules * 5 + metrics.resolutionCount * 3)}</span>
            <span className="text-ink-muted text-2xl">/100</span>
          </div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-success-text" />
            <span className="text-success-text text-sm font-medium">+8 vs last week</span>
          </div>
          <div className="text-xs text-ink-muted mb-3">Team Performance (7d)</div>
          <div className="space-y-3">
            <div onClick={() => setShowTeamModal('engineering')} className="p-3 bg-success-light rounded-lg border border-success cursor-pointer hover:shadow-[var(--shadow-card)] hover:border-success transition-all group relative">
              <div className="flex items-center justify-between mb-1">
                <span className="text-success-text font-semibold text-xs">Top Performer</span>
                <div className="relative group/tooltip">
                  <span className="text-success-text font-bold text-xs flex items-center gap-1"><TrendingUp className="w-3 h-3" />+18</span>
                  <div className="absolute bottom-full right-0 mb-2 hidden group-hover/tooltip:block z-10"><div className={tooltipCls}>Score improved by 18 points</div></div>
                </div>
              </div>
              <div className="text-success-text text-xs font-semibold">Engineering Team</div>
              <div className="text-success-text text-xs mt-1">Cleared 12 blockers, 0 missed check-ins</div>
              <div className="text-success-text text-xs mt-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"><ChevronRight className="w-3 h-3" />Click to view details</div>
            </div>
            <div onClick={() => setShowTeamModal('sales')} className="p-3 bg-danger-light rounded-lg border border-danger cursor-pointer hover:shadow-[var(--shadow-card)] hover:border-danger transition-all group relative">
              <div className="flex items-center justify-between mb-1">
                <span className="text-danger-text font-semibold text-xs">Needs Attention</span>
                <div className="relative group/tooltip">
                  <span className="text-danger-text font-bold text-xs flex items-center gap-1"><TrendingDown className="w-3 h-3" />-12</span>
                  <div className="absolute bottom-full right-0 mb-2 hidden group-hover/tooltip:block z-10"><div className={tooltipCls}>Score dropped by 12 points</div></div>
                </div>
              </div>
              <div className="text-danger-text text-xs font-semibold">Sales Team</div>
              <div className="text-danger-text text-xs mt-1">3 missed check-ins, 2 overdue KRs</div>
              <div className="text-danger-text text-xs mt-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity"><ChevronRight className="w-3 h-3" />Click to view details</div>
            </div>
          </div>
        </div>

        {/* Health Drivers */}
        <div className="bg-surface-0 rounded-2xl border border-edge p-6 shadow-[var(--shadow-card)]">
          <div className="flex items-center gap-2 mb-4">
            <Brain className="w-4 h-4 text-brand" />
            <span className="text-ink-secondary text-xs font-medium uppercase tracking-wide">Health Drivers</span>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-danger-light rounded-lg border border-danger-light">
              <AlertTriangle className="w-5 h-5 text-danger-text flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-danger-text font-semibold text-sm mb-0.5">3 missed check-ins</div>
                <div className="text-danger-text text-xs font-medium mb-1">&rarr; $2.4M revenue at risk</div>
                <button onClick={() => toast('TODO: Not implemented — would navigate to KR Center')} className="text-danger-text hover:text-danger-text text-xs font-medium flex items-center gap-1">View in KR Center<ExternalLink className="w-3 h-3" /></button>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-warning-light rounded-lg border border-warning-light">
              <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-warning font-semibold text-sm mb-0.5">2 blockers &gt;48h</div>
                <div className="text-warning text-xs font-medium mb-1">&rarr; Mobile launch delayed 2 weeks</div>
                <button onClick={() => toast('TODO: Not implemented — would navigate to Initiatives Hub')} className="text-warning hover:text-warning text-xs font-medium flex items-center gap-1">View in Initiatives Hub<ExternalLink className="w-3 h-3" /></button>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-info-light rounded-lg border border-info-light">
              <Clock className="w-5 h-5 text-info flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="text-info font-semibold text-sm mb-0.5">1 initiative slip</div>
                <div className="text-info text-xs font-medium mb-1">&rarr; Q1 goal in jeopardy</div>
                <button onClick={() => toast('TODO: Not implemented — would navigate to Strategy Room')} className="text-info hover:text-info text-xs font-medium flex items-center gap-1">View in Strategy Room<ExternalLink className="w-3 h-3" /></button>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-edge space-y-2">
            <div className="flex items-center justify-between text-xs"><span className="text-ink-secondary">Top driver (7d):</span><span className="text-danger-text font-medium">Missed check-ins &uarr; +3 (Engineering)</span></div>
            <div className="flex items-center justify-between text-xs"><span className="text-ink-secondary">Top win (7d):</span><span className="text-success-text font-medium">Blockers resolved &uarr; +6</span></div>
          </div>
        </div>

        {/* Action Center */}
        <div className="bg-gradient-to-br from-brand via-brand-hover to-brand-active rounded-2xl p-6 shadow-[var(--shadow-elevated)] text-[var(--white)] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-[rgba(255,255,255,0.1)] rounded-full blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-4 h-4" />
              <span className="text-[rgba(255,255,255,0.9)] text-xs font-medium uppercase tracking-wide">Action Required</span>
            </div>
            <div className="text-5xl font-bold mb-2">{metrics.totalRules > 0 ? Math.max(1, metrics.totalRules - metrics.enabledRules) : 3}</div>
            <div className="text-[rgba(255,255,255,0.8)] text-sm mb-6">{metrics.totalRules > 0 ? 'Rules need attention (disabled/draft)' : 'Critical issues need your decision'}</div>
            <button className="w-full py-3 bg-surface-0 text-brand rounded-xl hover:bg-surface-1 transition-all font-semibold shadow-[var(--shadow-card-hover)] mb-3" onClick={() => setShowFixIssuesModal(true)}>
              Fix {metrics.totalRules > 0 ? Math.max(1, metrics.totalRules - metrics.enabledRules) : 3} Issues Now
            </button>
            <div className="text-[rgba(255,255,255,0.7)] text-xs text-center">{metrics.enabledRules} rules active &bull; {metrics.totalTriggers} triggers this week</div>
            <div className="mt-6 pt-6 border-t border-[rgba(255,255,255,0.2)]">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-[rgba(255,255,255,0.8)]">Time saved this week</span>
                <span className="font-semibold">~{Math.round(metrics.totalTriggers * 0.2)} hours</span>
              </div>
              <button onClick={() => setShowTimeSavedModal(true)} className="text-[rgba(255,255,255,0.6)] text-xs hover:text-[rgba(255,255,255,0.9)] transition-colors text-left w-full cursor-pointer hover:underline">
                {metrics.totalTriggers} triggers auto-resolved before escalation
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Intelligence Feed */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-ink text-xl font-semibold mb-1">Intelligence Feed</h3>
            <p className="text-ink-muted text-sm">Cross-module signals requiring executive attention</p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => toast('TODO: Not implemented — would filter issues by module')} className="text-ink-secondary hover:text-ink text-sm font-medium">Filter by Module</button>
            <button onClick={() => toast('TODO: Not implemented — would show all critical issues')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View All ({metrics.totalRules})<ArrowRight className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4">
          {/* Critical Item 1 */}
          <div className="bg-surface-0 rounded-xl border-2 border-danger p-6 hover:shadow-[var(--shadow-elevated)] transition-all cursor-pointer group relative">
            <div className="absolute top-4 right-4">
              <span className="px-3 py-1 bg-danger-light text-danger-text rounded-full text-xs font-bold uppercase tracking-wide">Urgent &bull; 2h SLA</span>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-danger-light rounded-xl flex items-center justify-center flex-shrink-0"><AlertCircle className="w-7 h-7 text-danger-text" /></div>
              <div className="flex-1 pr-32">
                <div className="flex items-center gap-2 mb-2"><span className="text-xs font-medium text-ink-muted uppercase tracking-wide">KR Center &times; Weekly Check-in &times; Team Intelligence</span></div>
                <h4 className="text-ink font-bold text-xl mb-3">Revenue KR: &ldquo;Close $2M Enterprise ARR&rdquo; &mdash; 12 days overdue</h4>
                <div className="mb-3 inline-flex items-center gap-2 px-3 py-1.5 bg-brand-light border border-brand rounded-lg">
                  <Zap className="w-3.5 h-3.5 text-brand" />
                  <span className="text-xs text-brand-active"><span className="font-semibold">Triggered by:</span> Weekly Reality &rarr; <span className="font-semibold"> Policy:</span> Critical &rarr; <span className="font-semibold"> SLA:</span> 48h</span>
                </div>
                <div className="bg-surface-1 rounded-lg p-4 mb-4 space-y-2">
                  {[
                    { label: 'Impact', text: '$2.4M pipeline at risk (3 deals stalled in "Negotiation" for 14+ days)' },
                    { label: 'Owner', text: 'Sarah Chen (Sales) — Last update: Dec 8 (SLA: weekly)' },
                    { label: 'Escalation', text: 'Auto-escalated to you after 48h manager silence (Policy: Critical)' },
                    { label: 'Cross-impact', text: 'Blocking 2 other Q1 objectives (see Strategy Room)' },
                  ].map(item => (
                    <div key={item.label} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-ink-muted rounded-full mt-2" />
                      <div className="flex-1"><span className="text-ink font-medium text-sm">{item.label}: </span><span className="text-ink-secondary text-sm">{item.text}</span></div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-6 text-sm mb-4 pb-4 border-b border-edge">
                  <div className="flex items-center gap-2 text-ink-secondary"><Users className="w-4 h-4" /><span>Owner: Sarah Chen (Sales)</span></div>
                  <div className="flex items-center gap-2 text-ink-muted"><Clock className="w-4 h-4" /><span>Escalated 2h ago</span></div>
                  <div className="flex items-center gap-2 text-danger-text font-medium"><AlertTriangle className="w-4 h-4" /><span>10-15 min to resolve</span></div>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => { toast('TODO: Not implemented — would send notification to Sarah Chen (Sales)'); setOpenDropdown(null); }} className={priBtnCls}><Bell className="w-4 h-4" />Notify Owner</button>
                  <button onClick={() => toast('TODO: Not implemented — would create Jira task for Revenue KR Follow-up')} className={secBtnCls}><CheckSquare className="w-4 h-4" />Create Task</button>
                  <button onClick={() => toast('TODO: Not implemented — would schedule huddle with Sarah Chen')} className={secBtnCls}><Calendar className="w-4 h-4" />Schedule Huddle</button>
                  <div className="relative">
                    <button onClick={() => setOpenDropdown(openDropdown === 'item1' ? null : 'item1')} className="p-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all"><MoreVertical className="w-4 h-4" /></button>
                    {openDropdown === 'item1' && (
                      <div className={dropdownCls}>
                        <button onClick={() => { toast('TODO: Not implemented — would initiate owner reassignment'); setOpenDropdown(null); }} className={dropItemCls}><UserPlus className="w-4 h-4" />Reassign Owner</button>
                        <button onClick={() => { toast('TODO: Not implemented — would escalate to Sarah Chen\'s manager'); setOpenDropdown(null); }} className={dropItemCls}><ArrowUp className="w-4 h-4" />Escalate to Manager</button>
                        <button onClick={() => { toast('TODO: Not implemented — would require update and notify owner'); setOpenDropdown(null); }} className={dropItemCls}><FileText className="w-4 h-4" />Require Update</button>
                        <div className="border-t border-edge my-1" />
                        <button onClick={() => { toast('TODO: Not implemented — would snooze issue for 48 hours'); setOpenDropdown(null); }} className={dropItemCls}><Clock className="w-4 h-4" />Snooze 48h</button>
                        <button onClick={() => { toast('Issue dismissed', { icon: '🔕' }); setOpenDropdown(null); }} className={dropItemCls}><EyeOff className="w-4 h-4" />Dismiss</button>
                      </div>
                    )}
                  </div>
                  <div className="flex-1" />
                  <button onClick={() => navigate('/evidence/INC-2401')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View Details<ExternalLink className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          </div>

          {/* Critical Item 2 */}
          <div className="bg-surface-0 rounded-xl border-l-4 border-warning border border-warning p-6 hover:shadow-[var(--shadow-elevated)] transition-all cursor-pointer group relative">
            <div className="absolute top-4 right-4"><span className="px-3 py-1 bg-warning-light text-warning rounded-full text-xs font-bold uppercase tracking-wide">Today</span></div>
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-warning-light rounded-xl flex items-center justify-center flex-shrink-0"><Target className="w-7 h-7 text-warning" /></div>
              <div className="flex-1 pr-24">
                <div className="flex items-center gap-2 mb-2"><span className="text-xs font-medium text-ink-muted uppercase tracking-wide">Initiatives Hub &times; Risk Center &times; Team Intelligence</span></div>
                <h4 className="text-ink font-bold text-xl mb-3">Initiative: &ldquo;Mobile App v2 Launch&rdquo; blocked for 14+ days</h4>
                <div className="mb-3 inline-flex items-center gap-2 px-3 py-1.5 bg-brand-light border border-brand rounded-lg">
                  <Zap className="w-3.5 h-3.5 text-brand" />
                  <span className="text-xs text-brand-active"><span className="font-semibold">Triggered by:</span> Blocked SLA &rarr; <span className="font-semibold"> Policy:</span> Critical &rarr; <span className="font-semibold"> SLA:</span> 48h</span>
                </div>
                <div className="bg-surface-1 rounded-lg p-4 mb-4 space-y-2">
                  {[
                    { label: 'Impact', text: 'Mobile launch delayed 2 weeks → Q1 revenue target at risk ($800K)' },
                    { label: 'Blocker', text: '"API Redesign" dependency (Engineering) — Not started, no timeline' },
                    { label: 'Owner', text: 'Marcus Kim (Eng) — Last escalation: 4h ago (auto-triggered)' },
                    { label: 'Risk score', text: 'High (8.2/10) — see Risk Center OS' },
                  ].map(item => (
                    <div key={item.label} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-ink-muted rounded-full mt-2" />
                      <div className="flex-1"><span className="text-ink font-medium text-sm">{item.label}: </span><span className={`text-sm ${item.label === 'Risk score' ? 'text-warning font-semibold' : 'text-ink-secondary'}`}>{item.text}</span></div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-6 text-sm mb-4 pb-4 border-b border-edge">
                  <div className="flex items-center gap-2 text-ink-secondary"><Users className="w-4 h-4" /><span>Owner: Marcus Kim (Eng)</span></div>
                  <div className="flex items-center gap-2 text-ink-muted"><Clock className="w-4 h-4" /><span>Auto-escalated 4h ago</span></div>
                  <div className="flex items-center gap-2 text-warning font-medium"><AlertTriangle className="w-4 h-4" /><span>30 min to unblock</span></div>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => { toast('TODO: Not implemented — would send notification to Marcus Kim (Eng)'); setOpenDropdown(null); }} className={priBtnCls}><Bell className="w-4 h-4" />Notify Owner</button>
                  <button onClick={() => toast('TODO: Not implemented — would create Jira task to Unblock Mobile App v2')} className={secBtnCls}><CheckSquare className="w-4 h-4" />Create Task</button>
                  <button onClick={() => toast('TODO: Not implemented — would schedule huddle with Marcus Kim')} className={secBtnCls}><Calendar className="w-4 h-4" />Schedule Huddle</button>
                  <div className="relative">
                    <button onClick={() => setOpenDropdown(openDropdown === 'item2' ? null : 'item2')} className="p-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all"><MoreVertical className="w-4 h-4" /></button>
                    {openDropdown === 'item2' && (
                      <div className={dropdownCls}>
                        <button onClick={() => { toast('TODO: Not implemented — would initiate owner reassignment'); setOpenDropdown(null); }} className={dropItemCls}><UserPlus className="w-4 h-4" />Reassign Owner</button>
                        <button onClick={() => { toast('TODO: Not implemented — would escalate to Marcus Kim\'s manager'); setOpenDropdown(null); }} className={dropItemCls}><ArrowUp className="w-4 h-4" />Escalate to Manager</button>
                        <button onClick={() => { toast('TODO: Not implemented — would require update and notify owner'); setOpenDropdown(null); }} className={dropItemCls}><FileText className="w-4 h-4" />Require Update</button>
                        <div className="border-t border-edge my-1" />
                        <button onClick={() => { toast('TODO: Not implemented — would snooze issue for 48 hours'); setOpenDropdown(null); }} className={dropItemCls}><Clock className="w-4 h-4" />Snooze 48h</button>
                        <button onClick={() => { toast('Issue dismissed', { icon: '🔕' }); setOpenDropdown(null); }} className={dropItemCls}><EyeOff className="w-4 h-4" />Dismiss</button>
                      </div>
                    )}
                  </div>
                  <div className="flex-1" />
                  <button onClick={() => navigate('/evidence/INC-2395')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View Details<ExternalLink className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          </div>

          {/* Critical Item 3 - Coverage Gap */}
          <div className="bg-surface-0 rounded-xl border border-info p-6 hover:shadow-[var(--shadow-card-hover)] transition-all cursor-pointer group">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-info-light rounded-xl flex items-center justify-center flex-shrink-0"><Zap className="w-7 h-7 text-info" /></div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2"><span className="text-xs font-medium text-ink-muted uppercase tracking-wide">Initiatives Hub &times; Enforcement Center</span></div>
                <h4 className="text-ink font-bold text-lg mb-3">New &ldquo;Product Launch&rdquo; workflow detected &mdash; no enforcement coverage</h4>
                <p className="text-ink-secondary mb-4 leading-relaxed">Engineering team created 8 initiatives under new workflow type. No governance rules configured yet. <span className="font-medium text-ink"> Risk: Work can slip without oversight.</span></p>
                <div className="flex items-center gap-6 text-sm mb-4">
                  <div className="flex items-center gap-2 text-ink-secondary"><Users className="w-4 h-4" /><span>Engineering Team (8 initiatives)</span></div>
                  <div className="flex items-center gap-2 text-ink-muted"><Clock className="w-4 h-4" /><span>Detected 6h ago</span></div>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => { toast.success('Opening rule builder for "Product Launch" workflow...'); navigate('/operating-policies'); }} className={priBtnCls}><Zap className="w-4 h-4" />Create Rules (2 min)</button>
                  <button onClick={() => toast('TODO: Not implemented — would apply Standard Coverage template for 8 initiatives')} className={secBtnCls}><FileText className="w-4 h-4" />Apply Template</button>
                  <div className="relative">
                    <button onClick={() => setOpenDropdown(openDropdown === 'item3' ? null : 'item3')} className="p-2.5 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all"><MoreVertical className="w-4 h-4" /></button>
                    {openDropdown === 'item3' && (
                      <div className={dropdownCls}>
                        <button onClick={() => { toast('TODO: Not implemented — would send notification to Engineering Team Lead'); setOpenDropdown(null); }} className={dropItemCls}><Bell className="w-4 h-4" />Notify Team Lead</button>
                        <button onClick={() => { toast('TODO: Not implemented — would schedule review for this Friday'); setOpenDropdown(null); }} className={dropItemCls}><Calendar className="w-4 h-4" />Schedule Review</button>
                        <div className="border-t border-edge my-1" />
                        <button onClick={() => { toast('TODO: Not implemented — would snooze issue for 48 hours'); setOpenDropdown(null); }} className={dropItemCls}><Clock className="w-4 h-4" />Snooze 48h</button>
                        <button onClick={() => { toast('Issue dismissed', { icon: '🔕' }); setOpenDropdown(null); }} className={dropItemCls}><EyeOff className="w-4 h-4" />Dismiss</button>
                      </div>
                    )}
                  </div>
                  <div className="flex-1" />
                  <button onClick={() => navigate('/operating-policies')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View Details<ExternalLink className="w-4 h-4" /></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* What We Handled */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-ink text-xl font-semibold mb-1">What We Handled This Week</h3>
            <p className="text-ink-muted text-sm">Issues caught and auto-resolved &mdash; you didn't have to deal with these</p>
          </div>
          <button onClick={() => toast('TODO: Not implemented — would share win to #leadership Slack channel')} className={priBtnCls}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" /></svg>
            Share This Win
          </button>
        </div>
        <div className="bg-gradient-to-br from-success-light via-success-light to-surface-0 rounded-2xl border-2 border-success p-8 shadow-[var(--shadow-card)]">
          <div className="flex items-start gap-6">
            <div className="w-20 h-20 bg-gradient-to-br from-success to-success rounded-2xl flex items-center justify-center flex-shrink-0 shadow-[var(--shadow-card-hover)]"><CheckCircle2 className="w-10 h-10 text-[var(--white)]" /></div>
            <div className="flex-1">
              <div className="mb-6">
                <div className="flex items-baseline gap-3 mb-2">
                  <div className="text-6xl font-bold text-ink">{metrics.totalTriggers}</div>
                  <div className="flex items-center gap-2 bg-success-light px-3 py-1 rounded-full"><TrendingDown className="w-4 h-4 text-success-text" /><span className="text-success-text font-semibold text-sm">&darr;38% vs last week</span></div>
                </div>
                <p className="text-ink-secondary text-xl font-medium">policy triggers caught this week</p>
                <p className="text-ink-secondary text-sm mt-2">Translation: <span className="font-semibold text-ink">~{Math.round(metrics.totalTriggers * 0.2)}h saved</span> from {metrics.liveRules} live rules across {metrics.teams.size} teams</p>
              </div>
              <div className="grid grid-cols-3 gap-4 mb-6">
                {[
                  { value: '18', label: 'Stale updates', sub: 'Auto-collected from owners', tip: 'Auto-collected updates', tipDetail: 'Engineering: 8 KRs • Sales: 6 KRs • Product: 4 KRs', tipSub: 'System automatically requested status from owners who missed weekly check-ins', saved: 'Saved ~3 hours of follow-up' },
                  { value: '12', label: 'Stalled deals', sub: 'Moved to next stage', tip: 'Deal acceleration', tipDetail: 'Average stall time reduced from 18 days → 4 days', tipSub: 'Enforcement rules auto-nudged owners to progress deals through pipeline stages', saved: '$1.8M pipeline accelerated' },
                  { value: '12', label: 'Blockers', sub: 'Resolved pre-escalation', tip: 'Proactive resolution', tipDetail: 'Engineering: 7 • Product: 3 • Sales: 2', tipSub: 'Blockers resolved by owners within SLA, preventing executive escalation', saved: 'Saved ~5 hours of meetings' },
                ].map((card, idx) => (
                  <div key={idx} className="bg-surface-0 rounded-xl p-5 border-2 border-edge hover:border-success transition-all cursor-pointer group relative">
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="relative group/tooltip">
                        <Info className="w-4 h-4 text-ink-muted" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover/tooltip:block z-10 w-64">
                          <div className={tooltipCls + " !whitespace-normal"}>
                            <div className="font-semibold mb-1">{card.tip}</div>
                            <div className="mb-2">{card.tipDetail}</div>
                            <div className="text-ink-faint">{card.tipSub}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-3xl font-bold text-ink mb-2">{card.value}</div>
                    <div className="text-ink-secondary font-medium text-sm mb-1">{card.label}</div>
                    <div className="text-ink-secondary text-xs">{card.sub}</div>
                    <div className="mt-3 pt-3 border-t border-edge opacity-0 group-hover:opacity-100 transition-opacity"><div className="text-xs text-success-text font-medium">{card.saved}</div></div>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-success-text bg-success-light px-4 py-2.5 rounded-lg border border-success"><TrendingUp className="w-5 h-5" /><span className="font-semibold">60% fewer fire drills vs last month</span></div>
                <button onClick={() => setShowTimelineModal(true)} className="text-brand hover:text-brand font-semibold flex items-center gap-2 px-4 py-2.5 hover:bg-brand-light rounded-lg transition-all">View Full Timeline<ArrowRight className="w-4 h-4" /></button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Is Execution Getting Better? */}
      <div>
        <div className="flex items-center justify-between mb-5">
          <div><h3 className="text-ink text-xl mb-1">Is Execution Getting Better?</h3><p className="text-ink-muted text-sm">Key trends over the last 30 days</p></div>
        </div>
        <div className="grid grid-cols-4 gap-5">
          {[
            { key: 'velocity' as const, label: 'Velocity', value: '↑ 24%', sub: 'Tasks completed per week', pct: 76, Icon: TrendingUp, grad: 'from-success to-success' },
            { key: 'firedrills' as const, label: 'Fire Drills', value: '↓ 60%', sub: 'Urgent escalations reduced', pct: 40, Icon: TrendingDown, grad: 'from-info to-info' },
            { key: 'ontime' as const, label: 'On-time Delivery', value: '87%', sub: 'Projects hitting deadlines', pct: 87, Icon: TrendingUp, grad: 'from-brand to-brand' },
            { key: 'response' as const, label: 'Response Time', value: '2.4h', sub: 'Avg time to address issues', pct: 65, Icon: TrendingDown, grad: 'from-brand to-brand' },
          ].map(m => (
            <div key={m.key} onClick={() => setShowMetricModal(m.key)} className="bg-surface-0 rounded-xl border border-edge p-6 hover:shadow-[var(--shadow-card-hover)] transition-all cursor-pointer group relative">
              <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity"><BarChart3 className="w-4 h-4 text-brand" /></div>
              <div className="flex items-center justify-between mb-4"><span className="text-ink-secondary text-sm font-medium">{m.label}</span><m.Icon className="w-5 h-5 text-success-text" /></div>
              <div className="text-3xl font-semibold text-ink mb-2">{m.value}</div>
              <p className="text-ink-secondary text-sm">{m.sub}</p>
              <div className="mt-4 h-2 bg-surface-2 rounded-full overflow-hidden"><div className={`h-full bg-gradient-to-r ${m.grad} rounded-full`} style={{ width: `${m.pct}%` }} /></div>
              <div className="mt-3 text-xs text-ink-muted opacity-0 group-hover:opacity-100 transition-opacity">Click for detailed breakdown &rarr;</div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-surface-0 rounded-xl border border-edge p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-ink font-medium">Quick Actions</h3>
          <div className="relative group"><HelpCircle className="w-4 h-4 text-ink-muted cursor-pointer" /><div className="absolute bottom-full right-0 mb-2 hidden group-hover:block z-10 w-64"><div className={tooltipCls + " !whitespace-normal"}>One-click actions for common executive tasks</div></div></div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <button onClick={() => setShowExportModal(true)} className="px-5 py-3 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-medium flex items-center justify-center gap-2 group relative">
            <Download className="w-4 h-4" />Export Board Report
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-10 w-56"><div className={tooltipCls + " !whitespace-normal"}>Download PDF/Excel with all metrics, trends, and action items</div></div>
          </button>
          <button onClick={() => toast('TODO: Not implemented — would create review meeting invite')} className="px-5 py-3 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all text-sm font-medium flex items-center justify-center gap-2 group relative">
            <Calendar className="w-4 h-4" />Schedule Review Meeting
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-10 w-56"><div className={tooltipCls + " !whitespace-normal"}>Auto-create calendar event with key stakeholders and pre-populated agenda</div></div>
          </button>
          <button onClick={() => toast('TODO: Not implemented — would share summary with leadership via Slack & email')} className="px-5 py-3 border border-edge text-ink-secondary rounded-lg hover:bg-surface-1 transition-all text-sm font-medium flex items-center justify-center gap-2 group relative">
            <Share2 className="w-4 h-4" />Share with Leadership
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block z-10 w-56"><div className={tooltipCls + " !whitespace-normal"}>Send executive summary via email or Slack to leadership team</div></div>
          </button>
        </div>
      </div>

      {/* Team Performance Modal */}
      {showTeamModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowTeamModal(null)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-3xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className={`p-6 border-b ${showTeamModal === 'engineering' ? 'bg-success-light border-success' : 'bg-danger-light border-danger'}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${showTeamModal === 'engineering' ? 'bg-success-light' : 'bg-danger-light'}`}><Users className={`w-6 h-6 ${showTeamModal === 'engineering' ? 'text-success-text' : 'text-danger-text'}`} /></div>
                  <div><h3 className="text-ink text-xl font-bold">{showTeamModal === 'engineering' ? 'Engineering Team' : 'Sales Team'}</h3><p className="text-ink-secondary text-sm">Performance details (Last 7 days)</p></div>
                </div>
                <button onClick={() => setShowTeamModal(null)} className="p-2 hover:bg-[rgba(255,255,255,0.5)] rounded-lg transition-colors"><X className="w-5 h-5 text-ink-secondary" /></button>
              </div>
              <div className="flex items-center gap-4">
                <div className={`px-4 py-2 rounded-lg ${showTeamModal === 'engineering' ? 'bg-success-light' : 'bg-danger-light'}`}>
                  <div className="text-xs text-ink-secondary mb-1">Health Score Change</div>
                  <div className={`text-2xl font-bold flex items-center gap-2 ${showTeamModal === 'engineering' ? 'text-success-text' : 'text-danger-text'}`}>{showTeamModal === 'engineering' ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}{showTeamModal === 'engineering' ? '+18' : '-12'}</div>
                </div>
                <div className="flex-1 grid grid-cols-3 gap-3">
                  {[{ l: 'Blockers Cleared', v: showTeamModal === 'engineering' ? '12' : '2' }, { l: 'Missed Check-ins', v: showTeamModal === 'engineering' ? '0' : '3' }, { l: 'Overdue KRs', v: showTeamModal === 'engineering' ? '0' : '2' }].map(s => (
                    <div key={s.l}><div className="text-xs text-ink-secondary mb-1">{s.l}</div><div className="text-lg font-bold text-ink">{s.v}</div></div>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-250px)]">
              {showTeamModal === 'engineering' ? (
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center gap-2 mb-4"><CheckCircle2 className="w-5 h-5 text-success-text" /><h4 className="text-ink font-semibold text-lg">12 Blockers Cleared</h4></div>
                    <div className="space-y-3">
                      {[
                        { title: 'API Integration blocked Mobile Launch', resolved: '2 hours ago', impact: 'Unblocked $800K initiative' },
                        { title: 'Database migration dependency', resolved: '4 hours ago', impact: 'Unblocked 3 projects' },
                        { title: 'CI/CD pipeline failure blocking deployments', resolved: '1 day ago', impact: 'Restored deployment velocity' },
                        { title: 'Cross-team dependency on Design System', resolved: '1 day ago', impact: 'Unblocked Product team' },
                        { title: 'Infrastructure capacity issue', resolved: '2 days ago', impact: 'Prevented service outage' },
                        { title: 'Legacy code refactor blocker', resolved: '2 days ago', impact: 'Unblocked Q1 technical debt goal' },
                        { title: 'Security audit requirement', resolved: '3 days ago', impact: 'Cleared compliance gate' },
                        { title: 'Third-party API rate limit', resolved: '3 days ago', impact: 'Restored integration uptime' },
                        { title: 'Test environment configuration', resolved: '4 days ago', impact: 'Unblocked QA team' },
                        { title: 'Documentation dependency', resolved: '4 days ago', impact: 'Enabled customer onboarding' },
                        { title: 'Monitoring alert setup', resolved: '5 days ago', impact: 'Improved incident response' },
                        { title: 'Performance bottleneck in checkout flow', resolved: '6 days ago', impact: 'Prevented revenue loss' },
                      ].map((blocker, index) => (
                        <div key={index} className="p-4 bg-surface-1 rounded-lg border border-edge hover:border-success transition-all">
                          <div className="flex items-start justify-between mb-2"><div className="font-medium text-ink text-sm">{blocker.title}</div><span className="text-xs text-ink-muted whitespace-nowrap ml-3">{blocker.resolved}</span></div>
                          <div className="text-success-text text-xs font-medium bg-success-light inline-block px-2 py-1 rounded">&check; {blocker.impact}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-4 bg-brand-light border border-brand rounded-xl">
                    <div className="flex items-start gap-3"><Brain className="w-5 h-5 text-brand flex-shrink-0 mt-0.5" /><div><div className="font-semibold text-brand-active mb-1">Why This Matters</div><p className="text-brand-active text-sm">Engineering cleared 12 blockers proactively, preventing them from escalating to you. This directly contributed to the +18 health score improvement and saved approximately <span className="font-bold"> 6+ hours of executive time</span> this week.</p></div></div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center gap-2 mb-4"><AlertTriangle className="w-5 h-5 text-danger-text" /><h4 className="text-ink font-semibold text-lg">3 Missed Check-ins</h4></div>
                    <div className="space-y-3">
                      {[
                        { owner: 'Sarah Chen', kr: 'Close $2M Enterprise ARR', lastUpdate: 'Dec 8 (12 days ago)', impact: '$2.4M pipeline at risk' },
                        { owner: 'Mike Rodriguez', kr: 'Expand EMEA market share', lastUpdate: 'Dec 10 (10 days ago)', impact: '5 deals stalled' },
                        { owner: 'Jennifer Park', kr: 'Improve sales cycle time', lastUpdate: 'Dec 12 (8 days ago)', impact: 'No visibility on Q1 progress' },
                      ].map((item, index) => (
                        <div key={index} className="p-4 bg-danger-light rounded-lg border-2 border-danger">
                          <div className="flex items-start justify-between mb-2"><div><div className="font-semibold text-ink text-sm mb-1">{item.owner}</div><div className="text-ink-secondary text-sm">KR: &ldquo;{item.kr}&rdquo;</div></div></div>
                          <div className="flex items-center justify-between mt-3 pt-3 border-t border-danger"><span className="text-danger-text text-xs font-medium">Last update: {item.lastUpdate}</span><span className="text-danger-text text-xs font-bold bg-danger-light px-2 py-1 rounded">{item.impact}</span></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-4"><Clock className="w-5 h-5 text-warning" /><h4 className="text-ink font-semibold text-lg">2 Overdue KRs</h4></div>
                    <div className="space-y-3">
                      {[
                        { kr: 'Hit $500K MRR by end of Q1', owner: 'Sarah Chen', daysOverdue: 14, status: 'At risk' },
                        { kr: 'Close 10 enterprise deals', owner: 'Mike Rodriguez', daysOverdue: 7, status: 'Behind schedule' },
                      ].map((kr, index) => (
                        <div key={index} className="p-4 bg-warning-light rounded-lg border-2 border-warning">
                          <div className="font-semibold text-ink mb-2">&ldquo;{kr.kr}&rdquo;</div>
                          <div className="flex items-center justify-between"><span className="text-ink-secondary text-sm">Owner: {kr.owner}</span><div className="flex items-center gap-3"><span className="text-warning text-xs font-medium">{kr.daysOverdue} days overdue</span><span className="text-warning text-xs font-bold bg-warning-light px-2 py-1 rounded">{kr.status}</span></div></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-4 bg-brand-light border border-brand rounded-xl">
                    <div className="flex items-start gap-3"><Shield className="w-5 h-5 text-brand flex-shrink-0 mt-0.5" /><div><div className="font-semibold text-brand-active mb-2">Recommended Action</div><p className="text-brand-active text-sm mb-3">Sales team's -12 score is driven by 3 missed check-ins and 2 overdue KRs, putting <span className="font-bold"> $2.4M in pipeline at risk</span>. This requires immediate attention.</p>
                      <button onClick={() => { toast('TODO: Not implemented — would schedule 1:1 meeting with Sales VP'); setShowTeamModal(null); }} className="px-4 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-semibold">Schedule 1:1 with Sales VP</button>
                    </div></div>
                  </div>
                </div>
              )}
            </div>
            <div className="p-6 border-t border-edge bg-surface-1 flex items-center justify-between">
              <button onClick={() => toast('TODO: Not implemented — would navigate to Team Intelligence')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View in Team Intelligence<ExternalLink className="w-4 h-4" /></button>
              <div className="flex items-center gap-3">
                <button onClick={() => setShowTeamModal(null)} className="px-4 py-2 border border-edge text-ink-secondary rounded-lg hover:bg-surface-0 transition-all text-sm font-medium">Close</button>
                <button onClick={() => { toast('TODO: Not implemented — would initiate action for ' + (showTeamModal === 'engineering' ? 'Engineering' : 'Sales') + ' team'); setShowTeamModal(null); }} className="px-4 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-semibold">Take Action</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fix Issues Modal */}
      {showFixIssuesModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowFixIssuesModal(false)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-3xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b bg-danger-light border-danger">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3"><div className="w-12 h-12 rounded-xl flex items-center justify-center bg-danger-light"><AlertTriangle className="w-6 h-6 text-danger-text" /></div><div><h3 className="text-ink text-xl font-bold">Fix 3 Critical Issues Now</h3><p className="text-ink-secondary text-sm">Resolve these issues to unblock your pipeline</p></div></div>
                <button onClick={() => setShowFixIssuesModal(false)} className="p-2 hover:bg-[rgba(255,255,255,0.5)] rounded-lg transition-colors"><X className="w-5 h-5 text-ink-secondary" /></button>
              </div>
              <div className="flex items-center gap-4">
                <div className="px-4 py-2 rounded-lg bg-danger-light"><div className="text-xs text-ink-secondary mb-1">Health Score Change</div><div className="text-2xl font-bold flex items-center gap-2 text-danger-text"><TrendingDown className="w-5 h-5" />-12</div></div>
                <div className="flex-1 grid grid-cols-3 gap-3">
                  {[{ l: 'Blockers Cleared', v: '2' }, { l: 'Missed Check-ins', v: '3' }, { l: 'Overdue KRs', v: '2' }].map(s => (<div key={s.l}><div className="text-xs text-ink-secondary mb-1">{s.l}</div><div className="text-lg font-bold text-ink">{s.v}</div></div>))}
                </div>
              </div>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-250px)]">
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-4"><AlertTriangle className="w-5 h-5 text-danger-text" /><h4 className="text-ink font-semibold text-lg">3 Missed Check-ins</h4></div>
                  <div className="space-y-3">
                    {[
                      { owner: 'Sarah Chen', kr: 'Close $2M Enterprise ARR', lastUpdate: 'Dec 8 (12 days ago)', impact: '$2.4M pipeline at risk' },
                      { owner: 'Mike Rodriguez', kr: 'Expand EMEA market share', lastUpdate: 'Dec 10 (10 days ago)', impact: '5 deals stalled' },
                      { owner: 'Jennifer Park', kr: 'Improve sales cycle time', lastUpdate: 'Dec 12 (8 days ago)', impact: 'No visibility on Q1 progress' },
                    ].map((item, index) => (
                      <div key={index} className="p-4 bg-danger-light rounded-lg border-2 border-danger">
                        <div className="flex items-start justify-between mb-2"><div><div className="font-semibold text-ink text-sm mb-1">{item.owner}</div><div className="text-ink-secondary text-sm">KR: &ldquo;{item.kr}&rdquo;</div></div></div>
                        <div className="flex items-center justify-between mt-3 pt-3 border-t border-danger"><span className="text-danger-text text-xs font-medium">Last update: {item.lastUpdate}</span><span className="text-danger-text text-xs font-bold bg-danger-light px-2 py-1 rounded">{item.impact}</span></div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-4"><Clock className="w-5 h-5 text-warning" /><h4 className="text-ink font-semibold text-lg">2 Overdue KRs</h4></div>
                  <div className="space-y-3">
                    {[
                      { kr: 'Hit $500K MRR by end of Q1', owner: 'Sarah Chen', daysOverdue: 14, status: 'At risk' },
                      { kr: 'Close 10 enterprise deals', owner: 'Mike Rodriguez', daysOverdue: 7, status: 'Behind schedule' },
                    ].map((kr, index) => (
                      <div key={index} className="p-4 bg-warning-light rounded-lg border-2 border-warning">
                        <div className="font-semibold text-ink mb-2">&ldquo;{kr.kr}&rdquo;</div>
                        <div className="flex items-center justify-between"><span className="text-ink-secondary text-sm">Owner: {kr.owner}</span><div className="flex items-center gap-3"><span className="text-warning text-xs font-medium">{kr.daysOverdue} days overdue</span><span className="text-warning text-xs font-bold bg-warning-light px-2 py-1 rounded">{kr.status}</span></div></div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-4"><CheckCircle2 className="w-5 h-5 text-success-text" /><h4 className="text-ink font-semibold text-lg">2 Blockers Cleared</h4></div>
                  <div className="space-y-3">
                    {[
                      { title: 'API Integration blocked Mobile Launch', resolved: '2 hours ago', impact: 'Unblocked $800K initiative' },
                      { title: 'Database migration dependency', resolved: '4 hours ago', impact: 'Unblocked 3 projects' },
                    ].map((blocker, index) => (
                      <div key={index} className="p-4 bg-surface-1 rounded-lg border border-edge hover:border-success transition-all">
                        <div className="flex items-start justify-between mb-2"><div className="font-medium text-ink text-sm">{blocker.title}</div><span className="text-xs text-ink-muted whitespace-nowrap ml-3">{blocker.resolved}</span></div>
                        <div className="text-success-text text-xs font-medium bg-success-light inline-block px-2 py-1 rounded">&check; {blocker.impact}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-edge bg-surface-1 flex items-center justify-between">
              <button onClick={() => toast('TODO: Not implemented — would navigate to Team Intelligence')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View in Team Intelligence<ExternalLink className="w-4 h-4" /></button>
              <div className="flex items-center gap-3">
                <button onClick={() => setShowFixIssuesModal(false)} className="px-4 py-2 border border-edge text-ink-secondary rounded-lg hover:bg-surface-0 transition-all text-sm font-medium">Close</button>
                <button onClick={() => { toast('TODO: Not implemented — would address all 3 issues and send notifications'); setShowFixIssuesModal(false); }} className="px-4 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-semibold">Take Action</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Time Saved Modal — mirrors Fix Issues but with success data */}
      {showTimeSavedModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowTimeSavedModal(false)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-3xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b bg-success-light border-success">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3"><div className="w-12 h-12 rounded-xl flex items-center justify-center bg-success-light"><CheckCircle2 className="w-6 h-6 text-success-text" /></div><div><h3 className="text-ink text-xl font-bold">Time Saved This Week</h3><p className="text-ink-secondary text-sm">42 issues auto-resolved before escalation</p></div></div>
                <button onClick={() => setShowTimeSavedModal(false)} className="p-2 hover:bg-[rgba(255,255,255,0.5)] rounded-lg transition-colors"><X className="w-5 h-5 text-ink-secondary" /></button>
              </div>
              <div className="flex items-center gap-4">
                <div className="px-4 py-2 rounded-lg bg-success-light"><div className="text-xs text-ink-secondary mb-1">Health Score Change</div><div className="text-2xl font-bold flex items-center gap-2 text-success-text"><TrendingUp className="w-5 h-5" />+18</div></div>
                <div className="flex-1 grid grid-cols-3 gap-3">
                  {[{ l: 'Blockers Cleared', v: '12' }, { l: 'Missed Check-ins', v: '0' }, { l: 'Overdue KRs', v: '0' }].map(s => (<div key={s.l}><div className="text-xs text-ink-secondary mb-1">{s.l}</div><div className="text-lg font-bold text-ink">{s.v}</div></div>))}
                </div>
              </div>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-250px)]">
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-4"><CheckCircle2 className="w-5 h-5 text-success-text" /><h4 className="text-ink font-semibold text-lg">12 Blockers Cleared</h4></div>
                  <div className="space-y-3">
                    {[
                      { title: 'API Integration blocked Mobile Launch', resolved: '2 hours ago', impact: 'Unblocked $800K initiative' },
                      { title: 'Database migration dependency', resolved: '4 hours ago', impact: 'Unblocked 3 projects' },
                      { title: 'CI/CD pipeline failure blocking deployments', resolved: '1 day ago', impact: 'Restored deployment velocity' },
                      { title: 'Cross-team dependency on Design System', resolved: '1 day ago', impact: 'Unblocked Product team' },
                      { title: 'Infrastructure capacity issue', resolved: '2 days ago', impact: 'Prevented service outage' },
                      { title: 'Legacy code refactor blocker', resolved: '2 days ago', impact: 'Unblocked Q1 technical debt goal' },
                      { title: 'Security audit requirement', resolved: '3 days ago', impact: 'Cleared compliance gate' },
                      { title: 'Third-party API rate limit', resolved: '3 days ago', impact: 'Restored integration uptime' },
                      { title: 'Test environment configuration', resolved: '4 days ago', impact: 'Unblocked QA team' },
                      { title: 'Documentation dependency', resolved: '4 days ago', impact: 'Enabled customer onboarding' },
                      { title: 'Monitoring alert setup', resolved: '5 days ago', impact: 'Improved incident response' },
                      { title: 'Performance bottleneck in checkout flow', resolved: '6 days ago', impact: 'Prevented revenue loss' },
                    ].map((blocker, index) => (
                      <div key={index} className="p-4 bg-surface-1 rounded-lg border border-edge hover:border-success transition-all">
                        <div className="flex items-start justify-between mb-2"><div className="font-medium text-ink text-sm">{blocker.title}</div><span className="text-xs text-ink-muted whitespace-nowrap ml-3">{blocker.resolved}</span></div>
                        <div className="text-success-text text-xs font-medium bg-success-light inline-block px-2 py-1 rounded">&check; {blocker.impact}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-edge bg-surface-1 flex items-center justify-between">
              <button onClick={() => toast('TODO: Not implemented — would navigate to Team Intelligence')} className="text-brand hover:text-brand text-sm font-medium flex items-center gap-1">View in Team Intelligence<ExternalLink className="w-4 h-4" /></button>
              <div className="flex items-center gap-3">
                <button onClick={() => setShowTimeSavedModal(false)} className="px-4 py-2 border border-edge text-ink-secondary rounded-lg hover:bg-surface-0 transition-all text-sm font-medium">Close</button>
                <button onClick={() => { toast('TODO: Not implemented — would share detailed breakdown with team'); setShowTimeSavedModal(false); }} className="px-4 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all text-sm font-semibold">Take Action</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Timeline Modal */}
      {showTimelineModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowTimelineModal(false)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-4xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-8 py-6 border-b border-edge flex items-center justify-between bg-gradient-to-r from-brand-light to-info-light">
              <div><h2 className="text-ink text-2xl font-bold mb-1">30-Day Enforcement Timeline</h2><p className="text-ink-secondary text-sm">How enforcement prevented escalations over time</p></div>
              <button onClick={() => setShowTimelineModal(false)} className="p-2 hover:bg-[rgba(255,255,255,0.5)] rounded-lg transition-colors"><X className="w-5 h-5 text-ink-secondary" /></button>
            </div>
            <div className="p-8 overflow-y-auto max-h-[calc(90vh-150px)]">
              <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="bg-success-light border border-success rounded-xl p-5"><div className="text-3xl font-bold text-success-text mb-1">42</div><div className="text-sm text-success-text font-medium">Issues auto-resolved</div><div className="text-xs text-success-text mt-1">Before escalation</div></div>
                <div className="bg-info-light border border-info rounded-xl p-5"><div className="text-3xl font-bold text-info mb-1">~8h</div><div className="text-sm text-info font-medium">Exec time saved</div><div className="text-xs text-info mt-1">Last 7 days</div></div>
                <div className="bg-brand-light border border-brand rounded-xl p-5"><div className="text-3xl font-bold text-brand mb-1">60%</div><div className="text-sm text-brand-active font-medium">Fewer fire drills</div><div className="text-xs text-brand mt-1">vs. last month</div></div>
              </div>
              <div className="space-y-4">
                <h3 className="text-ink font-semibold text-lg mb-4">Key Events (Last 30 Days)</h3>
                {[
                  { week: 'Week 4 (Current)', events: 12, color: 'green', highlight: true, description: 'Engineering cleared 12 blockers proactively' },
                  { week: 'Week 3', events: 8, color: 'blue', highlight: false, description: 'Sales moved 8 stalled deals to next stage' },
                  { week: 'Week 2', events: 14, color: 'green', highlight: false, description: '14 auto-collected updates from missed check-ins' },
                  { week: 'Week 1', events: 8, color: 'purple', highlight: false, description: 'Product team resolved 8 dependency conflicts' },
                ].map((item, index) => (
                  <div key={index} className={`relative pl-8 pb-6 ${index < 3 ? 'border-l-2 border-edge' : ''}`}>
                    <div className={`absolute left-0 top-0 w-4 h-4 rounded-full -ml-[9px] ${item.highlight ? 'bg-success ring-4 ring-success-light' : 'bg-ink-muted'}`} />
                    <div className={`p-4 rounded-xl border-2 ${item.highlight ? 'bg-success-light border-success' : 'bg-surface-1 border-edge'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="text-ink font-semibold">{item.week}</h4>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${item.color === 'green' ? 'bg-success-light text-success-text' : item.color === 'blue' ? 'bg-info-light text-info' : 'bg-brand-light text-brand'}`}>{item.events} actions</span>
                      </div>
                      <p className="text-ink-secondary text-sm">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-8 p-6 bg-gradient-to-r from-brand-light to-info-light border border-brand rounded-xl">
                <h4 className="text-brand-active font-bold mb-3 flex items-center gap-2"><Activity className="w-5 h-5" />Cumulative Impact</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div><span className="text-ink-secondary">Total issues prevented:</span><span className="font-bold text-ink ml-2">42</span></div>
                  <div><span className="text-ink-secondary">Executive time saved:</span><span className="font-bold text-ink ml-2">~32 hours</span></div>
                  <div><span className="text-ink-secondary">Fire drills reduction:</span><span className="font-bold text-success-text ml-2">60% &darr;</span></div>
                  <div><span className="text-ink-secondary">Health score improvement:</span><span className="font-bold text-success-text ml-2">+18 points</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Metric Detail Modal */}
      {showMetricModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowMetricModal(null)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-3xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="px-8 py-6 border-b border-edge flex items-center justify-between bg-gradient-to-r from-brand-light to-info-light">
              <div>
                <h2 className="text-ink text-2xl font-bold mb-1">
                  {showMetricModal === 'velocity' && 'Velocity Breakdown'}
                  {showMetricModal === 'firedrills' && 'Fire Drills Analysis'}
                  {showMetricModal === 'ontime' && 'On-time Delivery Details'}
                  {showMetricModal === 'response' && 'Response Time Metrics'}
                </h2>
                <p className="text-ink-secondary text-sm">Detailed 30-day trend and breakdown</p>
              </div>
              <button onClick={() => setShowMetricModal(null)} className="p-2 hover:bg-[rgba(255,255,255,0.5)] rounded-lg transition-colors"><X className="w-5 h-5 text-ink-secondary" /></button>
            </div>
            <div className="p-8 overflow-y-auto max-h-[calc(90vh-150px)]">
              {showMetricModal === 'velocity' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-success-light border border-success rounded-xl p-5"><div className="text-3xl font-bold text-success-text mb-1">&uarr; 24%</div><div className="text-sm text-success-text font-medium">Overall increase</div></div>
                    <div className="bg-info-light border border-info rounded-xl p-5"><div className="text-3xl font-bold text-info mb-1">127</div><div className="text-sm text-info font-medium">Tasks/week (avg)</div></div>
                    <div className="bg-brand-light border border-brand rounded-xl p-5"><div className="text-3xl font-bold text-brand mb-1">103</div><div className="text-sm text-brand-active font-medium">Last month</div></div>
                  </div>
                  <div>
                    <h4 className="text-ink font-semibold mb-3">By Team</h4>
                    <div className="space-y-3">
                      {[{ team: 'Engineering', current: 54, prev: 42, color: 'green' }, { team: 'Product', current: 38, prev: 31, color: 'blue' }, { team: 'Sales', current: 35, prev: 30, color: 'purple' }].map(item => (
                        <div key={item.team} className="flex items-center justify-between p-4 bg-surface-1 rounded-lg">
                          <div className="flex-1"><div className="text-sm font-semibold text-ink mb-1">{item.team}</div><div className="text-xs text-ink-secondary">{item.current} tasks/week (was {item.prev})</div></div>
                          <div className={`px-3 py-1 rounded-full text-xs font-bold ${item.color === 'green' ? 'bg-success-light text-success-text' : item.color === 'blue' ? 'bg-info-light text-info' : 'bg-brand-light text-brand'}`}>+{Math.round(((item.current - item.prev) / item.prev) * 100)}%</div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-5 bg-gradient-to-r from-success-light to-info-light border border-success rounded-xl">
                    <h4 className="text-success-text font-bold mb-2">What's driving this?</h4>
                    <ul className="space-y-2 text-sm text-ink-secondary">{['12 blockers cleared proactively (Engineering)', 'Fewer context switches from fire drills (-60%)', 'Better focus time through enforcement rules'].map(t => (<li key={t} className="flex items-start gap-2"><CheckCircle2 className="w-4 h-4 text-success-text mt-0.5 flex-shrink-0" /><span>{t}</span></li>))}</ul>
                  </div>
                </div>
              )}
              {showMetricModal === 'firedrills' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-success-light border border-success rounded-xl p-5"><div className="text-3xl font-bold text-success-text mb-1">&darr; 60%</div><div className="text-sm text-success-text font-medium">Reduction</div></div>
                    <div className="bg-info-light border border-info rounded-xl p-5"><div className="text-3xl font-bold text-info mb-1">6</div><div className="text-sm text-info font-medium">This month</div></div>
                    <div className="bg-danger-light border border-danger rounded-xl p-5"><div className="text-3xl font-bold text-danger-text mb-1">15</div><div className="text-sm text-danger-text font-medium">Last month</div></div>
                  </div>
                  <div>
                    <h4 className="text-ink font-semibold mb-3">What counted as fire drills</h4>
                    <div className="space-y-3">
                      {[{ issue: 'Critical blocker escalations', current: 2, prev: 7 }, { issue: 'Urgent unplanned meetings', current: 3, prev: 6 }, { issue: 'Emergency pivots/decisions', current: 1, prev: 2 }].map((item, index) => (
                        <div key={index} className="p-4 bg-surface-1 rounded-lg">
                          <div className="flex items-center justify-between mb-2"><div className="text-sm font-semibold text-ink">{item.issue}</div><div className="flex items-center gap-2"><span className="text-xs text-ink-muted">Was {item.prev}</span><ArrowRight className="w-3 h-3 text-ink-muted" /><span className="text-sm font-bold text-success-text">Now {item.current}</span></div></div>
                          <div className="h-2 bg-edge rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-success to-success rounded-full transition-all" style={{ width: `${(item.current / item.prev) * 100}%` }} /></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-5 bg-gradient-to-r from-info-light to-brand-light border border-info rounded-xl">
                    <h4 className="text-info font-bold mb-2">Why fewer fire drills?</h4>
                    <ul className="space-y-2 text-sm text-ink-secondary">{['Enforcement rules caught issues before they escalated', 'Auto-nudges kept work on track proactively', 'Better visibility prevented last-minute surprises'].map(t => (<li key={t} className="flex items-start gap-2"><Shield className="w-4 h-4 text-info mt-0.5 flex-shrink-0" /><span>{t}</span></li>))}</ul>
                  </div>
                </div>
              )}
              {showMetricModal === 'ontime' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-brand-light border border-brand rounded-xl p-5"><div className="text-3xl font-bold text-brand mb-1">87%</div><div className="text-sm text-brand-active font-medium">On-time rate</div></div>
                    <div className="bg-success-light border border-success rounded-xl p-5"><div className="text-3xl font-bold text-success-text mb-1">26/30</div><div className="text-sm text-success-text font-medium">Projects delivered</div></div>
                    <div className="bg-info-light border border-info rounded-xl p-5"><div className="text-3xl font-bold text-info mb-1">&uarr; 12%</div><div className="text-sm text-info font-medium">vs. last month</div></div>
                  </div>
                  <div>
                    <h4 className="text-ink font-semibold mb-3">By Team Performance</h4>
                    <div className="space-y-3">
                      {[{ team: 'Engineering', ontime: 9, total: 10, pct: 90 }, { team: 'Product', ontime: 8, total: 9, pct: 89 }, { team: 'Sales', ontime: 9, total: 11, pct: 82 }].map(item => (
                        <div key={item.team} className="p-4 bg-surface-1 rounded-lg">
                          <div className="flex items-center justify-between mb-2"><div className="text-sm font-semibold text-ink">{item.team}</div><div className="text-sm font-bold text-brand">{item.pct}%</div></div>
                          <div className="flex items-center gap-2 text-xs text-ink-secondary mb-2"><span>{item.ontime} on-time</span><span className="text-ink-muted">&bull;</span><span>{item.total - item.ontime} delayed</span><span className="text-ink-muted">&bull;</span><span>{item.total} total</span></div>
                          <div className="h-2 bg-edge rounded-full overflow-hidden"><div className="h-full bg-gradient-to-r from-brand to-brand rounded-full" style={{ width: `${item.pct}%` }} /></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-5 bg-gradient-to-r from-brand-light to-danger-light border border-brand rounded-xl">
                    <h4 className="text-brand-active font-bold mb-2">Key success factors</h4>
                    <ul className="space-y-2 text-sm text-ink-secondary">{['Early blocker detection and resolution', 'Proactive timeline adjustments when needed', 'Better scope management with enforcement rules'].map(t => (<li key={t} className="flex items-start gap-2"><Target className="w-4 h-4 text-brand mt-0.5 flex-shrink-0" /><span>{t}</span></li>))}</ul>
                  </div>
                </div>
              )}
              {showMetricModal === 'response' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-brand-light border border-brand rounded-xl p-5"><div className="text-3xl font-bold text-brand mb-1">2.4h</div><div className="text-sm text-brand-active font-medium">Avg response time</div></div>
                    <div className="bg-success-light border border-success rounded-xl p-5"><div className="text-3xl font-bold text-success-text mb-1">&darr; 42%</div><div className="text-sm text-success-text font-medium">Improvement</div></div>
                    <div className="bg-surface-1 border border-edge rounded-xl p-5"><div className="text-3xl font-bold text-ink-secondary mb-1">4.1h</div><div className="text-sm text-ink font-medium">Last month</div></div>
                  </div>
                  <div>
                    <h4 className="text-ink font-semibold mb-3">Response time by priority</h4>
                    <div className="space-y-3">
                      {[{ priority: 'Critical', time: '0.8h', target: '< 1h', status: 'good' }, { priority: 'High', time: '2.1h', target: '< 4h', status: 'good' }, { priority: 'Medium', time: '4.5h', target: '< 8h', status: 'good' }].map(item => (
                        <div key={item.priority} className="p-4 bg-surface-1 rounded-lg">
                          <div className="flex items-center justify-between mb-2"><div className="text-sm font-semibold text-ink">{item.priority}</div><div className="flex items-center gap-2"><span className="text-xs text-ink-muted">Target: {item.target}</span><span className={`px-2 py-0.5 rounded-full text-xs font-bold ${item.status === 'good' ? 'bg-success-light text-success-text' : 'bg-warning-light text-warning'}`}>{item.time}</span></div></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="p-5 bg-gradient-to-r from-brand-light to-info-light border border-brand rounded-xl">
                    <h4 className="text-brand-active font-bold mb-2">What improved response time?</h4>
                    <ul className="space-y-2 text-sm text-ink-secondary">{['Auto-routing to right owners via enforcement rules', 'Faster context availability (no digging for info)', 'Clear escalation paths with SLA timers'].map(t => (<li key={t} className="flex items-start gap-2"><Zap className="w-4 h-4 text-brand mt-0.5 flex-shrink-0" /><span>{t}</span></li>))}</ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6" onClick={() => setShowExportModal(false)}>
          <div className="bg-surface-0 rounded-2xl shadow-[var(--shadow-elevated)] max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
            <div className="px-8 py-6 border-b border-edge"><h2 className="text-ink text-2xl font-bold mb-1">Export Board Report</h2><p className="text-ink-secondary text-sm">Choose format and sections to include</p></div>
            <div className="p-8 space-y-6">
              <div>
                <label className="block text-ink font-semibold mb-3">Format</label>
                <div className="grid grid-cols-2 gap-3">
                  <button onClick={() => setExportFormat('pdf')} className={`p-4 border-2 rounded-lg text-left transition-all ${exportFormat === 'pdf' ? 'border-brand bg-brand-light' : 'border-edge bg-surface-0 hover:border-brand'}`}>
                    <div className={`font-semibold mb-1 ${exportFormat === 'pdf' ? 'text-brand-active' : 'text-ink'}`}>PDF Report</div>
                    <div className={`text-xs ${exportFormat === 'pdf' ? 'text-brand' : 'text-ink-secondary'}`}>Executive summary</div>
                  </button>
                  <button onClick={() => setExportFormat('excel')} className={`p-4 border-2 rounded-lg text-left transition-all ${exportFormat === 'excel' ? 'border-brand bg-brand-light' : 'border-edge bg-surface-0 hover:border-brand'}`}>
                    <div className={`font-semibold mb-1 ${exportFormat === 'excel' ? 'text-brand-active' : 'text-ink'}`}>Excel Data</div>
                    <div className={`text-xs ${exportFormat === 'excel' ? 'text-brand' : 'text-ink-secondary'}`}>Raw metrics &amp; trends</div>
                  </button>
                </div>
              </div>
              <div>
                <label className="block text-ink font-semibold mb-3">Include Sections</label>
                <div className="space-y-2">
                  {Object.entries(exportSections).map(([label, checked]) => (
                    <label key={label} className="flex items-center gap-3 p-3 bg-surface-1 rounded-lg cursor-pointer hover:bg-surface-2">
                      <input type="checkbox" checked={checked} onChange={(e) => setExportSections(prev => ({ ...prev, [label]: e.target.checked }))} className="w-4 h-4 text-brand rounded" />
                      <span className="text-sm text-ink">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            <div className="px-8 py-6 border-t border-edge flex items-center justify-end gap-3">
              <button onClick={() => setShowExportModal(false)} className="px-6 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium">Cancel</button>
              <button onClick={() => { toast('TODO: Not implemented — would download board report'); setShowExportModal(false); }} className="px-6 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium flex items-center gap-2"><Download className="w-4 h-4" />Download Report</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

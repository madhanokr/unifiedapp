import { Clock, Plus, Settings, Shield, X } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { saveEscalationPolicies, loadEscalationPolicies } from './store';
import type { EscalationPolicyState } from './store';

interface EscalationStep {
  id: string;
  delay: number; // hours
  label: string;
  actions: string[];
  settings: Record<string, unknown>; // TODO: type properly during merge
}

interface EscalationPolicyEditorProps {
  isOpen: boolean;
  onClose: () => void;
  policyName?: string;
}

export function EscalationPolicyEditor({ isOpen, onClose, policyName = 'Critical' }: EscalationPolicyEditorProps) {
  // Initialize from localStorage if a saved policy exists
  const [steps, setSteps] = useState<EscalationStep[]>(() => {
    const saved = loadEscalationPolicies();
    const match = saved?.find(p => p.id === policyName || p.name === policyName);
    if (match && match.steps.length > 0) {
      return match.steps.map(s => ({
        id: s.id,
        delay: parseInt(s.delay) || 0,
        label: parseInt(s.delay) === 0 ? 'Immediately' : `After ${s.delay}h`,
        actions: s.actions,
        settings: {
          channel: s.channels?.[0] || 'Slack',
          requireAck: s.requireAck !== false,
          reminder: s.ackTimeout ?? 4,
        },
      }));
    }
    // Defaults for never-saved policies
    return [
      {
        id: '0',
        delay: 0,
        label: 'Immediately',
        actions: ['notify-owner'],
        settings: { channel: 'slack', requireAck: true, reminder: 4 }
      },
      {
        id: '1',
        delay: 24,
        label: 'After 24h (no ack)',
        actions: ['escalate-manager', 'create-task'],
        settings: {}
      },
      {
        id: '2',
        delay: 48,
        label: 'After 48h',
        actions: ['escalate-exec', 'schedule-huddle'],
        settings: {}
      },
      {
        id: '3',
        delay: 72,
        label: 'After 72h',
        actions: ['weekly-brief-top5'],
        settings: {}
      }
    ];
  });

  const [severity, setSeverity] = useState<string[]>(() => {
    const saved = loadEscalationPolicies();
    const match = saved?.find(p => p.id === policyName || p.name === policyName);
    // no severity stored in EscalationPolicyState, use default
    return ['critical'];
  });
  const [quietHours, setQuietHours] = useState(() => {
    const saved = loadEscalationPolicies();
    const match = saved?.find(p => p.id === policyName || p.name === policyName);
    return match?.quietHours || 'pause';
  });
  const [stopConditions, setStopConditions] = useState<string[]>(() => {
    const saved = loadEscalationPolicies();
    const match = saved?.find(p => p.id === policyName || p.name === policyName);
    const conds: string[] = ['acknowledged'];
    if (match?.autoResolve !== false) conds.push('resolved');
    return conds;
  });
  const [requireApproval, setRequireApproval] = useState(policyName === 'Critical');

  if (!isOpen) return null;

  const addStep = () => {
    const lastStep = steps[steps.length - 1];
    const newDelay = lastStep ? lastStep.delay + 24 : 0;
    setSteps([
      ...steps,
      {
        id: Date.now().toString(),
        delay: newDelay,
        label: `After ${newDelay}h`,
        actions: [],
        settings: {}
      }
    ]);
  };

  const removeStep = (id: string) => {
    if (steps.length <= 1) return;
    setSteps(steps.filter(s => s.id !== id));
  };

  const actionLabels: Record<string, string> = {
    'notify-owner': 'Notify Owner',
    'notify-manager': 'Notify Manager',
    'escalate-manager': 'Escalate to Manager',
    'escalate-exec': 'Escalate to Exec Sponsor',
    'create-task': 'Create Task',
    'require-update': 'Require Update',
    'schedule-huddle': 'Schedule Huddle (within 24h)',
    'weekly-brief-top5': 'Add to Weekly Brief Top 5',
    'mark-exec-attention': 'Auto-mark "Executive Attention Required"'
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-edge">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-ink text-xl font-semibold mb-1">
                Edit Escalation Policy: {policyName}
              </h2>
              <p className="text-ink-secondary text-sm">Design the escalation timeline and automation rules</p>
            </div>
            <button onClick={onClose} className="text-ink-muted hover:text-ink-secondary text-2xl leading-none">
              ×
            </button>
          </div>
        </div>

        {/* Body - Scrollable */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Timeline Steps */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-ink font-semibold text-sm">Escalation Timeline</h3>
                <p className="text-ink-secondary text-xs">Define what happens at each stage</p>
              </div>
              <button
                onClick={addStep}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium text-xs"
              >
                <Plus className="w-3 h-3" />
                Add Step
              </button>
            </div>

            {/* Visual Timeline */}
            <div className="relative">
              {/* Vertical Line */}
              <div className="absolute left-4 top-6 bottom-6 w-0.5 bg-edge"></div>

              <div className="space-y-3">
                {steps.map((step, index) => (
                  <div key={step.id} className="relative pl-11">
                    {/* Timeline Dot */}
                    <div className={`absolute left-0 top-2 w-8 h-8 rounded-full flex items-center justify-center ${
                      index === 0 ? 'bg-brand' : 'bg-info'
                    }`}>
                      <Clock className="w-4 h-4 text-[var(--white)]" />
                    </div>

                    {/* Step Card */}
                    <div className="bg-surface-0 border border-edge rounded-lg p-3 hover:border-brand transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1.5">
                            <h4 className="text-ink font-semibold text-xs">Step {index}</h4>
                            <input
                              type="text"
                              value={step.label}
                              onChange={(e) => {
                                const updated = steps.map(s =>
                                  s.id === step.id ? { ...s, label: e.target.value } : s
                                );
                                setSteps(updated);
                              }}
                              className="text-ink-secondary text-xs px-2 py-1 border border-edge rounded flex-1 focus:outline-none focus:ring-1 focus:ring-brand"
                              placeholder="e.g., After 24h (no ack)"
                            />
                          </div>
                        </div>
                        {index > 0 && (
                          <button
                            onClick={() => removeStep(step.id)}
                            className="p-1 text-ink-muted hover:text-danger-text hover:bg-danger-light rounded transition-colors ml-2"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </div>

                      {/* Delay Input */}
                      {index > 0 && (
                        <div className="mb-2 flex items-center gap-2">
                          <label className="text-ink-secondary text-xs font-medium">Delay:</label>
                          <input
                            type="number"
                            value={step.delay}
                            onChange={(e) => {
                              const updated = steps.map(s =>
                                s.id === step.id ? { ...s, delay: parseInt(e.target.value) || 0 } : s
                              );
                              setSteps(updated);
                            }}
                            className="w-16 px-2 py-1 border border-edge rounded text-xs focus:outline-none focus:ring-1 focus:ring-brand"
                          />
                          <span className="text-ink-secondary text-xs">hours</span>
                        </div>
                      )}

                      {/* Actions - Compact Multi-Select */}
                      <div>
                        <label className="block text-ink-secondary font-medium text-xs mb-1.5">Actions:</label>
                        <div className="relative">
                          <select
                            multiple
                            value={step.actions}
                            onChange={(e) => {
                              const selected = Array.from(e.target.selectedOptions, option => option.value);
                              const updated = steps.map(s =>
                                s.id === step.id ? { ...s, actions: selected } : s
                              );
                              setSteps(updated);
                            }}
                            className="w-full px-2 py-1.5 border border-edge rounded text-xs focus:outline-none focus:ring-1 focus:ring-brand"
                            size={4}
                          >
                            {Object.entries(actionLabels).map(([key, label]) => (
                              <option key={key} value={key} className="py-1">
                                {label}
                              </option>
                            ))}
                          </select>
                          <p className="text-ink-muted text-xs mt-1">Hold Ctrl/Cmd to select multiple</p>
                        </div>
                      </div>

                      {/* Action Settings (Collapsible) */}
                      {step.actions.includes('notify-owner') && (
                        <details className="mt-2">
                          <summary className="cursor-pointer text-xs text-brand font-medium hover:text-brand-hover py-1">
                            ⚙️ Notify Settings
                          </summary>
                          <div className="mt-2 p-2 bg-surface-1 border border-edge rounded-lg">
                            <div className="grid grid-cols-3 gap-2 text-xs">
                              <div>
                                <label className="block text-ink-secondary mb-1">Channel</label>
                                <select
                                  value={step.settings?.channel || 'Slack'}
                                  onChange={(e) => {
                                    const updated = steps.map(s =>
                                      s.id === step.id ? { ...s, settings: { ...s.settings, channel: e.target.value } } : s
                                    );
                                    setSteps(updated);
                                  }}
                                  className="w-full px-2 py-1 border border-edge rounded"
                                >
                                  <option>Slack</option>
                                  <option>Email</option>
                                  <option>Teams</option>
                                </select>
                              </div>
                              <div>
                                <label className="flex items-center gap-1 mt-4">
                                  <input
                                    type="checkbox"
                                    checked={step.settings?.requireAck !== false}
                                    onChange={(e) => {
                                      const updated = steps.map(s =>
                                        s.id === step.id ? { ...s, settings: { ...s.settings, requireAck: e.target.checked } } : s
                                      );
                                      setSteps(updated);
                                    }}
                                    className="w-3 h-3 text-brand rounded"
                                  />
                                  <span className="text-ink-secondary">Require Ack</span>
                                </label>
                              </div>
                              <div>
                                <label className="block text-ink-secondary mb-1">Reminder (h)</label>
                                <input
                                  type="number"
                                  value={step.settings?.reminder ?? 4}
                                  onChange={(e) => {
                                    const updated = steps.map(s =>
                                      s.id === step.id ? { ...s, settings: { ...s.settings, reminder: parseInt(e.target.value) || 0 } } : s
                                    );
                                    setSteps(updated);
                                  }}
                                  className="w-full px-2 py-1 border border-edge rounded"
                                />
                              </div>
                            </div>
                          </div>
                        </details>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Policy Settings */}
          <div className="border-t pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Settings className="w-4 h-4 text-ink-secondary" />
              <h3 className="text-ink font-semibold text-sm">Policy Settings</h3>
            </div>

            <div className="space-y-3">
              {/* Severity */}
              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">Applies to Severity:</label>
                <div className="flex items-center gap-3">
                  {['low', 'medium', 'high', 'critical'].map(sev => (
                    <label key={sev} className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={severity.includes(sev)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSeverity([...severity, sev]);
                          } else {
                            setSeverity(severity.filter(s => s !== sev));
                          }
                        }}
                        className="w-3 h-3 text-brand border-edge rounded"
                      />
                      <span className="text-ink-secondary text-xs capitalize">{sev}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Quiet Hours */}
              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">Quiet Hours Behavior:</label>
                <select
                  value={quietHours}
                  onChange={(e) => setQuietHours(e.target.value)}
                  className="w-full px-3 py-1.5 border border-edge rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-brand"
                >
                  <option value="pause">Pause escalation timer</option>
                  <option value="digest">Deliver in digest</option>
                  <option value="ignore">Ignore quiet hours</option>
                </select>
              </div>

              {/* Stop Conditions */}
              <div>
                <label className="block text-ink-secondary font-medium text-xs mb-1.5">Escalation Stop Conditions:</label>
                <div className="space-y-1.5">
                  {['acknowledged', 'resolved', 'on-track'].map(cond => (
                    <label key={cond} className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={stopConditions.includes(cond)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setStopConditions([...stopConditions, cond]);
                          } else {
                            setStopConditions(stopConditions.filter(c => c !== cond));
                          }
                        }}
                        className="w-3 h-3 text-brand border-edge rounded"
                      />
                      <span className="text-ink-secondary text-xs">
                        {cond === 'acknowledged' && 'Stop when acknowledged'}
                        {cond === 'resolved' && 'Stop when resolved'}
                        {cond === 'on-track' && 'Stop when status returns to On Track'}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Approvals */}
          <div className="border-t pt-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-warning" />
              <h3 className="text-ink font-semibold text-sm">Approvals</h3>
            </div>

            <div className="p-3 bg-warning-light border border-warning rounded-lg">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={requireApproval}
                  onChange={(e) => setRequireApproval(e.target.checked)}
                  className="w-4 h-4 text-brand border-edge rounded mt-0.5"
                />
                <div>
                  <p className="text-ink font-medium text-xs mb-0.5">
                    Require COO approval for changes to this policy
                  </p>
                  <p className="text-ink-secondary text-xs">
                    Critical policies require executive approval before going live.
                  </p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 pb-6 pt-4 border-t border-edge flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              // Persist to localStorage
              const existing = loadEscalationPolicies() || [];
              const policyState: EscalationPolicyState = {
                id: policyName,
                name: policyName,
                steps: steps.map(s => ({
                  id: s.id,
                  delay: String(s.delay),
                  delayUnit: 'hours',
                  actions: s.actions,
                  channels: [s.settings?.channel || 'Slack'],
                  requireAck: s.settings?.requireAck !== false,
                  ackTimeout: s.settings?.reminder ?? 4,
                })),
                quietHours: quietHours,
                autoResolve: stopConditions.includes('resolved'),
              };
              const updated = [...existing.filter(p => p.id !== policyName), policyState];
              saveEscalationPolicies(updated);
              toast.success(`Escalation policy "${policyName}" saved with ${steps.length} steps`);
              // Notify other components (EscalationPoliciesPage) to reload
              window.dispatchEvent(new CustomEvent('escalation-policies-updated'));
              onClose();
            }}
            className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium shadow-[var(--shadow-card)]"
          >
            Save Escalation Policy
          </button>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { Settings, History, Users2, Hash, AlertCircle, TrendingDown } from 'lucide-react';
import { PlaybookDrawer, formatChannels } from './PlaybookDrawer';
import type { Playbook } from './PlaybookDrawer';
import { toast } from 'sonner';
import { loadPlaybookStates, savePlaybookStates } from './store';
import type { PlaybookState } from './store';

// Helper to extract persistable state from a Playbook
function toPlaybookState(p: Playbook): PlaybookState {
  return {
    id: p.id,
    enabled: p.enabled,
    mode: p.mode,
    scope: p.scope,
    channels: p.channels,
    threshold: p.threshold,
    primaryOwner: p.primaryOwner,
    backupOwner: p.backupOwner,
    escalationPolicy: p.escalationPolicy,
    quietHoursStart: p.quietHoursStart,
    quietHoursEnd: p.quietHoursEnd,
    maxNotifications: p.maxNotifications,
    exceptions: p.exceptions,
  };
}

// Merge persisted state into default playbooks
function mergePlaybookStates(defaults: Playbook[], saved: PlaybookState[] | null): Playbook[] {
  if (!saved) return defaults;
  return defaults.map(d => {
    const s = saved.find(ps => ps.id === d.id);
    if (!s) return d;
    return { ...d, ...s };
  });
}

// Persist helper: save and return updated playbooks
function persistPlaybooks(playbooks: Playbook[]): void {
  savePlaybookStates(playbooks.map(toPlaybookState));
}

const DEFAULT_PLAYBOOKS: Playbook[] = [
  {
    id: '1',
    name: 'Weekly Reality',
    oneLiner: 'No weekly update = no trust. Automatically flags stale OKRs and routes ownership.',
    triggers: 'No update in 7 days OR No evidence attached',
    defaultAction: 'Request update → escalate if ignored',
    mode: 'enforce',
    enabled: true,
    wouldHaveFired: 9,
    scope: 'All teams',
    channels: { slack: true, teams: false, email: true },
    threshold: '7',
    primaryOwner: 'Auto-assign',
    backupOwner: 'None',
    escalationPolicy: 'Standard',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true },
  },
  {
    id: '2',
    name: 'Blocked SLA',
    oneLiner: 'Blocked work can\'t sit quietly. ShiftFocus forces unblocks within SLA.',
    triggers: 'Blocked for 24h / 48h',
    defaultAction: 'Assign unblock owner + schedule unblock huddle',
    mode: 'enforce',
    enabled: true,
    wouldHaveFired: 12,
    scope: 'All teams',
    channels: { slack: true, teams: false, email: true },
    threshold: '2',
    primaryOwner: 'Auto-assign',
    backupOwner: 'Manager',
    escalationPolicy: 'Critical',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true },
  },
  {
    id: '3',
    name: 'No Orphans',
    oneLiner: 'Every work item needs ownership and outcome linkage.',
    triggers: 'No owner OR No due date OR Not linked to KR/initiative',
    defaultAction: 'Require fix before work continues + notify owner/manager',
    mode: 'monitor',
    enabled: true,
    wouldHaveFired: 18,
    scope: 'All teams',
    channels: { slack: true, teams: false, email: false },
    threshold: '1',
    primaryOwner: 'Auto-assign',
    backupOwner: 'None',
    escalationPolicy: 'Standard',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true },
  },
  {
    id: '4',
    name: 'Dependency Heat',
    oneLiner: 'Prevent domino delays. Escalate critical dependency slips early.',
    triggers: 'Critical dependency delayed OR Dependency risk score ≥ High',
    defaultAction: 'Notify dependency owner + escalate to initiative sponsor',
    mode: 'monitor',
    enabled: false,
    wouldHaveFired: 6,
    scope: 'Engineering only',
    channels: { slack: true, teams: false, email: false },
    threshold: '3',
    primaryOwner: 'Initiative Owner',
    backupOwner: 'Exec Sponsor',
    escalationPolicy: 'Critical',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true },
  },
  {
    id: '5',
    name: 'Capacity Guardrail',
    oneLiner: 'Protect focus. Prevent overload from silently killing delivery.',
    triggers: 'Team load ≥ 85% OR WIP limit breached',
    defaultAction: 'Warn + recommend rebalance + freeze new work (optional)',
    mode: 'enforce',
    enabled: true,
    wouldHaveFired: 3,
    scope: 'Engineering only',
    channels: { slack: true, teams: false, email: true },
    threshold: '1',
    primaryOwner: 'Team Lead',
    backupOwner: 'Manager',
    escalationPolicy: 'Standard',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true },
  },
  {
    id: '6',
    name: 'Monday COO Brief',
    oneLiner: 'A weekly executive brief generated from real signals — not opinions.',
    triggers: 'Every Monday at 8:00am',
    defaultAction: 'Send brief to COO/CEO + deep links to top risks',
    mode: 'enforce',
    enabled: true,
    wouldHaveFired: 1,
    scope: 'Executives',
    channels: { slack: false, teams: false, email: true },
    threshold: '7',
    primaryOwner: 'Auto-assign',
    backupOwner: 'None',
    escalationPolicy: 'Silent',
    quietHoursStart: '20:00',
    quietHoursEnd: '08:00',
    maxNotifications: '5',
    exceptions: { excludeExec: false, excludeLaunchWeek: false, excludeWeekends: false },
  },
];

export function PlaybooksGallery() {
  const [playbooks, setPlaybooks] = useState<Playbook[]>(mergePlaybookStates(DEFAULT_PLAYBOOKS, loadPlaybookStates()));
  const [selectedPlaybook, setSelectedPlaybook] = useState<Playbook | null>(null);
  const [confirmToggle, setConfirmToggle] = useState<{ playbook: Playbook, action: 'enable' | 'disable' } | null>(null);

  const togglePlaybook = (id: string) => {
    const playbook = playbooks.find(p => p.id === id);
    if (!playbook) return;
    
    // Show confirmation modal instead of toggling directly
    setConfirmToggle({
      playbook,
      action: playbook.enabled ? 'disable' : 'enable'
    });
  };

  const confirmToggleAction = () => {
    if (!confirmToggle) return;
    
    const updated = playbooks.map((p) => 
      p.id === confirmToggle.playbook.id 
        ? { ...p, enabled: !p.enabled } 
        : p
    );
    setPlaybooks(updated);
    persistPlaybooks(updated);
    setConfirmToggle(null);
    toast.success(`Policy ${confirmToggle.action === 'enable' ? 'enabled' : 'disabled'}: ${confirmToggle.playbook.name}`);
  };

  const setMode = (id: string, mode: 'monitor' | 'enforce') => {
    const updated = playbooks.map((p) => (p.id === id ? { ...p, mode } : p));
    setPlaybooks(updated);
    persistPlaybooks(updated);
  };

  return (
    <>
      <div>
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-ink mb-1">Playbooks Gallery</h2>
            <p className="text-ink-muted text-sm">
              Pre-built enforcement patterns for common execution risks
            </p>
          </div>
          <button
            onClick={() => toast('Browse Templates: Coming soon — community templates will be available in a future release')}
            className="text-brand hover:text-brand-hover text-sm font-medium"
          >
            Browse Templates →
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
          {playbooks.map((playbook) => (
            <div
              key={playbook.id}
              className={`bg-surface-0 rounded-xl border p-6 shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)] transition-all ${
                playbook.enabled ? 'border-edge' : 'border-edge opacity-60'
              }`}
            >
              {/* Header with toggle */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="text-ink">{playbook.name}</h3>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={playbook.enabled}
                    onChange={() => togglePlaybook(playbook.id)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-edge peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-surface-0 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand"></div>
                </label>
              </div>

              {/* One-liner */}
              <p className="text-ink-secondary text-sm mb-4 leading-relaxed">{playbook.oneLiner}</p>

              {/* Operational Metadata */}
              <div className="flex items-center gap-4 mb-4 text-xs text-ink-secondary">
                <div className="flex items-center gap-1.5">
                  <Users2 className="w-3.5 h-3.5" />
                  <span>{playbook.scope}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5" />
                  <span>{formatChannels(playbook.channels)}</span>
                </div>
              </div>

              {/* Triggers */}
              <div className="bg-surface-1 rounded-lg p-3 mb-3">
                <p className="text-ink-secondary text-xs font-medium mb-1">Triggers</p>
                <p className="text-ink-secondary text-xs leading-relaxed">{playbook.triggers}</p>
              </div>

              {/* Default Action */}
              <div className="bg-brand-light rounded-lg p-3 mb-4">
                <p className="text-ink-secondary text-xs font-medium mb-1">Default action</p>
                <p className="text-ink-secondary text-xs leading-relaxed">{playbook.defaultAction}</p>
              </div>

              {/* Mode Selector - Only show when enabled */}
              {playbook.enabled && (
                <div className="mb-4">
                  <div className="inline-flex bg-surface-2 rounded-lg p-1 w-full">
                    <button
                      onClick={() => setMode(playbook.id, 'monitor')}
                      className={`flex-1 px-3 py-1.5 rounded text-sm transition-colors ${
                        playbook.mode === 'monitor'
                          ? 'bg-surface-0 text-ink shadow-[var(--shadow-card)]'
                          : 'text-ink-muted hover:text-ink-secondary'
                      }`}
                    >
                      Monitor-only
                    </button>
                    <button
                      onClick={() => setMode(playbook.id, 'enforce')}
                      className={`flex-1 px-3 py-1.5 rounded text-sm transition-colors ${
                        playbook.mode === 'enforce'
                          ? 'bg-surface-0 text-ink shadow-[var(--shadow-card)]'
                          : 'text-ink-muted hover:text-ink-secondary'
                      }`}
                    >
                      Enforce
                    </button>
                  </div>
                </div>
              )}

              {/* Status Badge */}
              <div className="mb-4">
                {playbook.enabled ? (
                  <span
                    className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${
                      playbook.mode === 'enforce'
                        ? 'bg-brand-light text-brand'
                        : 'bg-info-light text-info'
                    }`}
                  >
                    {playbook.mode === 'enforce' ? 'Enforcing' : 'Monitor-only'}
                  </span>
                ) : (
                  <div className="space-y-2">
                    <span className="inline-block px-2.5 py-1 rounded-full text-xs font-medium bg-surface-2 text-ink-secondary">
                      Disabled
                    </span>
                    <p className="text-xs text-ink-secondary">
                      Would have caught {playbook.wouldHaveFired} issues last week. 
                      <button
                        onClick={() => togglePlaybook(playbook.id)}
                        className="text-brand hover:text-brand-hover font-medium ml-1"
                      >
                        Enable now?
                      </button>
                    </p>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="pt-4 border-t border-edge-light">
                <div className="flex items-center justify-between">
                  <p className="text-ink-muted text-xs">
                    {playbook.wouldHaveFired} triggers last week
                    {playbook.enabled && (
                      <button
                        onClick={() => toast(`Preview: "${playbook.name}" triggered ${playbook.wouldHaveFired} times last week across ${playbook.scope}`)}
                        className="ml-2 text-brand hover:text-brand-hover text-xs"
                      >
                        Preview
                      </button>
                    )}
                  </p>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSelectedPlaybook(playbook)}
                      className="flex items-center gap-1 text-brand hover:text-brand-hover transition-colors text-xs"
                    >
                      <Settings className="w-3.5 h-3.5" />
                      Configure
                    </button>
                    <button
                      onClick={() => toast(`Trigger history for "${playbook.name}" — TODO: Not implemented`)}
                      className="flex items-center gap-1 text-ink-secondary hover:text-ink transition-colors text-xs"
                    >
                      <History className="w-3.5 h-3.5" />
                      History
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedPlaybook && (
        <PlaybookDrawer
          playbook={selectedPlaybook}
          onClose={() => setSelectedPlaybook(null)}
          onSave={(updated) => {
            const newPlaybooks = playbooks.map((p) => (p.id === updated.id ? updated : p));
            setPlaybooks(newPlaybooks);
            persistPlaybooks(newPlaybooks);
            setSelectedPlaybook(null);
          }}
        />
      )}

      {/* UPGRADE #1: "One toggle = company policy" Confirmation Modal */}
      {confirmToggle && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-40 flex items-center justify-center p-4">
          <div className="bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] max-w-lg w-full">
            {confirmToggle.action === 'enable' ? (
              <>
                {/* ENABLING - Show Impact */}
                <div className="p-6 border-b border-edge">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-12 h-12 bg-brand-light rounded-full flex items-center justify-center">
                      <AlertCircle className="w-6 h-6 text-brand" />
                    </div>
                    <div>
                      <h3 className="text-ink font-semibold">Enable Company Policy</h3>
                      <p className="text-sm text-ink-secondary">{confirmToggle.playbook.name}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  {/* Impact Statement */}
                  <div className="p-4 bg-brand-light border border-brand rounded-lg">
                    <p className="text-brand-active font-semibold mb-2">This will affect:</p>
                    <div className="space-y-1 text-sm text-brand">
                      <div className="flex items-center justify-between">
                        <span>• 312 owners across 9 teams</span>
                        <span className="font-semibold">Notified</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>• ~{confirmToggle.playbook.wouldHaveFired} interventions/week</span>
                        <span className="font-semibold">Expected</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>• Enforcement starts immediately</span>
                        <span className="font-semibold">Live</span>
                      </div>
                    </div>
                  </div>

                  {/* Confidence Statement */}
                  <div className="p-4 bg-success-light border border-success rounded-lg">
                    <p className="text-success-text text-sm">
                      <strong>Based on last week's data:</strong> This policy would have prevented{' '}
                      <span className="font-semibold">{Math.floor(confirmToggle.playbook.wouldHaveFired * 0.7)} fire drills</span> and saved{' '}
                      <span className="font-semibold">{(confirmToggle.playbook.wouldHaveFired * 1.8).toFixed(1)} hours</span> of reactive work.
                    </p>
                  </div>

                  <p className="text-ink-secondary text-sm">
                    You're enabling a company-wide execution policy. All teams under "{confirmToggle.playbook.scope}" will be subject to this enforcement pattern.
                  </p>
                </div>

                <div className="px-6 pb-6 flex items-center justify-end gap-3">
                  <button
                    onClick={() => setConfirmToggle(null)}
                    className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmToggleAction}
                    className="px-5 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors font-medium shadow-[var(--shadow-card)]"
                  >
                    Enable Policy
                  </button>
                </div>
              </>
            ) : (
              <>
                {/* DISABLING - Show Warning */}
                <div className="p-6 border-b border-edge">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-12 h-12 bg-warning-light rounded-full flex items-center justify-center">
                      <TrendingDown className="w-6 h-6 text-warning" />
                    </div>
                    <div>
                      <h3 className="text-ink font-semibold">Disable Company Policy</h3>
                      <p className="text-sm text-ink-secondary">{confirmToggle.playbook.name}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  {/* Warning Statement */}
                  <div className="p-4 bg-warning-light border border-warning rounded-lg">
                    <p className="text-warning font-semibold mb-2">⚠️ Execution trust may degrade</p>
                    <div className="space-y-1 text-sm text-warning">
                      <p>
                        • Last week this policy prevented <strong>{Math.floor(confirmToggle.playbook.wouldHaveFired * 0.7)} fire drills</strong>
                      </p>
                      <p>
                        • <strong>312 owners</strong> will no longer receive automated enforcement
                      </p>
                      <p>
                        • <strong>{confirmToggle.playbook.wouldHaveFired} potential issues/week</strong> will go undetected
                      </p>
                    </div>
                  </div>

                  <p className="text-ink-secondary text-sm">
                    Disabling this policy removes enforcement protection across "{confirmToggle.playbook.scope}". 
                    Manual oversight will be required to prevent execution drift.
                  </p>

                  <div className="flex items-center gap-2 p-3 bg-info-light border border-info rounded-lg">
                    <AlertCircle className="w-5 h-5 text-info flex-shrink-0" />
                    <p className="text-info text-xs">
                      <strong>Alternative:</strong> Switch to Monitor-only mode to keep visibility without active enforcement.
                    </p>
                  </div>
                </div>

                <div className="px-6 pb-6 flex items-center justify-end gap-3">
                  <button
                    onClick={() => setConfirmToggle(null)}
                    className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmToggleAction}
                    className="px-5 py-2.5 bg-warning text-[var(--white)] rounded-lg hover:bg-warning/90 transition-colors font-medium shadow-[var(--shadow-card)]"
                  >
                    Disable Policy
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}
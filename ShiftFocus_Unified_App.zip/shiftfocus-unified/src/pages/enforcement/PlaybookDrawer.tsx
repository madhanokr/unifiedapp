import { useState } from 'react';
import { X, Clock } from 'lucide-react';
import { toast } from 'sonner';

export interface PlaybookChannels {
  slack: boolean;
  teams: boolean;
  email: boolean;
}

export interface PlaybookExceptions {
  excludeExec: boolean;
  excludeLaunchWeek: boolean;
  excludeWeekends: boolean;
}

export interface Playbook {
  id: string;
  name: string;
  oneLiner: string;
  triggers: string;
  defaultAction: string;
  mode: 'monitor' | 'enforce';
  enabled: boolean;
  wouldHaveFired: number;
  scope: string;
  channels: PlaybookChannels;
  threshold: string;
  primaryOwner: string;
  backupOwner: string;
  escalationPolicy: string;
  quietHoursStart: string;
  quietHoursEnd: string;
  maxNotifications: string;
  exceptions: PlaybookExceptions;
}

/** Derive a human-readable label from the channels object */
export function formatChannels(channels: PlaybookChannels): string {
  const active: string[] = [];
  if (channels.slack) active.push('Slack');
  if (channels.teams) active.push('Teams');
  if (channels.email) active.push('Email');
  return active.join(' + ') || 'None';
}

/** Default values for new playbook config fields */
export const PLAYBOOK_DEFAULTS = {
  threshold: '7',
  primaryOwner: 'Auto-assign',
  escalationPolicy: 'Standard',
  quietHoursStart: '20:00',
  quietHoursEnd: '08:00',
  maxNotifications: '5',
  channels: { slack: true, teams: false, email: false } as PlaybookChannels,
  exceptions: { excludeExec: false, excludeLaunchWeek: true, excludeWeekends: true } as PlaybookExceptions,
} as const;

interface PlaybookDrawerProps {
  playbook: Playbook;
  onClose: () => void;
  onSave: (playbook: Playbook) => void;
}

export function PlaybookDrawer({ playbook, onClose, onSave }: PlaybookDrawerProps) {
  // Initialize ALL state from the playbook prop — so reopening shows previously saved values
  const [mode, setMode] = useState(playbook.mode);
  const [scope, setScope] = useState(playbook.scope);
  const [threshold, setThreshold] = useState(playbook.threshold);
  const [primaryOwner, setPrimaryOwner] = useState(playbook.primaryOwner);
  const [backupOwner, setBackupOwner] = useState(playbook.backupOwner || 'None');
  const [escalationPolicy, setEscalationPolicy] = useState(playbook.escalationPolicy);
  const [channels, setChannels] = useState<PlaybookChannels>(playbook.channels);
  const [quietHoursStart, setQuietHoursStart] = useState(playbook.quietHoursStart);
  const [quietHoursEnd, setQuietHoursEnd] = useState(playbook.quietHoursEnd);
  const [maxNotifications, setMaxNotifications] = useState(playbook.maxNotifications);
  const [exceptions, setExceptions] = useState<PlaybookExceptions>(playbook.exceptions);

  const handleSave = () => {
    onSave({
      ...playbook,
      mode,
      scope,
      threshold,
      primaryOwner,
      backupOwner,
      escalationPolicy,
      channels,
      quietHoursStart,
      quietHoursEnd,
      maxNotifications,
      exceptions,
    });
    toast.success(`Playbook "${playbook.name}" saved`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-25" onClick={onClose} />
      
      <div className="absolute inset-y-0 right-0 max-w-2xl w-full bg-surface-0 shadow-[var(--shadow-elevated)] flex flex-col">
        {/* Header */}
        <div className="px-8 py-6 border-b border-edge flex items-center justify-between">
          <div>
            <h2 className="text-ink mb-1">Configure Playbook</h2>
            <p className="text-ink-secondary">
              Adjust scope, thresholds, and escalation. Preview what would have fired recently.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-ink-secondary" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-6">
          {/* Mode */}
          <div>
            <label className="block text-ink mb-3">Enforcement Mode</label>
            <div className="inline-flex bg-surface-2 rounded-lg p-1 w-full">
              <button
                onClick={() => setMode('monitor')}
                className={`flex-1 px-4 py-2 rounded-md text-sm transition-colors ${
                  mode === 'monitor'
                    ? 'bg-surface-0 text-ink shadow-[var(--shadow-card)]'
                    : 'text-ink-secondary hover:text-ink'
                }`}
              >
                Monitor-only (no actions, logs only)
              </button>
              <button
                onClick={() => setMode('enforce')}
                className={`flex-1 px-4 py-2 rounded-md text-sm transition-colors ${
                  mode === 'enforce'
                    ? 'bg-surface-0 text-ink shadow-[var(--shadow-card)]'
                    : 'text-ink-secondary hover:text-ink'
                }`}
              >
                Enforce (actions + escalations enabled)
              </button>
            </div>
          </div>

          {/* Scope */}
          <div>
            <label className="block text-ink mb-3">Apply To</label>
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
            >
              <option value="All teams">All teams</option>
              <option value="Engineering only">Engineering only</option>
              <option value="Executives">Executives</option>
              <option value="Specific teams">Specific teams</option>
              <option value="Roles">Roles</option>
              <option value="Specific OKRs/initiatives">Specific OKRs/initiatives</option>
            </select>
            <p className="text-ink-muted mt-2">
              Start narrow. Expand once signal quality is proven.
            </p>
          </div>

          {/* Thresholds */}
          <div>
            <label className="block text-ink mb-3">Trigger Conditions</label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={threshold}
                onChange={(e) => setThreshold(e.target.value)}
                className="w-24 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
              />
              <span className="text-ink-secondary">days without update</span>
            </div>
            <p className="text-ink-muted mt-2">Tune sensitivity to reduce noise.</p>
          </div>

          {/* Routing */}
          <div>
            <label className="block text-ink mb-3">Primary Owner</label>
            <select
              value={primaryOwner}
              onChange={(e) => setPrimaryOwner(e.target.value)}
              className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent mb-3"
            >
              <option value="Auto-assign">Auto-assign</option>
              <option value="KR Owner">KR Owner</option>
              <option value="Initiative Owner">Initiative Owner</option>
              <option value="Team Lead">Team Lead</option>
            </select>
            <label className="block text-ink-secondary mb-2">Backup Owner (optional)</label>
            <select
              value={backupOwner}
              onChange={(e) => setBackupOwner(e.target.value)}
              className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
            >
              <option>None</option>
              <option>Manager</option>
              <option>Exec Sponsor</option>
            </select>
          </div>

          {/* Escalation */}
          <div>
            <label className="block text-ink mb-3">Escalation Policy</label>
            <select
              value={escalationPolicy}
              onChange={(e) => setEscalationPolicy(e.target.value)}
              className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
            >
              <option value="Standard">Standard</option>
              <option value="Critical">Critical</option>
              <option value="Silent">Silent</option>
            </select>
            <p className="text-ink-muted mt-2">
              Escalate only when there's no acknowledgment or resolution.
            </p>
          </div>

          {/* Channels */}
          <div>
            <label className="block text-ink mb-3">Send via</label>
            <div className="space-y-3">
              {Object.entries(channels).map(([channel, enabled]) => (
                <label key={channel} className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enabled}
                    onChange={(e) =>
                      setChannels((prev) => ({ ...prev, [channel]: e.target.checked }))
                    }
                    className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                  />
                  <span className="text-ink-secondary capitalize">{channel}</span>
                </label>
              ))}
            </div>
            <p className="text-ink-muted mt-2">
              We'll batch notifications where possible.
            </p>
          </div>

          {/* Quiet Hours & Throttling */}
          <div>
            <label className="block text-ink mb-3">Quiet Hours</label>
            <div className="flex items-center gap-3 mb-4">
              <input
                type="time"
                value={quietHoursStart}
                onChange={(e) => setQuietHoursStart(e.target.value)}
                className="px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
              />
              <span className="text-ink-secondary">to</span>
              <input
                type="time"
                value={quietHoursEnd}
                onChange={(e) => setQuietHoursEnd(e.target.value)}
                className="px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
              />
            </div>

            <label className="block text-ink mb-3">Notification Limits</label>
            <div className="flex items-center gap-3">
              <span className="text-ink-secondary">Max</span>
              <input
                type="number"
                value={maxNotifications}
                onChange={(e) => setMaxNotifications(e.target.value)}
                className="w-24 px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
              />
              <span className="text-ink-secondary">notifications per person per day.</span>
            </div>
            <p className="text-ink-muted mt-2">
              Switch to digest if exceeded.
            </p>
          </div>

          {/* Exceptions */}
          <div>
            <label className="block text-ink mb-3">Exclusions</label>
            <div className="space-y-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={exceptions.excludeExec}
                  onChange={(e) =>
                    setExceptions((prev) => ({ ...prev, excludeExec: e.target.checked }))
                  }
                  className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                />
                <span className="text-ink-secondary">Exclude Exec initiatives</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={exceptions.excludeLaunchWeek}
                  onChange={(e) =>
                    setExceptions((prev) => ({ ...prev, excludeLaunchWeek: e.target.checked }))
                  }
                  className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                />
                <span className="text-ink-secondary">Exclude Launch week</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={exceptions.excludeWeekends}
                  onChange={(e) =>
                    setExceptions((prev) => ({ ...prev, excludeWeekends: e.target.checked }))
                  }
                  className="w-5 h-5 text-brand border-edge rounded focus:ring-brand"
                />
                <span className="text-ink-secondary">Exclude weekends</span>
              </label>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-brand-light border border-brand rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-brand flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-ink mb-1">Preview (Last 7 days)</h4>
                <p className="text-ink-secondary">
                  This playbook would have triggered <span className="text-brand">{playbook.wouldHaveFired} times</span>. 
                  Estimated notifications: <span className="text-brand">{playbook.wouldHaveFired * 2}</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-6 border-t border-edge flex items-center justify-between">
          <button onClick={() => toast('TODO: Not implemented — would show playbook version history')} className="text-ink-secondary hover:text-ink transition-colors">
            View History
          </button>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-6 py-2 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
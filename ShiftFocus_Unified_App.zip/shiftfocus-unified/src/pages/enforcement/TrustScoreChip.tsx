import { TrendingUp, TrendingDown } from 'lucide-react';

interface TrustScoreChipProps {
  score: number;
  trend?: number;
  size?: 'small' | 'medium';
  showLabel?: boolean;
}

export function TrustScoreChip({ score, trend, size = 'small', showLabel = false }: TrustScoreChipProps) {
  const getColor = (score: number) => {
    if (score >= 80) return 'bg-success-light text-[var(--success-text)] border-[var(--success)]';
    if (score >= 60) return 'bg-warning-light text-[var(--warning)] border-[var(--warning)]';
    return 'bg-danger-light text-[var(--danger-text)] border-[var(--danger)]';
  };

  const getTrendColor = (trend: number) => {
    if (trend > 0) return 'text-[var(--success-text)]';
    if (trend < 0) return 'text-[var(--danger-text)]';
    return 'text-[var(--neutral-400)]';
  };

  if (size === 'small') {
    return (
      <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-semibold ${getColor(score)}`}>
        {showLabel && <span className="text-[10px] opacity-70">Trust:</span>}
        <span>{score}</span>
        {trend !== undefined && (
          <span className={`text-[10px] ${getTrendColor(trend)}`}>
            {trend > 0 ? '↑' : trend < 0 ? '↓' : '→'}{Math.abs(trend)}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg border ${getColor(score)}`}>
      {showLabel && <span className="text-xs opacity-70">Trust Score:</span>}
      <span className="font-bold">{score}/100</span>
      {trend !== undefined && (
        <div className="flex items-center gap-0.5">
          {trend > 0 ? (
            <TrendingUp className="w-3 h-3 text-[var(--success-text)]" />
          ) : trend < 0 ? (
            <TrendingDown className="w-3 h-3 text-[var(--danger-text)]" />
          ) : null}
          <span className={`text-xs ${getTrendColor(trend)}`}>
            {trend > 0 ? '+' : ''}{trend}
          </span>
        </div>
      )}
    </div>
  );
}

import { Zap, ArrowRight, Sparkles } from 'lucide-react';

interface EnterpriseUpgradeBannerProps {
  onTryNewBuilder: () => void;
  onEditEscalation: () => void;
}

export function EnterpriseUpgradeBanner({ onTryNewBuilder, onEditEscalation }: EnterpriseUpgradeBannerProps) {
  return (
    <div className="mb-6 p-6 rounded-xl text-[var(--white)] shadow-[var(--shadow-card-hover)]" style={{ background: 'linear-gradient(to right, var(--gradient-start), var(--brand-primary-active), var(--info))' }}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-6 h-6" />
            <h3 className="font-bold text-lg">Enterprise Governance Upgrade Available</h3>
          </div>
          <p className="text-sm mb-4 max-w-3xl" style={{ color: 'rgba(255,255,255,0.8)' }}>
            Transform policies from "great UI" → enterprise governance system with WHEN → IF → THEN logic, 
            escalation timelines, and evidence-based resolution tracking.
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={onTryNewBuilder}
              className="flex items-center gap-2 px-5 py-2.5 bg-surface-0 text-brand rounded-lg hover:bg-brand-light transition-colors font-semibold shadow-[var(--shadow-card)]"
            >
              <Zap className="w-4 h-4" />
              Try New Policy Builder (WHEN → IF → THEN)
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onEditEscalation}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg transition-colors font-semibold border border-[rgba(255,255,255,0.2)] text-[var(--white)]" style={{ backgroundColor: 'rgba(106, 61, 232, 0.5)' }}
            >
              Edit Escalation Timeline
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
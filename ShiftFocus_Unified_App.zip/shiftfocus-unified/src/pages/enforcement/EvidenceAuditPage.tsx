import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FileText, Search, Filter, AlertTriangle, CheckCircle2, Clock, Eye, Download, Link2, ArrowLeft } from 'lucide-react';
import { EvidenceTimeline } from './EvidenceTimeline';
import { toast } from 'sonner';
import { loadEvidenceResolutions } from './store';
import type { EvidenceResolution } from './store';

const incidents = [
  {
    id: 'INC-2401',
    title: 'Mobile App v2 Launch blocked',
    policy: 'Blocked SLA (Critical)',
    owner: 'Marcus Kim',
    status: 'open',
    severity: 'Critical',
    slaStatus: 'breached',
    slaDetails: 'Breached by 12h',
    created: '2 days ago',
    lastUpdate: '4h ago',
    escalationLevel: 'Director',
    acknowledgedCount: 0,
    totalNotifications: 8
  },
  {
    id: 'INC-2398',
    title: 'Q1 Pipeline KR stalled — no owner assigned',
    policy: 'No Orphans (High)',
    owner: 'Sarah Chen',
    status: 'resolved',
    severity: 'High',
    slaStatus: 'met',
    slaDetails: 'Resolved in 6h',
    created: '3 days ago',
    lastUpdate: '1 day ago',
    escalationLevel: 'Manager',
    acknowledgedCount: 1,
    totalNotifications: 3
  },
  {
    id: 'INC-2395',
    title: 'Design System v3 — cross-team dependency heat',
    policy: 'Dependency Heat (High)',
    owner: 'Alex Rivera',
    status: 'open',
    severity: 'High',
    slaStatus: 'warning',
    slaDetails: '4h until breach',
    created: '1 day ago',
    lastUpdate: '2h ago',
    escalationLevel: 'Owner',
    acknowledgedCount: 2,
    totalNotifications: 4
  },
  {
    id: 'INC-2392',
    title: 'API Integration task orphaned for 14 days',
    policy: 'No Orphans (Medium)',
    owner: 'Jordan Lee',
    status: 'resolved',
    severity: 'Medium',
    slaStatus: 'met',
    slaDetails: 'Resolved in 18h',
    created: '5 days ago',
    lastUpdate: '4 days ago',
    escalationLevel: 'Manager',
    acknowledgedCount: 1,
    totalNotifications: 2
  },
  {
    id: 'INC-2389',
    title: 'Customer Success KR — no update in 14 days',
    policy: 'Stale Update (Medium)',
    owner: 'Taylor Brooks',
    status: 'open',
    severity: 'Medium',
    slaStatus: 'on-track',
    slaDetails: 'On track',
    created: '12h ago',
    lastUpdate: '2h ago',
    escalationLevel: 'Owner',
    acknowledgedCount: 1,
    totalNotifications: 1
  },
  {
    id: 'INC-2387',
    title: 'Sales KR drift detected — off track for 2 weeks',
    policy: 'Risk Escalation (High)',
    owner: 'Morgan Davis',
    status: 'resolved',
    severity: 'High',
    slaStatus: 'met',
    slaDetails: 'Resolved in 24h',
    created: '1 week ago',
    lastUpdate: '6 days ago',
    escalationLevel: 'Manager',
    acknowledgedCount: 2,
    totalNotifications: 5
  },
  {
    id: 'INC-2384',
    title: 'Engineering capacity breach — 3 teams over 100%',
    policy: 'Capacity Guardrail (Critical)',
    owner: 'Casey Martinez',
    status: 'resolved',
    severity: 'Critical',
    slaStatus: 'met',
    slaDetails: 'Resolved in 8h',
    created: '2 weeks ago',
    lastUpdate: '2 weeks ago',
    escalationLevel: 'Director',
    acknowledgedCount: 3,
    totalNotifications: 6
  },
  {
    id: 'INC-2381',
    title: 'Product Initiative missing KR link',
    policy: 'No Orphans (Low)',
    owner: 'Riley Johnson',
    status: 'open',
    severity: 'Low',
    slaStatus: 'on-track',
    slaDetails: 'On track',
    created: '6h ago',
    lastUpdate: '1h ago',
    escalationLevel: 'Owner',
    acknowledgedCount: 0,
    totalNotifications: 1
  }
];

export function EvidenceAuditPage() {
  const { incidentId } = useParams<{ incidentId?: string }>();
  const navigate = useNavigate();
  const [selectedIncident, setSelectedIncident] = useState<typeof incidents[0] | null>(null);
  const [showEvidenceTimeline, setShowEvidenceTimeline] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [deepLinkedIncident, setDeepLinkedIncident] = useState<typeof incidents[0] | null>(null);
  const [evidenceResolutions, setEvidenceResolutions] = useState<EvidenceResolution[]>([]);

  // Load resolutions from localStorage on mount and listen for updates
  useEffect(() => {
    setEvidenceResolutions(loadEvidenceResolutions());
    const handleUpdate = () => setEvidenceResolutions(loadEvidenceResolutions());
    window.addEventListener('evidence-resolutions-updated', handleUpdate);
    return () => window.removeEventListener('evidence-resolutions-updated', handleUpdate);
  }, []);

  // Handle deep-linking to a specific incident
  useEffect(() => {
    if (incidentId) {
      const found = incidents.find(i => i.id === incidentId);
      if (found) {
        setDeepLinkedIncident(found);
        setSelectedIncident(found);
        setShowEvidenceTimeline(true);
        toast.success(`Deep-linked to incident ${found.id}`);
      } else {
        toast.error(`Incident "${incidentId}" not found`);
        navigate('/evidence', { replace: true });
      }
    }
  }, [incidentId]);

  // Merge resolution data into incidents — incidents resolved via EvidenceTimeline stay resolved
  const mergedIncidents = incidents.map(inc => {
    const resolution = evidenceResolutions.find(r => r.incidentId === inc.id);
    if (resolution) {
      return { ...inc, status: 'resolved' as const, slaStatus: inc.slaStatus === 'breached' ? 'breached' as const : 'met' as const, slaDetails: inc.slaStatus === 'breached' ? inc.slaDetails : 'Resolved' };
    }
    return inc;
  });

  const filteredIncidents = mergedIncidents.filter(incident => {
    const matchesStatus = filterStatus === 'all' || incident.status === filterStatus;
    const matchesSearch = searchQuery === '' || 
      incident.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      incident.policy.toLowerCase().includes(searchQuery.toLowerCase()) ||
      incident.owner.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: mergedIncidents.length,
    open: mergedIncidents.filter(i => i.status === 'open').length,
    resolved: mergedIncidents.filter(i => i.status === 'resolved').length,
    breached: mergedIncidents.filter(i => i.slaStatus === 'breached').length
  };

  const handleCopyDeepLink = (incident: typeof incidents[0]) => {
    const deepLink = `${window.location.origin}${window.location.pathname}#/evidence/${incident.id}`;
    navigator.clipboard.writeText(deepLink).then(() => {
      toast.success(`Deep link copied for ${incident.id}`);
    }).catch(() => {
      // Fallback for environments that don't support clipboard
      toast.success(`Deep link: #/evidence/${incident.id}`);
    });
  };

  const handleCloseTimeline = () => {
    setShowEvidenceTimeline(false);
    setSelectedIncident(null);
    // If we arrived via deep link, navigate back to the main evidence page
    if (incidentId) {
      navigate('/evidence', { replace: true });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between">
          <div>
            {incidentId && (
              <button
                onClick={() => navigate('/evidence')}
                className="flex items-center gap-1 text-brand hover:text-brand-hover text-sm font-medium mb-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to all incidents
              </button>
            )}
            <h2 className="text-ink mb-2">Evidence & Audit Trail</h2>
            <p className="text-ink-secondary text-sm">
              Legal-grade audit logs for every policy enforcement action — full transparency for governance
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-info-light rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-info" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">{stats.total}</div>
              <p className="text-ink-secondary text-xs">Total Incidents</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-warning-light rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-warning" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">{stats.open}</div>
              <p className="text-ink-secondary text-xs">Open</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-success-light rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-success-text" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">{stats.resolved}</div>
              <p className="text-ink-secondary text-xs">Resolved</p>
            </div>
          </div>
        </div>

        <div className="p-5 bg-surface-0 rounded-xl border border-edge">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-danger-light rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-danger-text" />
            </div>
            <div>
              <div className="text-2xl font-bold text-ink">{stats.breached}</div>
              <p className="text-ink-secondary text-xs">SLA Breached</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filterStatus === 'all'
                ? 'bg-brand text-[var(--white)]'
                : 'bg-surface-0 text-ink-secondary border border-edge hover:bg-surface-1'
            }`}
          >
            All ({stats.total})
          </button>
          <button
            onClick={() => setFilterStatus('open')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filterStatus === 'open'
                ? 'bg-warning text-[var(--white)]'
                : 'bg-surface-0 text-ink-secondary border border-edge hover:bg-surface-1'
            }`}
          >
            Open ({stats.open})
          </button>
          <button
            onClick={() => setFilterStatus('resolved')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              filterStatus === 'resolved'
                ? 'bg-success text-[var(--white)]'
                : 'bg-surface-0 text-ink-secondary border border-edge hover:bg-surface-1'
            }`}
          >
            Resolved ({stats.resolved})
          </button>
        </div>

        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search incidents, policies, owners..."
            className="w-full pl-10 pr-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
          />
        </div>

        <button onClick={() => toast('TODO: Not implemented — would export all evidence data')} className="flex items-center gap-2 px-4 py-2 bg-surface-0 text-ink-secondary border border-edge rounded-lg hover:bg-surface-1 transition-colors font-medium">
          <Download className="w-4 h-4" />
          Export All
        </button>
      </div>

      {/* Incidents Table */}
      <div className="bg-surface-0 rounded-xl border border-edge overflow-hidden">
        <table className="w-full">
          <thead className="bg-surface-1 border-b border-edge">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Incident</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Policy</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Owner</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">SLA</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Ack Rate</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-ink-secondary uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-edge">
            {filteredIncidents.map(incident => (
              <tr 
                key={incident.id} 
                className={`hover:bg-surface-1 transition-colors ${
                  incidentId === incident.id ? 'bg-brand-light ring-2 ring-brand ring-inset' : ''
                }`}
              >
                <td className="px-6 py-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-ink-muted text-xs font-mono">{incident.id}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        incident.severity === 'Critical' ? 'bg-danger-light text-danger-text' :
                        incident.severity === 'High' ? 'bg-warning-light text-warning' :
                        incident.severity === 'Medium' ? 'bg-warning-light text-warning' :
                        'bg-surface-2 text-ink-secondary'
                      }`}>
                        {incident.severity}
                      </span>
                    </div>
                    <p className="text-ink font-medium text-sm">{incident.title}</p>
                    <p className="text-ink-muted text-xs mt-1">Created {incident.created} • Updated {incident.lastUpdate}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <p className="text-ink text-sm font-medium">{incident.policy}</p>
                  <p className="text-ink-muted text-xs mt-1">Level: {incident.escalationLevel}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-ink text-sm">{incident.owner}</p>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${
                    incident.status === 'open' ? 'bg-warning-light text-warning' : 'bg-success-light text-success-text'
                  }`}>
                    {incident.status === 'open' ? (
                      <AlertTriangle className="w-3 h-3" />
                    ) : (
                      <CheckCircle2 className="w-3 h-3" />
                    )}
                    {incident.status === 'open' ? 'Open' : 'Resolved'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${
                    incident.slaStatus === 'breached' ? 'bg-danger-light text-danger-text' :
                    incident.slaStatus === 'warning' ? 'bg-warning-light text-warning' :
                    incident.slaStatus === 'met' ? 'bg-success-light text-success-text' :
                    'bg-info-light text-info'
                  }`}>
                    {incident.slaDetails}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <p className="text-ink text-sm font-medium">
                    {incident.acknowledgedCount}/{incident.totalNotifications}
                  </p>
                  <p className="text-ink-muted text-xs">
                    {incident.acknowledgedCount === 0 ? 'Not acknowledged' : 
                     incident.acknowledgedCount === incident.totalNotifications ? 'All acked' : 
                     'Partially acked'}
                  </p>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setSelectedIncident(incident);
                        setShowEvidenceTimeline(true);
                      }}
                      className="flex items-center gap-2 px-3 py-1.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-colors text-sm font-medium"
                    >
                      <Eye className="w-4 h-4" />
                      View Evidence
                    </button>
                    <div className="relative group/link">
                      <button
                        onClick={() => handleCopyDeepLink(incident)}
                        className="p-1.5 text-ink-muted hover:text-brand hover:bg-brand-light rounded transition-colors"
                      >
                        <Link2 className="w-4 h-4" />
                      </button>
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover/link:block z-10">
                        <div className="bg-ink text-[var(--white)] text-xs px-2 py-1 rounded whitespace-nowrap">
                          Copy deep link
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Evidence Timeline Modal */}
      {showEvidenceTimeline && selectedIncident && (
        <EvidenceTimeline
          isOpen={showEvidenceTimeline}
          onClose={handleCloseTimeline}
          incident={{
            id: selectedIncident.id,
            title: selectedIncident.title,
            status: selectedIncident.status,
            slaStatus: selectedIncident.slaStatus,
            slaDetails: selectedIncident.slaDetails,
            policy: selectedIncident.policy,
            owner: selectedIncident.owner,
            escalationLevel: selectedIncident.escalationLevel,
            signal: 'Blocked > 48h',
            conditions: [
              { field: 'severity', operator: '=', value: 'High' },
              { field: 'team', operator: '=', value: 'Engineering' },
              { field: 'dependency', operator: '=', value: 'cross-team' }
            ],
            exceptions: []
          }}
        />
      )}
    </div>
  );
}
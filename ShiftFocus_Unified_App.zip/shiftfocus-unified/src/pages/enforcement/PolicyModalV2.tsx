import { X, ChevronRight, ChevronLeft, Zap, Filter, ArrowRight, Play, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import { ConditionBuilder, Condition } from './ConditionBuilder';
import { ExceptionTemplates } from './ExceptionTemplates';
import { TestPolicySection } from './TestPolicySection';
import { toast } from 'sonner';
import { loadRules, saveRules } from './store';
import type { Rule } from './store';

interface PolicyModalV2Props {
  isOpen: boolean;
  onClose: () => void;
  mode?: 'create' | 'edit';
  existingPolicy?: Record<string, unknown>; // TODO: type properly during merge
}

export function PolicyModalV2({ isOpen, onClose, mode = 'create', existingPolicy }: PolicyModalV2Props) {
  const [currentStep, setCurrentStep] = useState(1);
  const [policyName, setPolicyName] = useState(existingPolicy?.name || '');
  
  // Step 1: WHEN
  const [signal, setSignal] = useState(existingPolicy?.signal || '');
  const [signalParams, setSignalParams] = useState<Record<string, string | number>>(existingPolicy?.signalParams as Record<string, string | number> || {
    blockedDuration: 2,
    objectType: 'All',
    timeframe: 7,
    checkinType: 'Weekly',
    checkinObjectType: 'KR',
  });
  
  // Step 2: IF (Conditions)
  const [conditions, setConditions] = useState<Condition[]>(existingPolicy?.conditions || []);
  const [showExceptions, setShowExceptions] = useState(false);
  const [exceptions, setExceptions] = useState<Condition[]>(existingPolicy?.exceptions || []);
  
  // Step 2b: Targeting
  const [objectTypes, setObjectTypes] = useState<string[]>(['KRs', 'Initiatives']);
  const [selectedWorkflow, setSelectedWorkflow] = useState('All workflows');
  const [tags, setTags] = useState<string[]>([]);
  
  // Step 3: THEN
  const [actions, setActions] = useState<string[]>(['notify-owner']);
  const [actionSettings, setActionSettings] = useState<Record<string, Record<string, string | number | boolean>>>(existingPolicy?.actionSettings as Record<string, Record<string, string | number | boolean>> || {
    'notify-owner': {
      channel: 'Slack',
      template: 'Standard',
      requireAck: true,
      reminderCadence: 4
    },
    'create-task': {
      assignTo: 'Owner',
      dueInHours: 24,
      taskTemplate: 'Unblock request'
    },
    'schedule-huddle': {
      duration: '15',
      schedulingRule: 'Next available slot within 24h',
      attendees: 'Owner + Blocker Owner + Manager'
    }
  });

  const updateActionSetting = (action: string, field: string, value: string | number | boolean) => {
    setActionSettings((prev) => ({
      ...prev,
      [action]: { ...(prev[action] || {}), [field]: value }
    }));
  };

  // Test Policy
  const [showTestResults, setShowTestResults] = useState(false);
  const [testDateRange, setTestDateRange] = useState('30');
  const [testRunning, setTestRunning] = useState(false);

  if (!isOpen) return null;

  const signals = [
    { value: '', label: 'Select signal...', disabled: true },
    { value: 'blocked-sla', label: 'Blocked > X days' },
    { value: 'missed-checkin', label: 'Missed check-in' },
    { value: 'stale-update', label: 'Stale update (no progress)' },
    { value: 'dependency-heat', label: 'Dependency heat detected' },
    { value: 'capacity-breach', label: 'Capacity limit breached' },
    { value: 'orphan-detected', label: 'Orphan detected (no owner/KR)' },
    { value: 'sla-breach', label: 'SLA breach' },
    { value: 'risk-escalation', label: 'Risk level escalation' },
  ];

  const actionOptions = [
    { value: 'notify-owner', label: 'Notify Owner' },
    { value: 'create-task', label: 'Create Follow-up Task' },
    { value: 'require-update', label: 'Require Update' },
    { value: 'schedule-huddle', label: 'Schedule Huddle' },
    { value: 'escalate-manager', label: 'Escalate to Manager' },
  ];

  const canProceed = () => {
    if (currentStep === 1) return policyName && signal;
    if (currentStep === 2) return true; // Conditions are optional
    if (currentStep === 3) return actions.length > 0;
    return false;
  };

  const handleSave = () => {
    // Map signal value to readable label
    const signalLabel = signals.find(s => s.value === signal)?.label || signal;
    // Map first action to readable label
    const actionLabel = actionOptions.find(a => a.value === actions[0])?.label || actions[0];
    // Build a Rule and persist to localStorage
    const newRule: Rule = {
      id: Date.now().toString(),
      name: policyName,
      signal: signalLabel,
      action: actionLabel,
      scope: selectedWorkflow === 'All workflows' ? 'All teams' : selectedWorkflow,
      enabled: true,
      status: 'draft',
      mode: 'monitor',
      team: 'Company-wide',
      severity: 'Medium',
      lastTriggered: 'Never',
      triggers7d: 0,
    };
    const current = loadRules();
    const updated = [...current, newRule];
    saveRules(updated);
    toast.success(`Policy "${policyName}" created with ${conditions.length} conditions and ${actions.length} actions`);
    // Notify other tabs (RulesBuilder, Overview, Simulation)
    window.dispatchEvent(new CustomEvent('rules-updated'));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-surface-0 rounded-xl shadow-[var(--shadow-elevated)] w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-edge">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-ink text-xl font-semibold mb-1">
                {mode === 'create' ? 'Create Policy' : 'Edit Policy'}
              </h2>
              <p className="text-ink-secondary text-sm">Automate governance logic: WHEN → IF → THEN</p>
            </div>
            <button onClick={onClose} className="text-ink-muted hover:text-ink-secondary text-2xl leading-none">
              ×
            </button>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center gap-2">
            {[1, 2, 3].map(step => (
              <div key={step} className="flex items-center flex-1">
                <div className={`flex items-center gap-2 flex-1 px-4 py-2 rounded-lg transition-colors ${
                  currentStep === step 
                    ? 'bg-brand-light border-2 border-brand' 
                    : currentStep > step
                    ? 'bg-success-light border-2 border-success'
                    : 'bg-surface-2 border-2 border-edge'
                }`}>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    currentStep === step
                      ? 'bg-brand text-[var(--white)]'
                      : currentStep > step
                      ? 'bg-success text-[var(--white)]'
                      : 'bg-edge text-ink-secondary'
                  }`}>
                    {currentStep > step ? '✓' : step}
                  </div>
                  <span className={`text-sm font-medium ${
                    currentStep === step ? 'text-brand-active' : currentStep > step ? 'text-success-text' : 'text-ink-secondary'
                  }`}>
                    {step === 1 ? 'WHEN' : step === 2 ? 'IF' : 'THEN'}
                  </span>
                </div>
                {step < 3 && <ChevronRight className="w-4 h-4 text-ink-muted mx-1" />}
              </div>
            ))}
          </div>
        </div>

        {/* Body - Scrollable */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Policy Name (Always Visible) */}
          <div>
            <label className="block text-ink-secondary font-medium text-sm mb-2">
              Policy Name <span className="text-danger-text">*</span>
            </label>
            <input
              type="text"
              value={policyName}
              onChange={(e) => setPolicyName(e.target.value)}
              placeholder="e.g., Blocked SLA - Engineering"
              className="w-full px-4 py-3 border-2 border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
            />
          </div>

          {/* Step 1: WHEN (Signal) */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="p-4 bg-brand-light border-2 border-brand rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-5 h-5 text-brand" />
                  <h3 className="text-brand-active font-semibold">Step 1: WHEN (Signal)</h3>
                </div>
                <p className="text-brand text-sm">
                  What event or condition should trigger this policy?
                </p>
              </div>

              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-2">
                  Select Signal <span className="text-danger-text">*</span>
                </label>
                <select
                  value={signal}
                  onChange={(e) => setSignal(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                >
                  {signals.map(s => (
                    <option key={s.value} value={s.value} disabled={s.disabled}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Signal Parameters (Dynamic based on signal) */}
              {signal === 'blocked-sla' && (
                <div className="grid grid-cols-2 gap-4 p-4 bg-surface-1 border border-edge rounded-lg">
                  <div>
                    <label className="block text-ink-secondary font-medium text-sm mb-2">
                      Blocked Duration (days)
                    </label>
                    <input
                      type="number"
                      value={signalParams.blockedDuration}
                      onChange={(e) => setSignalParams({ ...signalParams, blockedDuration: parseInt(e.target.value) })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                    />
                  </div>
                  <div>
                    <label className="block text-ink-secondary font-medium text-sm mb-2">
                      Object Type
                    </label>
                    <select
                      value={signalParams.objectType}
                      onChange={(e) => setSignalParams({ ...signalParams, objectType: e.target.value })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                    >
                      <option>All</option>
                      <option>KR only</option>
                      <option>Initiative only</option>
                      <option>Task only</option>
                    </select>
                  </div>
                </div>
              )}

              {signal === 'missed-checkin' && (
                <div className="grid grid-cols-3 gap-4 p-4 bg-surface-1 border border-edge rounded-lg">
                  <div>
                    <label className="block text-ink-secondary font-medium text-sm mb-2">
                      Timeframe (days)
                    </label>
                    <input
                      type="number"
                      value={signalParams.timeframe}
                      onChange={(e) => setSignalParams({ ...signalParams, timeframe: parseInt(e.target.value) })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                    />
                  </div>
                  <div>
                    <label className="block text-ink-secondary font-medium text-sm mb-2">
                      Check-in Type
                    </label>
                    <select
                      value={signalParams.checkinType}
                      onChange={(e) => setSignalParams({ ...signalParams, checkinType: e.target.value })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                    >
                      <option>Weekly</option>
                      <option>Daily</option>
                      <option>Bi-weekly</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-ink-secondary font-medium text-sm mb-2">
                      Object Type
                    </label>
                    <select
                      value={signalParams.checkinObjectType}
                      onChange={(e) => setSignalParams({ ...signalParams, checkinObjectType: e.target.value })}
                      className="w-full px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand"
                    >
                      <option>KR</option>
                      <option>Initiative</option>
                      <option>Both</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 2: IF (Conditions + Exceptions) */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="p-4 bg-info-light border-2 border-info rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Filter className="w-5 h-5 text-info" />
                  <h3 className="text-info font-semibold">Step 2: IF (Conditions)</h3>
                </div>
                <p className="text-info text-sm">
                  Optional: Add conditions to reduce noise and fire only when specific criteria are met.
                </p>
              </div>

              {/* Conditions */}
              <ConditionBuilder
                conditions={conditions}
                onChange={setConditions}
              />

              {/* Policy Targeting */}
              <div className="p-4 bg-surface-1 border border-edge rounded-lg space-y-4">
                <div>
                  <h4 className="text-ink font-semibold text-sm mb-2">Applies To</h4>
                  <p className="text-ink-secondary text-xs mb-3">Apply policies only where they matter.</p>
                </div>

                <div>
                  <label className="block text-ink-secondary font-medium text-xs mb-2">Object Types</label>
                  <div className="flex items-center gap-3">
                    {['KRs', 'Initiatives', 'Tasks', 'Dependencies'].map(type => (
                      <label key={type} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={objectTypes.includes(type)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setObjectTypes([...objectTypes, type]);
                            } else {
                              setObjectTypes(objectTypes.filter(t => t !== type));
                            }
                          }}
                          className="w-4 h-4 text-brand border-edge rounded"
                        />
                        <span className="text-ink-secondary text-sm">{type}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-ink-secondary font-medium text-xs mb-2">Workflows</label>
                  <select
                    value={selectedWorkflow}
                    onChange={(e) => setSelectedWorkflow(e.target.value)}
                    className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                  >
                    <option>All workflows</option>
                    <option>Sales pipeline</option>
                    <option>Product delivery</option>
                    <option>Hiring</option>
                    <option>Finance</option>
                  </select>
                </div>
              </div>

              {/* Exceptions */}
              <div className="border-t pt-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="text-ink font-semibold text-sm mb-1">Exceptions (Noise Killers)</h4>
                    <p className="text-ink-secondary text-xs">Exceptions prevent spam and false positives.</p>
                  </div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showExceptions}
                      onChange={(e) => setShowExceptions(e.target.checked)}
                      className="w-5 h-5 text-brand border-edge rounded"
                    />
                    <span className="text-ink-secondary text-sm font-medium">Add exceptions</span>
                  </label>
                </div>

                {showExceptions && (
                  <div className="space-y-4">
                    <ExceptionTemplates
                      onSelectTemplate={(template) => {
                        setExceptions([
                          ...exceptions,
                          {
                            id: Date.now().toString(),
                            ...template.condition
                          }
                        ]);
                      }}
                    />

                    <ConditionBuilder
                      conditions={exceptions}
                      onChange={setExceptions}
                      title="Ignore when..."
                      helper="Define conditions when this policy should NOT fire."
                      placeholder="No exceptions — policy will fire whenever conditions are met"
                      isException={true}
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 3: THEN (Actions) */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div className="p-4 bg-success-light border-2 border-success rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <ArrowRight className="w-5 h-5 text-success-text" />
                  <h3 className="text-success-text font-semibold">Step 3: THEN (Actions)</h3>
                </div>
                <p className="text-success-text text-sm">
                  What should happen when this policy fires?
                </p>
              </div>

              {/* Actions List */}
              <div>
                <label className="block text-ink-secondary font-medium text-sm mb-3">
                  Select Actions <span className="text-danger-text">*</span>
                </label>
                <div className="space-y-2">
                  {actionOptions.map(action => (
                    <label
                      key={action.value}
                      className={`flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                        actions.includes(action.value)
                          ? 'bg-brand-light border-brand'
                          : 'bg-surface-0 border-edge hover:border-ink-faint'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={actions.includes(action.value)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setActions([...actions, action.value]);
                          } else {
                            setActions(actions.filter(a => a !== action.value));
                          }
                        }}
                        className="w-5 h-5 text-brand border-edge rounded"
                      />
                      <div className="flex-1">
                        <p className="text-ink font-medium text-sm">{action.label}</p>
                        
                        {/* Action Settings (Expandable) */}
                        {actions.includes(action.value) && action.value === 'notify-owner' && (
                          <div className="mt-3 pt-3 border-t border-edge space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Channel</label>
                                <select
                                  value={actionSettings['notify-owner'].channel}
                                  onChange={(e) => updateActionSetting('notify-owner', 'channel', e.target.value)}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                >
                                  <option>Slack</option>
                                  <option>Email</option>
                                  <option>Teams</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Message Template</label>
                                <select
                                  value={actionSettings['notify-owner'].template}
                                  onChange={(e) => updateActionSetting('notify-owner', 'template', e.target.value)}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                >
                                  <option>Standard</option>
                                  <option>Friendly</option>
                                  <option>Critical</option>
                                </select>
                              </div>
                            </div>
                            <div className="flex items-center gap-4">
                              <label className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  checked={actionSettings['notify-owner']?.requireAck ?? true}
                                  onChange={(e) => updateActionSetting('notify-owner', 'requireAck', e.target.checked)}
                                  className="w-4 h-4 text-brand rounded"
                                />
                                <span className="text-ink-secondary text-xs">Require acknowledgement</span>
                              </label>
                              <div className="flex items-center gap-2">
                                <span className="text-ink-secondary text-xs">Reminder every</span>
                                <input
                                  type="number"
                                  value={actionSettings['notify-owner'].reminderCadence}
                                  onChange={(e) => updateActionSetting('notify-owner', 'reminderCadence', parseInt(e.target.value))}
                                  className="w-16 px-2 py-1 border border-edge rounded text-sm"
                                />
                                <span className="text-ink-secondary text-xs">hours</span>
                              </div>
                            </div>
                          </div>
                        )}

                        {actions.includes(action.value) && action.value === 'create-task' && (
                          <div className="mt-3 pt-3 border-t border-edge space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Assign to</label>
                                <select
                                  value={actionSettings['create-task'].assignTo}
                                  onChange={(e) => updateActionSetting('create-task', 'assignTo', e.target.value)}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                >
                                  <option>Owner</option>
                                  <option>Manager</option>
                                  <option>Policy Owner</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Due in (hours)</label>
                                <input
                                  type="number"
                                  value={actionSettings['create-task'].dueInHours}
                                  onChange={(e) => updateActionSetting('create-task', 'dueInHours', parseInt(e.target.value))}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-ink-secondary text-xs mb-1">Template</label>
                              <select
                                value={actionSettings['create-task'].taskTemplate}
                                onChange={(e) => updateActionSetting('create-task', 'taskTemplate', e.target.value)}
                                className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                              >
                                <option>Unblock request</option>
                                <option>Update request</option>
                                <option>Custom</option>
                              </select>
                            </div>
                          </div>
                        )}

                        {actions.includes(action.value) && action.value === 'schedule-huddle' && (
                          <div className="mt-3 pt-3 border-t border-edge space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Duration (min)</label>
                                <select
                                  value={actionSettings['schedule-huddle'].duration}
                                  onChange={(e) => updateActionSetting('schedule-huddle', 'duration', e.target.value)}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                >
                                  <option>15</option>
                                  <option>25</option>
                                  <option>50</option>
                                </select>
                              </div>
                              <div>
                                <label className="block text-ink-secondary text-xs mb-1">Scheduling Rule</label>
                                <select
                                  value={actionSettings['schedule-huddle'].schedulingRule}
                                  onChange={(e) => updateActionSetting('schedule-huddle', 'schedulingRule', e.target.value)}
                                  className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                                >
                                  <option>Next available slot within 24h</option>
                                  <option>Next business day</option>
                                  <option>Manual scheduling</option>
                                </select>
                              </div>
                            </div>
                            <div>
                              <label className="block text-ink-secondary text-xs mb-1">Required Attendees</label>
                              <input
                                type="text"
                                value={actionSettings['schedule-huddle'].attendees}
                                onChange={(e) => updateActionSetting('schedule-huddle', 'attendees', e.target.value)}
                                className="w-full px-3 py-2 border border-edge rounded-lg text-sm"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Test Policy Section */}
              <TestPolicySection 
                policyName={policyName}
                conditionsCount={conditions.length}
                exceptionsCount={exceptions.length}
              />
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 pb-6 pt-4 border-t border-edge flex items-center justify-between">
          <div className="flex items-center gap-2">
            {currentStep > 1 && (
              <button
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex items-center gap-2 px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
              >
                <ChevronLeft className="w-4 h-4" />
                Back
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-5 py-2.5 text-ink-secondary hover:bg-surface-2 rounded-lg transition-colors font-medium"
            >
              Cancel
            </button>

            {currentStep < 3 ? (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                disabled={!canProceed()}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-lg transition-colors font-medium ${
                  canProceed()
                    ? 'bg-brand text-[var(--white)] hover:bg-brand-hover'
                    : 'bg-edge text-ink-muted cursor-not-allowed'
                }`}
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleSave}
                disabled={!canProceed()}
                className={`px-5 py-2.5 rounded-lg transition-colors font-medium ${
                  canProceed()
                    ? 'bg-success text-[var(--white)] hover:bg-success/90'
                    : 'bg-edge text-ink-muted cursor-not-allowed'
                }`}
              >
                Save Policy
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
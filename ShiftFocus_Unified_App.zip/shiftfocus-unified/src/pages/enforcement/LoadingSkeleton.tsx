/**
 * Reusable loading skeleton component for data sections.
 * Displays shimmer placeholders during the 800ms simulated load.
 */
export function LoadingSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      {/* Header skeleton */}
      <div className="flex items-center justify-between">
        <div>
          <div className="h-6 w-48 bg-surface-2 rounded-lg mb-2" />
          <div className="h-4 w-80 bg-surface-2 rounded-lg" />
        </div>
        <div className="flex gap-3">
          <div className="h-10 w-28 bg-surface-2 rounded-lg" />
          <div className="h-10 w-28 bg-surface-2 rounded-lg" />
        </div>
      </div>

      {/* Stats row skeleton */}
      <div className="grid grid-cols-4 gap-5">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="bg-surface-0 rounded-xl border border-edge p-6">
            <div className="h-4 w-24 bg-surface-2 rounded mb-3" />
            <div className="h-8 w-16 bg-surface-2 rounded mb-2" />
            <div className="h-3 w-32 bg-surface-2 rounded" />
          </div>
        ))}
      </div>

      {/* Card list skeleton */}
      <div className="bg-surface-0 rounded-xl border border-edge p-6">
        <div className="h-5 w-40 bg-surface-2 rounded-lg mb-5" />
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="flex items-center gap-4 p-4 bg-surface-1 rounded-lg">
              <div className="w-10 h-10 bg-surface-2 rounded-lg" />
              <div className="flex-1">
                <div className="h-4 w-48 bg-surface-2 rounded mb-2" />
                <div className="h-3 w-64 bg-surface-2 rounded" />
              </div>
              <div className="h-6 w-16 bg-surface-2 rounded-full" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

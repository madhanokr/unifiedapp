import { CheckCircle2 } from 'lucide-react';

interface ExceptionTemplate {
  id: string;
  label: string;
  description: string;
  condition: {
    field: string;
    operator: string;
    value: string;
  };
}

interface ExceptionTemplatesProps {
  onSelectTemplate: (template: ExceptionTemplate) => void;
}

export function ExceptionTemplates({ onSelectTemplate }: ExceptionTemplatesProps) {
  const templates: ExceptionTemplate[] = [
    {
      id: 'resolved-2h',
      label: 'Ignore if resolved within 2 hours',
      description: 'Prevent false alarms for issues that self-resolve quickly',
      condition: { field: 'time.resolution_time', operator: '<', value: '2' }
    },
    {
      id: 'notified-24h',
      label: 'Ignore if already notified in last 24 hours',
      description: 'Prevent duplicate notifications for the same issue',
      condition: { field: 'notification.last_sent', operator: '<', value: '24' }
    },
    {
      id: 'planned-status',
      label: 'Ignore if item is in "Planned" status',
      description: 'Don\'t fire for items that haven\'t started yet',
      condition: { field: 'object.status', operator: '=', value: 'Planned' }
    },
    {
      id: 'quiet-hours',
      label: 'Ignore if within Quiet Hours',
      description: 'Use global quiet hours settings (9PM - 8AM)',
      condition: { field: 'time.quiet_hours', operator: '=', value: 'true' }
    }
  ];

  return (
    <div className="space-y-2">
      <p className="text-ink-secondary font-medium text-sm mb-3">Quick Add Templates:</p>
      <div className="grid grid-cols-2 gap-2">
        {templates.map(template => (
          <button
            key={template.id}
            onClick={() => onSelectTemplate(template)}
            className="p-3 bg-success-light border border-success rounded-lg hover:bg-success-light/80 transition-colors text-left group"
          >
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-success-text flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p className="text-ink font-medium text-xs mb-1">{template.label}</p>
                <p className="text-ink-secondary text-xs leading-relaxed">{template.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

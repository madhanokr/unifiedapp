import { useState } from 'react';
import { X, Search, Download, RotateCcw, FileText, Filter, Calendar } from 'lucide-react';
import { toast } from 'sonner';

interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  target: string;
  targetType: 'rule' | 'policy' | 'playbook' | 'setting' | 'integration';
  details: string;
  changes?: {
    field: string;
    before: string;
    after: string;
  }[];
}

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetId?: string;
  targetType?: 'rule' | 'policy' | 'playbook' | 'setting' | 'integration' | 'all';
  targetName?: string;
}

export function AuditLogModal({ isOpen, onClose, targetId, targetType = 'all', targetName }: AuditLogModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [userFilter, setUserFilter] = useState('all');
  const [actionFilter, setActionFilter] = useState('all');
  const [dateRange, setDateRange] = useState('7days');

  // Mock audit data
  const allAuditEntries: AuditEntry[] = [
    {
      id: '1',
      timestamp: '2024-01-15 14:23:45',
      user: 'Sarah Chen (COO)',
      action: 'Updated',
      target: 'Critical Escalation Policy',
      targetType: 'policy',
      details: 'Modified SLA timer from 24h to 48h',
      changes: [
        { field: 'SLA Level 1→2', before: '24 hours', after: '48 hours' }
      ]
    },
    {
      id: '2',
      timestamp: '2024-01-15 11:42:12',
      user: 'Marcus Kim',
      action: 'Activated',
      target: 'Dependency Heat Playbook',
      targetType: 'playbook',
      details: 'Changed from Draft to Live mode',
      changes: [
        { field: 'Status', before: 'Draft', after: 'Live' },
        { field: 'Mode', before: 'Monitor', after: 'Enforce' }
      ]
    },
    {
      id: '3',
      timestamp: '2024-01-15 09:18:33',
      user: 'Alex Rivera',
      action: 'Created',
      target: 'Missed Weekly Check-in',
      targetType: 'rule',
      details: 'New enforcement rule for Engineering team',
      changes: [
        { field: 'Signal', before: '-', after: 'Missed check-in' },
        { field: 'Scope', before: '-', after: 'Engineering' },
        { field: 'Severity', before: '-', after: 'High' }
      ]
    },
    {
      id: '4',
      timestamp: '2024-01-14 16:45:21',
      user: 'Sarah Chen (COO)',
      action: 'Updated',
      target: 'Notification Limits',
      targetType: 'setting',
      details: 'Reduced daily notification cap',
      changes: [
        { field: 'Max per day', before: '20', after: '15' }
      ]
    },
    {
      id: '5',
      timestamp: '2024-01-14 14:12:09',
      user: 'Marcus Kim',
      action: 'Paused',
      target: 'KR Drift Alert',
      targetType: 'rule',
      details: 'Temporarily disabled for testing',
      changes: [
        { field: 'Status', before: 'Live', after: 'Paused' }
      ]
    },
    {
      id: '6',
      timestamp: '2024-01-14 10:33:47',
      user: 'Alex Rivera',
      action: 'Connected',
      target: 'Jira Integration',
      targetType: 'integration',
      details: 'Connected to ShiftFocus Engineering workspace',
      changes: [
        { field: 'Status', before: 'Disconnected', after: 'Connected' },
        { field: 'Workspace', before: '-', after: 'ShiftFocus Engineering' }
      ]
    },
    {
      id: '7',
      timestamp: '2024-01-13 15:22:18',
      user: 'Sarah Chen (COO)',
      action: 'Rolled Back',
      target: 'Standard Escalation Policy',
      targetType: 'policy',
      details: 'Restored previous configuration',
      changes: [
        { field: 'Chain', before: 'Owner → Exec → COO', after: 'Owner → Manager → Exec' }
      ]
    },
    {
      id: '8',
      timestamp: '2024-01-13 11:08:52',
      user: 'Marcus Kim',
      action: 'Updated',
      target: 'Quiet Hours',
      targetType: 'setting',
      details: 'Extended quiet hours window',
      changes: [
        { field: 'Start Time', before: '20:00', after: '19:00' },
        { field: 'End Time', before: '08:00', after: '09:00' }
      ]
    },
    {
      id: '9',
      timestamp: '2024-01-12 16:54:33',
      user: 'Alex Rivera',
      action: 'Deleted',
      target: 'Old Test Rule',
      targetType: 'rule',
      details: 'Removed deprecated testing rule',
      changes: []
    },
    {
      id: '10',
      timestamp: '2024-01-12 09:41:15',
      user: 'Sarah Chen (COO)',
      action: 'Updated',
      target: 'Weekly Executive Brief',
      targetType: 'playbook',
      details: 'Modified trigger schedule',
      changes: [
        { field: 'Schedule', before: 'Monday 9:00 AM', after: 'Monday 8:00 AM' }
      ]
    }
  ];

  // Filter audit entries
  const filteredEntries = allAuditEntries.filter(entry => {
    // Filter by target if specified
    if (targetId && entry.target !== targetName) return false;
    if (targetType !== 'all' && entry.targetType !== targetType) return false;
    
    // Filter by search query
    if (searchQuery && !entry.target.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !entry.user.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !entry.details.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Filter by user
    if (userFilter !== 'all' && !entry.user.includes(userFilter)) return false;
    
    // Filter by action
    if (actionFilter !== 'all' && entry.action !== actionFilter) return false;
    
    return true;
  });

  const getActionColor = (action: string) => {
    switch (action) {
      case 'Created':
      case 'Connected':
      case 'Activated':
        return 'bg-success-light text-[var(--success-text)]';
      case 'Updated':
        return 'bg-info-light text-[var(--info)]';
      case 'Paused':
        return 'bg-warning-light text-[var(--warning)]';
      case 'Deleted':
      case 'Rolled Back':
        return 'bg-danger-light text-[var(--danger-text)]';
      default:
        return 'bg-surface-2 text-[var(--neutral-600)]';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'rule': return '⚡';
      case 'policy': return '📋';
      case 'playbook': return '📚';
      case 'setting': return '⚙️';
      case 'integration': return '🔌';
      default: return '📄';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-30" onClick={onClose} />

      <div className="absolute inset-y-0 right-0 max-w-4xl w-full bg-surface-0 shadow-[var(--shadow-elevated)] flex flex-col">
        {/* Header */}
        <div className="px-8 py-6 border-b border-[var(--neutral-200)] flex items-center justify-between bg-gradient-to-r from-brand-light to-[var(--white)]">
          <div>
            <h2 className="text-[var(--neutral-800)] mb-1">Audit Log</h2>
            {targetName ? (
              <p className="text-[var(--neutral-600)] text-sm">
                Activity history for <span className="font-semibold text-brand">{targetName}</span>
              </p>
            ) : (
              <p className="text-[var(--neutral-600)] text-sm">
                Complete activity history across all enforcement configurations
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-surface-2 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[var(--neutral-600)]" />
          </button>
        </div>

        {/* Filters */}
        <div className="px-8 py-5 border-b border-[var(--neutral-200)] bg-surface-1">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--neutral-400)]" />
              <input
                type="text"
                placeholder="Search by user, target, or action..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent text-sm"
              />
            </div>
            <button onClick={() => toast('TODO: Not implemented — would export audit log as CSV')} className="px-4 py-2 border border-[var(--neutral-200)] text-[var(--neutral-600)] rounded-lg hover:bg-[var(--neutral-50)] transition-all text-sm font-medium flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[var(--neutral-400)]" />
              <span className="text-sm text-[var(--neutral-600)] font-medium">Filters:</span>
            </div>
            
            <select
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              className="px-3 py-1.5 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand text-sm"
            >
              <option value="all">All Users</option>
              <option value="Sarah Chen">Sarah Chen</option>
              <option value="Marcus Kim">Marcus Kim</option>
              <option value="Alex Rivera">Alex Rivera</option>
            </select>

            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="px-3 py-1.5 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand text-sm"
            >
              <option value="all">All Actions</option>
              <option value="Created">Created</option>
              <option value="Updated">Updated</option>
              <option value="Deleted">Deleted</option>
              <option value="Activated">Activated</option>
              <option value="Paused">Paused</option>
              <option value="Connected">Connected</option>
              <option value="Rolled Back">Rolled Back</option>
            </select>

            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="px-3 py-1.5 border border-[var(--neutral-200)] rounded-lg focus:outline-none focus:ring-2 focus:ring-brand text-sm"
            >
              <option value="24hours">Last 24 hours</option>
              <option value="7days">Last 7 days</option>
              <option value="30days">Last 30 days</option>
              <option value="90days">Last 90 days</option>
              <option value="all">All time</option>
            </select>

            {(searchQuery || userFilter !== 'all' || actionFilter !== 'all' || dateRange !== '7days') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setUserFilter('all');
                  setActionFilter('all');
                  setDateRange('7days');
                }}
                className="text-sm text-brand hover:text-brand-hover font-medium"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>

        {/* Audit Entries */}
        <div className="flex-1 overflow-y-auto px-8 py-6">
          {filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-surface-2 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-[var(--neutral-400)]" />
              </div>
              <p className="text-[var(--neutral-600)] mb-1">No audit entries found</p>
              <p className="text-sm text-[var(--neutral-400)]">Try adjusting your filters</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="bg-surface-0 border border-[var(--neutral-200)] rounded-lg p-5 hover:shadow-md transition-all group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="w-10 h-10 bg-surface-2 rounded-lg flex items-center justify-center text-xl flex-shrink-0">
                        {getTypeIcon(entry.targetType)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getActionColor(entry.action)}`}>
                            {entry.action}
                          </span>
                          <span className="text-[var(--neutral-800)] font-semibold text-sm">{entry.target}</span>
                        </div>
                        <p className="text-[var(--neutral-600)] text-sm mb-2">{entry.details}</p>
                        <div className="flex items-center gap-4 text-xs text-[var(--neutral-400)]">
                          <span>By: <span className="font-medium text-[var(--neutral-600)]">{entry.user}</span></span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {entry.timestamp}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button onClick={() => toast('TODO: Not implemented — would rollback this change')} className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 px-3 py-1.5 text-brand hover:bg-brand-light rounded-lg text-xs font-medium">
                      <RotateCcw className="w-3 h-3" />
                      Rollback
                    </button>
                  </div>

                  {/* Change Details */}
                  {entry.changes && entry.changes.length > 0 && (
                    <div className="ml-13 pt-3 border-t border-[var(--neutral-100)]">
                      <div className="space-y-1.5">
                        {entry.changes.map((change, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-xs">
                            <span className="text-[var(--neutral-400)] font-medium min-w-[100px]">{change.field}:</span>
                            <span className="px-2 py-0.5 bg-danger-light text-[var(--danger-text)] rounded font-mono">
                              {change.before}
                            </span>
                            <span className="text-[var(--neutral-400)]">→</span>
                            <span className="px-2 py-0.5 bg-success-light text-[var(--success-text)] rounded font-mono">
                              {change.after}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Stats */}
        <div className="px-8 py-4 border-t border-[var(--neutral-200)] bg-surface-1">
          <div className="flex items-center justify-between text-sm">
            <div className="text-[var(--neutral-600)]">
              Showing <span className="font-semibold text-[var(--neutral-800)]">{filteredEntries.length}</span> of {allAuditEntries.length} entries
            </div>
            <div className="flex items-center gap-4 text-xs text-[var(--neutral-400)]">
              <span>⚡ {allAuditEntries.filter(e => e.targetType === 'rule').length} Rule changes</span>
              <span>📋 {allAuditEntries.filter(e => e.targetType === 'policy').length} Policy changes</span>
              <span>⚙️ {allAuditEntries.filter(e => e.targetType === 'setting').length} Setting changes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
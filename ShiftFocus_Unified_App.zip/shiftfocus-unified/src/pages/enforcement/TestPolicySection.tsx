import { Play, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

interface TestPolicySectionProps {
  policyName: string;
  conditionsCount: number;
  exceptionsCount: number;
}

export function TestPolicySection({ policyName, conditionsCount, exceptionsCount }: TestPolicySectionProps) {
  const [showTestResults, setShowTestResults] = useState(false);
  const [testDateRange, setTestDateRange] = useState('30');
  const [testRunning, setTestRunning] = useState(false);

  const runSimulation = () => {
    setTestRunning(true);
    setTimeout(() => {
      setTestRunning(false);
      setShowTestResults(true);
    }, 1500);
  };

  return (
    <div className="border-t pt-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-ink font-semibold text-sm mb-1">Test This Policy</h4>
          <p className="text-ink-secondary text-xs">See how many times this policy would have fired in the past</p>
        </div>
        {!showTestResults && (
          <button
            onClick={runSimulation}
            disabled={testRunning}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-lg transition-colors font-medium ${
              testRunning
                ? 'bg-edge text-ink-muted cursor-wait'
                : 'bg-info text-[var(--white)] hover:bg-info/90 shadow-[var(--shadow-card)]'
            }`}
          >
            <Play className="w-4 h-4" />
            {testRunning ? 'Running Simulation...' : 'Run Simulation'}
          </button>
        )}
      </div>

      {/* Date Range Selector */}
      {!showTestResults && (
        <div className="mb-4">
          <label className="block text-ink-secondary font-medium text-sm mb-2">Date Range:</label>
          <div className="flex items-center gap-3">
            {['7', '14', '30'].map(days => (
              <label key={days} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="testDateRange"
                  value={days}
                  checked={testDateRange === days}
                  onChange={(e) => setTestDateRange(e.target.value)}
                  className="w-4 h-4 text-info border-edge"
                />
                <span className="text-ink-secondary text-sm">Last {days} days</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Test Results */}
      {showTestResults && (
        <div className="space-y-4">
          {/* Summary Stats */}
          <div className="p-5 bg-gradient-to-br from-info-light to-info-light/50 border-2 border-info rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-info font-semibold text-lg mb-1">Would have fired 42 times</p>
                <p className="text-info text-sm">In the last {testDateRange} days</p>
              </div>
              <button
                onClick={() => setShowTestResults(false)}
                className="text-info hover:text-info/80 text-sm font-medium underline"
              >
                Run Again
              </button>
            </div>

            {/* Breakdown */}
            <div className="grid grid-cols-4 gap-3 mb-4">
              <div className="p-3 bg-surface-0 rounded-lg border border-danger">
                <div className="text-2xl font-bold text-danger-text mb-1">8</div>
                <p className="text-danger-text text-xs font-medium">Critical</p>
              </div>
              <div className="p-3 bg-surface-0 rounded-lg border border-warning">
                <div className="text-2xl font-bold text-warning mb-1">15</div>
                <p className="text-warning text-xs font-medium">High</p>
              </div>
              <div className="p-3 bg-surface-0 rounded-lg border border-warning">
                <div className="text-2xl font-bold text-warning mb-1">14</div>
                <p className="text-warning text-xs font-medium">Medium</p>
              </div>
              <div className="p-3 bg-surface-0 rounded-lg border border-edge">
                <div className="text-2xl font-bold text-ink-secondary mb-1">5</div>
                <p className="text-ink text-xs font-medium">Low</p>
              </div>
            </div>

            {/* Top Affected Teams */}
            <div className="p-3 bg-surface-0 rounded-lg border border-info">
              <p className="text-info font-semibold text-xs mb-2">Top Affected Teams:</p>
              <div className="flex items-center gap-2 flex-wrap">
                {['Engineering (18)', 'Product (12)', 'Sales (8)', 'Design (4)'].map(team => (
                  <span key={team} className="px-2 py-1 bg-info-light text-info rounded text-xs font-medium">
                    {team}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sample Incidents */}
          <div>
            <p className="text-ink font-semibold text-sm mb-3">Top 5 Sample Incidents (Why They Fired):</p>
            <div className="space-y-2">
              {[
                {
                  title: 'Mobile App v2 Launch blocked',
                  team: 'Engineering',
                  severity: 'Critical',
                  why: ['Severity = High', 'Team = Engineering', 'Aging > 48h']
                },
                {
                  title: 'Q1 Pipeline KR stalled',
                  team: 'Sales',
                  severity: 'High',
                  why: ['Severity = High', 'Team = Sales', 'Has cross-team dependency = Yes']
                },
                {
                  title: 'Design System v3 dependency heat',
                  team: 'Design',
                  severity: 'High',
                  why: ['Team = Design', 'Status = Blocked', '# of blockers >= 2']
                },
                {
                  title: 'API Integration orphaned task',
                  team: 'Engineering',
                  severity: 'Medium',
                  why: ['Team = Engineering', 'Has owner = No', 'Object Type = Task']
                },
                {
                  title: 'Customer Success KR drift',
                  team: 'Product',
                  severity: 'Medium',
                  why: ['Team = Product', 'Last update older than = 7 days', 'Priority = Medium']
                }
              ].map((incident, i) => (
                <div key={i} className="p-4 bg-surface-0 border-2 border-edge rounded-lg hover:border-info transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-ink-muted text-xs font-bold">#{i + 1}</span>
                        <h5 className="text-ink font-semibold text-sm">{incident.title}</h5>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                          incident.severity === 'Critical' ? 'bg-danger-light text-danger-text' :
                          incident.severity === 'High' ? 'bg-warning-light text-warning' :
                          'bg-warning-light text-warning'
                        }`}>
                          {incident.severity}
                        </span>
                      </div>
                      <p className="text-ink-secondary text-xs mb-2">{incident.team} Team</p>
                      
                      {/* Why Fired Explanation */}
                      <div className="p-3 bg-info-light border border-info rounded-lg">
                        <p className="text-info font-semibold text-xs mb-2">✓ Matched because:</p>
                        <ul className="space-y-1">
                          {incident.why.map((reason, j) => (
                            <li key={j} className="flex items-center gap-2 text-info text-xs">
                              <CheckCircle2 className="w-3 h-3 text-info flex-shrink-0" />
                              {reason}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="p-4 bg-gradient-to-r from-success-light to-success-light/50 border-2 border-success rounded-lg">
            <p className="text-success-text font-semibold text-sm mb-1">✓ Policy looks good!</p>
            <p className="text-success-text text-xs">
              This policy would catch real issues without creating noise. 
              {conditionsCount > 0 && ` The ${conditionsCount} condition${conditionsCount !== 1 ? 's' : ''}`}
              {conditionsCount > 0 && exceptionsCount > 0 && ' and'}
              {exceptionsCount > 0 && ` ${exceptionsCount} exception${exceptionsCount !== 1 ? 's' : ''}`}
              {(conditionsCount > 0 || exceptionsCount > 0) && ' are working as expected.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
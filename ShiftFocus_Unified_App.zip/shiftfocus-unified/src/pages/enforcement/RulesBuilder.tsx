import { useState, useEffect } from 'react';
import { Search, Plus, Clock, Play, Copy, History, Filter, FileText, Trash2 } from 'lucide-react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { CreateRuleModal } from './CreateRuleModal';
import { AuditLogModal } from './AuditLogModal';
import { PolicyModalV2 } from './PolicyModalV2';
import { EscalationPolicyEditor } from './EscalationPolicyEditor';
import { EnterpriseUpgradeBanner } from './EnterpriseUpgradeBanner';
import { loadRules, saveRules, updateRule, deleteRule, duplicateRule } from './store';
import type { Rule } from './store';
import { toast } from 'sonner';

export function RulesBuilder() {
  const [rules, setRules] = useState<Rule[]>(() => loadRules());
  const [searchQuery, setSearchQuery] = useState('');
  const [teamFilter, setTeamFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingRule, setEditingRule] = useState<Rule | null>(null);
  const [showAuditLogModal, setShowAuditLogModal] = useState(false);
  const [selectedRule, setSelectedRule] = useState<Rule | null>(null);
  const [showPolicyModalV2, setShowPolicyModalV2] = useState(false);
  const [showEscalationEditor, setShowEscalationEditor] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // Sync rules when another component (e.g. header "New Policy") writes to localStorage
  useEffect(() => {
    const handleExternalSave = () => setRules(loadRules());
    window.addEventListener('rules-updated', handleExternalSave);
    return () => window.removeEventListener('rules-updated', handleExternalSave);
  }, []);

  const filteredRules = rules.filter((rule) => {
    const matchesSearch = rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.signal.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTeam = teamFilter === 'all' || rule.team === teamFilter;
    const matchesStatus = statusFilter === 'all' || rule.status === statusFilter;
    const matchesSeverity = severityFilter === 'all' || rule.severity === severityFilter;
    
    return matchesSearch && matchesTeam && matchesStatus && matchesSeverity;
  });

  const handleToggleRule = (ruleId: string) => {
    const rule = rules.find(r => r.id === ruleId);
    if (!rule) return;
    const updated = updateRule(rules, ruleId, { enabled: !rule.enabled });
    setRules(updated);
    toast.success(`Rule "${rule.name}" ${rule.enabled ? 'disabled' : 'enabled'}`);
  };

  const handleEditRule = (rule: Rule) => {
    setEditingRule(rule);
    setShowCreateModal(true);
  };

  const handleCloseModal = () => {
    setShowCreateModal(false);
    setEditingRule(null);
  };

  const handleSaveRule = (savedRule: Rule) => {
    const existing = rules.find(r => r.id === savedRule.id);
    let updated: Rule[];
    if (existing) {
      updated = updateRule(rules, savedRule.id, savedRule);
      toast.success(`Rule "${savedRule.name}" updated`);
    } else {
      updated = [...rules, savedRule];
      saveRules(updated);
      toast.success(`Rule "${savedRule.name}" created`);
    }
    setRules(updated);
    handleCloseModal();
  };

  const handleDuplicateRule = (ruleId: string) => {
    const original = rules.find(r => r.id === ruleId);
    const updated = duplicateRule(rules, ruleId);
    setRules(updated);
    toast.success(`Duplicated "${original?.name}"`);
  };

  const handleDeleteRule = (ruleId: string) => {
    const rule = rules.find(r => r.id === ruleId);
    const updated = deleteRule(rules, ruleId);
    setRules(updated);
    setConfirmDeleteId(null);
    toast.success(`Deleted "${rule?.name}"`);
  };

  const handleViewAuditLog = (rule: Rule) => {
    setSelectedRule(rule);
    setShowAuditLogModal(true);
  };

  const handleCloseAuditLogModal = () => {
    setShowAuditLogModal(false);
    setSelectedRule(null);
  };

  return (
    <div>
      {/* Enterprise Upgrade Banner */}
      <EnterpriseUpgradeBanner
        onTryNewBuilder={() => setShowPolicyModalV2(true)}
        onEditEscalation={() => setShowEscalationEditor(true)}
      />

      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-ink mb-1">Rules Management</h2>
          <p className="text-ink-muted text-sm">
            Build custom enforcement logic with conditional triggers
          </p>
        </div>
        <button 
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-brand text-[var(--white)] rounded-lg hover:bg-brand-hover transition-all shadow-[var(--shadow-card)]"
        >
          <Plus className="w-4 h-4" />
          Create Rule
        </button>
      </div>

      {/* Search & Filters */}
      <div className="bg-surface-0 rounded-xl border border-edge p-4 mb-5">
        <div className="flex items-center gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-ink-muted" />
            <input
              type="text"
              placeholder="Search rules..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center gap-3">
            <Filter className="w-5 h-5 text-ink-muted" />
            
            <select
              value={teamFilter}
              onChange={(e) => setTeamFilter(e.target.value)}
              className="px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent text-sm"
            >
              <option value="all">All Teams</option>
              <option value="Company-wide">Company-wide</option>
              <option value="Engineering">Engineering</option>
              <option value="Sales">Sales</option>
              <option value="Product">Product</option>
            </select>

            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent text-sm"
            >
              <option value="all">All Severity</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-edge rounded-lg focus:outline-none focus:ring-2 focus:ring-brand focus:border-transparent text-sm"
            >
              <option value="all">All Status</option>
              <option value="live">Live</option>
              <option value="draft">Draft</option>
              <option value="paused">Paused</option>
            </select>
          </div>
        </div>
      </div>

      {/* Rules Table */}
      <div className="bg-surface-0 rounded-xl border border-edge shadow-[var(--shadow-card)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-surface-1 border-b border-edge">
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Rule Name
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Signal
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Action
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Last Triggered
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Triggers (7d)
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Mode
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-right text-xs font-medium text-ink-secondary uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-edge-light">
              {filteredRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-surface-1 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={rule.enabled}
                          onChange={() => handleToggleRule(rule.id)}
                          className="sr-only peer"
                        />
                        <div className="w-9 h-5 bg-edge peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-surface-0 after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-brand"></div>
                      </label>
                      <div>
                        <div className="text-ink font-medium">{rule.name}</div>
                        <div className="flex items-center gap-2 mt-1">
                          <span
                            className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                              rule.severity === 'High'
                                ? 'bg-danger-light text-danger-text'
                                : rule.severity === 'Medium'
                                ? 'bg-warning-light text-warning'
                                : 'bg-info-light text-info'
                            }`}
                          >
                            {rule.severity}
                          </span>
                          <span className="text-xs text-ink-muted">{rule.team}</span>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-ink-secondary">{rule.signal}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-ink-secondary">{rule.action}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-ink-secondary">
                      <Clock className="w-4 h-4" />
                      <span>{rule.lastTriggered}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-ink">{rule.triggers7d}</span>
                      {rule.triggers7d > 15 && (
                        <span className="text-danger-text text-xs flex items-center gap-0.5">
                          <TrendingUp className="w-3 h-3" />
                          ↑45%
                        </span>
                      )}
                      {rule.triggers7d >= 10 && rule.triggers7d <= 15 && (
                        <span className="text-ink-muted text-xs">
                          →
                        </span>
                      )}
                      {rule.triggers7d < 10 && rule.triggers7d > 0 && (
                        <span className="text-success-text text-xs flex items-center gap-0.5">
                          <TrendingDown className="w-3 h-3" />
                          ↓12%
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${
                        rule.mode === 'enforce'
                          ? 'bg-brand-light text-brand'
                          : 'bg-info-light text-info'
                      }`}
                    >
                      {rule.mode === 'enforce' ? 'Enforce' : 'Monitor'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${
                        rule.status === 'live'
                          ? 'bg-success-light text-success-text'
                          : rule.status === 'draft'
                          ? 'bg-surface-2 text-ink-secondary'
                          : 'bg-warning-light text-warning'
                      }`}
                    >
                      {rule.status.charAt(0).toUpperCase() + rule.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <div className="relative group/test">
                        <button onClick={() => toast('TODO: Not implemented — would run rule simulation test')} className="p-1.5 text-ink-secondary hover:text-brand hover:bg-brand-light rounded transition-colors">
                          <Play className="w-4 h-4" />
                        </button>
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover/test:block">
                          <div className="bg-ink text-[var(--white)] text-xs px-2 py-1 rounded whitespace-nowrap">
                            Test
                          </div>
                        </div>
                      </div>
                      <div className="relative group/duplicate">
                        <button
                          onClick={() => handleDuplicateRule(rule.id)}
                          className="p-1.5 text-ink-secondary hover:text-brand hover:bg-brand-light rounded transition-colors"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover/duplicate:block">
                          <div className="bg-ink text-[var(--white)] text-xs px-2 py-1 rounded whitespace-nowrap">
                            Duplicate
                          </div>
                        </div>
                      </div>
                      <div className="relative group/history">
                        <button onClick={() => toast('TODO: Not implemented — would show rule change history')} className="p-1.5 text-ink-secondary hover:text-brand hover:bg-brand-light rounded transition-colors">
                          <History className="w-4 h-4" />
                        </button>
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover/history:block">
                          <div className="bg-ink text-[var(--white)] text-xs px-2 py-1 rounded whitespace-nowrap">
                            History
                          </div>
                        </div>
                      </div>
                      <div className="relative group/audit-log">
                        <button
                          onClick={() => handleViewAuditLog(rule)}
                          className="p-1.5 text-ink-secondary hover:text-brand hover:bg-brand-light rounded transition-colors"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover/audit-log:block">
                          <div className="bg-ink text-[var(--white)] text-xs px-2 py-1 rounded whitespace-nowrap">
                            {rule.mode === 'enforce' ? 'Rule is actively enforcing policies' : 'Rule is monitoring but not enforcing'}
                          </div>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleEditRule(rule)}
                        className="text-brand hover:text-brand-hover text-sm font-medium ml-2 px-3 py-1 hover:bg-brand-light rounded transition-colors"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => setConfirmDeleteId(rule.id)}
                        className="text-danger-text hover:text-danger text-sm font-medium ml-2 px-3 py-1 hover:bg-danger-light rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Rule Modal */}
      <CreateRuleModal
        show={showCreateModal}
        onClose={handleCloseModal}
        editingRule={editingRule}
        onSave={handleSaveRule}
      />

      {/* Audit Log Modal */}
      <AuditLogModal
        isOpen={showAuditLogModal}
        onClose={handleCloseAuditLogModal}
        targetId={selectedRule?.id}
        targetType="rule"
        targetName={selectedRule?.name}
      />

      {/* Policy Modal V2 */}
      <PolicyModalV2
        isOpen={showPolicyModalV2}
        onClose={() => setShowPolicyModalV2(false)}
      />

      {/* Escalation Policy Editor */}
      <EscalationPolicyEditor
        isOpen={showEscalationEditor}
        onClose={() => setShowEscalationEditor(false)}
      />

      {/* Delete Confirmation */}
      {confirmDeleteId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-surface-0 p-6 rounded-lg shadow-[var(--shadow-card-hover)]">
            <h3 className="text-lg font-bold mb-4">Confirm Delete</h3>
            <p className="text-ink-muted mb-6">
              Are you sure you want to delete this rule?
            </p>
            <div className="flex justify-end">
              <button
                onClick={() => setConfirmDeleteId(null)}
                className="text-ink-muted hover:text-ink-secondary px-4 py-2 rounded mr-2"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteRule(confirmDeleteId)}
                className="bg-danger text-[var(--white)] hover:bg-danger-text px-4 py-2 rounded"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
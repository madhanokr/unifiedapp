import { X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { ReactNode } from 'react';

interface SlideUpProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  height?: string;
}

export function SlideUp({ isOpen, onClose, children, title, height = '70%' }: SlideUpProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40"
            style={{
              backgroundColor: 'rgba(0, 0, 0, 0.2)',
              backdropFilter: 'blur(4px)',
            }}
            onClick={onClose}
          />
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-50 flex flex-col"
            style={{
              height,
              backgroundColor: 'var(--white)',
              borderTopLeftRadius: 'var(--radius-card)',
              borderTopRightRadius: 'var(--radius-card)',
              boxShadow: 'var(--shadow-modal)',
            }}
          >
            <div className="flex flex-col items-center pt-4 pb-2">
              <div
                className="w-12 h-1 rounded-full mb-4"
                style={{ backgroundColor: 'var(--neutral-200)' }}
              />
            </div>
            {title && (
              <div
                className="flex items-center justify-between px-8 pb-4"
                style={{ borderBottom: '1px solid var(--neutral-200)' }}
              >
                <h2 className="text-h3" style={{ color: 'var(--neutral-800)' }}>
                  {title}
                </h2>
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-[var(--radius-button)] flex items-center justify-center transition-colors"
                  style={{ color: 'var(--neutral-400)' }}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}
            <div className="flex-1 overflow-y-auto px-8 py-6">{children}</div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

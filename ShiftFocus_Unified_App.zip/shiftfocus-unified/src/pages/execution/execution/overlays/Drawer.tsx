import type { ReactNode } from 'react';
import { Sheet } from '../../design-system/sheet';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
}

export function Drawer({ isOpen, onClose, children, title }: DrawerProps) {
  return (
    <Sheet open={isOpen} onOpenChange={(open) => !open && onClose()} title={title}>
      {children}
    </Sheet>
  );
}

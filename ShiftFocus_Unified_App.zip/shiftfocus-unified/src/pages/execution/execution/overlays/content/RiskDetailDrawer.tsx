import { useState } from 'react';
import { Clock, DollarSign, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import type { Risk } from '../../../types/execution';
import { Badge } from '../../../design-system/badge';
import { Button } from '../../../design-system/button';
import { ConfirmDialog } from '../../../design-system/dialog';

interface RiskDetailDrawerProps {
  risk: Risk;
}

function severityVariant(severity: string) {
  if (severity === 'high') return 'danger' as const;
  if (severity === 'medium') return 'warning' as const;
  return 'neutral' as const;
}

function ownerFullName(code: string): string {
  const map: Record<string, string> = {
    MJ: 'Marcus Johnson',
    SC: 'Sarah Chen',
    DM: 'David Miller',
    LP: 'Lisa Park',
    ER: 'Emma Rodriguez',
  };
  return map[code] || code;
}

export function RiskDetailDrawer({ risk }: RiskDetailDrawerProps) {
  const [resolveOpen, setResolveOpen] = useState(false);
  const [selectedFixes, setSelectedFixes] = useState<number[]>([]);

  const toggleFix = (idx: number) => {
    setSelectedFixes((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const fixes = [
    { text: 'Reallocate 2 engineers from Mobile to Backend', detail: 'Reduces workload by 28%' },
    { text: 'Defer 3 non-critical features to Q1', detail: 'Reduces scope by 22%' },
    { text: 'Approve contractor budget ($45k)', detail: 'Adds capacity immediately' },
  ];

  return (
    <div className="p-6 space-y-8">
      {/* Risk Level */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>RISK LEVEL</h3>
        <Badge variant={severityVariant(risk.severity)} size="md" className="capitalize">
          <div
            className="w-2 h-2 rounded-full"
            style={{
              backgroundColor: risk.severity === 'high' ? 'var(--danger)' : 'var(--at-risk)',
            }}
          />
          {risk.severity} Priority
        </Badge>
      </div>

      {/* Impact & Time Sensitivity */}
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--danger-light)' }}>
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4" style={{ color: 'var(--danger)' }} />
            <span className="text-micro" style={{ color: 'var(--danger)' }}>FINANCIAL IMPACT</span>
          </div>
          <div className="text-h1 tabular-nums" style={{ color: 'var(--neutral-800)' }}>{risk.impact}</div>
        </div>
        <div className="p-4 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--warning-light)' }}>
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4" style={{ color: 'var(--at-risk)' }} />
            <span className="text-micro" style={{ color: 'var(--at-risk)' }}>TIME SENSITIVITY</span>
          </div>
          <div className="text-h1 tabular-nums" style={{ color: 'var(--neutral-800)' }}>3 days</div>
        </div>
      </div>

      {/* Owner Assignment */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>OWNER ASSIGNMENT</h3>
        <div
          className="flex items-center gap-3 p-4 rounded-[var(--radius-card)]"
          style={{ backgroundColor: 'var(--neutral-50)' }}
        >
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-caption-medium"
            style={{
              background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
              color: 'var(--white)',
            }}
          >
            {risk.owner}
          </div>
          <div>
            <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
              {ownerFullName(risk.owner)}
            </div>
            <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>Engineering Lead</div>
          </div>
          <Button
            variant="secondary"
            size="sm"
            className="ml-auto"
            style={{ border: '1px solid var(--neutral-200)' }}
            onClick={() => toast.success('Reassignment requested')}
          >
            Reassign
          </Button>
        </div>
      </div>

      {/* Detailed Description */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>DETAILED DESCRIPTION</h3>
        <div
          className="p-4 rounded-[var(--radius-card)] text-body"
          style={{ backgroundColor: 'var(--neutral-50)', color: 'var(--neutral-600)', lineHeight: 1.6 }}
        >
          Engineering team workload has exceeded safe operational capacity by 3.2x. This is causing:
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>12 tasks past deadline (avg 4.3 days late)</li>
            <li>Developer burnout risk (3 engineers at 180% capacity)</li>
            <li>Quality degradation in recent deliverables</li>
          </ul>
        </div>
      </div>

      {/* Root Cause (AI Generated) */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>ROOT CAUSE (AI GENERATED)</h3>
        <div
          className="p-4 rounded-[var(--radius-card)]"
          style={{ backgroundColor: 'var(--brand-primary-light)', border: '1px solid var(--brand-primary-light)' }}
        >
          <div className="space-y-2">
            {[
              'Product scope increased 22% mid-sprint without capacity adjustment',
              'Sales committed to aggressive deadline without engineering consultation',
              'Unplanned high-priority work injected (8 tasks in 5 days)',
            ].map((cause) => (
              <div key={cause} className="flex items-start gap-2 text-body" style={{ color: 'var(--neutral-600)' }}>
                <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                  style={{ backgroundColor: 'var(--brand-primary)' }} />
                <span>{cause}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Suggested Fixes */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>SUGGESTED FIXES</h3>
        <div className="space-y-2">
          {fixes.map((fix, idx) => (
            <label
              key={fix.text}
              className="flex items-start gap-3 p-3 rounded-[var(--radius-button)] cursor-pointer transition-colors"
              style={{
                backgroundColor: selectedFixes.includes(idx) ? 'var(--brand-primary-light)' : 'var(--neutral-50)',
              }}
            >
              <input
                type="checkbox"
                className="mt-1"
                checked={selectedFixes.includes(idx)}
                onChange={() => toggleFix(idx)}
              />
              <div className="flex-1">
                <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{fix.text}</div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>{fix.detail}</div>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Resolve Button */}
      <div
        className="sticky bottom-0 -mx-6 -mb-6 p-6"
        style={{ backgroundColor: 'var(--white)', borderTop: '1px solid var(--neutral-200)' }}
      >
        <Button
          variant="brand-gradient"
          className="w-full h-12"
          disabled={selectedFixes.length === 0}
          onClick={() => setResolveOpen(true)}
        >
          <CheckCircle2 className="w-4 h-4" />
          Resolve Risk
        </Button>
      </div>

      <ConfirmDialog
        open={resolveOpen}
        onOpenChange={setResolveOpen}
        title="Resolve Risk"
        description={`Apply ${selectedFixes.length} selected fix${selectedFixes.length > 1 ? 'es' : ''} and mark this risk as resolved?`}
        confirmLabel="Resolve"
        onConfirm={() => toast.success('Risk resolved successfully')}
      />
    </div>
  );
}

import { AlertTriangle, MessageCircle, Link as LinkIcon } from 'lucide-react';
import { toast } from 'sonner';
import type { Initiative } from '../../../types/execution';
import { Badge } from '../../../design-system/badge';
import { Button } from '../../../design-system/button';
import { ProgressBar } from '../../../design-system/progress-bar';

interface InitiativeDrawerProps {
  initiative: Initiative;
}

function progressVariant(progress: number) {
  if (progress >= 70) return 'success' as const;
  if (progress >= 40) return 'warning' as const;
  return 'danger' as const;
}

export function InitiativeDrawer({ initiative }: InitiativeDrawerProps) {
  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-caption-medium"
          style={{
            background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
            color: 'var(--white)',
          }}
        >
          {initiative.owner}
        </div>
        <div>
          <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>Owner</div>
          <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
            {initiative.ownerName}
          </div>
        </div>
      </div>

      {/* Progress Over Time */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>PROGRESS OVER TIME</h3>
        <div
          className="h-32 rounded-[var(--radius-card)] flex items-center justify-center mb-3"
          style={{
            background: 'linear-gradient(135deg, var(--brand-primary-light) 0%, var(--neutral-50) 100%)',
            border: '1px solid var(--neutral-200)',
          }}
        >
          <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>Sparkline Chart</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Current Progress</span>
          <span className="text-h1 tabular-nums" style={{ color: 'var(--brand-primary)' }}>
            {initiative.progress}%
          </span>
        </div>
        <ProgressBar value={initiative.progress} variant={progressVariant(initiative.progress)} className="mt-2" />
      </div>

      {/* Dependencies */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>DEPENDENCIES</h3>
        <div className="space-y-2">
          <div
            className="flex items-center gap-2 p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--neutral-50)' }}
          >
            <LinkIcon className="w-4 h-4" style={{ color: 'var(--brand-primary)' }} />
            <span className="text-body" style={{ color: 'var(--neutral-800)' }}>AWS Infrastructure Migration</span>
            <Badge variant="warning" size="sm" className="ml-auto">Blocked</Badge>
          </div>
          <div
            className="flex items-center gap-2 p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--neutral-50)' }}
          >
            <LinkIcon className="w-4 h-4" style={{ color: 'var(--brand-primary)' }} />
            <span className="text-body" style={{ color: 'var(--neutral-800)' }}>Design System v2</span>
            <Badge variant="success" size="sm" className="ml-auto">On Track</Badge>
          </div>
        </div>
      </div>

      {/* Blockers */}
      {initiative.blocker && (
        <div>
          <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>BLOCKERS</h3>
          <div
            className="p-4 rounded-[var(--radius-card)]"
            style={{ backgroundColor: 'var(--danger-light)', border: '1px solid var(--danger-light)' }}
          >
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 mt-0.5" style={{ color: 'var(--danger)' }} />
              <div>
                <div className="text-body-medium mb-1" style={{ color: 'var(--neutral-800)' }}>
                  Resource constraint
                </div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                  Engineering team at capacity, need 2 additional developers
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Alignment Score */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>ALIGNMENT SCORE</h3>
        <div className="flex items-center gap-4">
          <ProgressBar value={92} variant="success" className="flex-1" />
          <span className="text-h1 tabular-nums" style={{ color: 'var(--success-darker)' }}>92%</span>
        </div>
      </div>

      {/* Comments */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>COMMENTS</h3>
        <div
          className="p-3 rounded-[var(--radius-button)] mb-3"
          style={{ backgroundColor: 'var(--neutral-50)' }}
        >
          <div className="flex items-center gap-2 mb-2">
            <div
              className="w-6 h-6 rounded-full flex items-center justify-center text-micro"
              style={{ backgroundColor: 'var(--brand-primary)', color: 'var(--white)' }}
            >
              SC
            </div>
            <span className="text-caption-medium" style={{ color: 'var(--neutral-800)' }}>Sarah Chen</span>
            <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>2h ago</span>
          </div>
          <div className="text-body" style={{ color: 'var(--neutral-600)' }}>
            On track for Q4 launch, coordinating with design team
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          className="w-full"
          style={{ border: '1px solid var(--neutral-200)' }}
          onClick={() => toast.success('Comment added')}
        >
          <MessageCircle className="w-3 h-3" /> Add Comment
        </Button>
      </div>

      {/* Related KPIs */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>RELATED KPIS</h3>
        <div className="grid grid-cols-2 gap-3">
          <div
            className="p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--success-light)', border: '1px solid var(--success-light)' }}
          >
            <div className="text-caption" style={{ color: 'var(--success-darker)' }}>Revenue Impact</div>
            <div className="text-h3 tabular-nums" style={{ color: 'var(--neutral-800)' }}>+$2.4M</div>
          </div>
          <div
            className="p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--brand-primary-light)', border: '1px solid var(--brand-primary-light)' }}
          >
            <div className="text-caption" style={{ color: 'var(--brand-primary)' }}>Customer NPS</div>
            <div className="text-h3 tabular-nums" style={{ color: 'var(--neutral-800)' }}>+12 pts</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div
        className="sticky bottom-0 -mx-6 -mb-6 p-6"
        style={{ backgroundColor: 'var(--white)', borderTop: '1px solid var(--neutral-200)' }}
      >
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>QUICK ACTIONS</h3>
        <div className="grid grid-cols-3 gap-2">
          <Button
            size="sm"
            style={{ backgroundColor: 'var(--danger-light)', color: 'var(--danger)' }}
            onClick={() => toast.error('Marked as at risk')}
          >
            Mark Risk
          </Button>
          <Button
            size="sm"
            style={{ backgroundColor: 'var(--brand-primary-light)', color: 'var(--brand-primary)' }}
            onClick={() => toast.success('Resource request submitted')}
          >
            Request Resources
          </Button>
          <Button
            size="sm"
            style={{ backgroundColor: 'var(--success-light)', color: 'var(--success-darker)' }}
            onClick={() => toast.success('Status updated')}
          >
            Update Status
          </Button>
        </div>
      </div>
    </div>
  );
}

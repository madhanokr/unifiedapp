import { useState } from 'react';
import { CheckCircle2, XCircle, ArrowRight, AlertTriangle, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '../../../design-system/badge';
import { Button } from '../../../design-system/button';
import { ConfirmDialog } from '../../../design-system/dialog';

const decisions = [
  { id: 1, text: 'Approve budget reallocation for R&D ($180k)', impact: 'High', urgency: 'Critical' },
  { id: 2, text: 'Hire 2 senior engineers', impact: 'High', urgency: 'High' },
  { id: 3, text: 'Defer 3 non-critical features to Q1', impact: 'Medium', urgency: 'Medium' },
];

const risks = [
  { id: 1, title: 'Engineering workload 3.2x threshold', status: 'Critical', owner: null },
  { id: 2, title: 'Customer churn threshold breach', status: 'High', owner: null },
  { id: 3, title: 'Talent retention risk', status: 'Medium', owner: 'DM' },
];

const adjustments = [
  { id: 1, type: 'Scope change', text: 'Remove analytics v2 from Q4', impact: '+4% forecast' },
  { id: 2, type: 'Deadline shift', text: 'Push mobile release by 1 week', impact: '+2% forecast' },
  { id: 3, type: 'Reprioritization', text: 'Focus on enterprise features first', impact: '+3% confidence' },
];

function urgencyVariant(urgency: string) {
  if (urgency === 'Critical') return 'danger' as const;
  if (urgency === 'High') return 'warning' as const;
  return 'neutral' as const;
}

export function WeeklyPlanModal() {
  const [rejectConfirm, setRejectConfirm] = useState<number | null>(null);

  return (
    <div className="p-8 space-y-8">
      {/* Urgent Decisions */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-5 h-5" style={{ color: 'var(--danger)' }} />
          <h3 className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
            Urgent Decisions (Needs CEO Approval)
          </h3>
          <Badge variant="danger" size="sm" className="ml-auto">{decisions.length}</Badge>
        </div>
        <div className="space-y-3">
          {decisions.map((decision) => (
            <div
              key={decision.id}
              className="p-4 rounded-[var(--radius-card)] transition-colors"
              style={{
                backgroundColor: 'var(--neutral-50)',
                border: '1px solid var(--neutral-200)',
              }}
            >
              <div className="mb-3">
                <div className="text-body-medium mb-2" style={{ color: 'var(--neutral-800)' }}>
                  {decision.text}
                </div>
                <div className="flex gap-2">
                  <Badge variant={decision.impact === 'High' ? 'warning' : 'neutral'} size="sm">
                    Impact: {decision.impact}
                  </Badge>
                  <Badge variant={urgencyVariant(decision.urgency)} size="sm">
                    {decision.urgency}
                  </Badge>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1"
                  style={{ backgroundColor: 'var(--success-darker)', color: 'var(--white)' }}
                  onClick={() => toast.success(`Approved: ${decision.text}`)}
                >
                  <CheckCircle2 className="w-3 h-3" /> Approve
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  className="flex-1"
                  onClick={() => setRejectConfirm(decision.id)}
                >
                  <XCircle className="w-3 h-3" /> Reject
                </Button>
                <Button
                  size="sm"
                  className="flex-1"
                  style={{ backgroundColor: 'var(--brand-primary-light)', color: 'var(--brand-primary)' }}
                  onClick={() => toast.success(`Delegated: ${decision.text}`)}
                >
                  <ArrowRight className="w-3 h-3" /> Delegate
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Risks to Resolve */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div
            className="w-5 h-5 rounded-[var(--radius-badge)] flex items-center justify-center"
            style={{ backgroundColor: 'var(--danger-light)' }}
          >
            <span className="text-caption" style={{ color: 'var(--danger)' }}>!</span>
          </div>
          <h3 className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
            Risks to Resolve
          </h3>
          <Badge variant="danger" size="sm" className="ml-auto">{risks.length}</Badge>
        </div>
        <div className="space-y-3">
          {risks.map((risk) => (
            <div
              key={risk.id}
              className="p-4 rounded-[var(--radius-card)]"
              style={{
                backgroundColor: 'var(--danger-light)',
                border: '1px solid var(--danger-light)',
              }}
            >
              <div className="mb-3">
                <div className="text-body-medium mb-2" style={{ color: 'var(--neutral-800)' }}>
                  {risk.title}
                </div>
                <div className="flex gap-2">
                  <Badge variant={urgencyVariant(risk.status)} size="sm">{risk.status}</Badge>
                  {risk.owner && (
                    <Badge variant="brand" size="sm">Owner: {risk.owner}</Badge>
                  )}
                </div>
              </div>
              {!risk.owner && (
                <Button
                  variant="secondary"
                  size="sm"
                  className="w-full"
                  style={{ backgroundColor: 'var(--white)', border: '1px solid var(--neutral-200)' }}
                  onClick={() => toast.success('Owner assignment requested')}
                >
                  Assign Owner
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Strategic Adjustments */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5" style={{ color: 'var(--brand-primary)' }} />
          <h3 className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
            Strategic Adjustments
          </h3>
          <Badge variant="brand" size="sm" className="ml-auto">{adjustments.length}</Badge>
        </div>
        <div className="space-y-3">
          {adjustments.map((adj) => (
            <div
              key={adj.id}
              className="p-4 rounded-[var(--radius-card)]"
              style={{
                backgroundColor: 'var(--brand-primary-light)',
                border: '1px solid var(--brand-primary-light)',
              }}
            >
              <div className="text-caption-medium mb-1" style={{ color: 'var(--brand-primary)' }}>
                {adj.type}
              </div>
              <div className="text-body-medium mb-2" style={{ color: 'var(--neutral-800)' }}>
                {adj.text}
              </div>
              <div className="text-caption" style={{ color: 'var(--success-darker)' }}>
                {adj.impact}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Summary Card */}
      <div
        className="rounded-[var(--radius-card)] p-6"
        style={{
          background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
          color: 'var(--white)',
        }}
      >
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-5 h-5" />
          <span className="text-micro" style={{ opacity: 0.8 }}>AI IMPACT SUMMARY</span>
        </div>
        <div className="text-h1 mb-2">Forecast improves by +6%</div>
        <div className="text-body mb-6" style={{ opacity: 0.8 }}>
          If you approve all recommended actions, Q4 success probability increases from 78% to 84%
        </div>
        <Button
          variant="secondary"
          className="w-full"
          style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)', color: 'var(--white)', border: 'none' }}
          onClick={() => toast.success('All actions applied successfully')}
        >
          Apply All Actions
        </Button>
      </div>

      <ConfirmDialog
        open={rejectConfirm !== null}
        onOpenChange={() => setRejectConfirm(null)}
        title="Reject Decision"
        description="Are you sure you want to reject this decision? This action will notify the relevant team leads."
        confirmLabel="Reject"
        destructive
        onConfirm={() => {
          toast.error(`Decision rejected`);
          setRejectConfirm(null);
        }}
      />
    </div>
  );
}

import { useState } from 'react';
import { FileDown, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '../../../design-system/button';

type TimeRange = '14d' | '30d' | '60d';

const timeRangeOptions: { value: TimeRange; label: string }[] = [
  { value: '14d', label: '14 Days' },
  { value: '30d', label: '30 Days' },
  { value: '60d', label: '60 Days' },
];

export function ForecastSlideUp() {
  const [timeRange, setTimeRange] = useState<TimeRange>('14d');
  const [engineers, setEngineers] = useState(0);
  const [weekDelay, setWeekDelay] = useState(0);
  const [scopeReduce, setScopeReduce] = useState(0);

  const base = 78;
  const newForecast = Math.min(100, base + engineers * 3 + weekDelay * 4 + scopeReduce * 0.5);

  return (
    <div className="space-y-6">
      {/* Time Range Toggle */}
      <div className="flex gap-2">
        {timeRangeOptions.map((opt) => (
          <button
            key={opt.value}
            onClick={() => setTimeRange(opt.value)}
            className="text-caption-medium px-4 py-2 rounded-[var(--radius-button)] transition-colors"
            style={{
              backgroundColor: timeRange === opt.value ? 'var(--brand-primary)' : 'var(--neutral-100)',
              color: timeRange === opt.value ? 'var(--white)' : 'var(--neutral-600)',
            }}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {/* Confidence Projection Curve */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>
          CONFIDENCE PROJECTION
        </h3>
        <div
          className="h-64 rounded-[var(--radius-card)] flex items-center justify-center"
          style={{
            background: 'linear-gradient(135deg, var(--neutral-50) 0%, var(--brand-primary-light) 100%)',
            border: '1px solid var(--neutral-200)',
          }}
        >
          <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>
            Forecast Curve Visualization ({timeRange})
          </span>
        </div>
      </div>

      {/* Scenario Simulator */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>
          SCENARIO SIMULATOR
        </h3>
        <div className="space-y-4 p-5 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--neutral-50)' }}>
          {/* Add Engineers */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-body" style={{ color: 'var(--neutral-800)' }}>Add Engineers</label>
              <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                +{engineers * 3}% impact
              </span>
            </div>
            <input type="range" min="0" max="5" value={engineers}
              onChange={(e) => setEngineers(Number(e.target.value))} className="w-full" />
            <div className="text-caption mt-1" style={{ color: 'var(--neutral-600)' }}>
              {engineers} engineers
            </div>
          </div>

          {/* Push Feature */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-body" style={{ color: 'var(--neutral-800)' }}>Push Feature Deadline</label>
              <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                +{weekDelay * 4}% impact
              </span>
            </div>
            <input type="range" min="0" max="4" value={weekDelay}
              onChange={(e) => setWeekDelay(Number(e.target.value))} className="w-full" />
            <div className="text-caption mt-1" style={{ color: 'var(--neutral-600)' }}>
              {weekDelay} week{weekDelay !== 1 ? 's' : ''}
            </div>
          </div>

          {/* Reduce Scope */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-body" style={{ color: 'var(--neutral-800)' }}>Reduce Scope</label>
              <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                +{(scopeReduce * 0.5).toFixed(1)}% impact
              </span>
            </div>
            <input type="range" min="0" max="30" value={scopeReduce}
              onChange={(e) => setScopeReduce(Number(e.target.value))} className="w-full" />
            <div className="text-caption mt-1" style={{ color: 'var(--neutral-600)' }}>
              {scopeReduce}% reduction
            </div>
          </div>

          {/* Result Preview */}
          <div className="pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-body" style={{ color: 'var(--neutral-800)' }}>New Forecast</span>
              <div className="flex items-center gap-2">
                <span className="text-h1 tabular-nums" style={{ color: 'var(--brand-primary)' }}>
                  {newForecast}%
                </span>
                {newForecast > 78 && (
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
                    <span className="text-caption" style={{ color: 'var(--success-darker)' }}>
                      +{newForecast - 78}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Button */}
      <Button
        variant="brand-gradient"
        className="w-full h-12"
        onClick={() => toast.success('Forecast PDF exported')}
      >
        <FileDown className="w-4 h-4" />
        Export Forecast PDF
      </Button>
    </div>
  );
}

import { useState } from 'react';
import { TrendingUp, Users, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '../../../design-system/badge';
import { Button } from '../../../design-system/button';

export function RootCauseDrawer() {
  const [timeRange, setTimeRange] = useState<'7d' | '30d'>('7d');

  const timeOptions: Array<'7d' | '30d'> = ['7d', '30d'];

  return (
    <div className="p-6">
      {/* Graph Section */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
            Workload vs Capacity
          </h3>
          <div className="flex gap-2">
            {timeOptions.map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className="text-caption-medium px-3 py-1 rounded-[var(--radius-button)] transition-colors"
                style={{
                  backgroundColor: timeRange === range ? 'var(--brand-primary-light)' : 'var(--neutral-100)',
                  color: timeRange === range ? 'var(--brand-primary)' : 'var(--neutral-600)',
                }}
              >
                {range === '7d' ? '7 Days' : '30 Days'}
              </button>
            ))}
          </div>
        </div>
        <div
          className="h-48 rounded-[var(--radius-card)] flex items-center justify-center"
          style={{
            background: 'linear-gradient(135deg, var(--neutral-50) 0%, var(--neutral-100) 100%)',
            border: '1px solid var(--neutral-200)',
          }}
        >
          <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>
            Workload Chart Visualization ({timeRange})
          </span>
        </div>
      </div>

      {/* Detected Patterns */}
      <div className="mb-8">
        <h3 className="text-micro mb-4" style={{ color: 'var(--neutral-400)' }}>
          DETECTED PATTERNS
        </h3>
        <div className="space-y-3">
          {[
            { text: 'Overdue tasks accumulating', detail: '12 tasks past deadline, avg 4.3 days late', severity: 'danger' as const },
            { text: 'Developer load imbalance', detail: '3 engineers at 180% capacity, 2 at 60%', severity: 'warning' as const },
            { text: 'High-priority work injected mid-sprint', detail: '8 unplanned tasks added in last 5 days', severity: 'warning' as const },
          ].map((pattern) => (
            <div
              key={pattern.text}
              className="flex items-start gap-3 p-3 rounded-[var(--radius-button)]"
              style={{
                backgroundColor: pattern.severity === 'danger' ? 'var(--danger-light)' : 'var(--warning-light)',
                border: `1px solid ${pattern.severity === 'danger' ? 'var(--danger-light)' : 'var(--warning-light)'}`,
              }}
            >
              <div
                className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                style={{
                  backgroundColor: pattern.severity === 'danger' ? 'var(--danger)' : 'var(--at-risk)',
                }}
              />
              <div className="flex-1">
                <div className="text-body-medium mb-1" style={{ color: 'var(--neutral-800)' }}>
                  {pattern.text}
                </div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                  {pattern.detail}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contributing Teams */}
      <div className="mb-8">
        <h3 className="text-micro mb-4" style={{ color: 'var(--neutral-400)' }}>
          CONTRIBUTING TEAMS
        </h3>
        <div className="space-y-3">
          <div
            className="flex items-center justify-between p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--neutral-50)' }}
          >
            <div className="flex items-center gap-3">
              <Users className="w-4 h-4" style={{ color: 'var(--brand-primary)' }} />
              <div>
                <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>Product Team</div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>Scope change mid-sprint</div>
              </div>
            </div>
            <Badge variant="danger" size="sm">High Impact</Badge>
          </div>
          <div
            className="flex items-center justify-between p-3 rounded-[var(--radius-button)]"
            style={{ backgroundColor: 'var(--neutral-50)' }}
          >
            <div className="flex items-center gap-3">
              <TrendingUp className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
              <div>
                <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>Sales Team</div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>Deadline commitment without capacity check</div>
              </div>
            </div>
            <Badge variant="warning" size="sm">Medium Impact</Badge>
          </div>
        </div>
      </div>

      {/* AI Recommendations */}
      <div
        className="sticky bottom-0 -mx-6 -mb-6 p-6"
        style={{
          background: 'linear-gradient(135deg, var(--brand-primary-light) 0%, var(--neutral-50) 100%)',
          borderTop: '1px solid var(--neutral-200)',
        }}
      >
        <div className="text-micro mb-3" style={{ color: 'var(--brand-primary)' }}>
          AI RECOMMENDATIONS
        </div>
        <div className="space-y-2 mb-4">
          {[
            'Reallocate 2 engineers from Mobile to Backend',
            'Freeze low-impact work until capacity recovers',
            'Adjust Q4 prediction to 72% (down from 78%)',
          ].map((rec) => (
            <div key={rec} className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" style={{ color: 'var(--brand-primary)' }} />
              <span className="text-body" style={{ color: 'var(--neutral-600)' }}>{rec}</span>
            </div>
          ))}
        </div>
        <div className="flex gap-3">
          <Button
            variant="brand-gradient"
            className="flex-1"
            onClick={() => toast.success('Recommended fixes applied successfully')}
          >
            Apply Recommended Fixes
          </Button>
          <Button variant="secondary">Dismiss</Button>
        </div>
      </div>
    </div>
  );
}

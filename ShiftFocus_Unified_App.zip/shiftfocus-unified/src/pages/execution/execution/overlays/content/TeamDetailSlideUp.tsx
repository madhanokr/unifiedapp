import { TrendingUp, AlertTriangle, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import type { Team } from '../../../types/execution';
import { Button } from '../../../design-system/button';

interface TeamDetailSlideUpProps {
  team: Team;
}

export function TeamDetailSlideUp({ team }: TeamDetailSlideUpProps) {
  return (
    <div className="space-y-6">
      {/* Team Metrics Grid */}
      <div className="grid grid-cols-4 gap-4">
        <div className="p-4 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--brand-primary-light)' }}>
          <div className="text-caption mb-2" style={{ color: 'var(--brand-primary)' }}>Confidence</div>
          <div className="text-display tabular-nums" style={{ color: 'var(--neutral-800)' }}>{team.confidence}%</div>
        </div>
        <div className="p-4 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--brand-primary-light)' }}>
          <div className="text-caption mb-2" style={{ color: 'var(--brand-primary)' }}>Alignment</div>
          <div className="text-display tabular-nums" style={{ color: 'var(--neutral-800)' }}>{team.alignment}%</div>
        </div>
        <div
          className="p-4 rounded-[var(--radius-card)]"
          style={{
            backgroundColor: team.velocity.startsWith('+') ? 'var(--success-light)' : 'var(--danger-light)',
          }}
        >
          <div className="text-caption mb-2" style={{
            color: team.velocity.startsWith('+') ? 'var(--success-darker)' : 'var(--danger)',
          }}>
            Velocity
          </div>
          <div className="text-display tabular-nums" style={{
            color: team.velocity.startsWith('+') ? 'var(--success-darker)' : 'var(--danger)',
          }}>
            {team.velocity}
          </div>
        </div>
        <div className="p-4 rounded-[var(--radius-card)]" style={{ backgroundColor: 'var(--warning-light)' }}>
          <div className="text-caption mb-2" style={{ color: 'var(--at-risk)' }}>Workload</div>
          <div className="text-display tabular-nums" style={{ color: 'var(--neutral-800)' }}>142%</div>
        </div>
      </div>

      {/* Top 3 Risks */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4" style={{ color: 'var(--danger)' }} />
          <h3 className="text-micro" style={{ color: 'var(--neutral-400)' }}>TOP 3 RISKS</h3>
        </div>
        <div className="space-y-2">
          {[
            { text: 'Budget overrun Q4', detail: '$142k exposure', severity: 'danger' as const },
            { text: 'Developer load imbalance', detail: '3 engineers at 180% capacity', severity: 'warning' as const },
            { text: 'Technical debt accumulation', detail: 'Impacting delivery speed', severity: 'warning' as const },
          ].map((risk) => (
            <div
              key={risk.text}
              className="flex items-start gap-2 p-3 rounded-[var(--radius-button)]"
              style={{
                backgroundColor: risk.severity === 'danger' ? 'var(--danger-light)' : 'var(--warning-light)',
                border: `1px solid ${risk.severity === 'danger' ? 'var(--danger-light)' : 'var(--warning-light)'}`,
              }}
            >
              <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                style={{ backgroundColor: risk.severity === 'danger' ? 'var(--danger)' : 'var(--at-risk)' }} />
              <div className="flex-1">
                <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{risk.text}</div>
                <div className="text-caption" style={{ color: 'var(--neutral-600)' }}>{risk.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Top 3 Opportunities */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
          <h3 className="text-micro" style={{ color: 'var(--neutral-400)' }}>TOP 3 OPPORTUNITIES</h3>
        </div>
        <div className="space-y-2">
          {[
            { text: 'Process automation', detail: '+15% velocity potential' },
            { text: 'Cross-team collaboration', detail: 'Reduce dependency wait time' },
            { text: 'Junior developer mentorship', detail: 'Long-term capacity building' },
          ].map((opp) => (
            <div
              key={opp.text}
              className="flex items-start gap-2 p-3 rounded-[var(--radius-button)]"
              style={{ backgroundColor: 'var(--success-light)', border: '1px solid var(--success-light)' }}
            >
              <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                style={{ backgroundColor: 'var(--success-darker)' }} />
              <div className="flex-1">
                <div className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{opp.text}</div>
                <div className="text-caption" style={{ color: 'var(--success-darker)' }}>{opp.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Team Health Stories */}
      <div>
        <h3 className="text-micro mb-3" style={{ color: 'var(--neutral-400)' }}>TEAM HEALTH STORIES</h3>
        <div className="space-y-3">
          <div
            className="p-4 rounded-[var(--radius-card)]"
            style={{ backgroundColor: 'var(--success-light)', border: '1px solid var(--success-light)' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
              <span className="text-micro" style={{ color: 'var(--success-darker)' }}>POSITIVE TREND</span>
            </div>
            <div className="text-body" style={{ color: 'var(--neutral-800)' }}>
              {team.name} velocity up {team.velocity.startsWith('+') ? team.velocity : '+12%'} this week
            </div>
          </div>
          {team.blocker && (
            <div
              className="p-4 rounded-[var(--radius-card)]"
              style={{ backgroundColor: 'var(--warning-light)', border: '1px solid var(--warning-light)' }}
            >
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4" style={{ color: 'var(--at-risk)' }} />
                <span className="text-micro" style={{ color: 'var(--at-risk)' }}>ATTENTION NEEDED</span>
              </div>
              <div className="text-body" style={{ color: 'var(--neutral-800)' }}>
                {team.blocker} affecting delivery timeline
              </div>
            </div>
          )}
        </div>
      </div>

      <Button
        variant="brand-gradient"
        className="w-full h-12"
        onClick={() => toast.success('Team report generated')}
      >
        View Team Report
      </Button>
    </div>
  );
}

import { Toaster } from 'sonner';

export function AppToaster() {
  return (
    <Toaster
      position="top-right"
      toastOptions={{
        style: {
          backgroundColor: 'var(--white)',
          color: 'var(--neutral-800)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-elevated)',
          borderRadius: 'var(--radius-card)',
          fontSize: '14px',
        },
      }}
    />
  );
}

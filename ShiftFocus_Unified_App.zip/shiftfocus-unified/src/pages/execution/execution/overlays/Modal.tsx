import type { ReactNode } from 'react';
import { Dialog } from '../../design-system/dialog';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function Modal({ isOpen, onClose, children, title, size = 'lg' }: ModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()} title={title} size={size}>
      {children}
    </Dialog>
  );
}

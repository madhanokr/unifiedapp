import { useState } from 'react';
import { ExecutionHeader } from './ExecutionHeader';
import { ActionRow } from './ActionRow';
import { IntelligenceGrid } from './IntelligenceGrid';
import { Drawer } from './overlays/Drawer';
import { Modal } from './overlays/Modal';
import { SlideUp } from './overlays/SlideUp';
import { RootCauseDrawer } from './overlays/content/RootCauseDrawer';
import { WeeklyPlanModal } from './overlays/content/WeeklyPlanModal';
import { ForecastSlideUp } from './overlays/content/ForecastSlideUp';
import { InitiativeDrawer } from './overlays/content/InitiativeDrawer';
import { TeamDetailSlideUp } from './overlays/content/TeamDetailSlideUp';
import { RiskDetailDrawer } from './overlays/content/RiskDetailDrawer';
import type { Initiative, Team, Risk } from '../types/execution';

export function ExecutionDashboard() {
  const [rootCauseOpen, setRootCauseOpen] = useState(false);
  const [weeklyPlanOpen, setWeeklyPlanOpen] = useState(false);
  const [forecastOpen, setForecastOpen] = useState(false);
  const [initiativeOpen, setInitiativeOpen] = useState<Initiative | null>(null);
  const [teamDetailOpen, setTeamDetailOpen] = useState<Team | null>(null);
  const [riskDetailOpen, setRiskDetailOpen] = useState<Risk | null>(null);

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--bg-level-1)' }}>
      <ExecutionHeader />
      <ActionRow
        onOpenRootCause={() => setRootCauseOpen(true)}
        onOpenWeeklyPlan={() => setWeeklyPlanOpen(true)}
      />
      <div className="max-w-[1320px] mx-auto px-8 py-8">
        <IntelligenceGrid
          onOpenForecast={() => setForecastOpen(true)}
          onOpenInitiative={(initiative) => setInitiativeOpen(initiative)}
          onOpenTeamDetail={(team) => setTeamDetailOpen(team)}
          onOpenRiskDetail={(risk) => setRiskDetailOpen(risk)}
        />
      </div>

      {/* Root Cause Analysis Drawer */}
      <Drawer
        isOpen={rootCauseOpen}
        onClose={() => setRootCauseOpen(false)}
        title="Root Cause Analysis: Engineering Workload Spike"
      >
        <RootCauseDrawer />
      </Drawer>

      {/* Weekly Plan Modal */}
      <Modal
        isOpen={weeklyPlanOpen}
        onClose={() => setWeeklyPlanOpen(false)}
        title="Your Weekly Action Plan"
        size="lg"
      >
        <WeeklyPlanModal />
      </Modal>

      {/* Forecast Slide Up */}
      <SlideUp
        isOpen={forecastOpen}
        onClose={() => setForecastOpen(false)}
        title="Q4 2025 Forecast Simulation"
        height="70%"
      >
        <ForecastSlideUp />
      </SlideUp>

      {/* Initiative Drawer */}
      {initiativeOpen && (
        <Drawer
          isOpen={!!initiativeOpen}
          onClose={() => setInitiativeOpen(null)}
          title={initiativeOpen.name}
        >
          <InitiativeDrawer initiative={initiativeOpen} />
        </Drawer>
      )}

      {/* Team Detail Slide Up */}
      {teamDetailOpen && (
        <SlideUp
          isOpen={!!teamDetailOpen}
          onClose={() => setTeamDetailOpen(null)}
          title={`${teamDetailOpen.name} Team Performance`}
          height="75%"
        >
          <TeamDetailSlideUp team={teamDetailOpen} />
        </SlideUp>
      )}

      {/* Risk Detail Drawer */}
      {riskDetailOpen && (
        <Drawer
          isOpen={!!riskDetailOpen}
          onClose={() => setRiskDetailOpen(null)}
          title={riskDetailOpen.title}
        >
          <RiskDetailDrawer risk={riskDetailOpen} />
        </Drawer>
      )}
    </div>
  );
}

import { useState, useEffect } from 'react';
import { Flame, Puzzle, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Card } from '../../design-system/card';
import { Badge } from '../../design-system/badge';
import { CardSkeleton } from '../../design-system/skeleton';
import type { Risk, Misalignment, Opportunity } from '../../types/execution';

const risks: Risk[] = [
  { title: 'Budget overrun Q4 (Eng)', severity: 'high', owner: 'MJ', badge: 'Escalating', impact: '$142k' },
  { title: 'Customer churn threshold', severity: 'high', owner: 'SC', badge: 'New', impact: '$89k' },
  { title: 'Talent retention risk', severity: 'medium', owner: 'DM', badge: null, impact: '$67k' },
];

const misalignments: Misalignment[] = [
  { title: 'Marketing-Sales divergence', severity: 'high', owner: 'Team Leads', badge: 'Escalating', impact: '$124k' },
  { title: 'Product vs customer demand', severity: 'medium', owner: 'LP', badge: 'New', impact: '$58k' },
  { title: 'Engineering priorities', severity: 'low', owner: 'MJ', badge: null, impact: '$23k' },
];

const opportunities: Opportunity[] = [
  { title: 'Enterprise upsell (+$2.4M)', impact: 'high', owner: 'SC', badge: 'New', value: '$2.4M' },
  { title: 'New market segment', impact: 'medium', owner: 'DM', badge: null, value: '$890k' },
  { title: 'Fortune 500 partnership', impact: 'high', owner: 'SC', badge: 'New', value: '$1.8M' },
];

function badgeVariant(badge: string | null) {
  if (badge === 'New') return 'info' as const;
  if (badge === 'Escalating') return 'danger' as const;
  return 'success' as const;
}

interface RiskBlockProps {
  onOpenRiskDetail: (risk: Risk) => void;
}

export function RiskBlock({ onOpenRiskDetail }: RiskBlockProps) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t); }, []);

  if (loading) return <CardSkeleton />;

  const totalRiskExposure = risks.reduce((sum, r) => sum + parseInt(r.impact.replace('$', '').replace('k', '')), 0);

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-h3 mb-1" style={{ color: 'var(--neutral-800)' }}>AI Risk Center</h3>
          <p className="text-caption" style={{ color: 'var(--neutral-600)' }}>Real-time threat detection</p>
        </div>
        <Badge variant="danger">Risk: ${totalRiskExposure}k</Badge>
      </div>

      <div className="space-y-6">
        {/* Top Risks */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Flame className="w-4 h-4" style={{ color: 'var(--danger)' }} />
            <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>Top Risks</span>
            <Badge variant="danger" size="sm" className="ml-auto">{risks.length}</Badge>
          </div>
          <div className="space-y-2">
            {risks.map((risk) => (
              <div
                key={risk.title}
                onClick={() => onOpenRiskDetail(risk)}
                className="flex items-start gap-3 relative group -mx-2 px-2 py-2 rounded-[var(--radius-button)] transition-colors cursor-pointer"
                onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--danger-light)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
              >
                {risk.badge === 'Escalating' && (
                  <div className="absolute left-0 top-0 bottom-0 w-0.5 rounded-full" style={{ backgroundColor: 'var(--danger)' }} />
                )}
                <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                  style={{ backgroundColor: risk.severity === 'high' ? 'var(--danger)' : 'var(--at-risk)' }} />
                <span className="text-body flex-1" style={{ color: 'var(--neutral-600)' }}>{risk.title}</span>
                <span className="text-body-medium tabular-nums" style={{ color: 'var(--danger)' }}>{risk.impact}</span>
                {risk.badge && (
                  <motion.span
                    initial={{ opacity: 1 }}
                    animate={risk.badge === 'New' ? { opacity: [1, 0.6, 1] } : {}}
                    transition={risk.badge === 'New' ? { duration: 1.6, repeat: Infinity, repeatDelay: 3, ease: 'easeInOut' } : {}}
                  >
                    <Badge variant={badgeVariant(risk.badge)} size="sm">{risk.badge}</Badge>
                  </motion.span>
                )}
              </div>
            ))}
          </div>
          <button className="text-body-medium mt-2 transition-all" style={{ color: 'var(--danger)', background: 'none', border: 'none', cursor: 'pointer' }}>
            View all &rarr;
          </button>
        </div>

        {/* Misalignments */}
        <div className="pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
          <div className="flex items-center gap-2 mb-3">
            <Puzzle className="w-4 h-4" style={{ color: 'var(--at-risk)' }} />
            <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>Misalignments</span>
            <Badge variant="warning" size="sm" className="ml-auto">{misalignments.length}</Badge>
          </div>
          <div className="space-y-2">
            {misalignments.map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-3 relative -mx-2 px-2 py-2 rounded-[var(--radius-button)] transition-colors"
                onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--warning-light)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
              >
                {item.badge === 'Escalating' && (
                  <div className="absolute left-0 top-0 bottom-0 w-0.5 rounded-full" style={{ backgroundColor: 'var(--danger)' }} />
                )}
                <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{ backgroundColor: 'var(--at-risk)' }} />
                <span className="text-body flex-1" style={{ color: 'var(--neutral-600)' }}>{item.title}</span>
                <span className="text-body-medium tabular-nums" style={{ color: 'var(--at-risk)' }}>{item.impact}</span>
                {item.badge && (
                  <motion.span
                    initial={{ opacity: 1 }}
                    animate={item.badge === 'New' ? { opacity: [1, 0.6, 1] } : {}}
                    transition={item.badge === 'New' ? { duration: 1.6, repeat: Infinity, repeatDelay: 3, ease: 'easeInOut' } : {}}
                  >
                    <Badge variant={badgeVariant(item.badge)} size="sm">{item.badge}</Badge>
                  </motion.span>
                )}
              </div>
            ))}
          </div>
          <button className="text-body-medium mt-2 transition-all" style={{ color: 'var(--at-risk)', background: 'none', border: 'none', cursor: 'pointer' }}>
            View all &rarr;
          </button>
        </div>

        {/* Opportunities */}
        <div className="pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
            <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>Opportunities</span>
            <Badge variant="success" size="sm" className="ml-auto">{opportunities.length}</Badge>
          </div>
          <div className="space-y-2">
            {opportunities.map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-3 -mx-2 px-2 py-2 rounded-[var(--radius-button)] transition-colors"
                onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--success-light)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
              >
                <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{ backgroundColor: 'var(--success-darker)' }} />
                <span className="text-body flex-1" style={{ color: 'var(--neutral-600)' }}>{item.title}</span>
                <span className="text-body-medium tabular-nums" style={{ color: 'var(--success-darker)' }}>{item.value}</span>
                {item.badge && (
                  <motion.span
                    initial={{ opacity: 1 }}
                    animate={item.badge === 'New' ? { opacity: [1, 0.6, 1] } : {}}
                    transition={item.badge === 'New' ? { duration: 1.6, repeat: Infinity, repeatDelay: 3, ease: 'easeInOut' } : {}}
                  >
                    <Badge variant="info" size="sm">{item.badge}</Badge>
                  </motion.span>
                )}
              </div>
            ))}
          </div>
          <button className="text-body-medium mt-2 transition-all" style={{ color: 'var(--success-darker)', background: 'none', border: 'none', cursor: 'pointer' }}>
            View all &rarr;
          </button>
        </div>
      </div>
    </Card>
  );
}

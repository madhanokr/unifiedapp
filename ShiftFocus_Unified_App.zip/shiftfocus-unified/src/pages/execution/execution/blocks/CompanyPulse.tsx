import { useState, useEffect } from 'react';
import { Card } from '../../design-system/card';
import { ProgressBar } from '../../design-system/progress-bar';
import { Button } from '../../design-system/button';
import { CardSkeleton } from '../../design-system/skeleton';

interface CompanyPulseProps {
  onOpenForecast: () => void;
}

export function CompanyPulse({ onOpenForecast }: CompanyPulseProps) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t); }, []);

  if (loading) return <CardSkeleton />;

  const progress = 67;
  const forecast = 78;
  const projection = 84;

  return (
    <Card>
      <h3 className="text-h3 mb-4" style={{ color: 'var(--neutral-800)' }}>Company Progress Pulse</h3>

      <div className="mb-8">
        <div className="flex items-baseline gap-3 mb-2">
          <div className="text-display tabular-nums" style={{ color: 'var(--neutral-950)', fontSize: '32px' }}>Q4</div>
          <div className="text-h1 tabular-nums" style={{ color: 'var(--neutral-400)' }}>2025</div>
        </div>
        <p className="text-body" style={{ color: 'var(--neutral-600)' }}>Are we on track this quarter?</p>
      </div>

      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-caption uppercase tracking-wide" style={{ color: 'var(--neutral-600)' }}>
              Current Progress
            </span>
            <span className="text-display tabular-nums" style={{ color: 'var(--brand-primary)' }}>{progress}%</span>
          </div>
          <ProgressBar value={progress} variant="brand" />
        </div>

        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-caption uppercase tracking-wide" style={{ color: 'var(--neutral-600)' }}>
              Forecasted Outcome
            </span>
            <span className="text-display tabular-nums" style={{ color: 'var(--success-darker)' }}>{forecast}%</span>
          </div>
          <ProgressBar value={forecast} variant="success" />
        </div>

        <div className="grid grid-cols-3 gap-4 pt-4">
          <div>
            <div className="text-caption mb-2" style={{ color: 'var(--neutral-600)' }}>Time Left</div>
            <div className="text-h1 tabular-nums" style={{ color: 'var(--neutral-800)' }}>23d</div>
          </div>
          <div>
            <div className="text-caption mb-2" style={{ color: 'var(--neutral-600)' }}>Confidence</div>
            <div className="text-h1" style={{ color: 'var(--success-darker)' }}>High</div>
          </div>
          <div>
            <div className="text-caption mb-2" style={{ color: 'var(--neutral-600)' }}>At Risk</div>
            <div className="text-h1 tabular-nums" style={{ color: 'var(--neutral-800)' }}>4/28</div>
          </div>
        </div>

        <div className="pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-caption uppercase tracking-wide" style={{ color: 'var(--neutral-600)' }}>
              14-Day Projection
            </span>
            <div className="flex items-center gap-3">
              <span className="text-display tabular-nums" style={{ color: 'var(--neutral-800)' }}>{projection}%</span>
              <span
                className="text-caption-medium px-3 py-1 rounded-full"
                style={{ backgroundColor: 'var(--success-light)', color: 'var(--success-darker)' }}
              >
                &#8593; +2%
              </span>
            </div>
          </div>
          <ProgressBar value={projection} variant="success" />
        </div>
      </div>

      <Button variant="ghost" className="w-full mt-6" onClick={onOpenForecast}>
        View Full Forecast &rarr;
      </Button>
    </Card>
  );
}

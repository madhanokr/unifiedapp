import { useState, useEffect } from 'react';
import { Code, Palette, TrendingUp, Wrench, Sparkles, Users } from 'lucide-react';
import { Card } from '../../design-system/card';
import { Button } from '../../design-system/button';
import { CardSkeleton } from '../../design-system/skeleton';
import type { Team } from '../../types/execution';

const teams: Team[] = [
  { name: 'Engineering', icon: Code, confidence: 85, velocity: '+12%', alignment: 92, blocker: null },
  { name: 'Product', icon: Sparkles, confidence: 78, velocity: '+8%', alignment: 88, blocker: 'Resource constraints' },
  { name: 'Sales', icon: TrendingUp, confidence: 91, velocity: '+18%', alignment: 95, blocker: null },
  { name: 'Marketing', icon: Users, confidence: 72, velocity: '+5%', alignment: 81, blocker: 'Approval delay' },
  { name: 'Design', icon: Palette, confidence: 88, velocity: '+14%', alignment: 90, blocker: null },
  { name: 'Operations', icon: Wrench, confidence: 67, velocity: '-3%', alignment: 74, blocker: 'Process bottleneck' },
];

interface TeamSnapshotProps {
  onOpenTeamDetail: (team: Team) => void;
}

export function TeamSnapshot({ onOpenTeamDetail }: TeamSnapshotProps) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t); }, []);

  if (loading) return <CardSkeleton />;

  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-h3 mb-1" style={{ color: 'var(--neutral-800)' }}>Team Performance Snapshot</h3>
        <p className="text-caption" style={{ color: 'var(--neutral-600)' }}>Real-time health across all departments</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {teams.map((team) => {
          const TeamIcon = team.icon;
          return (
            <div
              key={team.name}
              onClick={() => onOpenTeamDetail(team)}
              className="rounded-[var(--radius-button)] p-4 transition-all group cursor-pointer"
              style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid transparent' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--white)';
                e.currentTarget.style.borderColor = 'var(--brand-primary-light)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                e.currentTarget.style.borderColor = 'transparent';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div className="flex items-center gap-2 mb-3">
                <TeamIcon className="w-4 h-4" style={{ color: 'var(--neutral-400)' }} />
                <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>{team.name}</span>
              </div>
              <div className="space-y-2 mb-3">
                <div className="flex items-center justify-between">
                  <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Confidence</span>
                  <span className="text-body-medium tabular-nums" style={{ color: 'var(--neutral-800)' }}>{team.confidence}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Velocity</span>
                  <span className="text-body-medium tabular-nums" style={{
                    color: team.velocity.startsWith('+') ? 'var(--success-darker)' : 'var(--danger)',
                  }}>
                    {team.velocity}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Alignment</span>
                  <span className="text-body-medium tabular-nums" style={{ color: 'var(--neutral-800)' }}>{team.alignment}%</span>
                </div>
              </div>
              {team.blocker && (
                <div
                  className="text-caption px-3 py-1.5 rounded-[var(--radius-badge)]"
                  style={{ backgroundColor: 'var(--danger-light)', color: 'var(--danger)' }}
                >
                  &#9888; {team.blocker}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
        <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
          Engineering accelerating, Sales strong, Operations bottlenecking delivery.
        </p>
      </div>

      <Button variant="ghost" className="w-full mt-6">
        View Team Details &rarr;
      </Button>
    </Card>
  );
}

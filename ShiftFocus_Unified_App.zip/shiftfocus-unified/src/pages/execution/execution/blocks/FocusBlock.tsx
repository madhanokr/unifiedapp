import { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle2, Clock, Link as LinkIcon, Puzzle, Lightbulb } from 'lucide-react';
import { Card } from '../../design-system/card';
import { Badge } from '../../design-system/badge';
import { ProgressBar } from '../../design-system/progress-bar';
import { Button } from '../../design-system/button';
import { CardSkeleton } from '../../design-system/skeleton';
import type { Initiative } from '../../types/execution';

const initiatives: Initiative[] = [
  { name: 'Enterprise Pricing Launch', progress: 78, confidence: 'High', blocker: false, owner: 'SC', ownerName: 'Sarah Chen', tag: { icon: Lightbulb, label: 'opportunity', color: 'success' } },
  { name: 'AWS Infrastructure Migration', progress: 45, confidence: 'Medium', blocker: true, owner: 'MJ', ownerName: 'Marcus Johnson', tag: { icon: LinkIcon, label: 'dependency', color: 'warning' } },
  { name: 'Mobile App v2.0 Ship', progress: 92, confidence: 'High', blocker: false, owner: 'LP', ownerName: 'Lisa Park', tag: { icon: CheckCircle2, label: 'ahead', color: 'success' } },
  { name: 'European Market Expansion', progress: 34, confidence: 'Low', blocker: true, owner: 'DM', ownerName: 'David Miller', tag: { icon: Clock, label: 'behind', color: 'danger' } },
  { name: 'AI Analytics Implementation', progress: 61, confidence: 'Medium', blocker: false, owner: 'ER', ownerName: 'Emma Rodriguez', tag: { icon: Puzzle, label: 'alignment risk', color: 'warning' } },
];

function tagVariant(color: string) {
  if (color === 'success') return 'success' as const;
  if (color === 'warning') return 'warning' as const;
  return 'danger' as const;
}

function confidenceVariant(c: string) {
  if (c === 'High') return 'success' as const;
  if (c === 'Medium') return 'warning' as const;
  return 'danger' as const;
}

function progressVariant(p: number) {
  if (p >= 70) return 'success' as const;
  if (p >= 40) return 'warning' as const;
  return 'danger' as const;
}

interface FocusBlockProps {
  onOpenInitiative: (initiative: Initiative) => void;
}

export function FocusBlock({ onOpenInitiative }: FocusBlockProps) {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t); }, []);

  if (loading) return <CardSkeleton />;

  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-h3 mb-1" style={{ color: 'var(--neutral-800)' }}>Focus Zone</h3>
        <p className="text-caption" style={{ color: 'var(--neutral-600)' }}>Top 5 strategic initiatives only</p>
      </div>

      <div className="space-y-3">
        {initiatives.map((initiative) => {
          const TagIcon = initiative.tag.icon;
          return (
            <div
              key={initiative.name}
              onClick={() => onOpenInitiative(initiative)}
              className="rounded-[var(--radius-button)] p-4 transition-all cursor-pointer group"
              style={{
                backgroundColor: 'var(--neutral-50)',
                border: '1px solid transparent',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--white)';
                e.currentTarget.style.borderColor = 'var(--brand-primary-light)';
                e.currentTarget.style.boxShadow = 'var(--shadow-card)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                e.currentTarget.style.borderColor = 'transparent';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div
                    className="text-body-medium mb-2 transition-colors"
                    style={{ color: 'var(--neutral-800)' }}
                  >
                    {initiative.name}
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-micro"
                      style={{ backgroundColor: 'var(--brand-primary)', color: 'var(--white)' }}
                    >
                      {initiative.owner}
                    </div>
                    <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                      {initiative.ownerName}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={tagVariant(initiative.tag.color)} size="sm">
                    <TagIcon className="w-3 h-3" />
                    {initiative.tag.label}
                  </Badge>
                  <Badge variant={confidenceVariant(initiative.confidence)} size="sm">
                    {initiative.confidence}
                  </Badge>
                  {initiative.blocker ? (
                    <AlertCircle className="w-4 h-4" style={{ color: 'var(--danger)' }} />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" style={{ color: 'var(--success-darker)' }} />
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <ProgressBar value={initiative.progress} variant={progressVariant(initiative.progress)} className="flex-1" />
                <span className="text-body-medium tabular-nums w-12 text-right" style={{ color: 'var(--neutral-600)' }}>
                  {initiative.progress}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <Button variant="ghost" className="w-full mt-6">
        View All Initiatives &rarr;
      </Button>
    </Card>
  );
}

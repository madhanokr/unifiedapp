import { useState, useEffect } from 'react';
import { Button } from '../../design-system/button';
import { CardSkeleton } from '../../design-system/skeleton';
import { toast } from 'sonner';

const sections = [
  { emoji: '\u{1F7E2}', label: 'Improved', color: 'var(--success-darker)', items: ['Sales velocity +18%', 'CSAT score 4.7/5'] },
  { emoji: '\u{1F7E1}', label: 'Slowed', color: 'var(--danger)', items: ['Product delivery -1 week', 'Ops efficiency -8%'] },
  { emoji: '\u{1F535}', label: 'Changed', color: 'var(--brand-primary)', items: ['New priority: Enterprise', 'Budget realloc to R&D'] },
  { emoji: '\u{1F53A}', label: 'Risks', color: 'var(--at-risk)', items: ['Competitive threat', 'Vendor dependency'] },
  { emoji: '\u{2B50}', label: 'Recommendations', color: 'var(--brand-primary)', items: ['Accelerate enterprise sales', 'Fix ops bottleneck now'] },
];

export function WeeklyStoryBlock() {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t); }, []);

  if (loading) return <CardSkeleton />;

  return (
    <div
      className="rounded-[var(--radius-card)] p-6 transition-all relative overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, var(--glow-start) 0%, var(--glow-end) 100%)',
        border: '1px solid var(--brand-primary-light)',
        boxShadow: 'var(--shadow-card)',
      }}
    >
      <div
        className="absolute inset-0 opacity-50 pointer-events-none"
        style={{ background: 'radial-gradient(circle at top right, var(--brand-primary-light), transparent 60%)' }}
      />

      <div className="relative z-10">
        <div className="mb-4">
          <h3 className="text-h3 mb-1" style={{ color: 'var(--brand-primary)' }}>Weekly Story</h3>
          <p className="text-caption" style={{ color: 'var(--brand-primary)' }}>AI-generated executive summary</p>
        </div>

        <div className="space-y-4">
          {sections.map((section) => (
            <div key={section.label}>
              <div className="flex items-center gap-2 mb-2">
                <span>{section.emoji}</span>
                <span className="text-caption-medium uppercase tracking-wide" style={{ color: section.color }}>
                  {section.label}
                </span>
              </div>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <div key={item} className="text-body" style={{ color: 'var(--neutral-600)' }}>
                    &bull; {item}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <Button
          variant="secondary"
          className="w-full mt-6"
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.6)',
            border: '1px solid var(--brand-primary-light)',
            color: 'var(--brand-primary)',
          }}
          onClick={() => toast.success('Full summary generated')}
        >
          Generate Full Summary &rarr;
        </Button>
      </div>
    </div>
  );
}

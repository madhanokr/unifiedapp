import { useState, useEffect, useCallback } from 'react';
import { Circle, CheckCircle2, ShieldCheck, Brain, TrendingUp, X, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from '../../design-system/card';
import { Badge } from '../../design-system/badge';
import { Button } from '../../design-system/button';
import { CardSkeleton } from '../../design-system/skeleton';
import { EmptyState } from '../../design-system/empty-state';
import type { ActionItem } from '../../types/execution';

const STORAGE_KEY = 'shiftfocus_completed_actions';

const actions: ActionItem[] = [
  {
    id: 1, text: 'Approve budget reallocation for R&D', category: 'Approval', impact: 'High',
    value: '$180k strategic ROI', time: '5 min', deadline: 'Today',
    decisionType: 'Strategic Judgment', consequence: 'Delays R&D by 2 weeks if not approved today',
  },
  {
    id: 2, text: 'Resolve: Engineering workload threshold', category: 'Risk', impact: 'Critical',
    value: '$420k risk avoided', time: '15 min', deadline: 'Today',
    decisionType: 'System Required', consequence: 'Auto-escalates to board if unresolved by EOD',
  },
  {
    id: 3, text: 'Decision: Hire 2 senior engineers', category: 'Resource', impact: 'High',
    value: '$340k delivery value', time: '30 min', deadline: 'This Week',
    decisionType: 'Strategic Judgment', consequence: 'Q1 capacity planning affected if delayed beyond this week',
  },
  {
    id: 4, text: 'Fix: Marketing-Sales alignment gap', category: 'Alignment', impact: 'Medium',
    value: '$85k pipeline impact', time: '10 min', deadline: 'Today',
    decisionType: 'Optimization', consequence: 'Pipeline efficiency decreases 3% per day',
  },
  {
    id: 5, text: 'Review: Enterprise partnership terms', category: 'Escalation', impact: 'High',
    value: '$2.4M opportunity', time: '20 min', deadline: 'Tomorrow',
    decisionType: 'Strategic Judgment', consequence: 'Partner deadline expires Dec 27',
  },
];

type DecisionType = ActionItem['decisionType'];

function getDecisionConfig(type: DecisionType) {
  switch (type) {
    case 'System Required':
      return { bg: 'var(--brand-primary)', text: 'var(--white)', icon: ShieldCheck };
    case 'Strategic Judgment':
      return { bg: 'var(--brand-primary-light)', text: 'var(--brand-primary)', icon: Brain };
    case 'Optimization':
      return { bg: 'var(--neutral-200)', text: 'var(--neutral-600)', icon: TrendingUp };
  }
}

function impactColors(impact: string) {
  switch (impact) {
    case 'Critical': return { bg: 'var(--danger-light)', text: 'var(--danger)' };
    case 'High': return { bg: 'var(--warning-light)', text: 'var(--at-risk)' };
    default: return { bg: 'var(--neutral-100)', text: 'var(--neutral-600)' };
  }
}

function loadCompleted(): number[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) return JSON.parse(stored) as number[];
  } catch (err) {
    console.error('Failed to load completed actions:', err);
  }
  return [];
}

function saveCompleted(ids: number[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  } catch (err) {
    console.error('Failed to save completed actions:', err);
    toast.error('Failed to save progress');
  }
}

export function CommandCenter() {
  const [loading, setLoading] = useState(true);
  const [completed, setCompleted] = useState<number[]>([]);
  const [snoozed, setSnoozed] = useState<number[]>([]);

  useEffect(() => {
    setCompleted(loadCompleted());
    const t = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(t);
  }, []);

  const toggle = useCallback((id: number) => {
    setCompleted((prev) => {
      const next = prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id];
      saveCompleted(next);
      if (!prev.includes(id)) {
        toast.success('Action completed');
      }
      return next;
    });
  }, []);

  const snooze = useCallback((id: number) => {
    setSnoozed((prev) => [...prev, id]);
    toast.success('Snoozed for 2 hours');
  }, []);

  if (loading) return <CardSkeleton />;

  const visibleActions = actions.filter((a) => !snoozed.includes(a.id));
  const allDone = visibleActions.length > 0 && visibleActions.every((a) => completed.includes(a.id));

  return (
    <Card>
      <div className="mb-4">
        <h3 className="text-h3 mb-1" style={{ color: 'var(--neutral-800)' }}>CEO Action Center</h3>
        <p className="text-caption" style={{ color: 'var(--neutral-600)' }}>
          {completed.length} of {actions.length} completed today &middot; You have final authority
        </p>
      </div>

      {allDone ? (
        <EmptyState
          icon={CheckCircle2}
          title="All actions completed"
          message="Great work! Check back later for new items."
          actionLabel="Reset"
          onAction={() => {
            setCompleted([]);
            setSnoozed([]);
            saveCompleted([]);
          }}
        />
      ) : (
        <div className="space-y-3">
          {visibleActions.map((action) => {
            const isDone = completed.includes(action.id);
            const config = getDecisionConfig(action.decisionType);
            const TypeIcon = config.icon;
            const impact = impactColors(action.impact);

            return (
              <div
                key={action.id}
                className="flex items-start gap-3 p-4 rounded-[var(--radius-button)] cursor-pointer transition-all"
                style={{
                  backgroundColor: isDone ? 'var(--success-light)' : 'var(--neutral-50)',
                  border: `1px solid ${isDone ? 'var(--success-light)' : 'transparent'}`,
                }}
                onClick={() => toggle(action.id)}
                onMouseEnter={(e) => {
                  if (!isDone) {
                    e.currentTarget.style.backgroundColor = 'var(--white)';
                    e.currentTarget.style.borderColor = 'var(--brand-primary-light)';
                    e.currentTarget.style.boxShadow = 'var(--shadow-card)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isDone) {
                    e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                    e.currentTarget.style.borderColor = 'transparent';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                <div className="pt-0.5">
                  {isDone ? (
                    <CheckCircle2 className="w-5 h-5" style={{ color: 'var(--success-darker)' }} />
                  ) : (
                    <Circle className="w-5 h-5" style={{ color: 'var(--neutral-200)' }} />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start gap-2 mb-2">
                    <span
                      className="text-body flex-1"
                      style={{
                        textDecoration: isDone ? 'line-through' : 'none',
                        color: isDone ? 'var(--neutral-400)' : 'var(--neutral-800)',
                      }}
                    >
                      {action.text}
                    </span>
                    <span
                      className="flex items-center gap-1 text-micro px-2 py-1 rounded flex-shrink-0"
                      style={{ backgroundColor: config.bg, color: config.text }}
                    >
                      <TypeIcon className="w-3 h-3" />
                      {action.decisionType}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <Badge variant="brand" size="sm">{action.category}</Badge>
                    <Badge size="sm" style={{ backgroundColor: impact.bg, color: impact.text }}>{action.impact}</Badge>
                    <span className="text-caption tabular-nums" style={{ color: 'var(--neutral-600)' }}>
                      {action.value}
                    </span>
                    <span className="text-caption tabular-nums" style={{ color: 'var(--neutral-400)' }}>
                      {action.time} &middot; {action.deadline}
                    </span>
                  </div>

                  {!isDone && (
                    <div className="flex items-center justify-between">
                      <span className="text-caption italic" style={{ color: 'var(--neutral-400)', opacity: 0.8 }}>
                        {action.consequence}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          snooze(action.id);
                        }}
                        className="flex items-center gap-1 text-caption-medium px-2 py-1 rounded-[var(--radius-badge)] transition-colors ml-2 flex-shrink-0"
                        style={{ color: 'var(--neutral-400)', backgroundColor: 'transparent' }}
                        onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
                        onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                      >
                        <Clock className="w-3 h-3" />
                        Snooze
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Button variant="brand-gradient" className="w-full mt-6">
        Refresh AI Actions
      </Button>
    </Card>
  );
}

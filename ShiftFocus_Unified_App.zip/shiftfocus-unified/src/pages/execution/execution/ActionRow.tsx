import { Flame, Sparkles, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '../design-system/badge';
import { Tooltip } from '../design-system/tooltip';
import type { DailyDelta } from '../types/execution';

const dailyDeltas: DailyDelta[] = [
  { metric: 'Revenue KPI', change: '+12%', direction: 'up', icon: TrendingUp, time: '24h', provenance: 'auto-tracked' },
  { metric: 'Engineering Velocity', change: '-8%', direction: 'down', icon: TrendingDown, time: '24h', provenance: 'blocked SLA alert' },
  { metric: 'New Risk Detected', change: '2', direction: 'alert', icon: AlertTriangle, time: '24h', provenance: 'dependency heat scan' },
  { metric: 'Confidence Shift', change: '+5%', direction: 'up', icon: TrendingUp, time: '24h', provenance: 'auto-tracked' },
  { metric: 'Blocker Added', change: '1', direction: 'alert', icon: AlertTriangle, time: '24h', provenance: 'weekly reality check' },
];

function directionColor(direction: string): string {
  if (direction === 'up') return 'var(--success-darker)';
  if (direction === 'down') return 'var(--danger)';
  return 'var(--at-risk)';
}

interface ActionRowProps {
  onOpenRootCause: () => void;
  onOpenWeeklyPlan: () => void;
}

export function ActionRow({ onOpenRootCause, onOpenWeeklyPlan }: ActionRowProps) {
  return (
    <div style={{ borderBottom: '1px solid var(--neutral-200)' }}>
      <div className="max-w-[1320px] mx-auto px-8 py-8">
        <div className="grid grid-cols-3 gap-6">
          {/* Daily Delta Strip */}
          <div className="col-span-2">
            <div className="text-micro mb-3" style={{ color: 'var(--neutral-600)' }}>
              WHAT CHANGED (LAST 24H)
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {dailyDeltas.map((delta) => {
                const DeltaIcon = delta.icon;
                return (
                  <Tooltip key={delta.metric} content={`via ${delta.provenance}`}>
                    <div
                      className="flex items-center gap-2 px-4 py-2 rounded-[var(--radius-button)] whitespace-nowrap transition-all cursor-pointer"
                      style={{
                        backgroundColor: 'var(--white)',
                        border: '1px solid var(--neutral-200)',
                      }}
                    >
                      <DeltaIcon className="w-4 h-4" style={{ color: directionColor(delta.direction) }} />
                      <span className="text-body" style={{ color: 'var(--neutral-800)' }}>{delta.metric}</span>
                      <span className="text-body-medium tabular-nums" style={{ color: directionColor(delta.direction) }}>
                        {delta.change}
                      </span>
                      <span className="text-caption" style={{ color: 'var(--neutral-400)' }}>{delta.time}</span>
                    </div>
                  </Tooltip>
                );
              })}
            </div>

            {/* Critical Alert Card */}
            <div
              className="mt-6 rounded-[var(--radius-button)] p-4 relative overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, var(--danger-light) 0%, var(--warning-light) 100%)',
                borderLeft: '4px solid var(--danger)',
              }}
            >
              <div className="flex items-start gap-4">
                <div
                  className="w-10 h-10 rounded-[var(--radius-button)] flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: 'var(--danger-light)' }}
                >
                  <Flame className="w-5 h-5" style={{ color: 'var(--danger)' }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-caption-medium uppercase tracking-wide" style={{ color: 'var(--danger)' }}>
                      CRITICAL EXECUTION ALERT
                    </span>
                    <Badge variant="danger" size="sm">3.2x threshold</Badge>
                  </div>
                  <div className="text-body mb-2" style={{ color: 'var(--neutral-800)' }}>
                    Engineering team workload is 3.2x above safe threshold — increasing Q4 delivery failure risk by 67%
                  </div>

                  {/* Enforcement Provenance */}
                  <div
                    className="flex items-center gap-4 mb-4 pb-4"
                    style={{ borderBottom: '1px solid var(--neutral-200)' }}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Detected by:</span>
                      <Badge variant="brand" size="sm">Capacity Guardrail</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>Auto-action:</span>
                      <span className="text-caption-medium" style={{ color: 'var(--success-darker)' }}>
                        Notified engineering leads
                      </span>
                    </div>
                  </div>

                  {/* Consequence Awareness */}
                  <div
                    className="text-caption p-3 rounded-[var(--radius-badge)] mb-4"
                    style={{ backgroundColor: 'rgba(255, 255, 255, 0.6)', color: 'var(--neutral-600)' }}
                  >
                    If not addressed by Friday &rarr; Q4 delivery risk increases to 89% &middot; 2 OKRs at risk
                  </div>

                  <button
                    onClick={onOpenRootCause}
                    className="text-body-medium transition-all"
                    style={{ color: 'var(--danger)', background: 'none', border: 'none', cursor: 'pointer' }}
                  >
                    View Root Cause Analysis &rarr;
                  </button>
                </div>
              </div>
            </div>

            {/* AI Recommended Actions */}
            <div
              className="mt-4 rounded-[var(--radius-card)] p-4"
              style={{ backgroundColor: 'var(--white)', border: '1px solid var(--neutral-200)' }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-6 h-6 rounded flex items-center justify-center"
                  style={{ backgroundColor: 'var(--brand-primary-light)' }}
                >
                  <Sparkles className="w-3 h-3" style={{ color: 'var(--brand-primary)' }} />
                </div>
                <span className="text-caption-medium uppercase tracking-wide" style={{ color: 'var(--neutral-600)' }}>
                  AI RECOMMENDED ACTIONS
                </span>
              </div>
              <div className="space-y-2">
                {[
                  {
                    text: 'Reallocate 2 engineers from Mobile to Backend',
                    badge: 'System-Validated' as const,
                    badgeVariant: 'brand-solid' as const,
                    detail: 'Reduces workload by 28% \u00b7 System-validated solution',
                  },
                  {
                    text: 'Defer 3 non-critical features to Q1',
                    badge: 'Recommended' as const,
                    badgeVariant: 'brand' as const,
                    detail: 'Reduces scope by 22% \u00b7 High confidence (87%)',
                  },
                  {
                    text: 'Approve contractor budget ($45k)',
                    badge: 'Optional' as const,
                    badgeVariant: 'neutral' as const,
                    detail: 'Adds capacity immediately \u00b7 Optimization opportunity',
                  },
                ].map((action) => (
                  <button
                    key={action.text}
                    className="w-full flex items-center justify-between p-3 rounded-[var(--radius-button)] text-left transition-all group"
                    style={{
                      backgroundColor: 'var(--neutral-50)',
                      border: '1px solid transparent',
                    }}
                    onClick={() => toast.success(`Action initiated: ${action.text}`)}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = 'var(--brand-primary-light)';
                      e.currentTarget.style.backgroundColor = 'var(--white)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = 'transparent';
                      e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
                    }}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-body-medium" style={{ color: 'var(--neutral-800)' }}>
                          {action.text}
                        </span>
                        <Badge variant={action.badgeVariant} size="sm">{action.badge}</Badge>
                      </div>
                      <span className="text-caption" style={{ color: 'var(--neutral-600)' }}>
                        {action.detail}
                      </span>
                    </div>
                    <span
                      className="text-body opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ color: 'var(--brand-primary)' }}
                    >
                      &rarr;
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Weekly AI Plan Card */}
          <div
            className="rounded-[var(--radius-card)] p-6"
            style={{
              background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
              color: 'var(--white)',
            }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5" />
              <span className="text-caption-medium uppercase tracking-wide" style={{ opacity: 0.9 }}>
                AI WEEKLY PLAN
              </span>
            </div>
            <div className="text-h3 mb-2">Your Weekly Action Plan Is Ready</div>
            <div className="text-caption mb-4" style={{ opacity: 0.8 }}>
              We analyzed 3,218 signals from KPIs, OKRs, drift, risks &amp; dependencies — here&apos;s what matters.
            </div>
            <div className="space-y-2 mb-6">
              <div className="text-body" style={{ opacity: 0.9 }}>&bull; 5 decisions need approval</div>
              <div className="text-body" style={{ opacity: 0.9 }}>&bull; 3 risks to resolve</div>
              <div className="text-body" style={{ opacity: 0.9 }}>&bull; 2 strategic adjustments</div>
            </div>
            <button
              onClick={onOpenWeeklyPlan}
              className="w-full h-10 rounded-[var(--radius-button)] text-body-medium transition-all"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                color: 'var(--white)',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.3)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.2)'; }}
            >
              Open Weekly Plan &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

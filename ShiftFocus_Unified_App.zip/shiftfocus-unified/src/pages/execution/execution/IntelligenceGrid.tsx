import { CompanyPulse } from './blocks/CompanyPulse';
import { FocusBlock } from './blocks/FocusBlock';
import { TeamSnapshot } from './blocks/TeamSnapshot';
import { RiskBlock } from './blocks/RiskBlock';
import { WeeklyStoryBlock } from './blocks/WeeklyStoryBlock';
import { CommandCenter } from './blocks/CommandCenter';
import type { Initiative, Team, Risk } from '../types/execution';

interface IntelligenceGridProps {
  onOpenForecast: () => void;
  onOpenInitiative: (initiative: Initiative) => void;
  onOpenTeamDetail: (team: Team) => void;
  onOpenRiskDetail: (risk: Risk) => void;
}

export function IntelligenceGrid({ onOpenForecast, onOpenInitiative, onOpenTeamDetail, onOpenRiskDetail }: IntelligenceGridProps) {
  return (
    <div className="grid grid-cols-2 gap-6">
      <CompanyPulse onOpenForecast={onOpenForecast} />
      <FocusBlock onOpenInitiative={onOpenInitiative} />
      <TeamSnapshot onOpenTeamDetail={onOpenTeamDetail} />
      <RiskBlock onOpenRiskDetail={onOpenRiskDetail} />
      <WeeklyStoryBlock />
      <CommandCenter />
    </div>
  );
}

import { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Skeleton } from '../design-system/skeleton';

const healthMetrics = [
  { label: 'Execution Momentum', value: 78, change: 5.2, description: 'Proprietary score measuring org velocity toward goals' },
  { label: 'Confidence', value: 82, change: 3.1, description: 'Team belief in hitting targets' },
  { label: 'Risk Index', value: 23, change: -2.4, isInverted: true, description: '% of work at risk' },
  { label: 'Alignment', value: 88, change: -1.8, description: 'Cross-team strategic sync' },
  { label: 'Predictive Velocity', value: 91, change: 7.3, description: 'AI forecast of target achievement' },
  { label: 'Win Rate', value: 67, change: 4.5, description: '% milestones hit on time' },
];

export function ExecutionHeader() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{ backgroundColor: 'var(--white)', borderBottom: '1px solid var(--neutral-200)' }}>
      <div className="max-w-[1320px] mx-auto px-8 py-8">
        <div className="mb-8">
          <h1 className="text-display mb-2" style={{ color: 'var(--neutral-950)' }}>
            Execution Command Center
          </h1>
          <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
            Real-time Operational Health &middot; Updated every 2 hours
          </p>
        </div>

        <div className="grid grid-cols-6 gap-6">
          {loading
            ? Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton variant="text" width={64} height={32} />
                  <Skeleton variant="text" width={100} height={14} />
                  <Skeleton variant="text" width={80} height={10} />
                </div>
              ))
            : healthMetrics.map((metric) => {
                const isPositive = metric.isInverted ? metric.change < 0 : metric.change > 0;
                return (
                  <div key={metric.label} className="group">
                    <div className="flex items-baseline gap-3 mb-2">
                      <div className="text-display tabular-nums" style={{ color: 'var(--neutral-950)' }}>
                        {metric.value}
                      </div>
                      <div
                        className="flex items-center gap-0.5 text-caption-medium tabular-nums"
                        style={{ color: isPositive ? 'var(--success-darker)' : 'var(--danger)' }}
                      >
                        {isPositive ? (
                          <ArrowUpRight className="w-3 h-3" />
                        ) : (
                          <ArrowDownRight className="w-3 h-3" />
                        )}
                        {Math.abs(metric.change)}%
                      </div>
                    </div>
                    <div className="text-caption-medium mb-1" style={{ color: 'var(--neutral-800)' }}>
                      {metric.label}
                    </div>
                    <div className="text-micro" style={{ color: 'var(--neutral-400)' }}>
                      Updated 20m ago
                    </div>
                    <div
                      className="text-micro opacity-0 group-hover:opacity-100 transition-opacity mt-2"
                      style={{ color: 'var(--neutral-600)', transitionDuration: 'var(--duration-fast)' }}
                    >
                      {metric.description}
                    </div>
                  </div>
                );
              })}
        </div>
      </div>
    </div>
  );
}

import type { ComponentType } from 'react';

export interface IconProps {
  className?: string;
  style?: React.CSSProperties;
}

export type IconComponent = ComponentType<IconProps>;

export interface Initiative {
  name: string;
  progress: number;
  confidence: string;
  blocker: boolean;
  owner: string;
  ownerName: string;
  tag: {
    icon: IconComponent;
    label: string;
    color: string;
  };
}

export interface Team {
  name: string;
  icon: IconComponent;
  confidence: number;
  velocity: string;
  alignment: number;
  blocker: string | null;
}

export interface Risk {
  title: string;
  severity: string;
  owner: string;
  badge: string | null;
  impact: string;
  value?: string;
}

export interface DailyDelta {
  metric: string;
  change: string;
  direction: 'up' | 'down' | 'alert';
  icon: IconComponent;
  time: string;
  provenance: string;
}

export interface ActionItem {
  id: number;
  text: string;
  category: string;
  impact: string;
  value: string;
  time: string;
  deadline: string;
  decisionType: 'System Required' | 'Strategic Judgment' | 'Optimization';
  consequence: string;
}

export interface Misalignment {
  title: string;
  severity: string;
  owner: string;
  badge: string | null;
  impact: string;
}

export interface Opportunity {
  title: string;
  impact: string;
  owner: string;
  badge: string | null;
  value: string;
}

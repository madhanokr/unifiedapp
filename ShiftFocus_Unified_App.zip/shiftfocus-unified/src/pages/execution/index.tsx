import { ExecutionDashboard } from './execution/ExecutionDashboard';
export default function ExecutionPage() {
  return <ExecutionDashboard />;
}

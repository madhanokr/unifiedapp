import { type HTMLAttributes, type CSSProperties, forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const cardStructure = cva(
  'rounded-[var(--radius-card)] p-6 transition-all',
  {
    variants: {
      variant: {
        default: '',
        bordered: '',
        elevated: '',
      },
    },
    defaultVariants: { variant: 'bordered' },
  }
);

function cardColorStyles(variant: string): CSSProperties {
  const base: CSSProperties = {
    backgroundColor: 'var(--white)',
    borderRadius: 'var(--radius-card)',
  };
  switch (variant) {
    case 'bordered':
      return {
        ...base,
        border: '1px solid var(--neutral-200)',
        boxShadow: 'var(--shadow-card)',
      };
    case 'elevated':
      return {
        ...base,
        boxShadow: 'var(--shadow-elevated)',
      };
    default:
      return base;
  }
}

interface CardProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'style'>,
    VariantProps<typeof cardStructure> {
  variant?: 'default' | 'bordered' | 'elevated';
  hoverLift?: boolean;
  style?: CSSProperties;
}

const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className, variant = 'bordered', hoverLift = true, style, children, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        cardStructure({ variant }),
        hoverLift && 'hover:shadow-[var(--shadow-card-hover)]',
        'duration-[var(--duration-standard)]',
        className
      )}
      style={{ ...cardColorStyles(variant), ...style }}
      {...props}
    >
      {children}
    </div>
  )
);
Card.displayName = 'Card';

export { Card, cardStructure };
export type { CardProps };

import { type HTMLAttributes, forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const skeletonStructure = cva(
  'animate-pulse',
  {
    variants: {
      variant: {
        text: 'rounded-[var(--radius-badge)]',
        circle: 'rounded-full',
        rect: 'rounded-[var(--radius-button)]',
      },
    },
    defaultVariants: { variant: 'text' },
  }
);

interface SkeletonProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonStructure> {
  width?: string | number;
  height?: string | number;
}

const Skeleton = forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, variant, width, height, style, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(skeletonStructure({ variant }), className)}
      style={{
        backgroundColor: 'var(--neutral-200)',
        width: typeof width === 'number' ? `${width}px` : width,
        height: typeof height === 'number' ? `${height}px` : height,
        ...style,
      }}
      {...props}
    />
  )
);
Skeleton.displayName = 'Skeleton';

function CardSkeleton() {
  return (
    <div
      className="rounded-[var(--radius-card)] p-6 space-y-4"
      style={{ backgroundColor: 'var(--white)', border: '1px solid var(--neutral-200)' }}
    >
      <Skeleton variant="text" width="40%" height={20} />
      <Skeleton variant="text" width="60%" height={14} />
      <div className="space-y-3 pt-2">
        <Skeleton variant="rect" width="100%" height={48} />
        <Skeleton variant="rect" width="100%" height={48} />
        <Skeleton variant="rect" width="100%" height={48} />
      </div>
      <Skeleton variant="rect" width="100%" height={40} />
    </div>
  );
}

export { Skeleton, CardSkeleton };
export type { SkeletonProps };

import { forwardRef, type ButtonHTMLAttributes, type CSSProperties } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';

const buttonStructure = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]',
  {
    variants: {
      size: {
        sm: 'h-8 px-3 rounded-[var(--radius-badge)]',
        md: 'h-10 px-4 rounded-[var(--radius-button)]',
        lg: 'h-12 px-6 rounded-[var(--radius-button)]',
      },
    },
    defaultVariants: { size: 'md' },
  }
);

function variantStyles(variant: string): CSSProperties {
  switch (variant) {
    case 'secondary':
      return { backgroundColor: 'var(--neutral-100)', color: 'var(--neutral-800)' };
    case 'ghost':
      return { backgroundColor: 'transparent', color: 'var(--brand-primary)' };
    case 'destructive':
      return { backgroundColor: 'var(--danger)', color: 'var(--white)' };
    case 'brand-gradient':
      return {
        background: 'linear-gradient(135deg, var(--gradient-start) 0%, var(--gradient-end) 100%)',
        color: 'var(--white)',
        boxShadow: 'var(--shadow-brand)',
      };
    default:
      return { backgroundColor: 'var(--brand-primary)', color: 'var(--white)' };
  }
}

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'destructive' | 'brand-gradient';

interface ButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'style'>,
    VariantProps<typeof buttonStructure> {
  variant?: ButtonVariant;
  loading?: boolean;
  style?: CSSProperties;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size, loading, disabled, children, style, ...props }, ref) => (
    <button
      ref={ref}
      className={cn(buttonStructure({ size }), 'text-body-medium', className)}
      disabled={disabled || loading}
      style={{ ...variantStyles(variant), ...style }}
      {...props}
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
      {children}
    </button>
  )
);
Button.displayName = 'Button';

export { Button, buttonStructure };
export type { ButtonProps };

import { type HTMLAttributes, type CSSProperties, forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const progressStructure = cva(
  'w-full rounded-full overflow-hidden',
  {
    variants: {
      size: {
        sm: 'h-1',
        md: 'h-2',
      },
    },
    defaultVariants: { size: 'md' },
  }
);

type ProgressVariant = 'success' | 'warning' | 'danger' | 'brand';

function fillColor(variant: ProgressVariant): string {
  switch (variant) {
    case 'success': return 'var(--success-darker)';
    case 'warning': return 'var(--at-risk)';
    case 'danger': return 'var(--danger)';
    default: return 'var(--brand-primary)';
  }
}

interface ProgressBarProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'style'>,
    VariantProps<typeof progressStructure> {
  value: number;
  variant?: ProgressVariant;
  style?: CSSProperties;
}

const ProgressBar = forwardRef<HTMLDivElement, ProgressBarProps>(
  ({ className, variant = 'brand', size, value, style, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(progressStructure({ size }), className)}
      style={{ backgroundColor: 'var(--neutral-100)', ...style }}
      {...props}
    >
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{
          width: `${Math.min(100, Math.max(0, value))}%`,
          backgroundColor: fillColor(variant),
        }}
      />
    </div>
  )
);
ProgressBar.displayName = 'ProgressBar';

export { ProgressBar };
export type { ProgressBarProps, ProgressVariant };

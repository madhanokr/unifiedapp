import * as TooltipPrimitive from '@radix-ui/react-tooltip';
import type { ReactNode } from 'react';
import { cn } from '../lib/utils';

interface TooltipProps {
  children: ReactNode;
  content: ReactNode;
  side?: 'top' | 'right' | 'bottom' | 'left';
  delayDuration?: number;
  className?: string;
}

export function Tooltip({ children, content, side = 'top', delayDuration = 200, className }: TooltipProps) {
  return (
    <TooltipPrimitive.Provider>
      <TooltipPrimitive.Root delayDuration={delayDuration}>
        <TooltipPrimitive.Trigger asChild>{children}</TooltipPrimitive.Trigger>
        <TooltipPrimitive.Portal>
          <TooltipPrimitive.Content
            side={side}
            sideOffset={6}
            className={cn(
              'text-caption px-3 py-1.5 rounded-[var(--radius-badge)] animate-in fade-in-0 zoom-in-95',
              className
            )}
            style={{
              backgroundColor: 'var(--neutral-950)',
              color: 'var(--white)',
              boxShadow: 'var(--shadow-tooltip)',
              zIndex: 100,
            }}
          >
            {content}
            <TooltipPrimitive.Arrow
              className="fill-[var(--neutral-950)]"
              width={10}
              height={5}
            />
          </TooltipPrimitive.Content>
        </TooltipPrimitive.Portal>
      </TooltipPrimitive.Root>
    </TooltipPrimitive.Provider>
  );
}

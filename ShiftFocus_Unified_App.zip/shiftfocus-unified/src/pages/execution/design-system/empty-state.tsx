import type { ReactNode } from 'react';
import type { IconComponent } from '../types/execution';
import { Button } from './button';

interface EmptyStateProps {
  icon?: IconComponent;
  title: string;
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  children?: ReactNode;
}

export function EmptyState({ icon: Icon, title, message, actionLabel, onAction, children }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
      {Icon && (
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
          style={{ backgroundColor: 'var(--neutral-100)' }}
        >
          <Icon className="w-6 h-6" style={{ color: 'var(--neutral-400)' }} />
        </div>
      )}
      <h3 className="text-body-medium mb-1" style={{ color: 'var(--neutral-800)' }}>
        {title}
      </h3>
      {message && (
        <p className="text-caption mb-4" style={{ color: 'var(--neutral-600)' }}>
          {message}
        </p>
      )}
      {actionLabel && onAction && (
        <Button variant="ghost" size="sm" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
      {children}
    </div>
  );
}

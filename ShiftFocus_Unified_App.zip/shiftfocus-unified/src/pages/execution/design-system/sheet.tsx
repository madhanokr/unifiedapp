import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import type { ReactNode } from 'react';
import { cn } from '../lib/utils';

interface SheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  children: ReactNode;
  side?: 'left' | 'right';
  className?: string;
}

export function Sheet({ open, onOpenChange, title, children, side = 'right', className }: SheetProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay
          className="fixed inset-0 z-40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
          style={{
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            backdropFilter: 'blur(4px)',
          }}
        />
        <DialogPrimitive.Content
          className={cn(
            'fixed top-0 bottom-0 z-50 flex flex-col',
            'data-[state=open]:animate-in data-[state=closed]:animate-out',
            side === 'right'
              ? 'right-0 data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right'
              : 'left-0 data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left',
            className
          )}
          style={{
            width: '420px',
            backgroundColor: 'var(--white)',
            boxShadow: 'var(--shadow-drawer)',
          }}
        >
          {title && (
            <div
              className="flex items-center justify-between p-6"
              style={{ borderBottom: '1px solid var(--neutral-200)' }}
            >
              <DialogPrimitive.Title className="text-h3" style={{ color: 'var(--neutral-800)' }}>
                {title}
              </DialogPrimitive.Title>
              <DialogPrimitive.Close
                className="w-8 h-8 rounded-[var(--radius-button)] flex items-center justify-center transition-colors"
                style={{ color: 'var(--neutral-400)' }}
              >
                <X className="w-5 h-5" />
              </DialogPrimitive.Close>
            </div>
          )}
          <div className="flex-1 overflow-y-auto">{children}</div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

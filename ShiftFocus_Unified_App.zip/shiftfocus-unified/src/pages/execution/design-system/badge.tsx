import { type HTMLAttributes, type CSSProperties, forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const badgeStructure = cva(
  'inline-flex items-center gap-1 whitespace-nowrap rounded-[var(--radius-badge)]',
  {
    variants: {
      size: {
        sm: 'px-1.5 py-0.5 text-micro',
        md: 'px-3 py-1.5 text-caption-medium',
      },
    },
    defaultVariants: { size: 'md' },
  }
);

type BadgeVariant = 'success' | 'warning' | 'danger' | 'info' | 'neutral' | 'brand' | 'brand-solid';

function badgeColorStyles(variant: BadgeVariant): CSSProperties {
  switch (variant) {
    case 'success':
      return { backgroundColor: 'var(--success-light)', color: 'var(--success-darker)' };
    case 'warning':
      return { backgroundColor: 'var(--warning-light)', color: 'var(--at-risk)' };
    case 'danger':
      return { backgroundColor: 'var(--danger-light)', color: 'var(--danger)' };
    case 'info':
      return { backgroundColor: 'var(--info-light)', color: 'var(--info)' };
    case 'neutral':
      return { backgroundColor: 'var(--neutral-200)', color: 'var(--neutral-600)' };
    case 'brand':
      return { backgroundColor: 'var(--brand-primary-light)', color: 'var(--brand-primary)' };
    case 'brand-solid':
      return { backgroundColor: 'var(--brand-primary)', color: 'var(--white)' };
    default:
      return { backgroundColor: 'var(--neutral-100)', color: 'var(--neutral-600)' };
  }
}

interface BadgeProps
  extends Omit<HTMLAttributes<HTMLSpanElement>, 'style'>,
    VariantProps<typeof badgeStructure> {
  variant?: BadgeVariant;
  style?: CSSProperties;
}

const Badge = forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant = 'neutral', size, style, children, ...props }, ref) => (
    <span
      ref={ref}
      className={cn(badgeStructure({ size }), className)}
      style={{ ...badgeColorStyles(variant), ...style }}
      {...props}
    >
      {children}
    </span>
  )
);
Badge.displayName = 'Badge';

export { Badge, badgeStructure };
export type { BadgeProps, BadgeVariant };

import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X } from 'lucide-react';
import type { ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const dialogContent = cva(
  'relative flex flex-col rounded-[var(--radius-card)] overflow-hidden',
  {
    variants: {
      size: {
        sm: 'max-w-md max-h-[80vh]',
        md: 'max-w-2xl max-h-[85vh]',
        lg: 'max-w-5xl max-h-[90vh]',
      },
    },
    defaultVariants: { size: 'md' },
  }
);

interface DialogProps extends VariantProps<typeof dialogContent> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg';
}

export function Dialog({ open, onOpenChange, title, children, size = 'md' }: DialogProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay
          className="fixed inset-0 z-50 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0"
          style={{
            backgroundColor: 'rgba(0, 0, 0, 0.4)',
            backdropFilter: 'blur(4px)',
          }}
        />
        <DialogPrimitive.Content
          className={cn(
            dialogContent({ size }),
            'fixed left-1/2 top-1/2 z-50 w-full -translate-x-1/2 -translate-y-1/2 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95'
          )}
          style={{
            backgroundColor: 'var(--white)',
            boxShadow: 'var(--shadow-modal)',
          }}
        >
          {title && (
            <div
              className="flex items-center justify-between px-6 py-4"
              style={{ borderBottom: '1px solid var(--neutral-200)' }}
            >
              <DialogPrimitive.Title className="text-h3" style={{ color: 'var(--neutral-800)' }}>
                {title}
              </DialogPrimitive.Title>
              <DialogPrimitive.Close
                className="w-8 h-8 rounded-[var(--radius-button)] flex items-center justify-center transition-colors"
                style={{ color: 'var(--neutral-400)' }}
              >
                <X className="w-5 h-5" />
              </DialogPrimitive.Close>
            </div>
          )}
          <div className="flex-1 overflow-y-auto">{children}</div>
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  onConfirm,
  destructive = false,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  destructive?: boolean;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange} title={title} size="sm">
      <div className="p-6 space-y-6">
        <p className="text-body" style={{ color: 'var(--neutral-600)' }}>
          {description}
        </p>
        <div className="flex gap-3 justify-end">
          <button
            onClick={() => onOpenChange(false)}
            className="text-body-medium h-10 px-4 rounded-[var(--radius-button)] transition-colors"
            style={{ backgroundColor: 'var(--neutral-100)', color: 'var(--neutral-800)' }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={() => {
              onConfirm();
              onOpenChange(false);
            }}
            className="text-body-medium h-10 px-4 rounded-[var(--radius-button)] transition-colors"
            style={{
              backgroundColor: destructive ? 'var(--danger)' : 'var(--brand-primary)',
              color: 'var(--white)',
            }}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </Dialog>
  );
}

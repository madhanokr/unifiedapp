import { X, AlertTriangle } from 'lucide-react';
import { DSButton, DSBadge } from './design-system';

interface DependencyDetail {
  initiative: string;
  team: string;
  impactedKR: string;
  delayCost: string;
  owner: string;
  severity: string;
  aiRecommendation: string;
}

interface DependencyDetailPanelProps {
  detail: DependencyDetail | null;
  onClose: () => void;
}

export function DependencyDetailPanel({ detail, onClose }: DependencyDetailPanelProps) {
  if (!detail) return null;

  const getSeverityVariant = (severity: string): 'danger' | 'warning' | 'info' => {
    if (severity === 'Critical') return 'danger';
    if (severity === 'High') return 'warning';
    return 'info';
  };

  return (
    <div className="fixed right-0 top-0 bottom-0 w-96 z-50 animate-in slide-in-from-right duration-300" style={{ backgroundColor: 'var(--bg-level-0)', borderLeft: '1px solid var(--neutral-200)', boxShadow: 'var(--shadow-drawer)' }}>
      <div className="p-8 space-y-8">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg" style={{ backgroundColor: 'var(--at-risk-light)' }}>
              <AlertTriangle className="size-5" style={{ color: 'var(--warning-dark)' }} />
            </div>
            <h3 style={{ color: 'var(--neutral-950)' }}>Blocker Details</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg transition-colors" style={{ backgroundColor: 'transparent' }} onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }} onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
            <X className="size-5" style={{ color: 'var(--neutral-600)' }} />
          </button>
        </div>

        <div className="space-y-4">
          {[{ label: 'Initiative', value: detail.initiative }, { label: 'Blocked by Team', value: detail.team }, { label: 'Impacted KR', value: detail.impactedKR }, { label: 'Owner', value: detail.owner }].map((item) => (
            <div key={item.label}>
              <div style={{ color: 'var(--neutral-600)', fontSize: '14px', marginBottom: '4px' }}>{item.label}</div>
              <div style={{ color: 'var(--neutral-950)' }}>{item.value}</div>
            </div>
          ))}
          <div>
            <div style={{ color: 'var(--neutral-600)', fontSize: '14px', marginBottom: '4px' }}>Delay Cost</div>
            <div style={{ color: 'var(--warning-dark)', fontWeight: 500 }}>{detail.delayCost}</div>
          </div>
          <div>
            <div style={{ color: 'var(--neutral-600)', fontSize: '14px', marginBottom: '4px' }}>Severity</div>
            <DSBadge variant={getSeverityVariant(detail.severity)}>{detail.severity}</DSBadge>
          </div>

          <div className="pt-4" style={{ borderTop: '1px solid var(--neutral-200)' }}>
            <div style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>AI Recommendation</div>
            <p style={{ color: 'var(--brand-primary)', lineHeight: '1.6' }}>{detail.aiRecommendation}</p>
          </div>
        </div>

        <div className="pt-4">
          <DSButton variant="primary" style={{ width: '100%' }}>Apply Recommended Fix</DSButton>
        </div>
      </div>
    </div>
  );
}

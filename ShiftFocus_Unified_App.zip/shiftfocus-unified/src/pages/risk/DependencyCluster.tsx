import { useState, useEffect } from 'react';
import { Info } from 'lucide-react';
import { DSTooltip, DSCard, DSSkeleton, DSSkeletonCard } from './design-system';
import { DependencyDetailPanel } from './DependencyDetailPanel';
import { DependencyDrillDownModal } from './DependencyDrillDownModal';

const initiatives = ['Mobile App Launch', 'API v3 Migration', 'Design System Update', 'EMEA Expansion', 'Platform Scalability', 'Customer Portal', 'Analytics Dashboard', 'Security Audit'];
const teams = ['Engineering', 'Product', 'Design', 'Sales', 'Marketing', 'Support', 'Legal'];
const dependencies = [[3,1,2,0,0,1,0],[5,2,1,0,0,0,1],[4,3,0,0,0,0,0],[1,1,0,2,1,0,3],[6,1,0,0,0,1,0],[2,2,1,1,0,3,0],[3,2,0,0,1,0,0],[2,1,0,0,0,0,2]];

interface DependencyDetail {
  initiative: string;
  team: string;
  impactedKR: string;
  delayCost: string;
  owner: string;
  severity: string;
  aiRecommendation: string;
}

function getIntensityStyle(value: number): React.CSSProperties {
  if (value === 0) return { backgroundColor: 'var(--heatmap-0)' };
  if (value === 1) return { backgroundColor: 'var(--heatmap-1)' };
  if (value === 2) return { backgroundColor: 'var(--heatmap-2)' };
  if (value === 3) return { backgroundColor: 'var(--heatmap-3)' };
  if (value === 4) return { backgroundColor: 'var(--heatmap-4)' };
  if (value === 5) return { backgroundColor: 'var(--heatmap-5)' };
  return { backgroundColor: 'var(--heatmap-6)' };
}

export function DependencyCluster() {
  const [loading, setLoading] = useState(true);
  const [selectedDetail, setSelectedDetail] = useState<DependencyDetail | null>(null);
  const [drillDownModal, setDrillDownModal] = useState<{ isOpen: boolean; initiative: string; team: string }>({ isOpen: false, initiative: '', team: '' });

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const handleCellClick = (initiative: string, team: string, value: number) => {
    if (value > 0) setDrillDownModal({ isOpen: true, initiative, team });
  };

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h2 style={{ color: 'var(--neutral-950)' }}>Cross-Team Dependency Bottlenecks</h2>
            <DSTooltip
              content={
                <div style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--tooltip-text)' }}>
                  <p style={{ fontWeight: 500, marginBottom: '8px' }}>How is this calculated?</p>
                  <p style={{ marginBottom: '8px', color: 'var(--neutral-200)' }}><strong style={{ color: 'var(--tooltip-text)' }}>Each number</strong> = count of items blocked waiting on that team.</p>
                  <p style={{ color: 'var(--tooltip-muted)', fontSize: '12px', fontStyle: 'italic' }}>Higher numbers = more coordination risk.</p>
                </div>
              }
              side="right"
              maxWidth="400px"
            >
              <button className="p-1.5 rounded-lg transition-all duration-150" style={{ backgroundColor: 'var(--neutral-100)', border: '1px solid var(--neutral-200)' }} onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-200)'; }} onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
                <Info className="size-4" style={{ color: 'var(--neutral-600)' }} />
              </button>
            </DSTooltip>
          </div>
          <p style={{ color: 'var(--neutral-600)' }}>Each number shows how many items are blocked waiting on that team. Click any cell to see details.</p>
        </div>
      </div>

      {loading ? (
        <DSSkeletonCard />
      ) : (
        <DSCard>
          <div className="overflow-x-auto">
            <div className="inline-block min-w-full">
              <div className="flex">
                <div className="w-48 flex-shrink-0" />
                <div className="flex gap-3">
                  {teams.map((team) => (
                    <div key={team} className="w-28 text-center" style={{ color: 'var(--neutral-800)' }}>{team}</div>
                  ))}
                </div>
              </div>
              <div className="mt-4 space-y-3">
                {initiatives.map((initiative, i) => (
                  <div key={initiative} className="flex items-center">
                    <div className="w-48 flex-shrink-0 pr-4" style={{ color: 'var(--neutral-800)' }}>{initiative}</div>
                    <div className="flex gap-3">
                      {dependencies[i].map((value, j) => (
                        <DSTooltip
                          key={j}
                          content={value > 0 ? `${value} item${value !== 1 ? 's' : ''} blocked: ${initiative} ← ${teams[j]}. Click to drill down.` : 'No dependencies'}
                        >
                          <div
                            className="w-28 h-14 rounded-xl flex items-center justify-center transition-all hover:scale-110 hover:z-10 cursor-pointer"
                            style={{ ...getIntensityStyle(value), border: '1px solid var(--neutral-200)' }}
                            onClick={() => handleCellClick(initiative, teams[j], value)}
                            onMouseEnter={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-elevated)'; }}
                            onMouseLeave={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
                            onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                            onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
                            tabIndex={0}
                            role="button"
                          >
                            {value > 0 && <span style={{ color: 'var(--neutral-950)', fontWeight: 500 }}>{value}</span>}
                          </div>
                        </DSTooltip>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Legend */}
              <div className="flex items-center gap-8 mt-8 pt-8" style={{ borderTop: '1px solid var(--neutral-200)' }}>
                <span style={{ color: 'var(--neutral-600)', fontWeight: 500 }}>Blocked Items:</span>
                <div className="flex items-center gap-3">
                  {[{ label: 'None', var: '--heatmap-0' }, { label: '1', var: '--heatmap-1' }, { label: '2', var: '--heatmap-2' }, { label: '3', var: '--heatmap-3' }, { label: '4', var: '--heatmap-4' }, { label: '5+ Critical', var: '--heatmap-6' }].map((item) => (
                    <div key={item.label} className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: `var(${item.var})`, border: '1px solid var(--neutral-200)' }} />
                      <span style={{ color: 'var(--neutral-600)' }}>{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </DSCard>
      )}

      <DependencyDetailPanel detail={selectedDetail} onClose={() => setSelectedDetail(null)} />
      <DependencyDrillDownModal isOpen={drillDownModal.isOpen} onClose={() => setDrillDownModal({ isOpen: false, initiative: '', team: '' })} initiative={drillDownModal.initiative} team={drillDownModal.team} />
    </div>
  );
}

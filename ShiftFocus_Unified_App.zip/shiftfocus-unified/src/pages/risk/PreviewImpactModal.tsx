import { AlertCircle, Bell, CheckSquare, Shield } from 'lucide-react';
import { DSButton, DSDialog, DSDialogContent, DSDialogHeader, DSDialogTitle, DSDialogDescription, DSDialogBody, DSDialogFooter } from './design-system';

interface PreviewImpactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  mode: 'intervention' | 'resolved';
  selectedAction: string;
  escalateTo: string;
  reassignTo: string;
  autoEnforce: boolean;
  proofType: string;
}

export function PreviewImpactModal({ isOpen, onClose, onConfirm, mode, selectedAction, escalateTo, reassignTo, autoEnforce, proofType }: PreviewImpactModalProps) {
  if (!isOpen) return null;

  const getPersonName = (id: string) => {
    const names: Record<string, string> = { 'alex-kim': 'Alex Kim', 'jordan-lee': 'Jordan Lee', 'sam-patel': 'Sam Patel', 'taylor-wong': 'Taylor Wong' };
    return names[id] || id;
  };

  return (
    <DSDialog open={isOpen} onOpenChange={onClose}>
      <DSDialogContent size="md">
        <DSDialogHeader>
          <DSDialogTitle>Review Changes</DSDialogTitle>
          <DSDialogDescription>Confirm all actions before applying</DSDialogDescription>
        </DSDialogHeader>

        <DSDialogBody>
          {mode === 'intervention' && (
            <div className="space-y-5">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Bell className="size-4" style={{ color: 'var(--brand-primary)' }} />
                  <h4 style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)' }}>Notifications</h4>
                </div>
                <div className="space-y-2">
                  {[{ name: 'Sarah Chen', role: 'Current risk owner · Email + Slack' }, { name: 'Tom Martinez', role: "Manager · CC'd on all updates" }].map((p) => (
                    <div key={p.name} className="p-3 rounded-lg" style={{ backgroundColor: 'var(--neutral-50)' }}>
                      <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '2px' }}>{p.name}</div>
                      <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>{p.role}</div>
                    </div>
                  ))}
                  {selectedAction === 'recommended' && (
                    <div className="p-3 rounded-lg" style={{ backgroundColor: 'rgba(106, 61, 232, 0.06)', border: '1px solid rgba(106, 61, 232, 0.15)' }}>
                      <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '2px' }}>{getPersonName(escalateTo)}</div>
                      <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Unblock owner · Full task access</div>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <CheckSquare className="size-4" style={{ color: 'var(--brand-primary)' }} />
                  <h4 style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)' }}>System Actions</h4>
                </div>
                <div className="space-y-2">
                  {['Task created with 24h SLA', 'Risk status → "Intervention Applied"', 'Logged to Activity Log'].map((action, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <div className="size-5 rounded flex items-center justify-center mt-0.5" style={{ backgroundColor: 'var(--resolved-light)' }}>
                        <span style={{ fontSize: '10px', fontWeight: 600, color: 'var(--resolved)' }}>✓</span>
                      </div>
                      <p style={{ fontSize: '14px', color: 'var(--neutral-800)', lineHeight: '1.6' }}>{action}</p>
                    </div>
                  ))}
                </div>
              </div>

              {autoEnforce && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Shield className="size-4" style={{ color: 'var(--brand-primary)' }} />
                    <h4 style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)' }}>Enforcement Rule</h4>
                  </div>
                  <div className="p-4 rounded-lg" style={{ backgroundColor: 'rgba(106, 61, 232, 0.05)', border: '1px solid rgba(106, 61, 232, 0.15)' }}>
                    <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--brand-primary)', marginBottom: '4px' }}>Blocked SLA — Critical (Auto-created)</div>
                    <p style={{ fontSize: '12px', color: 'var(--neutral-800)', lineHeight: '1.5' }}>If owner silent &gt; 24h → Auto-escalate</p>
                  </div>
                </div>
              )}

              <div className="p-4 rounded-lg" style={{ backgroundColor: 'rgba(245, 166, 35, 0.05)', border: '1px solid rgba(245, 166, 35, 0.2)' }}>
                <div className="flex items-start gap-2">
                  <AlertCircle className="size-4 mt-0.5" style={{ color: 'var(--warning)' }} />
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--warning)', marginBottom: '4px' }}>Undo available for 5 minutes</div>
                    <p style={{ fontSize: '12px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>You can revert within 5 minutes. After that, it's permanent.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {mode === 'resolved' && (
            <div className="space-y-5">
              <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--resolved-light)', border: '1px solid var(--resolved-border)' }}>
                <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--resolved)', marginBottom: '8px' }}>Risk will be marked as Resolved</div>
                <div className="space-y-2">
                  <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Proof type: <strong>{proofType === 'update-received' ? 'Update received' : proofType === 'dependency-cleared' ? 'Dependency cleared' : 'SLA met'}</strong></div>
                  <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Logged to: <strong>Audit Trail</strong></div>
                </div>
              </div>
              <div className="p-4 rounded-lg" style={{ backgroundColor: 'rgba(229, 57, 53, 0.05)', border: '1px solid rgba(229, 57, 53, 0.2)' }}>
                <div className="flex items-start gap-2">
                  <AlertCircle className="size-4 mt-0.5" style={{ color: 'var(--danger)' }} />
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--danger)', marginBottom: '4px' }}>This action is permanent</div>
                    <p style={{ fontSize: '12px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>Once resolved, this risk will be archived.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DSDialogBody>

        <DSDialogFooter>
          <DSButton variant="secondary" onClick={onClose}>Cancel</DSButton>
          <DSButton variant="primary" onClick={onConfirm} style={{ backgroundColor: mode === 'resolved' ? 'var(--resolved)' : 'var(--brand-primary)' }}>Confirm & Apply</DSButton>
        </DSDialogFooter>
      </DSDialogContent>
    </DSDialog>
  );
}

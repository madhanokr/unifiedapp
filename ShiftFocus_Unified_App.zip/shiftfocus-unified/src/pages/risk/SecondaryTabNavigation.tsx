interface SecondaryTabNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function SecondaryTabNavigation({ activeTab, onTabChange }: SecondaryTabNavigationProps) {
  const tabs = [
    { id: 'patterns', label: 'Patterns', description: 'Cross-team dependencies & workload stress' },
    { id: 'forecast', label: 'Forecast', description: 'Predictive failure modes & scenarios' }
  ];

  return (
    <div className="flex items-center gap-2 p-1 rounded-lg" style={{ backgroundColor: 'var(--neutral-100)' }}>
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className="flex-1 px-8 py-3 rounded-md transition-all duration-200"
          style={{
            backgroundColor: activeTab === tab.id ? 'var(--bg-level-0)' : 'transparent',
            border: activeTab === tab.id ? '1px solid var(--neutral-200)' : '1px solid transparent',
            boxShadow: activeTab === tab.id ? 'var(--shadow-toggle-active)' : 'none',
            color: activeTab === tab.id ? 'var(--neutral-950)' : 'var(--neutral-600)',
            fontWeight: 500,
            fontSize: '14px',
            cursor: 'pointer',
            textAlign: 'left',
            outline: 'none'
          }}
          onFocus={(e) => {
            e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.boxShadow = activeTab === tab.id ? 'var(--shadow-toggle-active)' : 'none';
          }}
        >
          <div>{tab.label}</div>
          <div style={{ 
            fontSize: '12px', 
            color: activeTab === tab.id ? 'var(--neutral-600)' : 'var(--neutral-400)',
            marginTop: '2px'
          }}>
            {tab.description}
          </div>
        </button>
      ))}
    </div>
  );
}
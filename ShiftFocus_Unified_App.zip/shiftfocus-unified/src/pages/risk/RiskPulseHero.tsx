import { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';
import { DSCard, DSTooltip, DSSkeletonHero } from './design-system';

export function RiskPulseHero() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  if (loading) return <DSSkeletonHero />;

  const criticalCount = 7;
  const highCount = 12;
  const predictedImpact = '-6%';

  return (
    <div className="space-y-8">
      <DSCard padding="lg">
        {/* Top: Headline + Metrics */}
        <div className="flex items-start justify-between mb-12">
          <div className="flex-1 max-w-3xl">
            <div className="flex items-center gap-3 mb-4">
              <div
                className="size-2 rounded-full animate-pulse"
                style={{ backgroundColor: 'var(--danger)' }}
              />
              <p style={{
                color: 'var(--neutral-600)',
                fontSize: '12px',
                letterSpacing: '0.05em',
                textTransform: 'uppercase',
                fontWeight: 500
              }}>
                Risk Center OS
              </p>
            </div>
            <h1 className="mb-8" style={{
              fontSize: '32px',
              fontWeight: 600,
              letterSpacing: '-0.02em',
              color: 'var(--neutral-950)',
              lineHeight: '1.1'
            }}>
              {criticalCount} critical risks require intervention
            </h1>
            <p style={{
              fontSize: '16px',
              lineHeight: '1.6',
              color: 'var(--neutral-600)',
              maxWidth: '680px'
            }}>
              Engineering backlog delays 2 KRs. Sales overload (132%) increases burnout probability by 18%.
              Predicted KR loss: {predictedImpact} if unresolved this week.
            </p>
          </div>

          {/* Compact Metrics Grid */}
          <div className="grid grid-cols-2 gap-8">
            <div>
              <div style={{
                fontSize: '48px',
                fontWeight: 600,
                letterSpacing: '-0.03em',
                color: 'var(--danger)',
                lineHeight: '1'
              }}>
                {criticalCount}
              </div>
              <div style={{
                fontSize: '14px',
                color: 'var(--neutral-600)',
                marginTop: '8px',
                fontWeight: 500
              }}>
                Critical
              </div>
            </div>
            <div>
              <div style={{
                fontSize: '48px',
                fontWeight: 600,
                letterSpacing: '-0.03em',
                color: 'var(--warning)',
                lineHeight: '1'
              }}>
                {highCount}
              </div>
              <div style={{
                fontSize: '14px',
                color: 'var(--neutral-600)',
                marginTop: '8px',
                fontWeight: 500
              }}>
                High Priority
              </div>
            </div>
          </div>
        </div>

        {/* Minimal Divider */}
        <div style={{
          height: '1px',
          backgroundColor: 'var(--neutral-200)',
          margin: '48px 0'
        }} />

        {/* AI Insight Banner */}
        <DSTooltip
          content={
            <div>
              <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--tooltip-text)', marginBottom: '8px' }}>
                These are forecasted risks based on trend patterns (blockers, missed check-ins, workload, dependency congestion).
              </p>
              <p style={{ fontSize: '12px', lineHeight: '1.5', color: 'var(--tooltip-muted)', fontStyle: 'italic' }}>
                Forecast ≠ fact. Confidence is shown per item.
              </p>
            </div>
          }
          side="bottom"
          maxWidth="380px"
        >
          <div
            className="cursor-help transition-all duration-150 rounded-xl p-8"
            style={{
              backgroundColor: 'var(--neutral-50)',
              border: '1px solid var(--neutral-200)'
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-50)'; }}
          >
            <div className="flex items-start gap-4">
              <div
                className="size-10 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{
                  backgroundColor: 'var(--brand-primary-light)',
                  border: '1px solid rgba(106, 61, 232, 0.15)'
                }}
              >
                <Sparkles className="size-5" style={{ color: 'var(--brand-primary)' }} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 style={{
                    fontSize: '15px',
                    fontWeight: 500,
                    color: 'var(--neutral-950)'
                  }}>
                    AI Insight: Predicted Future Risks
                  </h3>
                  <div
                    className="px-2 py-0.5 rounded-md"
                    style={{
                      backgroundColor: 'rgba(106, 61, 232, 0.1)',
                      fontSize: '12px',
                      fontWeight: 500,
                      color: 'var(--brand-primary)',
                      letterSpacing: '0.02em'
                    }}
                  >
                    FORECAST
                  </div>
                </div>
                <p style={{
                  fontSize: '14px',
                  lineHeight: '1.6',
                  color: 'var(--neutral-600)'
                }}>
                  Based on current trajectory: 3 additional risks will escalate to Critical within 5 days.
                  Mobile App Launch has 87% probability of missing deadline without immediate dependency fix.
                </p>
              </div>
            </div>
          </div>
        </DSTooltip>
      </DSCard>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { DSButton, DSCard, DSProgressBar, DSSkeletonCard, DSEmptyState, sfToast } from './design-system';

interface Mitigation {
  id: number;
  title: string;
  risk: string;
  description: string;
  predictedImpact: string;
  recommendedFix: string;
  effort: 'Low' | 'Medium' | 'High';
  timeline: string;
  improvement: string;
  aiConfidence: number;
}

const mitigations: Mitigation[] = [
  { id: 1, title: 'Resolve Engineering dependency backlog', risk: 'RISK-001, RISK-008', description: 'Design system updates blocking 8 initiatives, reducing engineering velocity by 28%.', predictedImpact: '-$2.4M revenue, 3-week delay, 28% velocity drop', effort: 'Medium', timeline: '2 weeks', improvement: '+18% velocity recovery', aiConfidence: 87 },
  { id: 2, title: 'Rebalance Sales team workload', risk: 'RISK-002', description: 'Sales team at 132% capacity for 6 weeks. Burnout risk increases deal closure time by 40%.', predictedImpact: '40% slower deal closure, 18% quota miss risk', effort: 'Low', timeline: '1 week', improvement: 'Workload reduced to 98%', aiConfidence: 92 },
  { id: 3, title: 'Align Product-Engineering roadmaps', risk: 'RISK-003', description: 'Roadmaps diverging. Feature parity issues in 4 initiatives.', predictedImpact: 'Product-market fit score at risk', effort: 'Low', timeline: '3 days', improvement: 'Roadmap alignment restored', aiConfidence: 78 },
  { id: 4, title: 'Unblock Support team dependencies', risk: 'RISK-004', description: 'Support team blocked by Product updates. Ticket resolution +65%.', predictedImpact: '65% slower resolution, retention drop', effort: 'Low', timeline: '1 week', improvement: 'Resolution time back to baseline', aiConfidence: 85 },
  { id: 5, title: 'Optimize Infrastructure team capacity', risk: 'RISK-005', description: 'Infrastructure at 115%. Performance optimization delayed 2 sprints.', predictedImpact: '2-sprint delay in performance optimization', effort: 'Medium', timeline: '2 weeks', improvement: 'Capacity normalized to 102%', aiConfidence: 81 },
];

function getEffortColor(effort: string): string {
  if (effort === 'Low') return 'var(--success)';
  if (effort === 'Medium') return 'var(--warning)';
  return 'var(--danger)';
}

export function MitigationPanel() {
  const [selectedActions, setSelectedActions] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const toggleSelection = (id: number) => {
    setSelectedActions(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      if (!prev.includes(id)) sfToast.success('Mitigation plan applied');
      return next;
    });
  };

  return (
    <div>
      <div className="mb-8">
        <p style={{ color: 'var(--neutral-600)', fontSize: '12px', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500, marginBottom: '8px' }}>Structural Fixes (AI Recommended)</p>
        <p style={{ color: 'var(--neutral-400)', fontSize: '14px' }}>Longer-term changes to reduce future risk</p>
      </div>

      {loading ? (
        <div className="space-y-8">
          {Array.from({ length: 3 }).map((_, i) => <DSSkeletonCard key={i} />)}
        </div>
      ) : mitigations.length === 0 ? (
        <DSEmptyState title="No mitigations available" description="AI has not identified structural fixes at this time." />
      ) : (
        <div className="grid grid-cols-1 gap-8">
          {mitigations.map((item) => (
            <DSCard key={item.id} hoverable>
              <h4 style={{ color: 'var(--neutral-950)', marginBottom: '8px', fontWeight: 500 }}>{item.title}</h4>
              <p style={{ fontSize: '14px', color: 'var(--neutral-400)', marginBottom: '12px' }}>Affects: {item.risk}</p>
              <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--neutral-600)', marginBottom: '16px' }}>{item.description}</p>

              <div className="grid grid-cols-3 gap-8 mb-8">
                <div>
                  <p style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--neutral-400)', marginBottom: '8px', fontWeight: 500 }}>Problem</p>
                  <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>{item.predictedImpact}</p>
                </div>
                <div>
                  <p style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--neutral-400)', marginBottom: '8px', fontWeight: 500 }}>Expected Impact</p>
                  <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>{item.improvement}</p>
                </div>
                <div>
                  <p style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--neutral-400)', marginBottom: '8px', fontWeight: 500 }}>Effort</p>
                  <div className="flex items-center gap-2">
                    <span style={{ fontSize: '14px', fontWeight: 500, color: getEffortColor(item.effort) }}>{item.effort}</span>
                    <span style={{ fontSize: '12px', color: 'var(--neutral-400)' }}>· {item.timeline}</span>
                  </div>
                </div>
              </div>

              <div className="mb-8">
                <p style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--neutral-400)', marginBottom: '8px', fontWeight: 500 }}>Confidence</p>
                <DSProgressBar value={item.aiConfidence} variant="brand" showLabel />
              </div>

              <div className="flex items-center justify-between">
                <button className="transition-all duration-150" style={{ color: 'var(--brand-primary)', textDecoration: 'underline', border: 'none', backgroundColor: 'transparent', padding: 0, cursor: 'pointer', fontSize: '14px', fontWeight: 500 }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
                  View detailed plan
                </button>
                <DSButton
                  variant={selectedActions.includes(item.id) ? 'primary' : 'secondary'}
                  onClick={() => toggleSelection(item.id)}
                  style={selectedActions.includes(item.id) ? { backgroundColor: 'var(--success)' } : { backgroundColor: 'var(--neutral-800)', color: 'var(--bg-level-0)', border: 'none' }}
                >
                  {selectedActions.includes(item.id) ? <><CheckCircle2 className="size-4" /> Applied as Plan</> : 'Apply as Plan'}
                </DSButton>
              </div>
            </DSCard>
          ))}
        </div>
      )}
    </div>
  );
}

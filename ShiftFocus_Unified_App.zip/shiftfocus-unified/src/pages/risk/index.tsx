import { useState } from 'react';
import { RiskPulseHero } from './RiskPulseHero';
import { ExecutiveRiskSummary } from './ExecutiveRiskSummary';
import { RankedRiskQueue } from './RankedRiskQueue';
import { DependencyCluster } from './DependencyCluster';
import { WorkloadChart } from './WorkloadChart';
import { MitigationPanel } from './MitigationPanel';
import { PredictedFailurePanel } from './PredictedFailurePanel';
import { InterventionPanel } from './InterventionPanel';
import { CollaborationControls } from './CollaborationControls';
import { TabNavigation } from './TabNavigation';

export default function RiskPage() {
  const [activeTab, setActiveTab] = useState('overview');
  return (
    <div className="max-w-[1400px] mx-auto space-y-6">
      <h1 style={{ fontSize: '24px', fontWeight: 600, color: 'var(--neutral-800)' }}>Risk Center OS</h1>
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      <RiskPulseHero />
      <ExecutiveRiskSummary />
      <RankedRiskQueue />
      <div className="grid grid-cols-2 gap-6">
        <DependencyCluster />
        <WorkloadChart />
      </div>
      <MitigationPanel />
      <PredictedFailurePanel />
      <InterventionPanel />
      <CollaborationControls />
    </div>
  );
}

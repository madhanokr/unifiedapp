import { AlertTriangle, ExternalLink } from 'lucide-react';
import { DSButton, DSBadge, DSDialog, DSDialogContent, DSDialogHeader, DSDialogTitle, DSDialogBody, DSProgressBar } from './design-system';

interface DependencyDrillDownModalProps {
  isOpen: boolean;
  onClose: () => void;
  initiative: string;
  team: string;
}

export function DependencyDrillDownModal({ isOpen, onClose, initiative, team }: DependencyDrillDownModalProps) {
  if (!isOpen) return null;

  const risks = [
    { id: 'RISK-001', title: 'Engineering backlog blocking mobile release', severity: 'Critical' as const, impactChain: ['Mobile App v2', 'API Platform', 'KR-3.1'], delayPropagation: 87, suggestedFix: 'Reallocate 2 senior engineers from Q2 initiatives' },
    { id: 'RISK-008', title: 'API dependency causing integration delays', severity: 'High' as const, impactChain: ['API Platform', 'Mobile App v2', 'Design System'], delayPropagation: 64, suggestedFix: 'Fast-track API freeze to Week 8, run parallel testing' },
  ];

  const getSeverityVariant = (severity: string): 'danger' | 'warning' => severity === 'Critical' ? 'danger' : 'warning';

  return (
    <DSDialog open={isOpen} onOpenChange={onClose}>
      <DSDialogContent size="lg">
        <DSDialogHeader>
          <DSDialogTitle>Dependency Drill-Down</DSDialogTitle>
          <p style={{ color: 'var(--neutral-600)', fontSize: '14px', marginTop: '4px' }}>{initiative} ← {team}</p>
        </DSDialogHeader>

        <DSDialogBody>
          <div className="space-y-8">
            {risks.map((risk) => (
              <div key={risk.id} className="rounded-xl p-5" style={{ border: '1px solid var(--neutral-200)' }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="size-5" style={{ color: 'var(--danger)' }} />
                    <div>
                      <div style={{ color: 'var(--neutral-950)', fontWeight: 500 }}>{risk.title}</div>
                      <div style={{ color: 'var(--neutral-600)', fontSize: '14px' }}>{risk.id}</div>
                    </div>
                  </div>
                  <DSBadge variant={getSeverityVariant(risk.severity)}>{risk.severity}</DSBadge>
                </div>

                <div className="space-y-3">
                  <div>
                    <div style={{ color: 'var(--neutral-800)', fontSize: '14px', marginBottom: '8px' }}>Impact Chain</div>
                    <div className="flex items-center gap-2 flex-wrap">
                      {risk.impactChain.map((item, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <DSBadge variant="neutral" size="sm">{item}</DSBadge>
                          {i < risk.impactChain.length - 1 && <span style={{ color: 'var(--neutral-400)' }}>→</span>}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div style={{ color: 'var(--neutral-800)', fontSize: '14px', marginBottom: '4px' }}>Delay Propagation Probability</div>
                    <DSProgressBar value={risk.delayPropagation} variant="danger" showLabel />
                  </div>

                  <div className="rounded-lg p-3" style={{ backgroundColor: 'var(--brand-primary-light)', border: '1px solid rgba(106, 61, 232, 0.2)' }}>
                    <div style={{ color: 'var(--brand-primary-active)', fontSize: '14px', fontWeight: 500, marginBottom: '4px' }}>Suggested Fix</div>
                    <div style={{ color: 'var(--brand-primary)', fontSize: '14px' }}>{risk.suggestedFix}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-8" style={{ borderTop: '1px solid var(--neutral-200)' }}>
            <DSButton variant="primary" style={{ width: '100%' }}>
              <ExternalLink className="size-4" />
              Show on Timeline
            </DSButton>
          </div>
        </DSDialogBody>
      </DSDialogContent>
    </DSDialog>
  );
}

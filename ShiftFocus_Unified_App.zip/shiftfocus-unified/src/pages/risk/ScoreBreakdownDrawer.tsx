import { DSDrawer, DSDrawerHeader, DSDrawerBody } from './design-system';

interface ScoreBreakdownDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  risk: Record<string, unknown> | null;
  onViewEvidence: () => void;
}

export function ScoreBreakdownDrawer({ isOpen, onClose, risk }: ScoreBreakdownDrawerProps) {
  if (!risk) return null;

  const score = 92;
  const severity = 'Critical';

  const signals = [{ label: 'Missed check-ins (3x)', impact: '+28' }, { label: 'Blocked dependency', impact: '+17' }];
  const impactFactors = [{ label: 'Initiative criticality', impact: '+22' }, { label: 'Cross-team dependency', impact: '+10' }];
  const timePressure = [{ label: 'SLA breach imminent (6h)', impact: '+15' }];
  const reductionFactors = [{ label: 'Owner update submitted', impact: '-18' }, { label: 'Dependency resolved', impact: '-22' }, { label: 'Workload normalized', impact: '-14' }];

  return (
    <DSDrawer open={isOpen} onOpenChange={onClose} side="right" size="md">
      <DSDrawerHeader onClose={onClose}>
        <p style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--neutral-400)', fontWeight: 500, marginBottom: '8px' }}>Risk Score Breakdown</p>
        <h2 style={{ fontSize: '32px', fontWeight: 600, color: 'var(--danger)', letterSpacing: '-0.02em', marginBottom: '4px' }}>{score}</h2>
        <p style={{ fontSize: '14px', color: 'var(--neutral-600)', fontWeight: 500 }}>{severity}</p>
      </DSDrawerHeader>

      <DSDrawerBody>
        <div className="space-y-8">
          <div>
            <h3 style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '16px' }}>How this score is calculated</h3>

            {[{ title: 'Signals', pct: '45%', items: signals, color: 'var(--danger)' }, { title: 'Impact', pct: '35%', items: impactFactors, color: 'var(--warning)' }, { title: 'Time Pressure', pct: '20%', items: timePressure, color: 'var(--danger)' }].map((section) => (
              <div key={section.title} className="mb-8">
                <div className="flex items-baseline gap-2 mb-3">
                  <p style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>{section.title}</p>
                  <p style={{ fontSize: '12px', color: 'var(--neutral-400)' }}>{section.pct}</p>
                </div>
                <div className="space-y-2">
                  {section.items.map((item, i) => (
                    <div key={i} className="flex items-center justify-between py-2">
                      <p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>{item.label}</p>
                      <span style={{ fontSize: '14px', fontWeight: 500, color: section.color, fontFamily: 'monospace' }}>{item.impact}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div style={{ height: '1px', backgroundColor: 'var(--neutral-200)', margin: '24px 0' }} />

          <div>
            <h3 style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '16px' }}>What reduces this score</h3>
            <div className="space-y-2">
              {reductionFactors.map((factor, i) => (
                <div key={i} className="flex items-center justify-between py-2">
                  <p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>{factor.label}</p>
                  <span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--success)', fontFamily: 'monospace' }}>{factor.impact}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-lg p-4" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
            <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--neutral-600)' }}>Risk scores update automatically as signals change or enforcement is applied.</p>
          </div>
        </div>
      </DSDrawerBody>
    </DSDrawer>
  );
}
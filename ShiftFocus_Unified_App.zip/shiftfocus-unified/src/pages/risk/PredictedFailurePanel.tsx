import { useState, useEffect } from 'react';
import { AlertTriangle, TrendingUp, Users, Zap, Link2 } from 'lucide-react';
import { DSButton, DSCard, DSSkeleton } from './design-system';

const failureModes = [
  { icon: TrendingUp, title: 'KR-3.1 delay risk', value: '+18%', color: 'var(--danger)', bg: 'var(--danger-light)' },
  { icon: Users, title: 'Sales burnout probability', value: '+27%', color: 'var(--warning-dark)', bg: 'var(--at-risk-light)' },
  { icon: Zap, title: 'Engineering velocity collapse risk', value: '+11%', color: 'var(--warning)', bg: 'var(--warning-light)' },
  { icon: Link2, title: 'Cross-team dependency failure', value: '+3 new blockers', color: 'var(--brand-primary)', bg: 'var(--brand-primary-light)' },
];

export function PredictedFailurePanel() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="rounded-xl p-8 space-y-4" style={{ backgroundColor: 'var(--danger-light)', border: '2px solid var(--danger)' }}>
        <DSSkeleton variant="text" width="40%" height="24px" />
        <DSSkeleton variant="text" width="80%" height="16px" />
        <div className="grid grid-cols-4 gap-4 mt-8">
          {Array.from({ length: 4 }).map((_, i) => <DSSkeleton key={i} variant="rect" height="100px" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl p-8" style={{ backgroundColor: 'var(--danger-light)', border: '2px solid var(--danger)', boxShadow: 'var(--shadow-elevated)' }}>
      <div className="flex items-start gap-4 mb-8">
        <div className="p-3 rounded-xl" style={{ backgroundColor: 'rgba(229, 57, 53, 0.15)' }}>
          <AlertTriangle className="size-8" style={{ color: 'var(--danger)' }} />
        </div>
        <div className="flex-1">
          <h2 style={{ color: 'var(--neutral-950)', marginBottom: '8px' }}>AI Predicted Failure Modes</h2>
          <p style={{ color: 'var(--neutral-600)', lineHeight: '1.6' }}>If no action is taken this week, the following risks will materialize:</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {failureModes.map((mode, index) => {
          const Icon = mode.icon;
          return (
            <DSCard key={index} hoverable style={{ backgroundColor: mode.bg }}>
              <div className="flex items-start gap-3 mb-3">
                <Icon className="size-5 flex-shrink-0 mt-0.5" style={{ color: mode.color }} />
                <div className="flex-1">
                  <div style={{ color: 'var(--neutral-800)', fontSize: '14px', lineHeight: '1.4', marginBottom: '8px' }}>{mode.title}</div>
                  <div style={{ fontSize: '24px', fontWeight: 500, color: mode.color }}>{mode.value}</div>
                </div>
              </div>
            </DSCard>
          );
        })}
      </div>

      <div className="flex items-center justify-between pt-8" style={{ borderTop: '2px solid rgba(229, 57, 53, 0.2)' }}>
        <p style={{ color: 'var(--neutral-600)' }}>AI has identified <span style={{ color: 'var(--danger)', fontWeight: 500 }}>4 critical failure paths</span> that require immediate intervention</p>
        <DSButton variant="destructive">
          <Zap className="size-4" />
          Run Simulation
        </DSButton>
      </div>
    </div>
  );
}

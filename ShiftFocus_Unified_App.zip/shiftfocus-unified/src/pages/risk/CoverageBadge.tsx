import { Shield, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { DSTooltip } from './design-system';

interface CoverageBadgeProps {
  coverage: 'covered' | 'partial' | 'none';
  rules?: string[];
  onViewRule?: () => void;
  onStrengthenCoverage?: () => void;
  onAddEnforcement?: () => void;
}

export function CoverageBadge({
  coverage,
  rules = [],
  onViewRule,
  onStrengthenCoverage,
  onAddEnforcement
}: CoverageBadgeProps) {

  const config = {
    covered: {
      icon: CheckCircle2,
      bg: 'rgba(60, 203, 127, 0.1)',
      border: 'rgba(60, 203, 127, 0.3)',
      text: 'var(--success-dark)',
      label: 'Covered',
      tooltip: {
        title: 'Covered',
        message: `This risk is actively monitored by an enforcement rule${rules.length > 1 ? 's' : ''}.`,
        submessage: 'Escalation and notifications will trigger automatically.',
        cta: 'View rule',
        onClick: onViewRule
      }
    },
    partial: {
      icon: AlertTriangle,
      bg: 'var(--at-risk-light)',
      border: 'var(--warning-dark)',
      text: 'var(--warning-dark)',
      label: 'Partial',
      tooltip: {
        title: 'Partial Coverage',
        message: 'Some signals are monitored, but escalation is not enforced.',
        submessage: '',
        cta: 'Strengthen coverage',
        onClick: onStrengthenCoverage
      }
    },
    none: {
      icon: Shield,
      bg: 'var(--danger-light)',
      border: 'var(--danger)',
      text: 'var(--danger)',
      label: 'No Enforcement',
      tooltip: {
        title: 'No Enforcement Coverage',
        message: 'No rules are actively preventing this risk from repeating.',
        submessage: '',
        cta: 'Add enforcement',
        onClick: onAddEnforcement
      }
    }
  };

  const style = config[coverage];
  const Icon = style.icon;

  return (
    <DSTooltip
      content={
        <div className="space-y-3">
          <div>
            <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--tooltip-text)', marginBottom: '8px' }}>
              {style.tooltip.title}
            </div>
            {coverage === 'covered' && rules.length > 0 && (
              <div style={{ fontSize: '12px', color: 'var(--neutral-200)', marginBottom: '8px' }}>
                Covered by: <span style={{ fontWeight: 500, color: 'var(--tooltip-text)' }}>{rules[0]}</span>
                {rules.length > 1 && <span style={{ color: 'var(--tooltip-muted)' }}> +{rules.length - 1} more</span>}
              </div>
            )}
            <p style={{ fontSize: '12px', lineHeight: '1.5', color: 'var(--neutral-200)' }}>
              {style.tooltip.message}
            </p>
            {style.tooltip.submessage && (
              <p style={{ fontSize: '12px', lineHeight: '1.5', color: 'var(--neutral-200)', marginTop: '4px' }}>
                {style.tooltip.submessage}
              </p>
            )}
          </div>

          {style.tooltip.onClick && (
            <div className="pt-2" style={{ borderTop: '1px solid var(--tooltip-divider)' }}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  style.tooltip.onClick?.();
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  padding: 0,
                  fontSize: '12px',
                  color: 'var(--brand-primary)',
                  cursor: 'pointer',
                  textDecoration: 'underline'
                }}
                onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
              >
                {style.tooltip.cta} →
              </button>
            </div>
          )}
        </div>
      }
      side="top"
      maxWidth="320px"
    >
      <div
        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md cursor-help"
        style={{
          backgroundColor: style.bg,
          border: `1px solid ${style.border}`,
          fontSize: '12px',
          fontWeight: 500,
          color: style.text
        }}
      >
        <Icon className="size-3" />
        <span>{style.label}</span>
      </div>
    </DSTooltip>
  );
}

import * as TabsPrimitive from '@radix-ui/react-tabs';
import { type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const tabsListVariants = cva('flex', {
  variants: {
    variant: {
      underline: 'gap-0',
      pills: 'gap-1 p-1 rounded-lg',
    },
  },
  defaultVariants: {
    variant: 'underline',
  },
});

export interface DSTabsProps {
  value: string;
  onValueChange: (value: string) => void;
  children: ReactNode;
  className?: string;
}

export function DSTabs({ value, onValueChange, children, className }: DSTabsProps) {
  return (
    <TabsPrimitive.Root value={value} onValueChange={onValueChange} className={className}>
      {children}
    </TabsPrimitive.Root>
  );
}

export interface DSTabsListProps extends VariantProps<typeof tabsListVariants> {
  children: ReactNode;
  className?: string;
}

export function DSTabsList({ children, variant = 'underline', className }: DSTabsListProps) {
  return (
    <TabsPrimitive.List
      className={cn(tabsListVariants({ variant }), className)}
      style={
        variant === 'underline'
          ? { borderBottom: '1px solid var(--neutral-200)' }
          : { backgroundColor: 'var(--neutral-100)' }
      }
    >
      {children}
    </TabsPrimitive.List>
  );
}

export interface DSTabsTriggerProps {
  value: string;
  children: ReactNode;
  variant?: 'underline' | 'pills';
  className?: string;
}

export function DSTabsTrigger({ value, children, variant = 'underline', className }: DSTabsTriggerProps) {
  return (
    <TabsPrimitive.Trigger
      value={value}
      className={cn(
        'transition-all duration-150 cursor-pointer outline-none',
        variant === 'underline' ? 'px-4 py-3 -mb-px' : 'flex-1 px-4 py-2 rounded-md',
        className
      )}
      style={{ fontSize: '14px', fontWeight: 500, border: 'none', backgroundColor: 'transparent' }}
      onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
      onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
    >
      {children}
    </TabsPrimitive.Trigger>
  );
}

export interface DSTabsContentProps {
  value: string;
  children: ReactNode;
  className?: string;
}

export function DSTabsContent({ value, children, className }: DSTabsContentProps) {
  return (
    <TabsPrimitive.Content value={value} className={cn('outline-none', className)}>
      {children}
    </TabsPrimitive.Content>
  );
}

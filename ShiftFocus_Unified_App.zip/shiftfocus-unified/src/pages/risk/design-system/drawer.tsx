import * as DialogPrimitive from '@radix-ui/react-dialog';
import { type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { X } from 'lucide-react';

const drawerVariants = cva(
  'fixed top-0 h-full z-50 transition-transform duration-300 ease-out outline-none',
  {
    variants: {
      side: {
        left: 'left-0',
        right: 'right-0',
      },
      size: {
        sm: 'w-80',
        md: 'w-[480px]',
        lg: 'w-[640px]',
      },
    },
    defaultVariants: {
      side: 'right',
      size: 'md',
    },
  }
);

export interface DSDrawerProps extends VariantProps<typeof drawerVariants> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
  className?: string;
}

export function DSDrawer({ open, onOpenChange, side = 'right', size, children, className }: DSDrawerProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      <DialogPrimitive.Portal>
        <DialogPrimitive.Overlay
          className="fixed inset-0 z-50 transition-opacity duration-300"
          style={{
            backgroundColor: 'var(--overlay-40)',
            backdropFilter: 'blur(2px)',
            opacity: open ? 1 : 0,
          }}
        />
        <DialogPrimitive.Content
          className={cn(drawerVariants({ side, size }), className)}
          style={{
            backgroundColor: 'var(--bg-level-0)',
            boxShadow: 'var(--shadow-drawer)',
            borderLeft: side === 'right' ? '1px solid var(--neutral-200)' : 'none',
            borderRight: side === 'left' ? '1px solid var(--neutral-200)' : 'none',
          }}
        >
          {children}
        </DialogPrimitive.Content>
      </DialogPrimitive.Portal>
    </DialogPrimitive.Root>
  );
}

export interface DSDrawerHeaderProps {
  children: ReactNode;
  onClose?: () => void;
  className?: string;
}

export function DSDrawerHeader({ children, onClose, className }: DSDrawerHeaderProps) {
  return (
    <div
      className={cn('px-8 py-8 flex items-start justify-between', className)}
      style={{ borderBottom: '1px solid var(--neutral-200)' }}
    >
      <div className="flex-1">{children}</div>
      {onClose && (
        <button
          onClick={onClose}
          className="p-2 rounded-lg transition-all duration-150"
          style={{ backgroundColor: 'transparent', border: 'none', cursor: 'pointer' }}
          onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
          onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
          onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
        >
          <X className="size-5" style={{ color: 'var(--neutral-600)' }} />
        </button>
      )}
    </div>
  );
}

export function DSDrawerBody({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('px-8 py-8 overflow-y-auto', className)} style={{ height: 'calc(100% - 140px)' }}>
      {children}
    </div>
  );
}

export function DSDrawerFooter({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn('px-8 py-4 flex items-center gap-3', className)}
      style={{ borderTop: '1px solid var(--neutral-200)' }}
    >
      {children}
    </div>
  );
}
import * as SelectPrimitive from '@radix-ui/react-select';
import { forwardRef, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { ChevronDown, Check } from 'lucide-react';

const selectTriggerVariants = cva(
  'inline-flex items-center justify-between rounded-[var(--input-radius)] transition-all duration-150 outline-none cursor-pointer',
  {
    variants: {
      selectSize: {
        sm: 'h-8 px-3',
        md: 'h-10 px-4',
      },
    },
    defaultVariants: {
      selectSize: 'md',
    },
  }
);

export interface DSSelectProps extends VariantProps<typeof selectTriggerVariants> {
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
  error?: string;
  disabled?: boolean;
  children: ReactNode;
  className?: string;
  triggerClassName?: string;
}

export function DSSelect({
  value,
  onValueChange,
  placeholder,
  error,
  disabled,
  children,
  selectSize,
  className,
  triggerClassName,
}: DSSelectProps) {
  return (
    <div className={cn('w-full', className)}>
      <SelectPrimitive.Root value={value} onValueChange={onValueChange} disabled={disabled}>
        <SelectPrimitive.Trigger
          className={cn(selectTriggerVariants({ selectSize }), 'w-full', triggerClassName)}
          style={{
            backgroundColor: 'var(--bg-level-0)',
            border: error ? '1px solid var(--danger)' : '1px solid var(--neutral-200)',
            color: 'var(--neutral-800)',
            fontSize: '14px',
            opacity: disabled ? 0.5 : 1,
          }}
        >
          <SelectPrimitive.Value placeholder={placeholder} />
          <SelectPrimitive.Icon>
            <ChevronDown className="size-4" style={{ color: 'var(--neutral-400)' }} />
          </SelectPrimitive.Icon>
        </SelectPrimitive.Trigger>
        <SelectPrimitive.Portal>
          <SelectPrimitive.Content
            className="rounded-xl overflow-hidden z-50"
            position="popper"
            sideOffset={4}
            style={{
              backgroundColor: 'var(--bg-level-0)',
              border: '1px solid var(--neutral-200)',
              boxShadow: 'var(--shadow-dropdown)',
              minWidth: 'var(--radix-select-trigger-width)',
            }}
          >
            <SelectPrimitive.Viewport className="p-1">
              {children}
            </SelectPrimitive.Viewport>
          </SelectPrimitive.Content>
        </SelectPrimitive.Portal>
      </SelectPrimitive.Root>
      {error && (
        <p style={{ fontSize: '12px', color: 'var(--danger)', marginTop: '4px' }}>
          {error}
        </p>
      )}
    </div>
  );
}

export interface DSSelectItemProps {
  value: string;
  children: ReactNode;
  className?: string;
}

export const DSSelectItem = forwardRef<HTMLDivElement, DSSelectItemProps>(
  ({ value, children, className }, ref) => {
    return (
      <SelectPrimitive.Item
        ref={ref}
        value={value}
        className={cn(
          'flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer outline-none transition-colors duration-100',
          className
        )}
        style={{ fontSize: '14px', color: 'var(--neutral-800)' }}
        onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-50)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
      >
        <SelectPrimitive.ItemIndicator>
          <Check className="size-4" style={{ color: 'var(--brand-primary)' }} />
        </SelectPrimitive.ItemIndicator>
        <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
      </SelectPrimitive.Item>
    );
  }
);

DSSelectItem.displayName = 'DSSelectItem';

import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const skeletonVariants = cva(
  'animate-pulse',
  {
    variants: {
      variant: {
        text: 'rounded-md',
        circle: 'rounded-full',
        rect: 'rounded-xl',
      },
    },
    defaultVariants: {
      variant: 'text',
    },
  }
);

export interface DSSkeletonProps extends VariantProps<typeof skeletonVariants> {
  className?: string;
  width?: string | number;
  height?: string | number;
  style?: React.CSSProperties;
}

export function DSSkeleton({ variant, className, width, height, style }: DSSkeletonProps) {
  const defaultHeight = variant === 'text' ? '14px' : variant === 'circle' ? '40px' : '100px';
  const defaultWidth = variant === 'circle' ? '40px' : '100%';

  return (
    <div
      className={cn(skeletonVariants({ variant }), className)}
      style={{
        backgroundColor: 'var(--neutral-100)',
        width: width ?? defaultWidth,
        height: height ?? defaultHeight,
        ...style,
      }}
    />
  );
}

// Preset skeleton layouts
export function DSSkeletonCard({ className }: { className?: string }) {
  return (
    <div
      className={cn('rounded-xl p-8 space-y-4', className)}
      style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)' }}
    >
      <DSSkeleton variant="text" width="40%" height="20px" />
      <DSSkeleton variant="text" width="80%" />
      <DSSkeleton variant="text" width="60%" />
      <DSSkeleton variant="rect" height="32px" width="120px" />
    </div>
  );
}

export function DSSkeletonRow({ className }: { className?: string }) {
  return (
    <div className={cn('flex items-center gap-4 py-4', className)}>
      <DSSkeleton variant="circle" width="32px" height="32px" />
      <div className="flex-1 space-y-2">
        <DSSkeleton variant="text" width="60%" height="14px" />
        <DSSkeleton variant="text" width="30%" height="12px" />
      </div>
      <DSSkeleton variant="rect" width="80px" height="24px" />
    </div>
  );
}

export function DSSkeletonTable({ rows = 5, className }: { rows?: number; className?: string }) {
  return (
    <div
      className={cn('rounded-xl overflow-hidden', className)}
      style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)' }}
    >
      {/* Header */}
      <div className="px-8 py-4" style={{ backgroundColor: 'var(--neutral-50)', borderBottom: '1px solid var(--neutral-200)' }}>
        <div className="flex gap-8">
          <DSSkeleton variant="text" width="100px" height="12px" />
          <DSSkeleton variant="text" width="120px" height="12px" />
          <DSSkeleton variant="text" width="80px" height="12px" />
          <DSSkeleton variant="text" width="60px" height="12px" />
        </div>
      </div>
      {/* Rows */}
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="px-8 py-4" style={{ borderBottom: i < rows - 1 ? '1px solid var(--neutral-200)' : 'none' }}>
          <DSSkeletonRow />
        </div>
      ))}
    </div>
  );
}

export function DSSkeletonHero({ className }: { className?: string }) {
  return (
    <div
      className={cn('rounded-2xl p-12 space-y-8', className)}
      style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', boxShadow: 'var(--shadow-card)' }}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 space-y-4">
          <DSSkeleton variant="text" width="120px" height="12px" />
          <DSSkeleton variant="text" width="70%" height="32px" />
          <DSSkeleton variant="text" width="90%" height="16px" />
          <DSSkeleton variant="text" width="60%" height="16px" />
        </div>
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-2">
            <DSSkeleton variant="text" width="60px" height="48px" />
            <DSSkeleton variant="text" width="60px" height="14px" />
          </div>
          <div className="space-y-2">
            <DSSkeleton variant="text" width="60px" height="48px" />
            <DSSkeleton variant="text" width="80px" height="14px" />
          </div>
        </div>
      </div>
    </div>
  );
}

export function DSSkeletonStats({ count = 5, className }: { count?: number; className?: string }) {
  return (
    <div className={cn('grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8', className)}>
      {Array.from({ length: count }).map((_, i) => (
        <DSSkeletonCard key={i} />
      ))}
    </div>
  );
}

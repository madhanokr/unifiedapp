import { forwardRef, type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const cardVariants = cva(
  'rounded-xl transition-all duration-150',
  {
    variants: {
      variant: {
        default: '',
        bordered: '',
        elevated: '',
      },
      padding: {
        none: '',
        sm: 'p-4',
        md: 'p-8',
        lg: 'p-12',
      },
    },
    defaultVariants: {
      variant: 'default',
      padding: 'md',
    },
  }
);

const variantStyleMap: Record<string, React.CSSProperties> = {
  default: {
    backgroundColor: 'var(--bg-level-0)',
    border: '1px solid var(--neutral-200)',
    boxShadow: 'var(--shadow-card)',
  },
  bordered: {
    backgroundColor: 'var(--bg-level-0)',
    border: '1px solid var(--neutral-200)',
    boxShadow: 'none',
  },
  elevated: {
    backgroundColor: 'var(--bg-level-0)',
    border: '1px solid var(--neutral-200)',
    boxShadow: 'var(--shadow-elevated)',
  },
};

export interface DSCardProps
  extends Omit<HTMLAttributes<HTMLDivElement>, 'style'>,
    VariantProps<typeof cardVariants> {
  children: ReactNode;
  hoverable?: boolean;
  style?: React.CSSProperties;
}

export const DSCard = forwardRef<HTMLDivElement, DSCardProps>(
  ({ className, variant = 'default', padding, children, hoverable, style, ...props }, ref) => {
    const v = variant ?? 'default';

    return (
      <div
        ref={ref}
        className={cn(cardVariants({ variant: v, padding }), className)}
        style={{ ...variantStyleMap[v], ...style }}
        onMouseEnter={hoverable ? (e) => {
          e.currentTarget.style.boxShadow = 'var(--shadow-card-hover)';
          e.currentTarget.style.transform = 'translateY(-2px)';
        } : undefined}
        onMouseLeave={hoverable ? (e) => {
          e.currentTarget.style.boxShadow = variantStyleMap[v].boxShadow ?? 'none';
          e.currentTarget.style.transform = 'translateY(0)';
        } : undefined}
        {...props}
      >
        {children}
      </div>
    );
  }
);

DSCard.displayName = 'DSCard';

export { cardVariants };
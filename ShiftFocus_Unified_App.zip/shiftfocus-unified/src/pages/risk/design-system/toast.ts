import { toast as sonnerToast } from 'sonner';

/**
 * ShiftFocus standardized toast patterns.
 * Wraps Sonner with consistent messaging, durations, and undo support.
 */
export const sfToast = {
  success(title: string, description?: string) {
    sonnerToast.success(title, {
      description,
      duration: 5000,
    });
  },

  error(title: string, description?: string) {
    sonnerToast.error(title, {
      description,
      duration: 8000,
    });
  },

  warning(title: string, description?: string) {
    sonnerToast.warning(title, {
      description,
      duration: 6000,
    });
  },

  info(title: string, description?: string) {
    sonnerToast.info(title, {
      description,
      duration: 5000,
    });
  },

  /** Success toast with a 5-minute undo window */
  successWithUndo(title: string, description: string, onUndo: () => void) {
    sonnerToast.success(title, {
      description,
      duration: 300000,
      action: {
        label: 'Undo',
        onClick: onUndo,
      },
    });
  },

  /** Intervention applied — 5-min undo window */
  interventionApplied(riskId: string, onUndo: () => void) {
    sonnerToast.success('Intervention Applied', {
      description: `${riskId}: Owner notified. Task created with 24h SLA.`,
      duration: 300000,
      action: {
        label: 'Undo (5 min)',
        onClick: onUndo,
      },
    });
  },

  /** Risk resolved — permanent */
  riskResolved(riskId: string) {
    sonnerToast.success('Risk Resolved', {
      description: `${riskId}: Resolved with proof. Logged to audit trail.`,
      duration: 5000,
    });
  },

  /** Data operation */
  saved(entity: string) {
    sonnerToast.success(`${entity} saved`, { duration: 3000 });
  },

  deleted(entity: string, onUndo?: () => void) {
    if (onUndo) {
      sonnerToast.success(`${entity} deleted`, {
        duration: 300000,
        action: { label: 'Undo', onClick: onUndo },
      });
    } else {
      sonnerToast.success(`${entity} deleted`, { duration: 5000 });
    }
  },
};

import * as DropdownMenuPrimitive from '@radix-ui/react-dropdown-menu';
import { forwardRef, type ReactNode } from 'react';
import { cn } from '../lib/utils';

export interface DSDropdownMenuProps {
  children: ReactNode;
}

export function DSDropdownMenu({ children }: DSDropdownMenuProps) {
  return <DropdownMenuPrimitive.Root>{children}</DropdownMenuPrimitive.Root>;
}

export const DSDropdownMenuTrigger = DropdownMenuPrimitive.Trigger;

export interface DSDropdownMenuContentProps {
  children: ReactNode;
  align?: 'start' | 'center' | 'end';
  className?: string;
  sideOffset?: number;
}

export function DSDropdownMenuContent({ children, align = 'end', className, sideOffset = 4 }: DSDropdownMenuContentProps) {
  return (
    <DropdownMenuPrimitive.Portal>
      <DropdownMenuPrimitive.Content
        align={align}
        sideOffset={sideOffset}
        className={cn('z-50 rounded-xl p-1 animate-in fade-in zoom-in-95 duration-150', className)}
        style={{
          backgroundColor: 'var(--bg-level-0)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-dropdown)',
          minWidth: '180px',
        }}
      >
        {children}
      </DropdownMenuPrimitive.Content>
    </DropdownMenuPrimitive.Portal>
  );
}

export interface DSDropdownMenuItemProps {
  children: ReactNode;
  className?: string;
  onSelect?: () => void;
  destructive?: boolean;
}

export const DSDropdownMenuItem = forwardRef<HTMLDivElement, DSDropdownMenuItemProps>(
  ({ children, className, onSelect, destructive }, ref) => {
    return (
      <DropdownMenuPrimitive.Item
        ref={ref}
        className={cn('flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer outline-none transition-colors duration-100', className)}
        style={{
          fontSize: '14px',
          color: destructive ? 'var(--danger)' : 'var(--neutral-800)',
        }}
        onSelect={onSelect}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = destructive ? 'var(--danger-light)' : 'var(--neutral-50)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'transparent';
        }}
        onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
        onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
      >
        {children}
      </DropdownMenuPrimitive.Item>
    );
  }
);

DSDropdownMenuItem.displayName = 'DSDropdownMenuItem';

export function DSDropdownMenuSeparator({ className }: { className?: string }) {
  return (
    <DropdownMenuPrimitive.Separator
      className={cn('my-1', className)}
      style={{ height: '1px', backgroundColor: 'var(--neutral-200)' }}
    />
  );
}

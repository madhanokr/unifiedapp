import { forwardRef, type InputHTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const inputVariants = cva(
  'w-full rounded-[var(--input-radius)] transition-all duration-150 outline-none',
  {
    variants: {
      inputSize: {
        sm: 'h-8 px-3',
        md: 'h-10 px-4',
      },
    },
    defaultVariants: {
      inputSize: 'md',
    },
  }
);

export interface DSInputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size' | 'style'>,
    VariantProps<typeof inputVariants> {
  error?: string;
  style?: React.CSSProperties;
}

export const DSInput = forwardRef<HTMLInputElement, DSInputProps>(
  ({ className, inputSize, error, disabled, style, ...props }, ref) => {
    return (
      <div className="w-full">
        <input
          ref={ref}
          className={cn(inputVariants({ inputSize }), className)}
          disabled={disabled}
          style={{
            backgroundColor: 'var(--bg-level-0)',
            border: error ? '1px solid var(--danger)' : '1px solid var(--neutral-200)',
            color: 'var(--neutral-800)',
            fontSize: '14px',
            opacity: disabled ? 0.5 : 1,
            cursor: disabled ? 'not-allowed' : 'text',
            ...style,
          }}
          onFocus={(e) => {
            if (!error) e.currentTarget.style.borderColor = 'var(--brand-primary)';
            e.currentTarget.style.boxShadow = error ? '0 0 0 3px var(--danger-alpha-15)' : 'var(--shadow-focus)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = error ? 'var(--danger)' : 'var(--neutral-200)';
            e.currentTarget.style.boxShadow = 'none';
          }}
          {...props}
        />
        {error && (
          <p style={{ fontSize: '12px', color: 'var(--danger)', marginTop: '4px' }}>
            {error}
          </p>
        )}
      </div>
    );
  }
);

DSInput.displayName = 'DSInput';
export { inputVariants };
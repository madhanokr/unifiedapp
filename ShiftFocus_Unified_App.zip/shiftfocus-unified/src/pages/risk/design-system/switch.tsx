import * as SwitchPrimitive from '@radix-ui/react-switch';
import { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const switchVariants = cva(
  'relative inline-flex shrink-0 cursor-pointer rounded-full transition-all duration-200 outline-none',
  {
    variants: {
      switchSize: {
        sm: 'h-5 w-9',
        md: 'h-6 w-11',
      },
    },
    defaultVariants: {
      switchSize: 'md',
    },
  }
);

const thumbVariants = cva(
  'block rounded-full transition-transform duration-200',
  {
    variants: {
      switchSize: {
        sm: 'size-4',
        md: 'size-5',
      },
    },
    defaultVariants: {
      switchSize: 'md',
    },
  }
);

export interface DSSwitchProps extends VariantProps<typeof switchVariants> {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
  className?: string;
  id?: string;
}

export const DSSwitch = forwardRef<HTMLButtonElement, DSSwitchProps>(
  ({ checked, onCheckedChange, disabled, switchSize = 'md', className, id }, ref) => {
    const translateX = switchSize === 'sm' ? '16px' : '20px';

    return (
      <SwitchPrimitive.Root
        ref={ref}
        id={id}
        checked={checked}
        onCheckedChange={onCheckedChange}
        disabled={disabled}
        className={cn(switchVariants({ switchSize }), className)}
        style={{
          backgroundColor: checked ? 'var(--brand-primary)' : 'var(--neutral-200)',
          opacity: disabled ? 0.5 : 1,
          cursor: disabled ? 'not-allowed' : 'pointer',
          padding: '2px',
        }}
        onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
        onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
      >
        <SwitchPrimitive.Thumb
          className={cn(thumbVariants({ switchSize }))}
          style={{
            backgroundColor: 'var(--bg-level-0)',
            boxShadow: 'var(--shadow-toggle-active)',
            transform: checked ? `translateX(${translateX})` : 'translateX(0)',
          }}
        />
      </SwitchPrimitive.Root>
    );
  }
);

DSSwitch.displayName = 'DSSwitch';

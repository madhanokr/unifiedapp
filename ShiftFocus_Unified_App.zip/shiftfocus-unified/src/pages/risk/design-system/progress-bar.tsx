import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const progressBarVariants = cva(
  'w-full rounded-full overflow-hidden',
  {
    variants: {
      size: {
        sm: 'h-1',
        md: 'h-2',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

const colorMap: Record<string, string> = {
  success: 'var(--success)',
  warning: 'var(--warning)',
  danger: 'var(--danger)',
  brand: 'var(--brand-primary)',
};

export interface DSProgressBarProps extends VariantProps<typeof progressBarVariants> {
  value: number;
  max?: number;
  variant?: 'success' | 'warning' | 'danger' | 'brand';
  className?: string;
  showLabel?: boolean;
}

export function DSProgressBar({
  value,
  max = 100,
  variant = 'brand',
  size,
  className,
  showLabel,
}: DSProgressBarProps) {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <div
        className={cn(progressBarVariants({ size }))}
        style={{ backgroundColor: 'var(--neutral-200)' }}
      >
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{
            width: `${percentage}%`,
            backgroundColor: colorMap[variant],
          }}
        />
      </div>
      {showLabel && (
        <span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)', minWidth: '40px' }}>
          {Math.round(percentage)}%
        </span>
      )}
    </div>
  );
}

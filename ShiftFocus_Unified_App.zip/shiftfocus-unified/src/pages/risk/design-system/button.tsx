import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Loader2 } from 'lucide-react';

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 rounded-[var(--button-radius)] transition-all duration-150 cursor-pointer focus-visible:outline-none',
  {
    variants: {
      variant: {
        primary: '',
        secondary: '',
        ghost: '',
        destructive: '',
      },
      size: {
        sm: 'h-8 px-3',
        md: 'h-10 px-4',
        lg: 'h-12 px-6',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

const variantStyles: Record<string, React.CSSProperties> = {
  primary: {
    backgroundColor: 'var(--brand-primary)',
    color: 'var(--bg-level-0)',
    border: 'none',
    boxShadow: 'var(--shadow-brand)',
  },
  secondary: {
    backgroundColor: 'var(--bg-level-0)',
    color: 'var(--neutral-800)',
    border: '1px solid var(--neutral-200)',
  },
  ghost: {
    backgroundColor: 'transparent',
    color: 'var(--neutral-600)',
    border: 'none',
  },
  destructive: {
    backgroundColor: 'var(--danger)',
    color: 'var(--bg-level-0)',
    border: 'none',
    boxShadow: 'var(--shadow-brand)',
  },
};

const hoverStyles: Record<string, Partial<CSSStyleDeclaration>> = {
  primary: { backgroundColor: 'var(--brand-primary-hover)', boxShadow: 'var(--shadow-brand-hover)' },
  secondary: { backgroundColor: 'var(--neutral-50)' },
  ghost: { backgroundColor: 'var(--neutral-100)' },
  destructive: { backgroundColor: 'var(--danger-dark)' },
};

export interface DSButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'style'>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
  children: ReactNode;
  style?: React.CSSProperties;
}

export const DSButton = forwardRef<HTMLButtonElement, DSButtonProps>(
  ({ className, variant = 'primary', size, loading, disabled, children, style, ...props }, ref) => {
    const isDisabled = disabled || loading;
    const v = variant ?? 'primary';

    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant: v, size }), className)}
        disabled={isDisabled}
        style={{
          ...variantStyles[v],
          opacity: isDisabled ? 0.5 : 1,
          cursor: isDisabled ? 'not-allowed' : 'pointer',
          fontSize: '14px',
          fontWeight: 500,
          ...style,
        }}
        onMouseEnter={(e) => {
          if (!isDisabled) {
            const hv = hoverStyles[v];
            if (hv?.backgroundColor) e.currentTarget.style.backgroundColor = hv.backgroundColor;
            if (hv?.boxShadow) e.currentTarget.style.boxShadow = hv.boxShadow;
          }
        }}
        onMouseLeave={(e) => {
          if (!isDisabled) {
            const sv = variantStyles[v];
            e.currentTarget.style.backgroundColor = sv.backgroundColor ?? '';
            e.currentTarget.style.boxShadow = (sv.boxShadow as string) ?? '';
          }
        }}
        onFocus={(e) => {
          e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
        }}
        onBlur={(e) => {
          e.currentTarget.style.boxShadow = (variantStyles[v].boxShadow as string) ?? 'none';
        }}
        {...props}
      >
        {loading && <Loader2 className="size-4 animate-spin" />}
        {children}
      </button>
    );
  }
);

DSButton.displayName = 'DSButton';
export { buttonVariants };

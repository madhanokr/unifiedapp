import * as DialogPrimitive from '@radix-ui/react-dialog';
import { type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { X } from 'lucide-react';

const dialogContentVariants = cva(
  'fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-2xl z-50 outline-none',
  {
    variants: {
      size: {
        sm: 'w-full max-w-sm',
        md: 'w-full max-w-lg',
        lg: 'w-full max-w-2xl',
        xl: 'w-full max-w-4xl',
      },
    },
    defaultVariants: {
      size: 'md',
    },
  }
);

export interface DSDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
}

export function DSDialog({ open, onOpenChange, children }: DSDialogProps) {
  return (
    <DialogPrimitive.Root open={open} onOpenChange={onOpenChange}>
      {children}
    </DialogPrimitive.Root>
  );
}

export interface DSDialogContentProps extends VariantProps<typeof dialogContentVariants> {
  children: ReactNode;
  className?: string;
  showClose?: boolean;
}

export function DSDialogContent({ children, size, className, showClose = true }: DSDialogContentProps) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay
        className="fixed inset-0 z-50 animate-in fade-in duration-200"
        style={{ backgroundColor: 'var(--overlay-50)' }}
      />
      <DialogPrimitive.Content
        className={cn(dialogContentVariants({ size }), 'animate-in fade-in zoom-in-95 duration-200', className)}
        style={{
          backgroundColor: 'var(--bg-level-0)',
          boxShadow: 'var(--shadow-modal)',
          maxHeight: '90vh',
          overflow: 'hidden',
        }}
      >
        {children}
        {showClose && (
          <DialogPrimitive.Close
            className="absolute top-4 right-4 rounded-lg p-2 transition-colors duration-150 outline-none"
            style={{
              backgroundColor: 'transparent',
              border: 'none',
              cursor: 'pointer',
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
            onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
            onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
          >
            <X className="size-4" style={{ color: 'var(--neutral-600)' }} />
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}

export interface DSDialogHeaderProps {
  children: ReactNode;
  className?: string;
}

export function DSDialogHeader({ children, className }: DSDialogHeaderProps) {
  return (
    <div
      className={cn('px-8 py-5', className)}
      style={{ borderBottom: '1px solid var(--neutral-200)' }}
    >
      {children}
    </div>
  );
}

export function DSDialogTitle({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <DialogPrimitive.Title
      className={className}
      style={{ fontSize: '18px', fontWeight: 500, color: 'var(--neutral-950)' }}
    >
      {children}
    </DialogPrimitive.Title>
  );
}

export function DSDialogDescription({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <DialogPrimitive.Description
      className={className}
      style={{ fontSize: '14px', color: 'var(--neutral-600)', marginTop: '4px' }}
    >
      {children}
    </DialogPrimitive.Description>
  );
}

export function DSDialogBody({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('px-8 py-5', className)} style={{ overflowY: 'auto', maxHeight: '60vh' }}>
      {children}
    </div>
  );
}

export function DSDialogFooter({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn('px-8 py-4 flex items-center justify-end gap-3', className)}
      style={{ borderTop: '1px solid var(--neutral-200)', backgroundColor: 'var(--neutral-50)' }}
    >
      {children}
    </div>
  );
}

export const DSDialogTrigger = DialogPrimitive.Trigger;
export const DSDialogClose = DialogPrimitive.Close;
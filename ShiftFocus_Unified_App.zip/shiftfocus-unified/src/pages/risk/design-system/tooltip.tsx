import * as TooltipPrimitive from '@radix-ui/react-tooltip';
import { type ReactNode } from 'react';
import { cn } from '../lib/utils';

export interface DSTooltipProps {
  children: ReactNode;
  content: ReactNode;
  side?: 'top' | 'bottom' | 'left' | 'right';
  delayDuration?: number;
  className?: string;
  maxWidth?: string;
}

export function DSTooltip({
  children,
  content,
  side = 'top',
  delayDuration = 100,
  className,
  maxWidth = '320px',
}: DSTooltipProps) {
  return (
    <TooltipPrimitive.Provider delayDuration={delayDuration}>
      <TooltipPrimitive.Root>
        <TooltipPrimitive.Trigger asChild>{children}</TooltipPrimitive.Trigger>
        <TooltipPrimitive.Portal>
          <TooltipPrimitive.Content
            side={side}
            sideOffset={4}
            className={cn('z-50 rounded-lg px-3 py-2 animate-in fade-in zoom-in-95 duration-150', className)}
            style={{
              backgroundColor: 'var(--tooltip-bg)',
              boxShadow: 'var(--shadow-tooltip)',
              maxWidth,
            }}
          >
            {typeof content === 'string' ? (
              <p style={{ fontSize: '12px', lineHeight: '1.5', color: 'var(--tooltip-text)' }}>
                {content}
              </p>
            ) : (
              content
            )}
            <TooltipPrimitive.Arrow
              style={{ fill: 'var(--tooltip-bg)' }}
              width={10}
              height={5}
            />
          </TooltipPrimitive.Content>
        </TooltipPrimitive.Portal>
      </TooltipPrimitive.Root>
    </TooltipPrimitive.Provider>
  );
}

// Re-export primitives for advanced usage
export const DSTooltipProvider = TooltipPrimitive.Provider;
export const DSTooltipRoot = TooltipPrimitive.Root;
export const DSTooltipTrigger = TooltipPrimitive.Trigger;
export const DSTooltipContent = TooltipPrimitive.Content;

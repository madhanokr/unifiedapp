import { type HTMLAttributes, type ReactNode } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';

const badgeVariants = cva(
  'inline-flex items-center rounded-[var(--badge-radius)] transition-colors',
  {
    variants: {
      variant: {
        success: '',
        warning: '',
        danger: '',
        info: '',
        neutral: '',
        brand: '',
      },
      size: {
        sm: 'px-1.5 py-0.5',
        md: 'px-2.5 py-1',
      },
    },
    defaultVariants: {
      variant: 'neutral',
      size: 'md',
    },
  }
);

const variantStyleMap: Record<string, React.CSSProperties> = {
  success: {
    backgroundColor: 'var(--success-light)',
    color: 'var(--success-dark)',
    border: '1px solid var(--neutral-200)',
  },
  warning: {
    backgroundColor: 'var(--warning-light)',
    color: 'var(--warning-dark)',
    border: '1px solid var(--neutral-200)',
  },
  danger: {
    backgroundColor: 'var(--danger-light)',
    color: 'var(--danger-dark)',
    border: '1px solid var(--neutral-200)',
  },
  info: {
    backgroundColor: 'var(--info-light)',
    color: 'var(--info)',
    border: '1px solid var(--neutral-200)',
  },
  neutral: {
    backgroundColor: 'var(--neutral-100)',
    color: 'var(--neutral-600)',
    border: '1px solid var(--neutral-200)',
  },
  brand: {
    backgroundColor: 'var(--brand-primary-light)',
    color: 'var(--brand-primary)',
    border: '1px solid var(--brand-alpha-20)',
  },
};

const sizeStyleMap: Record<string, React.CSSProperties> = {
  sm: { fontSize: '10px', fontWeight: 500, letterSpacing: '0.04em' },
  md: { fontSize: '12px', fontWeight: 500, letterSpacing: '0.02em' },
};

export interface DSBadgeProps
  extends Omit<HTMLAttributes<HTMLSpanElement>, 'style'>,
    VariantProps<typeof badgeVariants> {
  children: ReactNode;
  style?: React.CSSProperties;
}

export function DSBadge({ className, variant = 'neutral', size = 'md', children, style, ...props }: DSBadgeProps) {
  const v = variant ?? 'neutral';
  const s = size ?? 'md';

  return (
    <span
      className={cn(badgeVariants({ variant: v, size: s }), className)}
      style={{
        ...variantStyleMap[v],
        ...sizeStyleMap[s],
        textTransform: 'uppercase',
        ...style,
      }}
      {...props}
    >
      {children}
    </span>
  );
}

export { badgeVariants };
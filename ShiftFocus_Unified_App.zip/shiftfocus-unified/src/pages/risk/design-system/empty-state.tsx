import { type ReactNode } from 'react';
import { cn } from '../lib/utils';
import { DSButton } from './button';
import { InboxIcon, AlertCircle, SearchX, type LucideIcon } from 'lucide-react';

export interface DSEmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  actionVariant?: 'primary' | 'secondary' | 'ghost';
  variant?: 'default' | 'error';
  className?: string;
  children?: ReactNode;
}

export function DSEmptyState({
  icon: Icon = InboxIcon,
  title,
  description,
  actionLabel,
  onAction,
  actionVariant = 'secondary',
  variant = 'default',
  className,
  children,
}: DSEmptyStateProps) {
  const ErrorIcon = variant === 'error' ? AlertCircle : Icon;

  return (
    <div
      className={cn('rounded-xl p-12 text-center flex flex-col items-center', className)}
      style={{
        backgroundColor: 'var(--bg-level-0)',
        border: variant === 'error' ? '1px solid var(--danger-alpha-20)' : '1px solid var(--neutral-200)',
      }}
    >
      <div
        className="size-12 rounded-xl flex items-center justify-center mb-4"
        style={{
          backgroundColor: variant === 'error' ? 'var(--danger-light)' : 'var(--neutral-100)',
        }}
      >
        <ErrorIcon
          className="size-6"
          style={{
            color: variant === 'error' ? 'var(--danger)' : 'var(--neutral-400)',
          }}
        />
      </div>
      <h3
        style={{
          fontSize: '16px',
          fontWeight: 500,
          color: 'var(--neutral-950)',
          marginBottom: '8px',
        }}
      >
        {title}
      </h3>
      {description && (
        <p
          style={{
            fontSize: '14px',
            color: 'var(--neutral-600)',
            maxWidth: '400px',
            lineHeight: '1.6',
            marginBottom: actionLabel ? '16px' : '0',
          }}
        >
          {description}
        </p>
      )}
      {actionLabel && onAction && (
        <DSButton
          variant={variant === 'error' ? 'destructive' : actionVariant}
          size="sm"
          onClick={onAction}
        >
          {actionLabel}
        </DSButton>
      )}
      {children}
    </div>
  );
}
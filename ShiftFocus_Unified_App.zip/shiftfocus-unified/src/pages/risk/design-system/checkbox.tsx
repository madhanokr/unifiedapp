import * as CheckboxPrimitive from '@radix-ui/react-checkbox';
import { forwardRef } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../lib/utils';
import { Check } from 'lucide-react';

const checkboxVariants = cva(
  'inline-flex items-center justify-center rounded transition-all duration-150 cursor-pointer outline-none',
  {
    variants: {
      checkboxSize: {
        sm: 'size-4',
        md: 'size-5',
      },
    },
    defaultVariants: {
      checkboxSize: 'md',
    },
  }
);

export interface DSCheckboxProps extends VariantProps<typeof checkboxVariants> {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  disabled?: boolean;
  className?: string;
  id?: string;
}

export const DSCheckbox = forwardRef<HTMLButtonElement, DSCheckboxProps>(
  ({ checked, onCheckedChange, disabled, checkboxSize, className, id }, ref) => {
    return (
      <CheckboxPrimitive.Root
        ref={ref}
        id={id}
        checked={checked}
        onCheckedChange={(val) => onCheckedChange(val === true)}
        disabled={disabled}
        className={cn(checkboxVariants({ checkboxSize }), className)}
        style={{
          backgroundColor: checked ? 'var(--brand-primary)' : 'var(--bg-level-0)',
          border: checked ? '2px solid var(--brand-primary)' : '2px solid var(--neutral-200)',
          opacity: disabled ? 0.5 : 1,
          cursor: disabled ? 'not-allowed' : 'pointer',
          borderRadius: '4px',
        }}
        onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
        onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
      >
        <CheckboxPrimitive.Indicator>
          <Check className="size-3" style={{ color: 'var(--bg-level-0)' }} />
        </CheckboxPrimitive.Indicator>
      </CheckboxPrimitive.Root>
    );
  }
);

DSCheckbox.displayName = 'DSCheckbox';

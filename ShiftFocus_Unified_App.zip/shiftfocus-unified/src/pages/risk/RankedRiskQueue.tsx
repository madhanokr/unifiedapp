import { useState, useEffect } from 'react';
import { AlertTriangle, Clock, Shield, ShieldOff } from 'lucide-react';
import {
  DSButton,
  DSTooltip,
  DSBadge,
  DSEmptyState,
  DSSkeletonTable,
} from './design-system';

interface RiskItem {
  id: string;
  title: string;
  type: 'KR' | 'Objective' | 'Initiative' | 'KPI';
  hierarchy: string;
  score: number;
  severity: 'critical' | 'high' | 'medium';
  whyBreaking: string[];
  protected: boolean;
  enforcementRule?: string;
  slaHours: number | null;
  slaDueTime?: string;
  slaStartTime?: string;
  slaRule?: string;
  teamsAffected: number;
  recommendedAction: string;
}

interface RankedRiskQueueProps {
  onFixNow: (risk: RiskItem) => void;
  appliedFilter: { type: string; value: string | boolean } | null;
  onViewEnforcementCenter: (riskId: string) => void;
  onScoreClick: (risk: RiskItem) => void;
}

export function RankedRiskQueue({
  onFixNow,
  appliedFilter,
  onViewEnforcementCenter,
  onScoreClick
}: RankedRiskQueueProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const risks: RiskItem[] = [
    { id: 'risk-1', title: 'Increase ARR by 40%', type: 'KR', hierarchy: 'Increase ARR 40% → Q1 Revenue Growth → Sales', score: 92, severity: 'critical', whyBreaking: ['Workload +132% — Team capacity exceeded by 132% for 10 business days', 'Slip risk: 3 weeks — Projected delay based on dependency velocity', 'No executive update in 14 days'], protected: false, slaHours: 6, slaDueTime: 'Today 6:00 PM', slaStartTime: 'Today 12:00 PM', slaRule: 'Blocked SLA (Critical)', teamsAffected: 3, recommendedAction: 'Require owner update within 24h + assign unblock owner' },
    { id: 'risk-2', title: 'Mobile App v2 Launch', type: 'Initiative', hierarchy: 'Mobile App v2 Launch → Product Delivery → Engineering', score: 87, severity: 'critical', whyBreaking: ['Workload +112% — Team capacity exceeded by 112%', 'Blocked dependency — Design system blocked for 3 weeks', 'Missed check-ins (3 weeks)'], protected: true, enforcementRule: 'Blocked SLA — Critical', slaHours: 12, slaDueTime: 'Tomorrow 12:00 AM', slaStartTime: 'Today 12:00 PM', slaRule: 'Blocked SLA (Critical)', teamsAffected: 4, recommendedAction: 'Escalate blocker to Design team lead + require daily sync' },
    { id: 'risk-3', title: 'Achieve Product-Market Fit', type: 'Objective', hierarchy: 'Achieve Product-Market Fit → Product', score: 81, severity: 'high', whyBreaking: ['Customer satisfaction declining — Score dropped 8%', 'Feature adoption below target — 62% vs 80%', 'No strategic update in 21 days'], protected: false, slaHours: 24, slaDueTime: 'Tomorrow 12:00 PM', slaStartTime: 'Today 12:00 PM', slaRule: 'Strategic Update Required', teamsAffected: 2, recommendedAction: 'Schedule executive review + analyze adoption blockers' },
    { id: 'risk-4', title: 'Customer Churn Rate', type: 'KPI', hierarchy: 'Customer Churn Rate → Customer Success', score: 76, severity: 'high', whyBreaking: ['Churn increased 2.1% — Threshold breach', 'Support response time degraded', 'Workload +104% — CS team capacity exceeded'], protected: true, enforcementRule: 'Threshold Alert', slaHours: 18, slaDueTime: 'Tomorrow 6:00 AM', slaStartTime: 'Today 12:00 PM', slaRule: 'Threshold Alert (High)', teamsAffected: 1, recommendedAction: 'Add CS capacity + implement escalation protocol' },
    { id: 'risk-5', title: 'Ship 5 major features', type: 'KR', hierarchy: 'Ship 5 major features → Innovation Excellence → Engineering', score: 71, severity: 'high', whyBreaking: ['Only 2 of 5 features completed', 'Resource constraints — Budget delayed', 'Slip risk: 2 weeks — Cross-team dependency delayed'], protected: false, slaHours: null, teamsAffected: 3, recommendedAction: 'Reprioritize features + unblock budget approval' },
    { id: 'risk-6', title: 'Infrastructure Modernization', type: 'Initiative', hierarchy: 'Infrastructure Modernization → Platform Stability → Platform', score: 68, severity: 'high', whyBreaking: ['Missed milestones (2 consecutive)', 'Workload +98% — Platform team capacity exceeded', 'Vendor delay impacting timeline'], protected: true, enforcementRule: 'Resource Threshold', slaHours: null, teamsAffected: 2, recommendedAction: 'Escalate vendor issue + adjust timeline or add contractors' },
  ];

  const filteredRisks = risks.filter(risk => {
    if (!appliedFilter) return true;
    if (appliedFilter.type === 'severity') {
      if (appliedFilter.value === 'Critical') return risk.severity === 'critical';
      if (appliedFilter.value === 'High') return risk.severity === 'high';
      if (appliedFilter.value === 'Medium') return risk.severity === 'medium';
    }
    if (appliedFilter.type === 'status') {
      if (appliedFilter.value === 'Escalating') return risk.slaHours !== null && risk.slaHours < 24;
    }
    if (appliedFilter.type === 'hasKRs') return appliedFilter.value === true;
    return true;
  });

  const getSeverityColor = (severity: string) => {
    if (severity === 'critical') return 'var(--danger)';
    if (severity === 'high') return 'var(--warning)';
    return 'var(--neutral-600)';
  };

  const getSeverityLabel = (severity: string) => {
    if (severity === 'critical') return 'Critical';
    if (severity === 'high') return 'High';
    return 'Medium';
  };

  const getTypeBg = (type: string) => {
    if (type === 'KR') return 'rgba(106, 61, 232, 0.1)';
    if (type === 'Objective') return 'rgba(62, 139, 255, 0.1)';
    if (type === 'KPI') return 'rgba(245, 166, 35, 0.1)';
    return 'rgba(60, 203, 127, 0.1)';
  };

  const getTypeColor = (type: string) => {
    if (type === 'KR') return 'var(--brand-primary)';
    if (type === 'Objective') return 'var(--info)';
    if (type === 'KPI') return 'var(--warning)';
    return 'var(--success)';
  };

  return (
    <div>
      <div className="mb-8">
        <p style={{ color: 'var(--neutral-600)', fontSize: '12px', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500, marginBottom: '8px' }}>
          Risk Queue
        </p>
        <p style={{ color: 'var(--neutral-400)', fontSize: '14px' }}>Ranked by severity and time pressure</p>
      </div>

      {loading ? (
        <DSSkeletonTable rows={5} />
      ) : filteredRisks.length === 0 ? (
        <DSEmptyState
          title="No risks match the current filter"
          description="Try adjusting your filter criteria or view all risks."
          actionLabel="Clear Filter"
          onAction={() => window.location.reload()}
        />
      ) : (
        <div
          className="rounded-xl overflow-hidden"
          style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)' }}
        >
          {/* Header */}
          <div
            className="grid grid-cols-12 gap-8 px-8 py-4"
            style={{ backgroundColor: 'var(--neutral-50)', borderBottom: '1px solid var(--neutral-200)' }}
          >
            <div className="col-span-3">
              <p style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Problem</p>
            </div>
            <div className="col-span-3">
              <p style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Why It's Breaking</p>
            </div>
            <div className="col-span-3">
              <p style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Recommended Action</p>
            </div>
            <div className="col-span-3">
              <p style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Control</p>
            </div>
          </div>

          {/* Rows */}
          <div>
            {filteredRisks.map((risk, index) => (
              <div
                key={risk.id}
                className="grid grid-cols-12 gap-8 px-8 py-8 transition-all duration-150"
                style={{ borderBottom: index < filteredRisks.length - 1 ? '1px solid var(--neutral-200)' : 'none' }}
              >
                {/* Problem */}
                <div className="col-span-3">
                  <DSBadge variant="brand" size="sm" style={{ backgroundColor: getTypeBg(risk.type), color: getTypeColor(risk.type), border: 'none', marginBottom: '8px' }}>
                    {risk.type}
                  </DSBadge>
                  <h4 style={{ color: 'var(--neutral-950)', marginBottom: '8px', fontWeight: 500 }}>{risk.title}</h4>
                  <p style={{ fontSize: '14px', color: 'var(--neutral-400)', marginBottom: '8px' }}>{risk.hierarchy}</p>
                  <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>
                    <span style={{ fontWeight: 500 }}>Teams Affected:</span> {risk.teamsAffected}
                  </div>
                </div>

                {/* Why + Score */}
                <div className="col-span-3">
                  <DSTooltip content="Click to see score breakdown" side="bottom">
                    <button
                      onClick={(e) => { e.stopPropagation(); onScoreClick(risk); }}
                      className="flex items-center gap-2 mb-3 transition-all duration-150 rounded-lg px-3 py-1.5 -ml-3"
                      style={{ border: 'none', backgroundColor: 'transparent' }}
                      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                      onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                      onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
                    >
                      <span style={{ fontSize: '18px', fontWeight: 600, color: getSeverityColor(risk.severity), letterSpacing: '-0.01em' }}>{risk.score}</span>
                      <span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-600)' }}>{getSeverityLabel(risk.severity)}</span>
                      {risk.slaHours !== null && (
                        <DSTooltip
                          content={
                            <div style={{ fontSize: '12px', lineHeight: '1.6', color: 'var(--tooltip-text)' }}>
                              <p style={{ marginBottom: '4px' }}><strong>Breach at:</strong> {risk.slaDueTime}</p>
                              <p style={{ marginBottom: '4px' }}><strong>Clock started:</strong> {risk.slaStartTime}</p>
                              <p><strong>Rule:</strong> {risk.slaRule}</p>
                            </div>
                          }
                          side="bottom"
                        >
                          <div className="flex items-center gap-1 ml-2">
                            <Clock className="size-3" style={{ color: 'var(--danger)' }} />
                            <span style={{ fontSize: '12px', color: 'var(--danger)', fontWeight: 500 }}>Due in {risk.slaHours}h</span>
                          </div>
                        </DSTooltip>
                      )}
                    </button>
                  </DSTooltip>
                  <div className="space-y-1.5">
                    {risk.whyBreaking.map((reason, i) => {
                      const parts = reason.split(' — ');
                      return (
                        <div key={i} className="flex items-start gap-2">
                          <div className="size-1 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: 'var(--neutral-400)' }} />
                          <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--neutral-600)' }}>
                            <span style={{ fontWeight: 500 }}>{parts[0]}</span>
                            {parts[1] && <span> — {parts[1].substring(0, 40)}{parts[1].length > 40 ? '...' : ''}</span>}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Recommended Action */}
                <div className="col-span-3">
                  <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--neutral-800)', fontStyle: 'italic' }}>{risk.recommendedAction}</p>
                </div>

                {/* Control */}
                <div className="col-span-3 flex flex-col items-end justify-start gap-3">
                  <DSTooltip
                    content={risk.protected ? 'This risk is covered by active enforcement rules. Click to view.' : 'No enforcement preventing recurrence. Click to create a rule.'}
                    side="left"
                  >
                    <button
                      onClick={(e) => { e.stopPropagation(); onViewEnforcementCenter(risk.id); }}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all duration-150"
                      style={{
                        backgroundColor: risk.protected ? 'var(--brand-primary-light)' : 'var(--neutral-100)',
                        border: risk.protected ? '1px solid rgba(106, 61, 232, 0.2)' : '1px solid var(--neutral-200)',
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = risk.protected ? 'rgba(106, 61, 232, 0.12)' : 'var(--neutral-200)'; }}
                      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = risk.protected ? 'var(--brand-primary-light)' : 'var(--neutral-100)'; }}
                      onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                      onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
                    >
                      {risk.protected ? <Shield className="size-4" style={{ color: 'var(--brand-primary)' }} /> : <ShieldOff className="size-4" style={{ color: 'var(--neutral-400)' }} />}
                      <span style={{ fontSize: '12px', fontWeight: 500, color: risk.protected ? 'var(--brand-primary)' : 'var(--neutral-600)' }}>
                        {risk.protected ? 'Coverage: Enforced' : 'Coverage: Not enforced'}
                      </span>
                    </button>
                  </DSTooltip>
                  <DSButton
                    variant="primary"
                    onClick={(e) => { e.stopPropagation(); onFixNow(risk); }}
                    style={{ width: '100%' }}
                  >
                    <AlertTriangle className="size-4" />
                    Fix Now
                  </DSButton>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

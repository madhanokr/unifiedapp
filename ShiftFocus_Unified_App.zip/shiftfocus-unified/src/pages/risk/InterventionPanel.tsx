import { useState, useEffect } from 'react';
import { X, CheckSquare, Users, Clock, AlertTriangle, TrendingUp, Link as LinkIcon } from 'lucide-react';
import {
  DSButton,
  DSDialog,
  DSDialogContent,
  DSDialogHeader,
  DSDialogTitle,
  DSDialogDescription,
  DSDialogBody,
  DSDialogFooter,
  sfToast,
} from './design-system';

interface InterventionPanelProps {
  isOpen: boolean;
  onClose: () => void;
  risk: Record<string, unknown> | null;
  onApply: () => void;
}

export function InterventionPanel({ isOpen, onClose, risk, onApply }: InterventionPanelProps) {
  const [mode, setMode] = useState<'intervention' | 'resolved'>('intervention');
  const [selectedAction, setSelectedAction] = useState('recommended');
  const [autoEnforce, setAutoEnforce] = useState(false);
  const [proofType, setProofType] = useState('update-received');
  const [resolutionNote, setResolutionNote] = useState('');
  const [reassignTo, setReassignTo] = useState('alex-kim');
  const [escalateTo, setEscalateTo] = useState('alex-kim');
  const [evidenceLink, setEvidenceLink] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<'context' | 'history' | 'impact'>('context');

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  if (!risk) return null;

  const riskTitle = (risk.title as string) || 'Unknown Risk';
  const riskId = (risk.id as string) || '';
  const riskSeverity = (risk.severity as string) || 'high';
  const riskDriver = (risk.driver as string) || '';

  const getPersonName = (id: string) => {
    const names: Record<string, string> = { 'alex-kim': 'Alex Kim', 'jordan-lee': 'Jordan Lee', 'sam-patel': 'Sam Patel', 'taylor-wong': 'Taylor Wong' };
    return names[id] || id;
  };

  const handleApply = async () => {
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1200));
    onApply();
    if (mode === 'intervention') {
      sfToast.interventionApplied(riskId, () => sfToast.info('Intervention reverted'));
    } else {
      sfToast.riskResolved(riskId);
    }
    setIsSubmitting(false);
    setShowConfirmDialog(false);
    onClose();
  };

  const handleSubmitClick = () => {
    if (mode === 'resolved') {
      setShowConfirmDialog(true);
    } else {
      handleApply();
    }
  };

  const tabStyle = (tab: string): React.CSSProperties => ({
    fontSize: '14px',
    fontWeight: 500,
    color: activeTab === tab ? 'var(--brand-primary)' : 'var(--neutral-600)',
    backgroundColor: 'transparent',
    border: 'none',
    borderBottom: activeTab === tab ? '2px solid var(--brand-primary)' : '2px solid transparent',
    cursor: 'pointer',
    marginBottom: '-2px'
  });

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 transition-opacity duration-300 ${isOpen ? 'opacity-40 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        style={{ zIndex: 50, backgroundColor: 'var(--neutral-950)' }}
        onClick={onClose}
      />

      {/* Side Panel */}
      <div
        className={`fixed top-0 right-0 h-full transition-transform duration-300 ease-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ zIndex: 51, width: '90%', maxWidth: '1280px', backgroundColor: 'var(--bg-level-0)', boxShadow: 'var(--shadow-drawer)' }}
      >
        {/* Header */}
        <div className="px-10 py-8 flex items-center justify-between" style={{ borderBottom: '1px solid var(--neutral-200)' }}>
          <div className="flex items-center gap-4">
            <div className="size-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: riskSeverity === 'critical' ? 'rgba(229, 57, 53, 0.1)' : 'rgba(245, 166, 35, 0.1)' }}>
              <AlertTriangle className="size-5" style={{ color: riskSeverity === 'critical' ? 'var(--danger)' : 'var(--warning)' }} />
            </div>
            <div>
              <h2 style={{ fontSize: '20px', fontWeight: 500, color: 'var(--neutral-950)' }}>{riskTitle}</h2>
              <div className="flex items-center gap-2" style={{ marginTop: '4px' }}>
                <p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>{riskId} · Mobile App v2 Launch</p>
                <span style={{ fontSize: '12px', color: 'var(--brand-primary)', backgroundColor: 'rgba(106, 61, 232, 0.1)', padding: '2px 8px', borderRadius: '4px', fontWeight: 500 }}>Your role: Product Lead</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <DSButton variant="secondary" size="md" onClick={() => sfToast.info('Opening Activity Log')}>View Activity Log</DSButton>
            <button
              onClick={onClose}
              className="size-9 rounded-lg flex items-center justify-center transition-colors duration-150"
              style={{ backgroundColor: 'transparent', border: '1px solid var(--neutral-200)', cursor: 'pointer' }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-100)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
              onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
              onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}
            >
              <X className="size-4" style={{ color: 'var(--neutral-600)' }} />
            </button>
          </div>
        </div>

        {/* Content - 2 Column */}
        <div className="flex h-[calc(100%-144px)]">
          {/* LEFT - Action Selection (42%) */}
          <div className="px-10 py-8 flex flex-col" style={{ width: '42%', borderRight: '1px solid var(--neutral-200)' }}>
            {/* MODE TOGGLE */}
            <div className="mb-8">
              <div className="flex rounded-lg p-1" style={{ backgroundColor: 'var(--neutral-100)' }}>
                <button
                  onClick={() => setMode('intervention')}
                  className="flex-1 px-4 py-2 rounded-md transition-all duration-150"
                  style={{ fontSize: '14px', fontWeight: 500, backgroundColor: mode === 'intervention' ? 'var(--bg-level-0)' : 'transparent', color: mode === 'intervention' ? 'var(--neutral-950)' : 'var(--neutral-600)', border: 'none', cursor: 'pointer', boxShadow: mode === 'intervention' ? 'var(--shadow-toggle-active)' : 'none' }}
                  onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                  onBlur={(e) => { e.currentTarget.style.boxShadow = mode === 'intervention' ? 'var(--shadow-toggle-active)' : 'none'; }}
                >
                  Apply Intervention
                </button>
                <button
                  onClick={() => setMode('resolved')}
                  className="flex-1 px-4 py-2 rounded-md transition-all duration-150"
                  style={{ fontSize: '14px', fontWeight: 500, backgroundColor: mode === 'resolved' ? 'var(--bg-level-0)' : 'transparent', color: mode === 'resolved' ? 'var(--neutral-950)' : 'var(--neutral-600)', border: 'none', cursor: 'pointer', boxShadow: mode === 'resolved' ? 'var(--shadow-toggle-active)' : 'none' }}
                  onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }}
                  onBlur={(e) => { e.currentTarget.style.boxShadow = mode === 'resolved' ? 'var(--shadow-toggle-active)' : 'none'; }}
                >
                  Mark as Resolved
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {/* INTERVENTION MODE */}
              {mode === 'intervention' && (
                <>
                  <div className="mb-8">
                    <h3 style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '16px' }}>Choose Correction</h3>
                    <div className="space-y-3">
                      {/* Option 1 */}
                      <div>
                        <label className="block cursor-pointer" onClick={() => setSelectedAction('recommended')}>
                          <div className="rounded-lg p-4 transition-all duration-150" style={{ backgroundColor: selectedAction === 'recommended' ? 'rgba(106, 61, 232, 0.06)' : 'transparent', border: selectedAction === 'recommended' ? '2px solid var(--brand-primary)' : '2px solid var(--neutral-200)' }}>
                            <div className="flex items-start gap-3">
                              <input type="radio" name="action" checked={selectedAction === 'recommended'} onChange={() => setSelectedAction('recommended')} style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary)', cursor: 'pointer', marginTop: '2px' }} />
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <span style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)' }}>Escalate to unblock owner</span>
                                  <span style={{ fontSize: '10px', color: 'var(--brand-primary)', backgroundColor: 'rgba(106, 61, 232, 0.12)', padding: '2px 8px', borderRadius: '4px', fontWeight: 500 }}>AI</span>
                                </div>
                                <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--neutral-600)' }}>Notify current owner + manager, assign someone to unblock</p>
                              </div>
                            </div>
                          </div>
                        </label>
                        {selectedAction === 'recommended' && (
                          <div className="mt-3 ml-7 p-4 rounded-lg" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
                            <label style={{ display: 'block', marginBottom: '8px' }}>
                              <span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>Assign unblock owner</span>
                            </label>
                            <select value={escalateTo} onChange={(e) => setEscalateTo(e.target.value)} className="w-full px-3 py-2 rounded-lg" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', fontSize: '14px', color: 'var(--neutral-800)', cursor: 'pointer', outline: 'none' }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
                              <option value="alex-kim">Alex Kim (Design Lead)</option>
                              <option value="jordan-lee">Jordan Lee (Design Manager)</option>
                              <option value="sam-patel">Sam Patel (Product Manager)</option>
                              <option value="taylor-wong">Taylor Wong (Engineering Lead)</option>
                            </select>
                            <div className="mt-3 pt-3" style={{ borderTop: '1px solid var(--neutral-200)' }}>
                              <div style={{ fontSize: '12px', color: 'var(--neutral-600)', marginBottom: '8px' }}>Will notify:</div>
                              <div style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>
                                • <strong>Sarah Chen</strong> (current owner)<br/>• <strong>Tom Martinez</strong> (manager)<br/>• <strong>{getPersonName(escalateTo)}</strong> (unblock owner)
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Option 2 */}
                      <label className="block cursor-pointer" onClick={() => setSelectedAction('huddle')}>
                        <div className="rounded-lg p-4" style={{ backgroundColor: selectedAction === 'huddle' ? 'rgba(106, 61, 232, 0.06)' : 'transparent', border: selectedAction === 'huddle' ? '2px solid var(--brand-primary)' : '2px solid var(--neutral-200)' }}>
                          <div className="flex items-start gap-3">
                            <input type="radio" name="action" checked={selectedAction === 'huddle'} onChange={() => setSelectedAction('huddle')} style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary)', cursor: 'pointer', marginTop: '2px' }} />
                            <div><span style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)', display: 'block', marginBottom: '4px' }}>Schedule unblock huddle</span><p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>Sync with Design + Sales leads within 2h</p></div>
                          </div>
                        </div>
                      </label>

                      {/* Option 3 */}
                      <div>
                        <label className="block cursor-pointer" onClick={() => setSelectedAction('reassign')}>
                          <div className="rounded-lg p-4" style={{ backgroundColor: selectedAction === 'reassign' ? 'rgba(106, 61, 232, 0.06)' : 'transparent', border: selectedAction === 'reassign' ? '2px solid var(--brand-primary)' : '2px solid var(--neutral-200)' }}>
                            <div className="flex items-start gap-3">
                              <input type="radio" name="action" checked={selectedAction === 'reassign'} onChange={() => setSelectedAction('reassign')} style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary)', cursor: 'pointer', marginTop: '2px' }} />
                              <div><span style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)', display: 'block', marginBottom: '4px' }}>Reassign risk owner</span><p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>Transfer ownership to someone else</p></div>
                            </div>
                          </div>
                        </label>
                        {selectedAction === 'reassign' && (
                          <div className="mt-3 ml-7 p-4 rounded-lg" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
                            <div className="mb-3 pb-3" style={{ borderBottom: '1px solid var(--neutral-200)' }}>
                              <div style={{ fontSize: '12px', color: 'var(--neutral-600)', marginBottom: '4px' }}>Current owner</div>
                              <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)' }}>Sarah Chen</div>
                            </div>
                            <label style={{ display: 'block', marginBottom: '8px' }}><span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>New owner</span></label>
                            <select value={reassignTo} onChange={(e) => setReassignTo(e.target.value)} className="w-full px-3 py-2 rounded-lg" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', fontSize: '14px', color: 'var(--neutral-800)', cursor: 'pointer', outline: 'none' }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
                              <option value="alex-kim">Alex Kim (Design Lead)</option>
                              <option value="jordan-lee">Jordan Lee (Design Manager)</option>
                              <option value="sam-patel">Sam Patel (Product Manager)</option>
                              <option value="taylor-wong">Taylor Wong (Engineering Lead)</option>
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Auto-enforce */}
                  <label className="flex items-center justify-between cursor-pointer p-4 rounded-lg" style={{ backgroundColor: autoEnforce ? 'rgba(106, 61, 232, 0.04)' : 'var(--neutral-50)', border: autoEnforce ? '1px solid rgba(106, 61, 232, 0.2)' : '1px solid var(--neutral-200)' }}>
                    <div className="flex items-center gap-3">
                      <input type="checkbox" checked={autoEnforce} onChange={(e) => setAutoEnforce(e.target.checked)} style={{ width: '18px', height: '18px', accentColor: 'var(--brand-primary)', cursor: 'pointer' }} />
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '2px' }}>Prevent recurrence</div>
                        <div style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Auto-escalate if this pattern repeats</div>
                      </div>
                    </div>
                  </label>
                </>
              )}

              {/* RESOLVED MODE */}
              {mode === 'resolved' && (
                <div>
                  <h3 style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '16px' }}>Close Risk with Proof</h3>
                  <div className="mb-8">
                    <label style={{ display: 'block', marginBottom: '8px' }}><span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>Proof Type <span style={{ color: 'var(--danger)' }}>*</span></span></label>
                    <select value={proofType} onChange={(e) => setProofType(e.target.value)} className="w-full px-4 py-3 rounded-lg" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', fontSize: '14px', color: 'var(--neutral-800)', cursor: 'pointer', outline: 'none' }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
                      <option value="update-received">Update received from owner</option>
                      <option value="dependency-cleared">Dependency cleared (confirmed)</option>
                      <option value="sla-met">SLA met (24h response)</option>
                    </select>
                  </div>
                  <div className="mb-8">
                    <label style={{ display: 'block', marginBottom: '8px' }}><span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>Resolution Note</span> <span style={{ fontSize: '12px', color: 'var(--neutral-400)', marginLeft: '8px' }}>Optional</span></label>
                    <textarea value={resolutionNote} onChange={(e) => setResolutionNote(e.target.value)} className="w-full px-4 py-3 rounded-lg" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', fontSize: '14px', color: 'var(--neutral-800)', outline: 'none', resize: 'vertical', minHeight: '100px' }} placeholder="Explain how this risk was resolved..." onFocus={(e) => { e.currentTarget.style.borderColor = 'var(--brand-primary)'; e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.borderColor = 'var(--neutral-200)'; e.currentTarget.style.boxShadow = 'none'; }} />
                  </div>
                  <div>
                    <label style={{ display: 'block', marginBottom: '8px' }}><span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-800)' }}>Evidence Link</span> <span style={{ fontSize: '12px', color: 'var(--neutral-400)', marginLeft: '8px' }}>Optional</span></label>
                    <div className="flex items-center gap-2">
                      <LinkIcon className="size-4" style={{ color: 'var(--neutral-400)' }} />
                      <input type="url" value={evidenceLink} onChange={(e) => setEvidenceLink(e.target.value)} className="flex-1 px-4 py-3 rounded-lg" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', fontSize: '14px', color: 'var(--neutral-800)', outline: 'none' }} placeholder="https://..." onFocus={(e) => { e.currentTarget.style.borderColor = 'var(--brand-primary)'; e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.borderColor = 'var(--neutral-200)'; e.currentTarget.style.boxShadow = 'none'; }} />
                    </div>
                    <p style={{ fontSize: '12px', color: 'var(--neutral-600)', marginTop: '8px', lineHeight: '1.5' }}>Link to JIRA ticket, Slack thread, or document showing proof of resolution</p>
                  </div>
                  <div className="rounded-lg p-4 mt-8" style={{ backgroundColor: 'var(--resolved-light)', border: '1px solid var(--resolved-border)' }}>
                    <div className="flex items-start gap-2">
                      <CheckSquare className="size-4 mt-0.5" style={{ color: 'var(--resolved)' }} />
                      <div>
                        <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--resolved)', marginBottom: '4px' }}>Resolution will be logged</div>
                        <p style={{ fontSize: '12px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>This action will mark the risk as resolved in the audit trail with timestamp and proof.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-8" style={{ borderTop: '1px solid var(--neutral-200)' }}>
              <div className="flex gap-3">
                <DSButton variant="secondary" onClick={onClose} disabled={isSubmitting} style={{ flex: 1, height: '44px' }}>Cancel</DSButton>
                <DSButton
                  variant="primary"
                  onClick={handleSubmitClick}
                  disabled={isSubmitting}
                  loading={isSubmitting}
                  style={{ flex: 1, height: '44px', backgroundColor: mode === 'resolved' ? 'var(--resolved)' : 'var(--brand-primary)' }}
                >
                  {mode === 'resolved' ? 'Apply & Resolve' : 'Apply'}
                </DSButton>
              </div>
            </div>
          </div>

          {/* RIGHT - Context (58%) */}
          <div className="flex flex-col" style={{ width: '58%' }}>
            <div className="flex items-center px-10 pt-8 pb-4" style={{ borderBottom: '1px solid var(--neutral-200)' }}>
              <button onClick={() => setActiveTab('context')} className="px-3 py-2 transition-all duration-150" style={tabStyle('context')} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>Context</button>
              <button onClick={() => setActiveTab('history')} className="px-3 py-2 transition-all duration-150" style={tabStyle('history')} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>History</button>
              <button onClick={() => setActiveTab('impact')} className="px-3 py-2 transition-all duration-150" style={tabStyle('impact')} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>Impact</button>
            </div>

            <div className="flex-1 overflow-y-auto px-10 py-8">
              {activeTab === 'context' && (
                <div className="space-y-8">
                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px' }}>Risk Score</div>
                    <div className="flex items-center gap-4">
                      <div style={{ fontSize: '48px', fontWeight: 600, color: 'var(--danger)', lineHeight: 1 }}>75</div>
                      <div className="flex-1 space-y-2">
                        {[{ label: 'Owner Engagement', score: '-30', pct: '85%', color: 'var(--danger)' }, { label: 'Dependency Risk', score: '-25', pct: '70%', color: 'var(--warning)' }, { label: 'Timeline Pressure', score: '-20', pct: '60%', color: 'var(--warning)' }].map((item, i) => (
                          <div key={i}>
                            <div className="flex items-center justify-between mb-1">
                              <span style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>{item.label}</span>
                              <span style={{ fontSize: '12px', fontWeight: 500, color: item.color }}>{item.score}</span>
                            </div>
                            <div style={{ width: '100%', height: '4px', backgroundColor: 'var(--neutral-100)', borderRadius: '2px', overflow: 'hidden' }}>
                              <div style={{ width: item.pct, height: '100%', backgroundColor: item.color }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px' }}>Root Cause</div>
                    <p style={{ fontSize: '14px', color: 'var(--neutral-800)', lineHeight: '1.6' }}>{riskDriver || 'Owner silent for 3+ days on Critical risk. Design dependency blocking progress.'}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    {[{ icon: Clock, label: 'Silent For', value: '3d' }, { icon: Users, label: 'Blocked Teams', value: '3' }, { icon: AlertTriangle, label: 'Days to Launch', value: '12' }].map((metric, i) => (
                      <div key={i} className="rounded-lg p-4" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
                        <div className="flex items-center gap-2 mb-2">
                          <metric.icon className="size-4" style={{ color: 'var(--neutral-400)' }} />
                          <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase' }}>{metric.label}</span>
                        </div>
                        <div style={{ fontSize: '24px', fontWeight: 600, color: 'var(--neutral-950)' }}>{metric.value}</div>
                      </div>
                    ))}
                  </div>

                  <div className="rounded-lg p-4" style={{ backgroundColor: 'rgba(106, 61, 232, 0.05)', border: '1px solid rgba(106, 61, 232, 0.15)' }}>
                    <div className="flex items-start gap-3">
                      <TrendingUp className="size-4 mt-0.5" style={{ color: 'var(--brand-primary)' }} />
                      <div>
                        <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--brand-primary)', marginBottom: '4px' }}>Pattern Detected</div>
                        <p style={{ fontSize: '14px', color: 'var(--neutral-800)', lineHeight: '1.5' }}>This owner missed SLA on 2 previous Critical risks in past 30 days. Similar patterns resolved 40% faster with Design Lead involvement.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'history' && (
                <div className="space-y-4">
                  {[
                    { label: 'Escalation sent', desc: 'Escalated to Design Lead. Task created with 24h SLA.', time: '2d ago', color: 'var(--brand-primary)' },
                    { label: 'Status update received', desc: 'Owner: "Design mockups in review"', time: '5d ago', color: 'var(--resolved)' },
                    { label: 'Risk detected', desc: 'System flagged: Owner silent > 48h on Critical dependency', time: '7d ago', color: 'var(--danger)' },
                  ].map((item, i) => (
                    <div key={i} className="rounded-lg p-4" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
                      <div className="flex items-start gap-3">
                        <div className="size-2 rounded-full mt-2" style={{ backgroundColor: item.color }} />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)' }}>{item.label}</span>
                            <span style={{ fontSize: '12px', color: 'var(--neutral-400)' }}>{item.time}</span>
                          </div>
                          <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>{item.desc}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'impact' && (
                <div className="space-y-8">
                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px' }}>Immediate Actions</div>
                    <div className="space-y-2">
                      {['2 people notified (Sarah Chen, Tom Martinez)', 'Task created with 24h SLA deadline', 'Alex Kim assigned as unblock owner', 'Risk status → "Intervention Applied"'].map((item, i) => (
                        <div key={i} className="flex items-start gap-3">
                          <div className="size-5 rounded flex items-center justify-center mt-0.5" style={{ backgroundColor: 'var(--resolved-light)' }}>
                            <span style={{ fontSize: '10px', fontWeight: 600, color: 'var(--resolved)' }}>✓</span>
                          </div>
                          <p style={{ fontSize: '14px', color: 'var(--neutral-800)', lineHeight: '1.6' }}>{item}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div style={{ height: '1px', backgroundColor: 'var(--neutral-200)' }} />
                  <div>
                    <div style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '12px' }}>Expected Outcome</div>
                    <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.6' }}>Similar interventions reduced resolution time by <strong>3.2 days</strong> and improved owner response rate by <strong>65%</strong>.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Resolve Confirmation Dialog */}
      <DSDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DSDialogContent size="sm">
          <DSDialogHeader>
            <DSDialogTitle>Confirm Resolution</DSDialogTitle>
            <DSDialogDescription>This action is permanent and cannot be undone.</DSDialogDescription>
          </DSDialogHeader>
          <DSDialogBody>
            <div className="rounded-lg p-4" style={{ backgroundColor: 'rgba(229, 57, 53, 0.05)', border: '1px solid rgba(229, 57, 53, 0.2)' }}>
              <p style={{ fontSize: '14px', color: 'var(--danger)', fontWeight: 500, marginBottom: '4px' }}>Permanent action</p>
              <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.5' }}>Once marked as resolved, this risk will be archived. You cannot undo this action.</p>
            </div>
          </DSDialogBody>
          <DSDialogFooter>
            <DSButton variant="secondary" onClick={() => setShowConfirmDialog(false)}>Cancel</DSButton>
            <DSButton variant="primary" onClick={handleApply} loading={isSubmitting} style={{ backgroundColor: 'var(--resolved)' }}>Confirm & Resolve</DSButton>
          </DSDialogFooter>
        </DSDialogContent>
      </DSDialog>
    </>
  );
}

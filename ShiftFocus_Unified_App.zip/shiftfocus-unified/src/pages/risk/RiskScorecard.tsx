import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { DSCard, DSTooltip } from './design-system';

interface RiskScorecardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'neutral';
  description: string;
  color: 'red' | 'orange' | 'yellow' | 'green' | 'purple';
  tooltip?: string;
}

const colorMap = {
  red: { text: 'var(--danger)', icon: 'var(--danger)' },
  orange: { text: 'var(--warning-dark)', icon: 'var(--warning-dark)' },
  yellow: { text: 'var(--warning)', icon: 'var(--warning)' },
  green: { text: 'var(--success)', icon: 'var(--success)' },
  purple: { text: 'var(--brand-primary)', icon: 'var(--brand-primary)' },
};

export function RiskScorecard({ title, value, change, trend, description, color, tooltip }: RiskScorecardProps) {
  const colors = colorMap[color];
  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;

  const card = (
    <DSCard hoverable style={{ cursor: 'pointer' }}>
      <div className="flex items-start justify-between mb-4">
        <h3 style={{ color: 'var(--neutral-600)', fontSize: '14px', fontWeight: 500 }}>{title}</h3>
        <TrendIcon className="size-5" style={{ color: colors.icon }} />
      </div>
      <div style={{ fontSize: '32px', fontWeight: 600, color: colors.text, marginBottom: '8px', letterSpacing: '-0.02em' }}>{value}</div>
      <div style={{ color: 'var(--neutral-600)', fontSize: '12px', marginBottom: '4px' }}>{change}</div>
      <div style={{ color: 'var(--neutral-400)', fontSize: '12px' }}>{description}</div>
    </DSCard>
  );

  if (tooltip) {
    return <DSTooltip content={tooltip}>{card}</DSTooltip>;
  }

  return card;
}

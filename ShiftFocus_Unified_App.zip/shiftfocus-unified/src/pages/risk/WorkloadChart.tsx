import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine, Line, ComposedChart } from 'recharts';
import { AlertTriangle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { DSSkeleton } from './design-system';

const workloadData = [
  { team: 'Engineering', workload: 118, capacity: 100, krsImpacted: 3, overloadedWeeks: 4, lastWeek: 115 },
  { team: 'Sales', workload: 132, capacity: 100, krsImpacted: 2, overloadedWeeks: 6, lastWeek: 128 },
  { team: 'Product', workload: 95, capacity: 100, krsImpacted: 0, overloadedWeeks: 0, lastWeek: 93 },
  { team: 'Design', workload: 108, capacity: 100, krsImpacted: 1, overloadedWeeks: 2, lastWeek: 105 },
  { team: 'Marketing', workload: 88, capacity: 100, krsImpacted: 0, overloadedWeeks: 0, lastWeek: 90 },
  { team: 'Support', workload: 122, capacity: 100, krsImpacted: 2, overloadedWeeks: 5, lastWeek: 118 },
  { team: 'Infrastructure', workload: 115, capacity: 100, krsImpacted: 2, overloadedWeeks: 3, lastWeek: 112 },
  { team: 'Data', workload: 92, capacity: 100, krsImpacted: 0, overloadedWeeks: 0, lastWeek: 94 }
];

// Recharts <Cell fill> requires raw hex — CSS vars don't resolve in SVG.
// Values mirror design tokens: --success, --warning, --warning-dark, --danger
function getWorkloadColorHex(workload: number): string {
  if (workload <= 100) return '#3CCB7F';
  if (workload <= 110) return '#F5A623';
  if (workload <= 130) return '#F98B2B';
  return '#E53935';
}

function getWorkloadStatus(workload: number) {
  if (workload <= 100) return 'Healthy (90-100%)';
  if (workload <= 110) return 'Caution (100-110%)';
  if (workload <= 130) return 'Overloaded (110-130%)';
  return 'Critical (>130%)';
}

interface TooltipPayloadItem {
  payload: typeof workloadData[number];
}

const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: TooltipPayloadItem[] }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div 
        className="rounded-xl p-5" 
        style={{ 
          maxWidth: '320px',
          backgroundColor: 'var(--bg-level-0)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-elevated)'
        }}
      >
        <p style={{ color: 'var(--neutral-950)', marginBottom: '12px' }}>{data.team}</p>
        <p style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>
          <span style={{ fontSize: '12px', textTransform: 'uppercase', color: 'var(--neutral-600)' }}>Team Load %</span>
          <br />
          <span style={{ color: 'var(--neutral-950)' }}>{data.workload}%</span>
        </p>
        <p style={{ color: 'var(--neutral-600)', fontSize: '14px', marginBottom: '12px' }}>
          Estimated load = active WIP + deadlines + interrupt work. Above 85-90% increases slip probability sharply.
        </p>
        <p style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>Status: <span style={{ color: 'var(--neutral-950)' }}>{getWorkloadStatus(data.workload)}</span></p>
        {data.overloadedWeeks > 0 && (
          <>
            <p style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>
              <span style={{ fontSize: '12px', textTransform: 'uppercase', color: 'var(--neutral-600)' }}>Burnout Risk</span>
              <br />
              <span style={{ color: 'var(--warning-dark)' }}>High</span>
            </p>
            <p style={{ color: 'var(--neutral-600)', fontSize: '14px', marginBottom: '12px' }}>
              Burnout risk is inferred from sustained overload + after-hours activity + rapid context switching. Used to predict throughput decay.
            </p>
            <p style={{ color: 'var(--neutral-800)', marginBottom: '8px' }}>Overloaded weeks: <span style={{ color: 'var(--warning-dark)' }}>{data.overloadedWeeks}</span></p>
            <p style={{ color: 'var(--neutral-800)', marginBottom: '12px' }}>KRs impacted: <span style={{ color: 'var(--danger)' }}>{data.krsImpacted}</span></p>
          </>
        )}
        <div className="pt-3 mt-3" style={{ borderTop: '1px solid var(--neutral-200)' }}>
          <p style={{ fontSize: '12px', color: 'var(--neutral-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '4px' }}>Why it matters</p>
          <p style={{ fontSize: '14px', color: 'var(--neutral-800)', marginBottom: '8px' }}>
            {data.workload > 110 
              ? `Team is ${data.workload - 100}% over capacity. High burnout risk and quality degradation likely.` 
              : 'Team capacity is sustainable. Monitor for changes.'}
          </p>
          {data.workload > 110 && (
            <>
              <p style={{ fontSize: '12px', color: 'var(--neutral-400)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '4px' }}>Click to filter</p>
              <p style={{ fontSize: '14px', color: 'var(--brand-primary)' }}>
                Shows risks for {data.team} with Driver = Workload
              </p>
            </>
          )}
        </div>
      </div>
    );
  }
  return null;
};

export function WorkloadChart() {
  const overloadedTeams = workloadData.filter(t => t.workload > 110);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="space-y-8">
        <div>
          <DSSkeleton variant="text" width="280px" height="24px" />
          <DSSkeleton variant="text" width="400px" height="14px" style={{ marginTop: '8px' }} />
        </div>
        <div className="rounded-xl p-8" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)' }}>
          <DSSkeleton variant="rect" height="450px" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 style={{ color: 'var(--neutral-950)' }}>Workload Risk Scanning</h2>
        <p style={{ color: 'var(--neutral-600)', marginTop: '8px' }}>
          Team utilization vs capacity. Color-coded by sustainability threshold.
        </p>
      </div>

      <div 
        className="rounded-xl p-8"
        style={{ 
          backgroundColor: 'var(--bg-level-0)',
          border: '1px solid var(--neutral-200)',
          boxShadow: 'var(--shadow-card)'
        }}
      >
        <ResponsiveContainer width="100%" height={450}>
          <ComposedChart data={workloadData}>
            <CartesianGrid 
              strokeDasharray="0" 
              stroke="var(--chart-grid)" 
              vertical={false}
            />
            <XAxis 
              dataKey="team" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'var(--neutral-600)', fontSize: 14, fontWeight: 500 }}
              dy={8}
            />
            <YAxis 
              label={{ 
                value: 'Workload %', 
                angle: -90, 
                position: 'insideLeft',
                style: { fill: 'var(--neutral-600)', fontSize: 14, fontWeight: 500 }
              }}
              domain={[0, 150]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'var(--neutral-400)', fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            
            <ReferenceLine 
              y={100} 
              stroke="var(--neutral-400)" 
              strokeDasharray="4 4" 
              strokeWidth={1.5}
              label={{ 
                value: '100% Capacity', 
                position: 'right',
                fill: 'var(--neutral-400)',
                fontSize: 12,
                fontWeight: 500
              }} 
            />
            
            <Line 
              type="monotone" 
              dataKey="lastWeek" 
              stroke="var(--neutral-400)" 
              strokeWidth={2}
              strokeDasharray="6 4"
              dot={false}
            />
            
            <Bar dataKey="workload" radius={[6, 6, 0, 0]} maxBarSize={64}>
              {workloadData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={getWorkloadColorHex(entry.workload)} />
              ))}
            </Bar>
          </ComposedChart>
        </ResponsiveContainer>

        {/* Overload Callouts */}
        {overloadedTeams.length > 0 && (
          <div 
            className="mt-8 p-8 rounded-xl"
            style={{ 
              backgroundColor: 'var(--neutral-50)',
              border: '1px solid var(--neutral-200)'
            }}
          >
            <div className="flex items-start gap-4">
              <div 
                className="p-2 rounded-lg"
                style={{ backgroundColor: 'rgba(245, 166, 35, 0.1)' }}
              >
                <AlertTriangle className="size-5" style={{ color: 'var(--warning)' }} />
              </div>
              <div className="space-y-4 flex-1">
                <p style={{ 
                  fontSize: '12px', 
                  fontWeight: 500, 
                  color: 'var(--neutral-800)',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}>
                  Teams Above Capacity
                </p>
                {overloadedTeams.map((team) => (
                  <div 
                    key={team.team}
                    className="flex items-center justify-between py-3 px-4 rounded-lg"
                    style={{ 
                      backgroundColor: 'var(--bg-level-0)',
                      border: '1px solid var(--neutral-200)'
                    }}
                  >
                    <div>
                      <p style={{ 
                        fontSize: '15px', 
                        fontWeight: 500, 
                        color: 'var(--neutral-950)',
                        marginBottom: '4px'
                      }}>
                        {team.team}
                      </p>
                      <p style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>
                        Burnout risk increased by {Math.round((team.workload - 100) * 1.3)}%
                      </p>
                    </div>
                    <div className="text-right">
                      <p style={{ 
                        fontSize: '24px', 
                        fontWeight: 600, 
                        color: 'var(--danger)',
                        letterSpacing: '-0.02em'
                      }}>
                        {team.workload}%
                      </p>
                      <p style={{ fontSize: '12px', color: 'var(--neutral-400)' }}>
                        +{team.workload - 100}% over
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-8 mt-8 pt-8" style={{ borderTop: '1px solid var(--neutral-200)' }}>
          <span style={{ fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Status
          </span>
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: 'var(--success)' }}
            />
            <span style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>Healthy (&le;100%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: 'var(--warning)' }}
            />
            <span style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>Caution (100-110%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: 'var(--warning-dark)' }}
            />
            <span style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>Overload (110-130%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: 'var(--danger)' }}
            />
            <span style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>Critical (&gt;130%)</span>
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <div style={{ 
              width: '24px', 
              height: '2px', 
              borderTop: '2px dashed var(--neutral-400)'
            }} />
            <span style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Last week trend</span>
          </div>
        </div>
      </div>
    </div>
  );
}
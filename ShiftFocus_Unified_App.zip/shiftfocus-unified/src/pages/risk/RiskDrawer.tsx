import { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronRight, Zap, Users } from 'lucide-react';
import { DSDrawer, DSDrawerHeader, DSDrawerBody, DSButton, DSBadge } from './design-system';

interface RiskDrawerProps {
  risk: Record<string, unknown> | null;
  isOpen: boolean;
  onClose: () => void;
  onFixNow?: () => void;
}

const timeline = [
  { date: 'Dec 3, 2024', event: 'Risk detected by AI', type: 'detected' },
  { date: 'Dec 2, 2024', event: 'Dependency chain analysis completed', type: 'analysis' },
  { date: 'Dec 1, 2024', event: 'Engineering velocity drop observed (-28%)', type: 'signal' },
  { date: 'Nov 28, 2024', event: 'Design system update delayed', type: 'trigger' },
];

function getTimelineColor(type: string): string {
  if (type === 'detected') return 'var(--danger)';
  if (type === 'analysis') return 'var(--info)';
  if (type === 'signal') return 'var(--warning)';
  return 'var(--neutral-400)';
}

function getSeverityVariant(severity: string): 'danger' | 'warning' | 'info' {
  if (severity === 'Critical') return 'danger';
  if (severity === 'High') return 'warning';
  return 'info';
}

export function RiskDrawer({ risk, isOpen, onClose, onFixNow }: RiskDrawerProps) {
  const [showDetails, setShowDetails] = useState(false);
  if (!risk) return null;

  const severity = (risk.severity as string) || 'High';
  const owner = (risk.owner as string) || 'Unknown';
  const riskId = (risk.id as string) || '';
  const kr = (risk.kr as string) || '';
  const insight = (risk.insight as string) || '';

  return (
    <DSDrawer open={isOpen} onOpenChange={onClose} side="right" size="lg">
      <DSDrawerHeader onClose={onClose}>
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl flex-shrink-0" style={{ backgroundColor: 'rgba(229, 57, 53, 0.1)' }}>
            <AlertTriangle className="size-6" style={{ color: 'var(--danger)' }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-3 flex-wrap">
              <DSBadge variant={getSeverityVariant(severity)}>{severity}</DSBadge>
              <span style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>Owner: <span style={{ color: 'var(--neutral-950)', fontWeight: 500 }}>{owner}</span></span>
            </div>
            <h2 style={{ fontSize: '20px', lineHeight: '1.4', marginBottom: '12px', color: 'var(--neutral-950)' }}>{riskId}: {kr}</h2>
            <p style={{ fontSize: '14px', lineHeight: '1.6', color: 'var(--neutral-600)' }}>{insight}</p>
          </div>
        </div>
      </DSDrawerHeader>

      <DSDrawerBody>
        {/* Impact Summary */}
        <div className="rounded-xl p-8 mb-8" style={{ backgroundColor: 'rgba(229, 57, 53, 0.05)', border: '1px solid rgba(229, 57, 53, 0.2)' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '16px' }}>Business Impact</h3>
          <div className="grid grid-cols-2 gap-8 mb-5">
            <div>
              <div style={{ fontSize: '12px', color: 'var(--neutral-600)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Revenue at Risk</div>
              <div style={{ fontSize: '32px', fontWeight: 600, color: 'var(--danger)' }}>$2.4M</div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: 'var(--neutral-600)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Initiatives Blocked</div>
              <div style={{ fontSize: '32px', fontWeight: 600, color: 'var(--danger)' }}>8</div>
            </div>
          </div>
          <div className="pt-4" style={{ borderTop: '1px solid rgba(229, 57, 53, 0.15)' }}>
            <div style={{ fontSize: '14px', color: 'var(--neutral-800)', lineHeight: '1.6' }}>
              <strong>Root Cause:</strong> Design system update delayed → 8 downstream initiatives blocked → Engineering velocity dropped 28%
            </div>
          </div>
        </div>

        {/* Recommended Action */}
        <div className="rounded-xl p-8 mb-8" style={{ backgroundColor: 'rgba(106, 61, 232, 0.05)', border: '2px solid rgba(106, 61, 232, 0.2)' }}>
          <div className="flex items-start gap-4 mb-5">
            <Zap className="size-6 mt-0.5" style={{ color: 'var(--brand-primary)' }} />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 style={{ fontSize: '16px', fontWeight: 500, color: 'var(--neutral-950)' }}>Recommended Action</h3>
                <DSBadge variant="brand" size="sm">AI RECOMMENDED</DSBadge>
              </div>
              <p style={{ fontSize: '15px', lineHeight: '1.6', color: 'var(--neutral-800)', marginBottom: '16px' }}>Re-prioritize design system completion to Sprint N+1 as P0.</p>
              <div className="flex items-center gap-3 flex-wrap">
                <DSBadge variant="success">High Impact</DSBadge>
                <DSBadge variant="warning">Medium Effort</DSBadge>
                <span style={{ fontSize: '14px', color: 'var(--neutral-600)' }}>Est. 2 weeks</span>
              </div>
            </div>
          </div>
          <DSButton variant="primary" onClick={onFixNow} style={{ width: '100%', height: '48px', fontSize: '15px' }}>Fix Now</DSButton>
        </div>

        {/* Collapsible Details */}
        <button onClick={() => setShowDetails(!showDetails)} className="flex items-center gap-2 w-full mb-4" style={{ border: 'none', backgroundColor: 'transparent', cursor: 'pointer', padding: '12px 16px', borderRadius: '8px' }} onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-50)'; }} onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }} onFocus={(e) => { e.currentTarget.style.boxShadow = 'var(--shadow-focus)'; }} onBlur={(e) => { e.currentTarget.style.boxShadow = 'none'; }}>
          {showDetails ? <ChevronDown className="size-5" style={{ color: 'var(--neutral-600)' }} /> : <ChevronRight className="size-5" style={{ color: 'var(--neutral-600)' }} />}
          <span style={{ fontSize: '14px', color: 'var(--neutral-800)', fontWeight: 500 }}>{showDetails ? 'Hide' : 'Show'} Timeline & Alternatives</span>
        </button>

        {showDetails && (
          <div className="space-y-8 pl-4">
            <div>
              <h4 style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '16px' }}>Risk Timeline</h4>
              <div className="space-y-3">
                {timeline.map((item, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="size-2 rounded-full" style={{ backgroundColor: getTimelineColor(item.type) }} />
                      {index < timeline.length - 1 && <div className="w-px flex-1 min-h-6" style={{ backgroundColor: 'var(--neutral-200)' }} />}
                    </div>
                    <div className="flex-1 pb-2">
                      <div style={{ fontSize: '12px', color: 'var(--neutral-600)', marginBottom: '2px' }}>{item.date}</div>
                      <div style={{ fontSize: '14px', color: 'var(--neutral-800)' }}>{item.event}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '16px' }}>Alternative Actions</h4>
              <div className="rounded-lg p-5" style={{ backgroundColor: 'var(--neutral-50)', border: '1px solid var(--neutral-200)' }}>
                <div className="flex items-start gap-3">
                  <Users className="size-5 mt-0.5" style={{ color: 'var(--neutral-600)' }} />
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 500, color: 'var(--neutral-950)', marginBottom: '8px' }}>Allocate additional engineering resources</div>
                    <p style={{ fontSize: '14px', color: 'var(--neutral-600)', lineHeight: '1.5', marginBottom: '12px' }}>Assign 2 senior engineers to backend API. Run parallel integration testing.</p>
                    <div className="flex items-center gap-3 flex-wrap">
                      <DSBadge variant="success">High Impact</DSBadge>
                      <DSBadge variant="success">Low Effort</DSBadge>
                      <span style={{ fontSize: '12px', color: 'var(--neutral-600)' }}>Est. 1 week</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </DSDrawerBody>
    </DSDrawer>
  );
}

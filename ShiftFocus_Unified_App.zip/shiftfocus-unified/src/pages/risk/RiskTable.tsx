import { useState, useEffect } from 'react';
import { Eye, Network, Search } from 'lucide-react';
import React from 'react';
import {
  DSBadge,
  DSButton,
  DSTooltip,
  DSInput,
  DSSelect,
  DSSelectItem,
  DSSkeletonTable,
  DSEmptyState,
} from './design-system';

const risks = [
  { id: 'RISK-001', title: 'Engineering dependency backlog blocking mobile release', severity: 'Critical', owner: 'Sarah Chen', team: 'Engineering', impact: 'High delay risk to KR-3.1', status: 'Active', daysOpen: 12, predictedEscalation: 'Dec 10, 2025', propagationScore: 87, forecastedDelay: '6 days', krTargets: 2 },
  { id: 'RISK-002', title: 'Sales team workload exceeding capacity threshold', severity: 'Critical', owner: 'Marcus Rodriguez', team: 'Sales', impact: 'Burnout probability +18%', status: 'Escalating', daysOpen: 8, predictedEscalation: 'Dec 8, 2025', propagationScore: 92, forecastedDelay: '0 days', krTargets: 1 },
  { id: 'RISK-003', title: 'Product-Engineering roadmap misalignment detected', severity: 'High', owner: 'Alex Kim', team: 'Product', impact: 'Feature parity issues in 4 initiatives', status: 'Active', daysOpen: 5, predictedEscalation: 'Dec 12, 2025', propagationScore: 64, forecastedDelay: '3 days', krTargets: 3 },
  { id: 'RISK-004', title: 'Support team blocked by Product documentation updates', severity: 'High', owner: 'Jordan Lee', team: 'Support', impact: 'Ticket resolution time +65%', status: 'Active', daysOpen: 6, predictedEscalation: 'Dec 14, 2025', propagationScore: 58, forecastedDelay: '2 days', krTargets: 1 },
  { id: 'RISK-005', title: 'Infrastructure team capacity constrained', severity: 'High', owner: 'Taylor Morgan', team: 'Infrastructure', impact: 'Performance optimization delayed 2 sprints', status: 'Monitoring', daysOpen: 3, predictedEscalation: 'Dec 16, 2025', propagationScore: 71, forecastedDelay: '4 days', krTargets: 2 },
  { id: 'RISK-006', title: 'Marketing campaign dependencies unresolved', severity: 'Medium', owner: 'Casey Williams', team: 'Marketing', impact: 'Campaign launch delayed', status: 'Active', daysOpen: 4, predictedEscalation: 'Dec 18, 2025', propagationScore: 42, forecastedDelay: '2 days', krTargets: 1 },
  { id: 'RISK-007', title: 'Design handoff timing mismatched with dev sprint', severity: 'Medium', owner: 'Riley Park', team: 'Design', impact: 'Sprint velocity reduction', status: 'Active', daysOpen: 2, predictedEscalation: 'Dec 20, 2025', propagationScore: 38, forecastedDelay: '1 day', krTargets: 1 },
  { id: 'RISK-008', title: 'Backend API integration delays affecting mobile', severity: 'Critical', owner: 'Sarah Chen', team: 'Engineering', impact: 'Mobile app launch -3 weeks', status: 'Escalating', daysOpen: 10, predictedEscalation: 'Dec 6, 2025', propagationScore: 89, forecastedDelay: '8 days', krTargets: 2 }
];

function getSeverityVariant(severity: string): 'danger' | 'warning' | 'info' | 'neutral' {
  if (severity === 'Critical') return 'danger';
  if (severity === 'High') return 'warning';
  if (severity === 'Medium') return 'info';
  return 'neutral';
}

function getSeverityBarColor(severity: string) {
  if (severity === 'Critical') return 'var(--danger)';
  if (severity === 'High') return 'var(--warning-dark)';
  if (severity === 'Medium') return 'var(--warning)';
  return 'var(--info)';
}

function getSeverityRowBg(severity: string) {
  if (severity === 'Critical') return 'rgba(229, 57, 53, 0.04)';
  if (severity === 'High') return 'rgba(249, 139, 43, 0.04)';
  if (severity === 'Medium') return 'rgba(245, 166, 35, 0.04)';
  return 'rgba(62, 139, 255, 0.04)';
}

interface RiskTableProps {
  onRowClick: (risk: typeof risks[number]) => void;
}

export function RiskTable({ onRowClick }: RiskTableProps) {
  const [severityFilter, setSeverityFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const filteredRisks = risks.filter(risk => {
    if (severityFilter !== 'all' && risk.severity !== severityFilter) return false;
    if (searchTerm && !risk.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !risk.id.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const groupedRisks = [
    { severity: 'Critical', risks: filteredRisks.filter(r => r.severity === 'Critical') },
    { severity: 'High', risks: filteredRisks.filter(r => r.severity === 'High') },
    { severity: 'Medium', risks: filteredRisks.filter(r => r.severity === 'Medium') }
  ];

  const thStyle: React.CSSProperties = { fontSize: '12px', fontWeight: 500, color: 'var(--neutral-600)', textTransform: 'uppercase', letterSpacing: '0.01em', height: '40px' };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 style={{ color: 'var(--neutral-800)' }}>Risk Identifier</h2>
          <p style={{ color: 'var(--neutral-600)', fontSize: '14px', marginTop: '8px' }}>Active risks sorted by severity and impact</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="size-4 absolute left-3 top-1/2 -translate-y-1/2 z-10" style={{ color: 'var(--neutral-400)' }} />
            <DSInput
              placeholder="Search risks..."
              className="pl-9 w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <DSSelect
            value={severityFilter}
            onValueChange={setSeverityFilter}
            placeholder="Severity"
            triggerClassName="w-40"
          >
            <DSSelectItem value="all">All Severity</DSSelectItem>
            <DSSelectItem value="Critical">Critical</DSSelectItem>
            <DSSelectItem value="High">High</DSSelectItem>
            <DSSelectItem value="Medium">Medium</DSSelectItem>
          </DSSelect>
        </div>
      </div>

      {loading ? (
        <DSSkeletonTable rows={6} />
      ) : filteredRisks.length === 0 ? (
        <DSEmptyState
          title="No risks match your search"
          description="Try adjusting your search term or filter criteria."
          actionLabel="Clear Filters"
          onAction={() => { setSearchTerm(''); setSeverityFilter('all'); }}
        />
      ) : (
        <div className="rounded-xl overflow-hidden" style={{ backgroundColor: 'var(--bg-level-0)', border: '1px solid var(--neutral-200)', boxShadow: 'var(--shadow-card)' }}>
          <table className="w-full">
            <thead style={{ backgroundColor: 'var(--neutral-50)', borderBottom: '1px solid var(--neutral-200)' }}>
              <tr>
                <th className="text-left px-4 py-3" style={thStyle}>Risk ID</th>
                <th className="text-left px-4 py-3" style={thStyle}>Impact</th>
                <th className="text-left px-4 py-3" style={thStyle}>Severity</th>
                <th className="text-left px-4 py-3" style={thStyle}>Escalation</th>
                <th className="text-left px-4 py-3" style={thStyle}>Propagation</th>
                <th className="text-left px-4 py-3" style={thStyle}>Delay</th>
                <th className="text-left px-4 py-3" style={thStyle}>KRs</th>
                <th className="text-left px-4 py-3" style={thStyle}>Owner</th>
                <th className="text-left px-4 py-3" style={thStyle}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {groupedRisks.map((group) => (
                <React.Fragment key={group.severity}>
                  {group.risks.length > 0 && (
                    <>
                      <tr style={{ backgroundColor: getSeverityRowBg(group.severity), borderTop: '2px solid var(--neutral-200)' }}>
                        <td colSpan={9} className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="size-3 rounded-full" style={{ backgroundColor: getSeverityBarColor(group.severity) }} />
                            <span style={{ fontWeight: 500, color: 'var(--neutral-800)', fontSize: '14px' }}>{group.severity}</span>
                            <span style={{ color: 'var(--neutral-600)', fontSize: '14px' }}>({group.risks.length})</span>
                          </div>
                        </td>
                      </tr>
                      {group.risks.map((risk) => (
                        <tr
                          key={risk.id}
                          className="group transition-all duration-80 cursor-pointer relative"
                          style={{ borderBottom: '1px solid var(--neutral-200)', height: '48px' }}
                          onClick={() => onRowClick(risk)}
                          onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'var(--neutral-50)'; }}
                          onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                        >
                          <td className="py-3 px-4 relative">
                            <div className="absolute left-0 top-0 bottom-0 w-1" style={{ backgroundColor: getSeverityBarColor(risk.severity) }} />
                            <span style={{ color: 'var(--brand-primary)', fontFamily: 'monospace', fontSize: '12px', fontWeight: 500 }}>{risk.id}</span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="max-w-md">
                              <div style={{ color: 'var(--neutral-800)', fontSize: '14px', marginBottom: '4px' }}>{risk.title}</div>
                              <div style={{ color: 'var(--neutral-600)', fontSize: '12px' }}>{risk.impact}</div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <DSBadge variant={getSeverityVariant(risk.severity)} size="sm">
                              {risk.severity}
                            </DSBadge>
                          </td>
                          <td className="py-3 px-4">
                            <div style={{ color: 'var(--neutral-800)', fontSize: '12px' }}>{risk.predictedEscalation}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <div className="flex-1 rounded-full h-2 w-16" style={{ backgroundColor: 'var(--neutral-200)' }}>
                                <div className="h-2 rounded-full transition-all duration-200" style={{ width: `${risk.propagationScore}%`, backgroundColor: risk.propagationScore >= 80 ? 'var(--danger)' : risk.propagationScore >= 60 ? 'var(--warning-dark)' : 'var(--warning)' }} />
                              </div>
                              <span style={{ color: 'var(--neutral-800)', fontSize: '12px', fontWeight: 500 }}>{risk.propagationScore}%</span>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            <span style={{ fontSize: '12px', fontWeight: 500, color: parseInt(risk.forecastedDelay) >= 5 ? 'var(--danger)' : parseInt(risk.forecastedDelay) >= 2 ? 'var(--warning-dark)' : 'var(--neutral-600)' }}>
                              {risk.forecastedDelay}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <DSBadge variant="neutral" size="sm">{risk.krTargets} KRs</DSBadge>
                          </td>
                          <td className="py-3 px-4">
                            <div style={{ color: 'var(--neutral-800)', fontSize: '14px' }}>{risk.owner}</div>
                            <div style={{ color: 'var(--neutral-600)', fontSize: '12px' }}>{risk.team}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-120">
                              <DSButton variant="secondary" size="sm" onClick={(e) => { e.stopPropagation(); onRowClick(risk); }}>
                                <Eye className="size-3" /> View
                              </DSButton>
                              <DSTooltip content="Show in Network Graph">
                                <DSButton variant="secondary" size="sm" onClick={(e) => e.stopPropagation()} style={{ width: '32px', padding: 0 }}>
                                  <Network className="size-3" />
                                </DSButton>
                              </DSTooltip>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
interface TabNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'overview', label: 'Overview' },
  { id: 'forecast', label: 'Forecast & Scenarios' }
];

export function TabNavigation({ activeTab, onTabChange }: TabNavigationProps) {
  return (
    <div className="mb-8" style={{ borderBottom: '1px solid var(--neutral-200)' }}>
      <div className="flex gap-1 -mb-px">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className="px-8 py-3 rounded-t-lg transition-all duration-120"
            style={
              activeTab === tab.id
                ? {
                    backgroundColor: 'var(--bg-level-0)',
                    borderTop: '2px solid var(--brand-primary)',
                    borderLeft: '1px solid var(--neutral-200)',
                    borderRight: '1px solid var(--neutral-200)',
                    borderBottom: 'none',
                    color: 'var(--neutral-800)',
                    fontWeight: 500,
                    fontSize: '14px',
                    boxShadow: 'var(--shadow-card)',
                    cursor: 'pointer',
                    outline: 'none'
                  }
                : {
                    backgroundColor: 'transparent',
                    border: 'none',
                    color: 'var(--neutral-600)',
                    fontWeight: 400,
                    fontSize: '14px',
                    cursor: 'pointer',
                    outline: 'none'
                  }
            }
            onMouseEnter={(e) => {
              if (activeTab !== tab.id) {
                e.currentTarget.style.color = 'var(--neutral-800)';
                e.currentTarget.style.backgroundColor = 'var(--neutral-50)';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== tab.id) {
                e.currentTarget.style.color = 'var(--neutral-600)';
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
            onFocus={(e) => {
              e.currentTarget.style.boxShadow = 'var(--shadow-focus)';
            }}
            onBlur={(e) => {
              e.currentTarget.style.boxShadow = activeTab === tab.id ? 'var(--shadow-card)' : 'none';
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}
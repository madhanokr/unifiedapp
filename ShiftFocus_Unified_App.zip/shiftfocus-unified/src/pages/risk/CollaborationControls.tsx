import { Share2, Download, Bell } from 'lucide-react';
import {
  DSButton,
  DSDropdownMenu,
  DSDropdownMenuTrigger,
  DSDropdownMenuContent,
  DSDropdownMenuItem,
  sfToast,
} from './design-system';

export function CollaborationControls() {
  return (
    <div className="flex items-center gap-2">
      <DSDropdownMenu>
        <DSDropdownMenuTrigger asChild>
          <DSButton variant="secondary" size="md">
            <Share2 className="size-4" />
            Share Risk Report
          </DSButton>
        </DSDropdownMenuTrigger>
        <DSDropdownMenuContent align="end">
          <DSDropdownMenuItem onSelect={() => sfToast.info('Email share', 'Opening email composer...')}>
            Share via Email
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.success('Link copied to clipboard')}>
            Copy Share Link
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.info('Slack', 'Opening Slack channel picker...')}>
            Share to Slack
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.info('Teams', 'Opening Teams channel picker...')}>
            Share to Teams
          </DSDropdownMenuItem>
        </DSDropdownMenuContent>
      </DSDropdownMenu>

      <DSDropdownMenu>
        <DSDropdownMenuTrigger asChild>
          <DSButton variant="secondary" size="md">
            <Download className="size-4" />
            Export as PDF
          </DSButton>
        </DSDropdownMenuTrigger>
        <DSDropdownMenuContent align="end">
          <DSDropdownMenuItem onSelect={() => sfToast.success('Export started', 'Summary PDF will download shortly')}>
            Export Summary
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.success('Export started', 'Full report PDF will download shortly')}>
            Export Full Report
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.success('Export started', 'Report with forecasts will download shortly')}>
            Export with Forecasts
          </DSDropdownMenuItem>
          <DSDropdownMenuItem onSelect={() => sfToast.info('Custom Export', 'Opening export configuration...')}>
            Custom Export...
          </DSDropdownMenuItem>
        </DSDropdownMenuContent>
      </DSDropdownMenu>

      <DSButton
        variant="secondary"
        size="md"
        onClick={() => sfToast.success('Team leads notified', 'All team leads have been sent a notification with current risk summary')}
      >
        <Bell className="size-4" />
        Notify Team Leads
      </DSButton>
    </div>
  );
}

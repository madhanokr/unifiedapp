import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Zap, Target, AlertCircle } from 'lucide-react';
import { DSCard, DSTooltip, DSSkeletonStats } from './design-system';

interface StatCard {
  id: string;
  metric: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down';
  icon: React.ElementType;
  color: 'red' | 'orange' | 'purple' | 'blue';
  whyItMatters: string;
  whatHappensIfIgnored: string;
  slaWarning?: string;
  filter: {
    type: string;
    value: string | boolean;
  };
}

interface ExecutiveRiskSummaryProps {
  onFilterApply: (filter: { type: string; value: string | boolean }) => void;
}

const colorMap = {
  red: { text: 'var(--danger)', icon: 'var(--danger)' },
  orange: { text: 'var(--warning-dark)', icon: 'var(--warning-dark)' },
  purple: { text: 'var(--brand-primary)', icon: 'var(--brand-primary)' },
  blue: { text: 'var(--info)', icon: 'var(--info)' },
};

export function ExecutiveRiskSummary({ onFilterApply }: ExecutiveRiskSummaryProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const statCards: StatCard[] = [
    { id: 'critical', metric: 'Critical Risks', value: '7', change: '+2 from last week', trend: 'up', icon: AlertTriangle, color: 'red', whyItMatters: 'Critical risks are items that can miss a board-facing outcome unless intervened.', whatHappensIfIgnored: 'Will trigger automatic escalation to executives.', slaWarning: '2 are already past SLA', filter: { type: 'severity', value: 'Critical' } },
    { id: 'high-priority', metric: 'High Priority', value: '12', change: '+3 this week', trend: 'up', icon: AlertCircle, color: 'orange', whyItMatters: 'High priority risks are important but not yet board-critical.', whatHappensIfIgnored: '3 risks will escalate to Critical by Dec 28.', filter: { type: 'severity', value: 'High' } },
    { id: 'medium', metric: 'Medium Risks', value: '18', change: '-2 from last week', trend: 'down', icon: Target, color: 'purple', whyItMatters: 'Medium risks are early signals. Cheap to fix now, expensive later.', whatHappensIfIgnored: 'May escalate to High within 7-14 days.', filter: { type: 'severity', value: 'Medium' } },
    { id: 'velocity', metric: 'Delivery Velocity', value: '+23%', change: 'vs last week', trend: 'up', icon: Zap, color: 'purple', whyItMatters: 'Velocity = completed vs planned work. High velocity can still hide risk.', whatHappensIfIgnored: '3 teams showing high velocity but also high dependency load.', filter: { type: 'status', value: 'Escalating' } },
    { id: 'impact-map', metric: 'Impact Map', value: '24', change: 'cross-team risks', trend: 'up', icon: Target, color: 'blue', whyItMatters: 'Impact Map shows how many teams and outcomes a risk touches.', whatHappensIfIgnored: 'Cross-team risks have 3.2x higher failure rate.', filter: { type: 'hasKRs', value: true } },
  ];

  const TrendIcon = (trend?: 'up' | 'down') => {
    if (trend === 'up') return TrendingUp;
    if (trend === 'down') return TrendingDown;
    return null;
  };

  return (
    <div>
      <div className="mb-8">
        <p style={{ color: 'var(--neutral-600)', fontSize: '12px', letterSpacing: '0.05em', textTransform: 'uppercase', fontWeight: 500, marginBottom: '16px' }}>
          Executive Summary
        </p>
        <p style={{ color: 'var(--neutral-600)', fontSize: '14px', lineHeight: '1.6' }}>
          Start here: Top risks ranked by likelihood x impact x time pressure.
        </p>
      </div>

      {loading ? (
        <DSSkeletonStats count={5} />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {statCards.map((card) => {
            const colors = colorMap[card.color];
            const IconComponent = card.icon;
            const TrendIconComponent = TrendIcon(card.trend);

            return (
              <DSTooltip
                key={card.id}
                content={
                  <div className="space-y-3">
                    <div>
                      <div style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--tooltip-muted)', marginBottom: '4px' }}>
                        {card.metric}
                      </div>
                      <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--tooltip-text)' }}>
                        {card.whyItMatters}
                      </p>
                    </div>
                    <div className="pt-2" style={{ borderTop: '1px solid var(--tooltip-divider)' }}>
                      <div style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--tooltip-muted)', marginBottom: '4px' }}>
                        What happens if ignored
                      </div>
                      <p style={{ fontSize: '14px', lineHeight: '1.5', color: 'var(--danger-light)' }}>
                        {card.whatHappensIfIgnored}
                      </p>
                    </div>
                    <div className="pt-2" style={{ borderTop: '1px solid var(--tooltip-divider)' }}>
                      <p style={{ fontSize: '12px', color: 'var(--tooltip-muted)', fontStyle: 'italic' }}>
                        Click to filter risk queue
                      </p>
                    </div>
                  </div>
                }
                side="bottom"
              >
                <DSCard
                  hoverable
                  onClick={() => onFilterApply(card.filter)}
                  style={{ cursor: 'pointer' }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <IconComponent className="size-5" style={{ color: colors.icon }} />
                    {TrendIconComponent && (
                      <TrendIconComponent className="size-4" style={{ color: colors.icon }} />
                    )}
                  </div>
                  <div style={{ fontSize: '36px', fontWeight: 600, color: colors.text, marginBottom: '8px', letterSpacing: '-0.02em' }}>
                    {card.value}
                  </div>
                  <div style={{ color: 'var(--neutral-800)', fontSize: '14px', marginBottom: '4px', fontWeight: 500 }}>
                    {card.metric}
                  </div>
                  {card.change && (
                    <div style={{ color: 'var(--neutral-400)', fontSize: '12px', marginBottom: '8px' }}>
                      {card.change}
                    </div>
                  )}
                  {card.slaWarning && (
                    <div className="px-2 py-1 rounded-md mt-3" style={{ backgroundColor: 'var(--danger-light)', fontSize: '12px', color: 'var(--danger)', fontWeight: 500 }}>
                      {card.slaWarning}
                    </div>
                  )}
                </DSCard>
              </DSTooltip>
            );
          })}
        </div>
      )}
    </div>
  );
}

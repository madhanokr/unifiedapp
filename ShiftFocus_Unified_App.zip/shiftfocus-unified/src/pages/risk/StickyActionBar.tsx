interface StickyActionBarProps {
  criticalRisksCount: number;
}

export function StickyActionBar({
  criticalRisksCount = 0
}: StickyActionBarProps) {
  // Intentionally renders null — slot reserved for future sticky bar feature
  return null;
}
